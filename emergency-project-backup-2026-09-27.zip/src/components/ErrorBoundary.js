const _jsxFileName = "src/components/ErrorBoundary.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React from 'react';
import { Button } from './ui/button.js';
import { AlertCircle, RefreshCw } from 'lucide-react';

/**
 * ErrorBoundary — catches uncaught errors in the React tree and shows
 * a user-friendly fallback UI with a "Retry" button instead of a white screen.
 */
export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);ErrorBoundary.prototype.__init.call(this);;
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught:', error, errorInfo);
  }

  __init() {this.handleRetry = () => {
    this.setState({ hasError: false, error: null });
    window.location.href = window.location.pathname;
  }}

  render() {
    if (this.state.hasError) {
      return (
        _jsxDEV('div', { className: "min-h-screen flex items-center justify-center bg-background p-4"     , dir: "rtl", children: 
          _jsxDEV('div', { className: "max-w-md w-full text-center space-y-4"   , children: [
            _jsxDEV('div', { className: "flex justify-center" , children: 
              _jsxDEV(AlertCircle, { className: "w-16 h-16 text-destructive"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 34}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 33}, this)
            , _jsxDEV('h1', { className: "text-xl font-bold" , children: "خطایی رخ داد"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this)
            , _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "یک خطای پیش‌بینی‌نشده در برنامه رخ داد. لطفاً دوباره تلاش کنید."

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this)
            , _optionalChain([this, 'access', _ => _.state, 'access', _2 => _2.error, 'optionalAccess', _3 => _3.message]) && (
              _jsxDEV('p', { className: "text-xs text-muted-foreground/70 bg-muted rounded-md p-2 font-mono break-all"      , children: 
                this.state.error.message
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this)
            )
            , _jsxDEV(Button, { onClick: this.handleRetry, className: "w-full", children: [
              _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this ), "تلاش مجدد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 45}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 32}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 31}, this)
      );
    }
    return this.props.children;
  }
}