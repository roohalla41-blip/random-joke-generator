const _jsxFileName = "src/components/CustomerLayout.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext.js';
import { Button } from './ui/button.js';
import { loadNotifications } from '../lib/notificationsMockData.js';
import {
  Home, Wallet, Smartphone, Gamepad2, Send, Landmark,
  Package, MessageSquare, Coins, LogOut, Bell, LifeBuoy, MoreHorizontal, X
} from 'lucide-react';
import ExchangeMark from './ExchangeMark.js';
import TermsGate from './TermsGate.js';

const NAV_ITEMS = [
  { path: '/customer', label: 'خانه', icon: Home, exact: true },
  { path: '/customer/wallet', label: 'کیف پول', icon: Wallet },
  { path: '/customer/recharge', label: 'شارژ', icon: Smartphone },
  { path: '/customer/games', label: 'بازی‌ها', icon: Gamepad2 },
  { path: '/customer/transfer', label: 'ارسال پول', icon: Send },
  { path: '/customer/account', label: 'حساب من', icon: Landmark },
  { path: '/customer/orders', label: 'سفارش‌ها', icon: Package },
  { path: '/customer/messages', label: 'پیام‌ها', icon: MessageSquare },
  { path: '/customer/support', label: 'پشتیبانی', icon: LifeBuoy },
];

export default function CustomerLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();
  const [unreadCount, setUnreadCount] = useState(0);
  const [moreOpen, setMoreOpen] = useState(false);

  useEffect(() => {
    let mounted = true;
    loadNotifications(_optionalChain([user, 'optionalAccess', _ => _.id])).then((list) => {
      if (mounted) setUnreadCount(list.filter((n) => !n.read).length);
    }).catch((err) => console.error('Failed to load notifications:', err.message));
    return () => { mounted = false; };
  }, [location.pathname]);

  const isActive = (item) => {
    if (item.exact) return location.pathname === item.path;
    return location.pathname === item.path || location.pathname.startsWith(item.path + '/');
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const renderNavButton = (item) => {
    const Icon = item.icon;
    const active = isActive(item);
    return (
      _jsxDEV('button', {

      onClick: () => navigate(item.path),
      className: `flex flex-col items-center gap-1 px-2 pt-2 pb-1 rounded-lg transition-colors min-w-0 flex-1 ${
          active
            ? 'text-primary bg-primary/10'
            : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
        }`,
 children: [
        _jsxDEV(Icon, { className: "w-5 h-5 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this )
        , _jsxDEV('span', { className: "text-[10px] font-medium truncate"  , children: item.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
      ]}, item.path, true, {fileName: _jsxFileName, lineNumber: 54}, this)
    );
  };

  return (
    _jsxDEV(TermsGate, { role: "customer", children: 
    _jsxDEV('div', { className: "min-h-screen bg-background" , dir: "rtl", children: [
      /* Header */
      _jsxDEV('header', { className: "sticky top-0 z-50 bg-card/95 backdrop-blur border-b border-border shadow-sm"       , children: 
        _jsxDEV('div', { className: "max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-2"       , children: [
          _jsxDEV('div', { className: "flex items-center gap-2 min-w-0"   , children: [
            _jsxDEV('div', { className: "shrink-0", children: 
              _jsxDEV(ExchangeMark, { size: "sm",}, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)
            , _jsxDEV('div', { className: "min-w-0", children: [
              _jsxDEV('p', { className: "font-bold text-sm text-foreground truncate"   , children: _optionalChain([user, 'optionalAccess', _2 => _2.full_name]) || 'پنل مشتری'}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)
              , _jsxDEV('p', { className: "text-[10px] text-muted-foreground truncate"  , children: "حساب صراف" }, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 79}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 75}, this)
          , _jsxDEV('div', { className: "flex items-center gap-1.5 shrink-0"   , children: [
            _jsxDEV(Button, { variant: "ghost", size: "icon", className: "h-8 w-8 relative"  , onClick: () => navigate('/customer/notifications'), children: [
              _jsxDEV(Bell, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this )
              , unreadCount > 0 && (
                _jsxDEV('span', { className: "absolute -top-0.5 -right-0.5 inline-flex items-center justify-center min-w-[15px] h-[15px] px-1 rounded-full bg-destructive text-destructive-foreground text-[8px] font-bold"             , children: 
                  unreadCount
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 85}, this)
            , _jsxDEV(Button, { variant: "ghost", size: "icon", onClick: handleLogout, className: "h-8 w-8" , children: 
              _jsxDEV(LogOut, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 84}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 74}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)

      /* Desktop Layout */
      , _jsxDEV('div', { className: "max-w-5xl mx-auto flex gap-4 px-4 py-4"     , children: [
        /* Desktop Sidebar */
        _jsxDEV('aside', { className: "hidden md:block w-44 shrink-0"   , children: 
          _jsxDEV('nav', { className: "sticky top-20 space-y-1 bg-card border border-border rounded-xl p-2"       , children: 
            NAV_ITEMS.map(item => {
              const Icon = item.icon;
              const active = isActive(item);
              return (
                _jsxDEV('button', {

                  onClick: () => navigate(item.path),
                  className: `flex items-center gap-2.5 w-full px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    active
                      ? 'text-primary bg-primary/10'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`,
 children: [
                  _jsxDEV(Icon, { className: "w-4.5 h-4.5 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this )
                  , _jsxDEV('span', { className: "truncate", children: item.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this)
                ]}, item.path, true, {fileName: _jsxFileName, lineNumber: 109}, this)
              );
            })
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this)

        /* Content */
        , _jsxDEV('main', { className: "flex-1 min-w-0 pb-36 md:pb-16"   , children: 
          _jsxDEV(Outlet, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 128}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 101}, this)

      /* Mobile Bottom Navigation — 4 items + More button */
      , _jsxDEV('nav', { className: "fixed bottom-0 left-0 right-0 z-50 bg-card/95 backdrop-blur border-t border-border shadow-lg md:hidden"          , children: 
        _jsxDEV('div', {
          className: "flex items-stretch justify-around px-1 py-1"    ,
          style: { paddingBottom: 'env(safe-area-inset-bottom)' },
 children: [
          NAV_ITEMS.slice(0, 4).map(renderNavButton)
          , _jsxDEV('button', {
            onClick: () => setMoreOpen(true),
            className: `flex flex-col items-center gap-1 px-2 pt-2 pb-1 rounded-lg transition-colors min-w-0 flex-1 ${
              moreOpen
                ? 'text-primary bg-primary/10'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
            }`,
 children: [
            _jsxDEV(MoreHorizontal, { className: "w-5 h-5 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this )
            , _jsxDEV('span', { className: "text-[10px] font-medium truncate"  , children: "بیشتر"}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 139}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 134}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 133}, this)

      /* More Menu Drawer */
      , moreOpen && (
        _jsxDEV('div', { className: "md:hidden fixed inset-0 z-50 bg-black/50"    , onClick: () => setMoreOpen(false), children: 
          _jsxDEV('div', { className: "absolute bottom-0 left-0 right-0 bg-card rounded-t-2xl shadow-xl p-4"       , onClick: e => e.stopPropagation(), children: [
            _jsxDEV('div', { className: "flex items-center justify-between mb-3"   , children: [
              _jsxDEV('h3', { className: "font-bold text-sm" , children: "بیشتر"}, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this)
              , _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => setMoreOpen(false), className: "h-7 w-7 p-0"  , children: 
                _jsxDEV(X, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 157}, this)
            , _jsxDEV('div', { className: "grid grid-cols-3 gap-2"  , children: [
              NAV_ITEMS.slice(4).map(item => {
                const Icon = item.icon;
                const active = isActive(item);
                return (
                  _jsxDEV('button', {

                    onClick: () => { navigate(item.path); setMoreOpen(false); },
                    className: `flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-colors ${
                      active ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground hover:bg-muted'
                    }`,
 children: [
                    _jsxDEV(Icon, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 175}, this )
                    , _jsxDEV('span', { className: "text-[10px] font-medium" , children: item.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 176}, this)
                  ]}, item.path, true, {fileName: _jsxFileName, lineNumber: 168}, this)
                );
              })
              , _jsxDEV('button', {
                onClick: handleLogout,
                className: "flex flex-col items-center gap-1.5 p-3 rounded-xl border border-destructive/30 text-destructive hover:bg-destructive/5 transition-colors"          ,
 children: [
                _jsxDEV(LogOut, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 184}, this )
                , _jsxDEV('span', { className: "text-[10px] font-medium" , children: "خروج"}, void 0, false, {fileName: _jsxFileName, lineNumber: 185}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 180}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 163}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 156}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 155}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 71}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)
  );
}