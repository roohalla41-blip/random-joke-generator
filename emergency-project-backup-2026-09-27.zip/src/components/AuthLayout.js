const _jsxFileName = "src/components/AuthLayout.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from "react";

export default function AuthLayout({ icon: Icon, title, subtitle, footer, children }) {
  return (
    _jsxDEV('div', { className: "min-h-screen flex items-center justify-center bg-background px-4"     , children: 
      _jsxDEV('div', { className: "w-full max-w-md" , children: [
        _jsxDEV('div', { className: "text-center mb-10" , children: [
          _jsxDEV('div', { className: "inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary mb-4"       , children: 
            _jsxDEV(Icon, { className: "w-7 h-7 text-primary-foreground"  , 'aria-hidden': "true",}, void 0, false, {fileName: _jsxFileName, lineNumber: 9}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 8}, this)
          , _jsxDEV('h1', { className: "text-3xl font-bold tracking-tight text-foreground"   , children: title}, void 0, false, {fileName: _jsxFileName, lineNumber: 11}, this)
          , subtitle && _jsxDEV('p', { className: "text-muted-foreground mt-2" , children: subtitle}, void 0, false, {fileName: _jsxFileName, lineNumber: 12}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 7}, this)
        , _jsxDEV('div', { className: "bg-card rounded-2xl shadow-sm border border-border p-8"     , children: 
          children
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 14}, this)
        , footer && (
          _jsxDEV('p', { className: "text-center text-sm text-muted-foreground mt-6"   , children: footer}, void 0, false, {fileName: _jsxFileName, lineNumber: 18}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 6}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 5}, this)
  );
}
