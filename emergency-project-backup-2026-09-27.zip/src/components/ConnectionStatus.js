const _jsxFileName = "src/components/ConnectionStatus.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { getPendingCount, onSyncStatusChange, isSyncing } from '../lib/offlineQueue.js';
import { Wifi, WifiOff, Cloud, CloudOff, Loader2, RefreshCw, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '../lib/i18n.js';

export default function ConnectionStatus({ compact }) {
  const { lang } = useLanguage();
  const [online, setOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [serverConnected, setServerConnected] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [pendingSync, setPendingSync] = useState(0);
  const [syncing, setSyncing] = useState(isSyncing());
  const [justSynced, setJustSynced] = useState(false);

  const checkServer = async () => {
    setServerConnected(typeof navigator !== 'undefined' ? navigator.onLine : true);
  };

  useEffect(() => {
    const handleOnline = () => { setOnline(true); checkServer(); };
    const handleOffline = () => { setOnline(false); setServerConnected(false); };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    checkServer();
    const interval = setInterval(checkServer, 30000);
    setPendingSync(getPendingCount());

    // Subscribe to sync status changes
    const unsub = onSyncStatusChange(({ syncing: s, pending }) => {
      setSyncing(s);
      setPendingSync(pending);
      if (!s && pending === 0 && justSynced === false) {
        setJustSynced(true);
        setTimeout(() => setJustSynced(false), 3000);
      }
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
      unsub();
    };
  }, []);

  const isFullyOnline = online && serverConnected === true;
  const isChecking = serverConnected === null;

  const label = syncing
    ? (lang === 'english' ? 'Syncing...' : 'در حال همگام‌سازی...')
    : justSynced
    ? (lang === 'english' ? 'Synced' : 'همگام‌سازی کامل')
    : isChecking
    ? (lang === 'english' ? 'Checking...' : 'در حال بررسی...')
    : isFullyOnline
    ? (lang === 'english' ? 'Online' : 'آنلاین')
    : (lang === 'english' ? 'Offline' : 'آفلاین');

  const icon = syncing
    ? _jsxDEV(RefreshCw, { className: `${compact ? "w-3.5 h-3.5" : "w-4 h-4"} animate-spin`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this )
    : justSynced
    ? _jsxDEV(CheckCircle2, { className: compact ? "w-3.5 h-3.5" : "w-4 h-4",}, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this )
    : isChecking
    ? _jsxDEV(Loader2, { className: `${compact ? "w-3.5 h-3.5" : "w-4 h-4"} animate-spin`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this )
    : isFullyOnline
    ? (compact ? _jsxDEV(Wifi, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this ) : _jsxDEV(Cloud, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this ))
    : (compact ? _jsxDEV(WifiOff, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this ) : _jsxDEV(CloudOff, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this ));

  const colorClass = syncing
    ? 'bg-primary/10 text-primary'
    : justSynced
    ? 'bg-success/10 text-success'
    : isFullyOnline
    ? 'bg-success/10 text-success'
    : 'bg-destructive/10 text-destructive';

  if (compact) {
    return (
      _jsxDEV('div', { className: `flex items-center gap-1.5 px-2 py-1 rounded-lg text-xs font-medium ${colorClass}`, children: [
        icon
        , _jsxDEV('span', { children: label}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)
        , !isFullyOnline && !syncing && pendingSync > 0 && (
          _jsxDEV('span', { className: "bg-warning/20 text-warning px-1.5 rounded-full text-[10px]"    , children: pendingSync}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 78}, this)
    );
  }

  return (
    _jsxDEV('div', { className: `flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium border ${colorClass} ${
      syncing ? 'border-primary/20' : justSynced ? 'border-success/20' : isFullyOnline ? 'border-success/20' : 'border-destructive/20'
    }`, children: [
      icon
      , _jsxDEV('span', { children: label}, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this)
      , !isFullyOnline && !syncing && pendingSync > 0 && (
        _jsxDEV('span', { className: "bg-warning/20 text-warning px-1.5 rounded-full text-[10px]"    , children: [
          pendingSync, " " , lang === 'english' ? 'pending' : 'در انتظار'
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 89}, this)
  );
}