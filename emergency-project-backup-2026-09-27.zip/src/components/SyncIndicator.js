const _jsxFileName = "src/components/SyncIndicator.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { subscribe, getState } from '../lib/syncStatus.js';
import { syncPendingWrites } from '../lib/offlineQueue.js';
import { CloudOff, Cloud, Loader2, RefreshCw } from 'lucide-react';

export default function SyncIndicator({ compact = false }) {
  const [state, setState] = useState(getState());

  useEffect(() => {
    return subscribe(setState);
  }, []);

  const iconClass = "w-3.5 h-3.5";
  const wrapClass = "flex items-center gap-1.5 text-xs";

  if (state.syncing) {
    return (
      _jsxDEV('div', { className: compact ? "w-7 h-7 rounded-lg bg-sky-500/90 flex items-center justify-center text-white" : wrapClass + " text-warning", children: [
        _jsxDEV(Loader2, { className: iconClass + " animate-spin",}, void 0, false, {fileName: _jsxFileName, lineNumber: 19}, this )
        , !compact && _jsxDEV('span', { children: "در حال همگام‌سازی..."  }, void 0, false, {fileName: _jsxFileName, lineNumber: 20}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 18}, this)
    );
  }

  if (state.pendingCount > 0) {
    return (
      _jsxDEV('button', {
        onClick: () => syncPendingWrites(),
        className: compact ? "w-7 h-7 rounded-lg bg-amber-500/90 hover:bg-amber-500 flex items-center justify-center text-white transition-colors" : wrapClass + " text-warning hover:text-warning/80",
 children: [
        _jsxDEV(RefreshCw, { className: iconClass,}, void 0, false, {fileName: _jsxFileName, lineNumber: 31}, this )
        , !compact && _jsxDEV('span', { children: [state.pendingCount, " در انتظار همگام‌سازی"   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 32}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 27}, this)
    );
  }

  if (!state.isOnline) {
    return (
      _jsxDEV('div', { className: compact ? "w-7 h-7 rounded-lg bg-rose-500/90 flex items-center justify-center text-white" : wrapClass + " text-destructive", children: [
        _jsxDEV(CloudOff, { className: iconClass,}, void 0, false, {fileName: _jsxFileName, lineNumber: 40}, this )
        , !compact && _jsxDEV('span', { children: "آفلاین"}, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 39}, this)
    );
  }

  return (
    _jsxDEV('div', { className: compact ? "w-7 h-7 rounded-lg bg-emerald-500/90 flex items-center justify-center text-white" : wrapClass + " text-success", children: [
      _jsxDEV(Cloud, { className: iconClass,}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this )
      , !compact && _jsxDEV('span', { children: "آنلاین"}, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 47}, this)
  );
}