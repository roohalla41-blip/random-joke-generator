const _jsxFileName = "src/components/chat/MessageBubble.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React from 'react';
import RoleBadge from './RoleBadge.js';
import { getRoleDisplay } from '../../lib/chat.js';
import { CloudOff, Check, Trash2, Flag } from 'lucide-react';
import { useAuth } from '../../lib/AuthContext.js';

function formatTime(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  return d.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
}

export default function MessageBubble({ message, onDelete, onReport, showActions }) {
  const { user } = useAuth();
  const isMine = message.sender_id === _optionalChain([user, 'optionalAccess', _ => _.id]);
  const display = getRoleDisplay(message.sender_role);

  return (
    _jsxDEV('div', { className: `flex ${isMine ? 'justify-end' : 'justify-start'}`, children: 
      _jsxDEV('div', { className: `max-w-[80%] ${isMine ? 'items-end' : 'items-start'} flex flex-col gap-0.5`, children: [
        !isMine && (
          _jsxDEV('div', { className: "flex items-center gap-1.5 px-1"   , children: [
            _jsxDEV('span', { className: "text-[10px] font-medium text-foreground"  , children: message.sender_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 23}, this)
            , _jsxDEV(RoleBadge, { userRole: message.sender_role === 'admin' ? 'admin' : (message.sender_role === 'customer' ? 'customer' : 'user'),}, void 0, false, {fileName: _jsxFileName, lineNumber: 24}, this )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 22}, this)
        )
        , _jsxDEV('div', {
          className: `relative rounded-2xl px-3 py-2 ${
            isMine
              ? 'bg-primary text-primary-foreground rounded-br-sm'
              : 'bg-muted text-foreground rounded-bl-sm'
          }`,
 children: [
          _jsxDEV('p', { className: "text-sm whitespace-pre-wrap break-words"  , children: message.message}, void 0, false, {fileName: _jsxFileName, lineNumber: 34}, this)
          , _jsxDEV('div', { className: "flex items-center gap-1 mt-0.5"   , children: [
            _jsxDEV('span', { className: `text-[9px] ${isMine ? 'text-primary-foreground/70' : 'text-muted-foreground'}`, children: 
              formatTime(message.created_date)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this)
            , message.sync_status === 'pending' && (
              _jsxDEV(CloudOff, { className: "w-3 h-3 text-warning"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 40}, this )
            )
            , message.sync_status === 'synced' && isMine && (
              _jsxDEV(Check, { className: "w-3 h-3 opacity-50"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this )
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 35}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 27}, this)
        , showActions && (
          _jsxDEV('div', { className: "flex items-center gap-1 px-1"   , children: [
            onDelete && (
              _jsxDEV('button', {
                onClick: () => onDelete(message),
                className: "text-[9px] text-destructive hover:underline flex items-center gap-0.5"     ,
 children: [
                _jsxDEV(Trash2, { className: "w-2.5 h-2.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 54}, this ), "حذف"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 50}, this)
            )
            , onReport && !isMine && (
              _jsxDEV('button', {
                onClick: () => onReport(message),
                className: "text-[9px] text-muted-foreground hover:underline flex items-center gap-0.5"     ,
 children: [
                _jsxDEV(Flag, { className: "w-2.5 h-2.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this ), "گزارش"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 59}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 48}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 20}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 19}, this)
  );
}