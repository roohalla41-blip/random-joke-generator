const _jsxFileName = "src/components/chat/GroupCard.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '../ui/card.js';
import { getGroupTypeDisplay } from '../../lib/chat.js';
import { Users, Lock, Globe, MessageSquare, Clock, Crown } from 'lucide-react';
import { formatNumber } from '../../lib/sarraaf.js';

function formatTime(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const now = new Date();
  const diff = (now - d) / 1000;
  if (diff < 60) return 'هم‌اکنون';
  if (diff < 3600) return `${Math.floor(diff / 60)} دقیقه پیش`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} ساعت پیش`;
  return d.toLocaleDateString('fa-IR');
}

export default function GroupCard({ group, lastMessage, to }) {
  const typeDisplay = getGroupTypeDisplay(group.type);
  const isCreatorManaged = group.creator_managed === true;

  return (
    _jsxDEV(Link, { to: to, children: 
      _jsxDEV(Card, { className: "hover:shadow-md transition-shadow cursor-pointer"  , children: 
        _jsxDEV(CardContent, { className: "p-3", children: 
          _jsxDEV('div', { className: "flex items-center gap-3"  , children: [
            /* Group Image / Icon */
            _jsxDEV('div', { className: `w-12 h-12 rounded-xl flex items-center justify-center shrink-0 overflow-hidden ${isCreatorManaged ? 'bg-gradient-to-br from-primary/30 to-primary/10' : 'bg-gradient-to-br from-primary/20 to-primary/5'}`, children: 
              group.image ? (
                _jsxDEV('img', { src: group.image, alt: group.name, className: "w-full h-full object-cover"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 31}, this )
              ) : isCreatorManaged ? (
                _jsxDEV(Crown, { className: "w-6 h-6 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 33}, this )
              ) : group.type === 'private' ? (
                _jsxDEV(Lock, { className: "w-6 h-6 text-purple-500"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 35}, this )
              ) : (
                _jsxDEV(Globe, { className: "w-6 h-6 text-green-500"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this )
              )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 29}, this)

            /* Info */
            , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
              _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                _jsxDEV('h3', { className: "font-bold text-sm truncate"  , children: group.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 44}, this)
                , isCreatorManaged && (
                  _jsxDEV('span', { className: "text-[9px] px-1.5 py-0.5 rounded-full font-medium bg-primary/10 text-primary flex items-center gap-0.5 shrink-0"          , children: [
                    _jsxDEV(Crown, { className: "w-2.5 h-2.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 47}, this ), "سیستمی"

                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 46}, this)
                )
                , _jsxDEV('span', { className: `text-[9px] px-1.5 py-0.5 rounded-full font-medium ${typeDisplay.bg} ${typeDisplay.color} shrink-0`, children: 
                  typeDisplay.label
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 51}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 43}, this)
              , group.description && (
                _jsxDEV('p', { className: "text-xs text-muted-foreground truncate mt-0.5"   , children: group.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
              )
              , _jsxDEV('div', { className: "flex items-center gap-3 mt-1"   , children: [
                _jsxDEV('span', { className: "flex items-center gap-0.5 text-[10px] text-muted-foreground"    , children: [
                  _jsxDEV(Users, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this )
                  , formatNumber(group.member_count || 0)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 59}, this)
                , group.creator_name && !isCreatorManaged && (
                  _jsxDEV('span', { className: "text-[10px] text-muted-foreground truncate"  , children: 
                    group.creator_name
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
                )
                , lastMessage && (
                  _jsxDEV('span', { className: "flex items-center gap-0.5 text-[10px] text-muted-foreground truncate"     , children: [
                    _jsxDEV(MessageSquare, { className: "w-3 h-3 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this )
                    , _jsxDEV('span', { className: "truncate", children: [lastMessage.sender_name, ": " , lastMessage.message]}, void 0, true, {fileName: _jsxFileName, lineNumber: 71}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 69}, this)
                )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 58}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 42}, this)

            /* Time */
            , lastMessage && (
              _jsxDEV('span', { className: "text-[9px] text-muted-foreground shrink-0 flex items-center gap-0.5"     , children: [
                _jsxDEV(Clock, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this )
                , formatTime(lastMessage.created_date)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 79}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 27}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 26}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 25}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 24}, this)
  );
}