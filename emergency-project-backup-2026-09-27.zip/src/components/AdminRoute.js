const _jsxFileName = "src/components/AdminRoute.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext.js';
import { Loader2 } from 'lucide-react';
import { canAccessRoute, HOME_BY_ROLE } from '../lib/rbac.js';
import { checkBuilderAccess, fetchAndCacheBuilderAccess } from '../lib/builderAccess.js';
import { useEffect, useState } from 'react';

// ── AdminRoute ──
// برای نقش‌های مدیریتی: creator و admin
// همچنین بررسی دسترسی کمک‌سازنده‌ها برای پنل سازنده
export default function AdminRoute() {
  const { user, isLoadingAuth, isAuthenticated } = useAuth();
  const location = useLocation();
  const [accessChecked, setAccessChecked] = useState(false);
  const [hasBuilderAccess, setHasBuilderAccess] = useState(false);

  useEffect(() => {
    if (!user || !isAuthenticated) {
      setAccessChecked(true);
      return;
    }
    // Creator always has access
    if (user.role === 'creator' || user.role === 'admin') {
      setHasBuilderAccess(true);
      setAccessChecked(true);
      return;
    }
    // Check co-creator access
    fetchAndCacheBuilderAccess().then(() => {
      const access = checkBuilderAccess(user);
      setHasBuilderAccess(!!access);
      setAccessChecked(true);
    });
  }, [user, isAuthenticated]);

  if (isLoadingAuth || !accessChecked) {
    return (
      _jsxDEV('div', { className: "fixed inset-0 flex items-center justify-center bg-background"     , children: 
        _jsxDEV(Loader2, { className: "w-8 h-8 animate-spin text-primary"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 39}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this)
    );
  }

  // پنل سازنده فقط آنلاین — حتی خود سازنده باید آنلاین وارد شود
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return _jsxDEV(Navigate, { to: "/login", replace: true, state: { reason: 'offline_admin' },}, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this );
  }

  if (!isAuthenticated || !user) {
    return _jsxDEV(Navigate, { to: "/login", replace: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this );
  }

  const role = user.role || 'user';

  // Creator and admin always pass
  if (role === 'creator' || role === 'admin') {
    if (!canAccessRoute(role, location.pathname)) {
      const home = HOME_BY_ROLE[role] || '/';
      return _jsxDEV(Navigate, { to: home, replace: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this );
    }
    return _jsxDEV(Outlet, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this );
  }

  // Co-creator: only builder panel, check tab permissions
  if (location.pathname.startsWith('/builder')) {
    if (!hasBuilderAccess) {
      return _jsxDEV(Navigate, { to: "/dashboard", replace: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this );
    }
    return _jsxDEV(Outlet, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this );
  }

  // Non-admin users: redirect to dashboard
  return _jsxDEV(Navigate, { to: "/dashboard", replace: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this );
}