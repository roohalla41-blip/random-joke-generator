const _jsxFileName = "src/components/FeatureGate.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React from 'react';
import { useFeatures } from '../lib/useSarraaf.js';
import { isFeatureEnabled, getFeatureStatus } from '../lib/features.js';
import { Loader2, ShieldAlert } from 'lucide-react';
import UpdatingNotice from './sarraaf/UpdatingNotice.js';

export default function FeatureGate({ featureKey, children }) {
  const { data: features, isLoading } = useFeatures();

  if (isLoading) {
    return (
      _jsxDEV('div', { className: "flex items-center justify-center py-12"   , children: 
        _jsxDEV(Loader2, { className: "w-6 h-6 animate-spin text-primary"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 13}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 12}, this)
    );
  }

  const status = getFeatureStatus(features || [], featureKey);

  if (!isFeatureEnabled(features || [], featureKey) || status === 'disabled') {
    return (
      _jsxDEV('div', { className: "flex flex-col items-center justify-center py-16 text-center"     , children: [
        _jsxDEV(ShieldAlert, { className: "w-12 h-12 text-muted-foreground/40 mb-3"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 23}, this )
        , _jsxDEV('p', { className: "text-base font-semibold" , children: "این بخش غیرفعال است"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 24}, this)
        , _jsxDEV('p', { className: "text-sm text-muted-foreground mt-1"  , children: "برای فعال‌سازی، با مدیر سیستم تماس بگیرید"

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 25}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 22}, this)
    );
  }

  if (status === 'updating') {
    const f = _optionalChain([features, 'optionalAccess', _ => _.find, 'call', _2 => _2(fx => fx.feature_key === featureKey)]);
    return (
      _jsxDEV('div', { children: [
        children
        , _jsxDEV(UpdatingNotice, { message: _optionalChain([f, 'optionalAccess', _3 => _3.message]),}, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 35}, this)
    );
  }

  return children;
}