const _jsxFileName = "src/components/ProtectedRoute.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext.js';
import { Loader2 } from 'lucide-react';
import { canAccessRoute, HOME_BY_ROLE } from '../lib/rbac.js';

// ── ProtectedRoute ──
// محافظت از مسیرها بر اساس نقش کاربر
// - unauthenticatedElement: المانی که برای کاربران واردنشده نمایش داده می‌شود
// - requiredRole: نقش مورد نیاز (برای پنل مشتری: 'customer')
// - allowedRoles: لیست نقش‌های مجاز (برای مسیرهای خاص)
export default function ProtectedRoute({ unauthenticatedElement, requiredRole, allowedRoles }) {
  const { user, isLoadingAuth, isAuthenticated } = useAuth();
  const location = useLocation();

  if (isLoadingAuth) {
    return (
      _jsxDEV('div', { className: "fixed inset-0 flex items-center justify-center bg-background"     , children: 
        _jsxDEV(Loader2, { className: "w-8 h-8 animate-spin text-primary"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 18}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 17}, this)
    );
  }

  if (!isAuthenticated || !user) {
    return unauthenticatedElement || _jsxDEV(Navigate, { to: "/login", replace: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 24}, this );
  }

  const role = user.role || 'user';

  // اگر requiredRole مشخص شده و نقش کاربر متفاوت است
  if (requiredRole && role !== requiredRole) {
    const home = HOME_BY_ROLE[role] || '/';
    return _jsxDEV(Navigate, { to: home, replace: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 32}, this );
  }

  // اگر allowedRoles مشخص شده، بررسی کن آیا نقش کاربر در لیست است
  if (allowedRoles && !allowedRoles.includes(role)) {
    const home = HOME_BY_ROLE[role] || '/';
    return _jsxDEV(Navigate, { to: home, replace: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this );
  }

  // بررسی ماتریس دسترسی RBAC
  const currentPath = location.pathname;
  if (!canAccessRoute(role, currentPath)) {
    const home = HOME_BY_ROLE[role] || '/';
    return _jsxDEV(Navigate, { to: home, replace: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 45}, this );
  }

  return _jsxDEV(Outlet, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this );
}