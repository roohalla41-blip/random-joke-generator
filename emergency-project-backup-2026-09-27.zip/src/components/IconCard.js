const _jsxFileName = "src/components/IconCard.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Lock } from 'lucide-react';

export default function IconCard({ icon: Icon, label, path, color, bgColor, disabled, disabledMessage }) {
  const navigate = useNavigate();

  return (
    _jsxDEV(motion.button, {
      whileTap: { scale: disabled ? 1 : 0.92 },
      whileHover: { y: disabled ? 0 : -3 },
      onClick: () => !disabled && path && navigate(path),
      className: `relative flex flex-col items-center justify-center gap-2 aspect-square rounded-2xl border p-3 transition-all w-full ${
        disabled
          ? 'bg-muted border-border opacity-60 cursor-not-allowed'
          : 'bg-card border-border hover:shadow-md hover:border-primary/30'
      }`,
 children: [
      _jsxDEV('div', {
        className: `w-12 h-12 rounded-2xl flex items-center justify-center ${disabled ? 'bg-muted' : ''}`,
        style: !disabled ? { backgroundColor: bgColor || 'hsl(var(--muted))' } : {},
 children: 
        typeof Icon === 'string' ? (
          _jsxDEV('span', { className: "text-2xl", children: Icon}, void 0, false, {fileName: _jsxFileName, lineNumber: 25}, this)
        ) : (
          _jsxDEV(Icon, { className: `w-6 h-6 ${disabled ? 'text-muted-foreground' : ''}`, style: !disabled ? { color } : {},}, void 0, false, {fileName: _jsxFileName, lineNumber: 27}, this )
        )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 20}, this)
      , _jsxDEV('span', { className: `text-xs font-medium text-center leading-tight ${disabled ? 'text-muted-foreground' : 'text-foreground'}`, children: label}, void 0, false, {fileName: _jsxFileName, lineNumber: 30}, this)
      , disabled && (
        _jsxDEV('div', { className: "absolute top-1 end-1"  , children: 
          _jsxDEV(Lock, { className: "w-3.5 h-3.5 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 33}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 32}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 10}, this)
  );
}