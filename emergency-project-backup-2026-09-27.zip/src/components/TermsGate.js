const _jsxFileName = "src/components/TermsGate.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { useAuth } from '../lib/AuthContext.js';
import { getTerms, hasAcceptedTerms, acceptTerms } from '../lib/termsService.js';
import { Button } from './ui/button.js';
import { ScrollText, Check, Loader2 } from 'lucide-react';

export default function TermsGate({ children, role }) {
  const { user } = useAuth();
  const [terms, setTerms] = useState(null);
  const [accepted, setAccepted] = useState(false);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const t = await getTerms();
      if (!mounted) return;
      setTerms(t);
      setAccepted(hasAcceptedTerms(_optionalChain([user, 'optionalAccess', _ => _.id]), t.version));
      setChecked(true);
    })();
    return () => { mounted = false; };
  }, [_optionalChain([user, 'optionalAccess', _2 => _2.id])]);

  const handleAccept = () => {
    acceptTerms(_optionalChain([user, 'optionalAccess', _3 => _3.id]), terms.version);
    setAccepted(true);
  };

  if (!checked || accepted) return children;

  const text = role === 'customer' ? terms.customer : terms.sarraaf;

  return (
    _jsxDEV('div', { className: "fixed inset-0 z-50 bg-background flex flex-col"     , children: [
      _jsxDEV('div', { className: "flex items-center gap-2 p-4 border-b border-border"     , children: [
        _jsxDEV(ScrollText, { className: "w-5 h-5 text-primary shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this )
        , _jsxDEV('h2', { className: "font-bold text-sm" , children: "قوانین و مقررات"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 36}, this)

      , _jsxDEV('div', { className: "flex-1 overflow-y-auto p-4 scrollbar-thin"   , children: 
        _jsxDEV('div', { className: "whitespace-pre-wrap text-sm leading-relaxed text-foreground/90"   , children: 
          text
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this)

      , _jsxDEV('div', { className: "border-t border-border p-4 space-y-2 safe-bottom"    , children: [
        _jsxDEV(Button, { className: "w-full h-11" , onClick: handleAccept, children: [
          _jsxDEV(Check, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this ), "موافقم — ادامه"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 48}, this)
        , _jsxDEV('p', { className: "text-xs text-center text-muted-foreground"  , children: "با ادامه، شما قوانین و مقررات را می‌پذیرید."

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 52}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 47}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 35}, this)
  );
}