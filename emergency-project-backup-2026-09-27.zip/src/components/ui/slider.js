const _jsxFileName = "src/components/ui/slider.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import * as __xns1 from "@radix-ui/react-slider"; const SliderPrimitive = __cjsReq(__xns1);

import { cn } from "../../lib/utils.js"

const Slider = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(SliderPrimitive.Root, {
    ref: ref,
    className: cn("relative flex w-full touch-none select-none items-center", className),
    ...props, children: [
    _jsxDEV(SliderPrimitive.Track, {
      className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-primary/20"      , children: 
      _jsxDEV(SliderPrimitive.Range, { className: "absolute h-full bg-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 13}, this )
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 11}, this)
    , _jsxDEV(SliderPrimitive.Thumb, {
      className: "block h-4 w-4 rounded-full border border-primary/50 bg-background shadow transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"             ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 15}, this )
  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 7}, this)
))
Slider.displayName = SliderPrimitive.Root.displayName

export { Slider }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
