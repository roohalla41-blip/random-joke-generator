const _jsxFileName = "src/components/ui/switch.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import * as __xns1 from "@radix-ui/react-switch"; const SwitchPrimitives = __cjsReq(__xns1);

import { cn } from "../../lib/utils.js"

const Switch = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(SwitchPrimitives.Root, {
    className: cn(
      "peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",
      className
    ),
    ...props,
    ref: ref, children: 
    _jsxDEV(SwitchPrimitives.Thumb, {
      className: cn(
        "pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0"
      ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 14}, this )
  }, void 0, false, {fileName: _jsxFileName, lineNumber: 7}, this)
))
Switch.displayName = SwitchPrimitives.Root.displayName

export { Switch }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
