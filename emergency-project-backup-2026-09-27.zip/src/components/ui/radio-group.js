const _jsxFileName = "src/components/ui/radio-group.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import * as __xns1 from "@radix-ui/react-radio-group"; const RadioGroupPrimitive = __cjsReq(__xns1);
import { Circle } from "lucide-react"

import { cn } from "../../lib/utils.js"

const RadioGroup = React.forwardRef(({ className, ...props }, ref) => {
  return (_jsxDEV(RadioGroupPrimitive.Root, { className: cn("grid gap-2", className), ...props, ref: ref,}, void 0, false, {fileName: _jsxFileName, lineNumber: 8}, this ));
})
RadioGroup.displayName = RadioGroupPrimitive.Root.displayName

const RadioGroupItem = React.forwardRef(({ className, ...props }, ref) => {
  return (
    (_jsxDEV(RadioGroupPrimitive.Item, {
      ref: ref,
      className: cn(
        "aspect-square h-4 w-4 rounded-full border border-primary text-primary shadow focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
        className
      ),
      ...props, children: 
      _jsxDEV(RadioGroupPrimitive.Indicator, { className: "flex items-center justify-center"  , children: 
        _jsxDEV(Circle, { className: "h-3.5 w-3.5 fill-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 22}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 21}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 14}, this))
  );
})
RadioGroupItem.displayName = RadioGroupPrimitive.Item.displayName

export { RadioGroup, RadioGroupItem }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
