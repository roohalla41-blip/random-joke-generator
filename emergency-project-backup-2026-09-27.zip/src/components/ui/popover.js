const _jsxFileName = "src/components/ui/popover.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import * as __xns1 from "@radix-ui/react-popover"; const PopoverPrimitive = __cjsReq(__xns1);

import { cn } from "../../lib/utils.js"

const Popover = PopoverPrimitive.Root

const PopoverTrigger = PopoverPrimitive.Trigger

const PopoverAnchor = PopoverPrimitive.Anchor

const PopoverContent = React.forwardRef(({ className, align = "center", sideOffset = 4, ...props }, ref) => (
  _jsxDEV(PopoverPrimitive.Portal, { children: 
    _jsxDEV(PopoverPrimitive.Content, {
      ref: ref,
      align: align,
      sideOffset: sideOffset,
      className: cn(
        "z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        className
      ),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 14}, this )
  }, void 0, false, {fileName: _jsxFileName, lineNumber: 13}, this)
))
PopoverContent.displayName = PopoverPrimitive.Content.displayName

export { Popover, PopoverTrigger, PopoverContent, PopoverAnchor }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
