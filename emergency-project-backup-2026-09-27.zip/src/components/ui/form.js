const _jsxFileName = "src/components/ui/form.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }"use client";
import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import { Slot } from "@radix-ui/react-slot"
import { Controller, FormProvider, useFormContext } from "react-hook-form";

import { cn } from "../../lib/utils.js"
import { Label } from "./label.js"

const Form = FormProvider

const FormFieldContext = React.createContext({})

const FormField = (
  {
    ...props
  }
) => {
  return (
    (_jsxDEV(FormFieldContext.Provider, { value: { name: props.name }, children: 
      _jsxDEV(Controller, { ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 20}, this )
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 19}, this))
  );
}

const useFormField = () => {
  const fieldContext = React.useContext(FormFieldContext)
  const itemContext = React.useContext(FormItemContext)
  const { getFieldState, formState } = useFormContext()

  const fieldState = getFieldState(fieldContext.name, formState)

  if (!fieldContext) {
    throw new Error("useFormField should be used within <FormField>")
  }

  const { id } = itemContext

  return {
    id,
    name: fieldContext.name,
    formItemId: `${id}-form-item`,
    formDescriptionId: `${id}-form-item-description`,
    formMessageId: `${id}-form-item-message`,
    ...fieldState,
  }
}

const FormItemContext = React.createContext({})

const FormItem = React.forwardRef(({ className, ...props }, ref) => {
  const id = React.useId()

  return (
    (_jsxDEV(FormItemContext.Provider, { value: { id }, children: 
      _jsxDEV('div', { ref: ref, className: cn("space-y-2", className), ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this )
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 54}, this))
  );
})
FormItem.displayName = "FormItem"

const FormLabel = React.forwardRef(({ className, ...props }, ref) => {
  const { error, formItemId } = useFormField()

  return (
    (_jsxDEV(Label, {
      ref: ref,
      className: cn(error && "text-destructive", className),
      htmlFor: formItemId,
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this ))
  );
})
FormLabel.displayName = "FormLabel"

const FormControl = React.forwardRef(({ ...props }, ref) => {
  const { error, formItemId, formDescriptionId, formMessageId } = useFormField()

  return (
    (_jsxDEV(Slot, {
      ref: ref,
      id: formItemId,
      'aria-describedby': 
        !error
          ? `${formDescriptionId}`
          : `${formDescriptionId} ${formMessageId}`
      ,
      'aria-invalid': !!error,
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this ))
  );
})
FormControl.displayName = "FormControl"

const FormDescription = React.forwardRef(({ className, ...props }, ref) => {
  const { formDescriptionId } = useFormField()

  return (
    (_jsxDEV('p', {
      ref: ref,
      id: formDescriptionId,
      className: cn("text-[0.8rem] text-muted-foreground", className),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this ))
  );
})
FormDescription.displayName = "FormDescription"

const FormMessage = React.forwardRef(({ className, children, ...props }, ref) => {
  const { error, formMessageId } = useFormField()
  const body = error ? String(_optionalChain([error, 'optionalAccess', _ => _.message])) : children

  if (!body) {
    return null
  }

  return (
    (_jsxDEV('p', {
      ref: ref,
      id: formMessageId,
      className: cn("text-[0.8rem] font-medium text-destructive", className),
      ...props, children: 
      body
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this))
  );
})
FormMessage.displayName = "FormMessage"

export {
  useFormField,
  Form,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
  FormField,
}

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
