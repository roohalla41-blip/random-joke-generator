const _jsxFileName = "src/components/ui/scroll-area.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import * as __xns1 from "@radix-ui/react-scroll-area"; const ScrollAreaPrimitive = __cjsReq(__xns1);

import { cn } from "../../lib/utils.js"

const ScrollArea = React.forwardRef(({ className, children, ...props }, ref) => (
  _jsxDEV(ScrollAreaPrimitive.Root, {
    ref: ref,
    className: cn("relative overflow-hidden", className),
    ...props, children: [
    _jsxDEV(ScrollAreaPrimitive.Viewport, { className: "h-full w-full rounded-[inherit]"  , children: 
      children
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 11}, this)
    , _jsxDEV(ScrollBar, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 14}, this )
    , _jsxDEV(ScrollAreaPrimitive.Corner, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 15}, this )
  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 7}, this)
))
ScrollArea.displayName = ScrollAreaPrimitive.Root.displayName

const ScrollBar = React.forwardRef(({ className, orientation = "vertical", ...props }, ref) => (
  _jsxDEV(ScrollAreaPrimitive.ScrollAreaScrollbar, {
    ref: ref,
    orientation: orientation,
    className: cn(
      "flex touch-none select-none transition-colors",
      orientation === "vertical" &&
        "h-full w-2.5 border-l border-l-transparent p-[1px]",
      orientation === "horizontal" &&
        "h-2.5 flex-col border-t border-t-transparent p-[1px]",
      className
    ),
    ...props, children: 
    _jsxDEV(ScrollAreaPrimitive.ScrollAreaThumb, { className: "relative flex-1 rounded-full bg-border"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 33}, this )
  }, void 0, false, {fileName: _jsxFileName, lineNumber: 21}, this)
))
ScrollBar.displayName = ScrollAreaPrimitive.ScrollAreaScrollbar.displayName

export { ScrollArea, ScrollBar }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
