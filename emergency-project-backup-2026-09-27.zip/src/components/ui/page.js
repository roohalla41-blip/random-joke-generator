const _jsxFileName = "src/components/ui/page.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';
import { cn } from '../../lib/utils.js';
import { Loader2, Inbox } from 'lucide-react';

export function PageHeader({ title, subtitle, icon: Icon, actions }) {
  return (
    _jsxDEV('div', { className: "flex items-center justify-between gap-3"   , children: [
      _jsxDEV('div', { className: "flex items-center gap-3 min-w-0"   , children: [
        Icon && (
          _jsxDEV('div', { className: "w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0"       , children: 
            _jsxDEV(Icon, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 11}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 10}, this)
        )
        , _jsxDEV('div', { className: "min-w-0", children: [
          _jsxDEV('h1', { className: "text-lg sm:text-xl font-bold text-foreground truncate"    , children: title}, void 0, false, {fileName: _jsxFileName, lineNumber: 15}, this)
          , subtitle && _jsxDEV('p', { className: "text-sm text-muted-foreground truncate"  , children: subtitle}, void 0, false, {fileName: _jsxFileName, lineNumber: 16}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 14}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 8}, this)
      , actions && _jsxDEV('div', { className: "flex items-center gap-2 shrink-0"   , children: actions}, void 0, false, {fileName: _jsxFileName, lineNumber: 19}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 7}, this)
  );
}

export function LoadingState({ text, className }) {
  return (
    _jsxDEV('div', { className: cn('flex flex-col items-center justify-center py-12 gap-2', className), children: [
      _jsxDEV(Loader2, { className: "w-6 h-6 animate-spin text-muted-foreground"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 27}, this )
      , text && _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: text}, void 0, false, {fileName: _jsxFileName, lineNumber: 28}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 26}, this)
  );
}

export function EmptyState({ icon: Icon = Inbox, text, className }) {
  return (
    _jsxDEV('div', { className: cn('flex flex-col items-center justify-center py-10 gap-2', className), children: [
      _jsxDEV('div', { className: "w-14 h-14 rounded-2xl bg-muted flex items-center justify-center"      , children: 
        _jsxDEV(Icon, { className: "w-7 h-7 text-muted-foreground/60"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this)
      , text && _jsxDEV('p', { className: "text-sm text-muted-foreground text-center"  , children: text}, void 0, false, {fileName: _jsxFileName, lineNumber: 39}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 35}, this)
  );
}

export function StatCard({ label, value, icon: Icon, color = 'primary', sub }) {
  const colorMap = {
    primary: 'bg-primary/10 text-primary',
    success: 'bg-success/10 text-success',
    warning: 'bg-warning/10 text-warning',
    destructive: 'bg-destructive/10 text-destructive',
  };
  return (
    _jsxDEV('div', { className: "rounded-xl border bg-card p-4"   , children: [
      Icon && (
        _jsxDEV('div', { className: cn('w-9 h-9 rounded-lg flex items-center justify-center mb-2', colorMap[color]), children: 
          _jsxDEV(Icon, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 54}, this)
      )
      , _jsxDEV('p', { className: "text-xl font-bold text-foreground"  , children: value}, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this)
      , label && _jsxDEV('p', { className: "text-xs text-muted-foreground mt-0.5"  , children: label}, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this)
      , sub && _jsxDEV('p', { className: "text-xs text-muted-foreground/80 mt-0.5"  , children: sub}, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 52}, this)
  );
}

export function ListItem({ icon: Icon, iconColor = 'primary', title, subtitle, badge, amount, amountColor, onClick, children }) {
  const colorMap = {
    primary: 'bg-primary/10 text-primary',
    success: 'bg-success/10 text-success',
    warning: 'bg-warning/10 text-warning',
    destructive: 'bg-destructive/10 text-destructive',
  };
  return (
    _jsxDEV('div', {
      className: cn(
        'flex items-center gap-3 p-3 rounded-lg bg-muted/50 border border-border',
        onClick && 'cursor-pointer hover:bg-muted transition-colors'
      ),
      onClick: onClick,
 children: [
      Icon && (
        _jsxDEV('div', { className: cn('w-9 h-9 rounded-full flex items-center justify-center shrink-0', colorMap[iconColor]), children: 
          _jsxDEV(Icon, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
      )
      , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
        title && _jsxDEV('p', { className: "text-sm font-medium text-foreground truncate"   , children: title}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this)
        , subtitle && _jsxDEV('p', { className: "text-xs text-muted-foreground truncate mt-0.5"   , children: subtitle}, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this)
        , children
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 85}, this)
      , (amount !== undefined || badge) && (
        _jsxDEV('div', { className: "text-end shrink-0 space-y-1"  , children: [
          amount !== undefined && (
            _jsxDEV('p', { className: cn('text-sm font-bold', amountColor), dir: "ltr", children: amount}, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this)
          )
          , badge
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 91}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 73}, this)
  );
}