const _jsxFileName = "src/components/ui/card.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);

import { cn } from "../../lib/utils.js"

const Card = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('div', {
    ref: ref,
    className: cn("rounded-xl border bg-card text-card-foreground shadow", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 6}, this )
))
Card.displayName = "Card"

const CardHeader = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('div', {
    ref: ref,
    className: cn("flex flex-col space-y-1.5 p-6", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 14}, this )
))
CardHeader.displayName = "CardHeader"

const CardTitle = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('div', {
    ref: ref,
    className: cn("font-semibold leading-none tracking-tight", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 22}, this )
))
CardTitle.displayName = "CardTitle"

const CardDescription = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('div', {
    ref: ref,
    className: cn("text-sm text-muted-foreground", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 30}, this )
))
CardDescription.displayName = "CardDescription"

const CardContent = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('div', { ref: ref, className: cn("p-6 pt-0", className), ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this )
))
CardContent.displayName = "CardContent"

const CardFooter = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('div', {
    ref: ref,
    className: cn("flex items-center p-6 pt-0", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this )
))
CardFooter.displayName = "CardFooter"

export { Card, CardHeader, CardFooter, CardTitle, CardDescription, CardContent }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
