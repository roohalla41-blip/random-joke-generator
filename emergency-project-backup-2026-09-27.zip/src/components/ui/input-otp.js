const _jsxFileName = "src/components/ui/input-otp.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import { OTPInput, OTPInputContext } from "input-otp"
import { Minus } from "lucide-react"

import { cn } from "../../lib/utils.js"

const InputOTP = React.forwardRef(({ className, containerClassName, ...props }, ref) => (
  _jsxDEV(OTPInput, {
    ref: ref,
    containerClassName: cn("flex items-center gap-2 has-[:disabled]:opacity-50", containerClassName),
    className: cn("disabled:cursor-not-allowed", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 8}, this )
))
InputOTP.displayName = "InputOTP"

const InputOTPGroup = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('div', { ref: ref, className: cn("flex items-center", className), ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 17}, this )
))
InputOTPGroup.displayName = "InputOTPGroup"

const InputOTPSlot = React.forwardRef(({ index, className, ...props }, ref) => {
  const inputOTPContext = React.useContext(OTPInputContext)
  const { char, hasFakeCaret, isActive } = inputOTPContext.slots[index]

  return (
    (_jsxDEV('div', {
      ref: ref,
      className: cn(
        "relative flex h-9 w-9 items-center justify-center border-y border-r border-input text-sm shadow-sm transition-all first:rounded-l-md first:border-l last:rounded-r-md",
        isActive && "z-10 ring-1 ring-ring",
        className
      ),
      ...props, children: [
      char
      , hasFakeCaret && (
        _jsxDEV('div', {
          className: "pointer-events-none absolute inset-0 flex items-center justify-center"     , children: 
          _jsxDEV('div', { className: "h-4 w-px animate-caret-blink bg-foreground duration-1000"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 26}, this))
  );
})
InputOTPSlot.displayName = "InputOTPSlot"

const InputOTPSeparator = React.forwardRef(({ ...props }, ref) => (
  _jsxDEV('div', { ref: ref, role: "separator", ...props, children: 
    _jsxDEV(Minus, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this )
  }, void 0, false, {fileName: _jsxFileName, lineNumber: 47}, this)
))
InputOTPSeparator.displayName = "InputOTPSeparator"

export { InputOTP, InputOTPGroup, InputOTPSlot, InputOTPSeparator }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
