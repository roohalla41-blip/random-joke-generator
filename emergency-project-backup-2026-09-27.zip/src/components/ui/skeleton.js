const _jsxFileName = "src/components/ui/skeleton.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import { cn } from "../../lib/utils.js"

function Skeleton({
  className,
  ...props
}) {
  return (
    (_jsxDEV('div', {
      className: cn("animate-pulse rounded-md bg-primary/10", className),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 8}, this ))
  );
}

export { Skeleton }
