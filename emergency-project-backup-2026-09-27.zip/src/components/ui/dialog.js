const _jsxFileName = "src/components/ui/dialog.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";"use client"

import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import * as __xns1 from "@radix-ui/react-dialog"; const DialogPrimitive = __cjsReq(__xns1);
import { X } from "lucide-react"

import { cn } from "../../lib/utils.js"

const Dialog = DialogPrimitive.Root

const DialogTrigger = DialogPrimitive.Trigger

const DialogPortal = DialogPrimitive.Portal

const DialogClose = DialogPrimitive.Close

const DialogOverlay = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(DialogPrimitive.Overlay, {
    ref: ref,
    className: cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    ),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 18}, this )
))
DialogOverlay.displayName = DialogPrimitive.Overlay.displayName

const DialogContent = React.forwardRef(({ className, children, ...props }, ref) => (
  _jsxDEV(DialogPortal, { children: [
    _jsxDEV(DialogOverlay, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 30}, this )
    , _jsxDEV(DialogPrimitive.Content, {
      ref: ref,
      className: cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg max-h-[90vh] overflow-y-auto translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg",
        className
      ),
      ...props, children: [
      children
      , _jsxDEV(DialogPrimitive.Close, {
        className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground"              , children: [
        _jsxDEV(X, { className: "h-4 w-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this )
        , _jsxDEV('span', { className: "sr-only", children: "Close"}, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 39}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 31}, this)
  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 29}, this)
))
DialogContent.displayName = DialogPrimitive.Content.displayName

const DialogHeader = ({
  className,
  ...props
}) => (
  _jsxDEV('div', {
    className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 53}, this )
)
DialogHeader.displayName = "DialogHeader"

const DialogFooter = ({
  className,
  ...props
}) => (
  _jsxDEV('div', {
    className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this )
)
DialogFooter.displayName = "DialogFooter"

const DialogTitle = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(DialogPrimitive.Title, {
    ref: ref,
    className: cn("text-lg font-semibold leading-none tracking-tight", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this )
))
DialogTitle.displayName = DialogPrimitive.Title.displayName

const DialogDescription = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(DialogPrimitive.Description, {
    ref: ref,
    className: cn("text-sm text-muted-foreground", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this )
))
DialogDescription.displayName = DialogPrimitive.Description.displayName

export {
  Dialog,
  DialogPortal,
  DialogOverlay,
  DialogTrigger,
  DialogClose,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
}
function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
