const _jsxFileName = "src/components/ui/table.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);

import { cn } from "../../lib/utils.js"

const Table = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('div', { className: "relative w-full overflow-auto"  , children: 
    _jsxDEV('table', {
      ref: ref,
      className: cn("w-full caption-bottom text-sm", className),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 7}, this )
  }, void 0, false, {fileName: _jsxFileName, lineNumber: 6}, this)
))
Table.displayName = "Table"

const TableHeader = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('thead', { ref: ref, className: cn("[&_tr]:border-b", className), ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 16}, this )
))
TableHeader.displayName = "TableHeader"

const TableBody = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('tbody', {
    ref: ref,
    className: cn("[&_tr:last-child]:border-0", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 21}, this )
))
TableBody.displayName = "TableBody"

const TableFooter = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('tfoot', {
    ref: ref,
    className: cn("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 29}, this )
))
TableFooter.displayName = "TableFooter"

const TableRow = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('tr', {
    ref: ref,
    className: cn(
      "border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted",
      className
    ),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this )
))
TableRow.displayName = "TableRow"

const TableHead = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('th', {
    ref: ref,
    className: cn(
      "h-10 px-2 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
      className
    ),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this )
))
TableHead.displayName = "TableHead"

const TableCell = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('td', {
    ref: ref,
    className: cn(
      "p-2 align-middle [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
      className
    ),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this )
))
TableCell.displayName = "TableCell"

const TableCaption = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('caption', {
    ref: ref,
    className: cn("mt-4 text-sm text-muted-foreground", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this )
))
TableCaption.displayName = "TableCaption"

export {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableHead,
  TableRow,
  TableCell,
  TableCaption,
}

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
