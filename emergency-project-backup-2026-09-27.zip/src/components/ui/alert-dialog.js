const _jsxFileName = "src/components/ui/alert-dialog.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import * as __xns1 from "@radix-ui/react-alert-dialog"; const AlertDialogPrimitive = __cjsReq(__xns1);

import { cn } from "../../lib/utils.js"
import { buttonVariants } from "./button.js"

const AlertDialog = AlertDialogPrimitive.Root

const AlertDialogTrigger = AlertDialogPrimitive.Trigger

const AlertDialogPortal = AlertDialogPrimitive.Portal

const AlertDialogOverlay = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(AlertDialogPrimitive.Overlay, {
    className: cn(
      "fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    ),
    ...props,
    ref: ref,}, void 0, false, {fileName: _jsxFileName, lineNumber: 14}, this )
))
AlertDialogOverlay.displayName = AlertDialogPrimitive.Overlay.displayName

const AlertDialogContent = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(AlertDialogPortal, { children: [
    _jsxDEV(AlertDialogOverlay, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 26}, this )
    , _jsxDEV(AlertDialogPrimitive.Content, {
      ref: ref,
      className: cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg",
        className
      ),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 27}, this )
  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 25}, this)
))
AlertDialogContent.displayName = AlertDialogPrimitive.Content.displayName

const AlertDialogHeader = ({
  className,
  ...props
}) => (
  _jsxDEV('div', {
    className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this )
)
AlertDialogHeader.displayName = "AlertDialogHeader"

const AlertDialogFooter = ({
  className,
  ...props
}) => (
  _jsxDEV('div', {
    className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 52}, this )
)
AlertDialogFooter.displayName = "AlertDialogFooter"

const AlertDialogTitle = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(AlertDialogPrimitive.Title, { ref: ref, className: cn("text-lg font-semibold", className), ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this )
))
AlertDialogTitle.displayName = AlertDialogPrimitive.Title.displayName

const AlertDialogDescription = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(AlertDialogPrimitive.Description, {
    ref: ref,
    className: cn("text-sm text-muted-foreground", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this )
))
AlertDialogDescription.displayName =
  AlertDialogPrimitive.Description.displayName

const AlertDialogAction = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(AlertDialogPrimitive.Action, { ref: ref, className: cn(buttonVariants(), className), ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this )
))
AlertDialogAction.displayName = AlertDialogPrimitive.Action.displayName

const AlertDialogCancel = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(AlertDialogPrimitive.Cancel, {
    ref: ref,
    className: cn(buttonVariants({ variant: "outline" }), "mt-2 sm:mt-0", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this )
))
AlertDialogCancel.displayName = AlertDialogPrimitive.Cancel.displayName

export {
  AlertDialog,
  AlertDialogPortal,
  AlertDialogOverlay,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
}

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
