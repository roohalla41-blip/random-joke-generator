const _jsxFileName = "src/components/ui/textarea.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);

import { cn } from "../../lib/utils.js"

const Textarea = React.forwardRef(({ className, ...props }, ref) => {
  return (
    (_jsxDEV('textarea', {
      className: cn(
        "flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
        className
      ),
      ref: ref,
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 7}, this ))
  );
})
Textarea.displayName = "Textarea"

export { Textarea }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
