const _jsxFileName = "src/components/ui/label.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import * as __xns1 from "@radix-ui/react-label"; const LabelPrimitive = __cjsReq(__xns1);
import { cva } from "class-variance-authority";

import { cn } from "../../lib/utils.js"

const labelVariants = cva(
  "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
)

const Label = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(LabelPrimitive.Root, { ref: ref, className: cn(labelVariants(), className), ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 12}, this )
))
Label.displayName = LabelPrimitive.Root.displayName

export { Label }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
