const _jsxFileName = "src/components/ui/avatar.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";"use client"

import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import * as __xns1 from "@radix-ui/react-avatar"; const AvatarPrimitive = __cjsReq(__xns1);

import { cn } from "../../lib/utils.js"

const Avatar = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(AvatarPrimitive.Root, {
    ref: ref,
    className: cn("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 9}, this )
))
Avatar.displayName = AvatarPrimitive.Root.displayName

const AvatarImage = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(AvatarPrimitive.Image, {
    ref: ref,
    className: cn("aspect-square h-full w-full", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 17}, this )
))
AvatarImage.displayName = AvatarPrimitive.Image.displayName

const AvatarFallback = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(AvatarPrimitive.Fallback, {
    ref: ref,
    className: cn(
      "flex h-full w-full items-center justify-center rounded-full bg-muted",
      className
    ),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 25}, this )
))
AvatarFallback.displayName = AvatarPrimitive.Fallback.displayName

export { Avatar, AvatarImage, AvatarFallback }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
