const _jsxFileName = "src/components/ui/toggle-group.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";"use client";
import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import * as __xns1 from "@radix-ui/react-toggle-group"; const ToggleGroupPrimitive = __cjsReq(__xns1);

import { cn } from "../../lib/utils.js"
import { toggleVariants } from "./toggle.js"

const ToggleGroupContext = React.createContext({
  size: "default",
  variant: "default",
})

const ToggleGroup = React.forwardRef(({ className, variant, size, children, ...props }, ref) => (
  _jsxDEV(ToggleGroupPrimitive.Root, {
    ref: ref,
    className: cn("flex items-center justify-center gap-1", className),
    ...props, children: 
    _jsxDEV(ToggleGroupContext.Provider, { value: { variant, size }, children: 
      children
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 18}, this)
  }, void 0, false, {fileName: _jsxFileName, lineNumber: 14}, this)
))

ToggleGroup.displayName = ToggleGroupPrimitive.Root.displayName

const ToggleGroupItem = React.forwardRef(({ className, children, variant, size, ...props }, ref) => {
  const context = React.useContext(ToggleGroupContext)

  return (
    (_jsxDEV(ToggleGroupPrimitive.Item, {
      ref: ref,
      className: cn(toggleVariants({
        variant: context.variant || variant,
        size: context.size || size,
      }), className),
      ...props, children: 
      children
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 30}, this))
  );
})

ToggleGroupItem.displayName = ToggleGroupPrimitive.Item.displayName

export { ToggleGroup, ToggleGroupItem }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
