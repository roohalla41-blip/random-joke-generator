const _jsxFileName = "src/components/ui/resizable.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";"use client"

import { GripVertical } from "lucide-react"
import * as __xns0 from "react-resizable-panels"; const ResizablePrimitive = __cjsReq(__xns0);

import { cn } from "../../lib/utils.js"

const ResizablePanelGroup = ({
  className,
  ...props
}) => (
  _jsxDEV(ResizablePrimitive.PanelGroup, {
    className: cn(
      "flex h-full w-full data-[panel-group-direction=vertical]:flex-col",
      className
    ),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 12}, this )
)

const ResizablePanel = ResizablePrimitive.Panel

const ResizableHandle = ({
  withHandle,
  className,
  ...props
}) => (
  _jsxDEV(ResizablePrimitive.PanelResizeHandle, {
    className: cn(
      "relative flex w-px items-center justify-center bg-border after:absolute after:inset-y-0 after:left-1/2 after:w-1 after:-translate-x-1/2 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring focus-visible:ring-offset-1 data-[panel-group-direction=vertical]:h-px data-[panel-group-direction=vertical]:w-full data-[panel-group-direction=vertical]:after:left-0 data-[panel-group-direction=vertical]:after:h-1 data-[panel-group-direction=vertical]:after:w-full data-[panel-group-direction=vertical]:after:-translate-y-1/2 data-[panel-group-direction=vertical]:after:translate-x-0 [&[data-panel-group-direction=vertical]>div]:rotate-90",
      className
    ),
    ...props, children: 
    withHandle && (
      _jsxDEV('div', {
        className: "z-10 flex h-4 w-3 items-center justify-center rounded-sm border bg-border"        , children: 
        _jsxDEV(GripVertical, { className: "h-2.5 w-2.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 34}, this)
    )
  }, void 0, false, {fileName: _jsxFileName, lineNumber: 27}, this)
)

export { ResizablePanelGroup, ResizablePanel, ResizableHandle }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
