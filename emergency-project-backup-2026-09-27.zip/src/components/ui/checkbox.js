const _jsxFileName = "src/components/ui/checkbox.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import * as __xns1 from "@radix-ui/react-checkbox"; const CheckboxPrimitive = __cjsReq(__xns1);
import { Check } from "lucide-react"

import { cn } from "../../lib/utils.js"

const Checkbox = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV(CheckboxPrimitive.Root, {
    ref: ref,
    className: cn(
      "peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground",
      className
    ),
    ...props, children: 
    _jsxDEV(CheckboxPrimitive.Indicator, { className: cn("flex items-center justify-center text-current"), children: 
      _jsxDEV(Check, { className: "h-4 w-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 16}, this )
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 15}, this)
  }, void 0, false, {fileName: _jsxFileName, lineNumber: 8}, this)
))
Checkbox.displayName = CheckboxPrimitive.Root.displayName

export { Checkbox }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
