const _jsxFileName = "src/components/ui/toaster.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import { useToast } from "./use-toast.js";
import {
  Toast,
  ToastClose,
  ToastDescription,
  ToastProvider,
  ToastTitle,
  ToastViewport,
} from "./toast.js";

export function Toaster() {
  const { toasts } = useToast();

  return (
    _jsxDEV(ToastProvider, { children: [
      toasts.map(function ({ id, title, description, action, ...props }) {
        return (
          _jsxDEV(Toast, { ...props, children: [
            _jsxDEV('div', { className: "grid gap-1" , children: [
              title && _jsxDEV(ToastTitle, { children: title}, void 0, false, {fileName: _jsxFileName, lineNumber: 20}, this)
              , description && (
                _jsxDEV(ToastDescription, { children: description}, void 0, false, {fileName: _jsxFileName, lineNumber: 22}, this)
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 19}, this)
            , action
            , _jsxDEV(ToastClose, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 26}, this )
          ]}, id, true, {fileName: _jsxFileName, lineNumber: 18}, this)
        );
      })
      , _jsxDEV(ToastViewport, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 30}, this )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 15}, this)
  );
} 