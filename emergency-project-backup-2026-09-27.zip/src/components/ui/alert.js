const _jsxFileName = "src/components/ui/alert.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import { cva } from "class-variance-authority";

import { cn } from "../../lib/utils.js"

const alertVariants = cva(
  "relative w-full rounded-lg border px-4 py-3 text-sm [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground [&>svg~*]:pl-7",
  {
    variants: {
      variant: {
        default: "bg-background text-foreground",
        destructive:
          "border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

const Alert = React.forwardRef(({ className, variant, ...props }, ref) => (
  _jsxDEV('div', {
    ref: ref,
    role: "alert",
    className: cn(alertVariants({ variant }), className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 23}, this )
))
Alert.displayName = "Alert"

const AlertTitle = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('h5', {
    ref: ref,
    className: cn("mb-1 font-medium leading-none tracking-tight", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 32}, this )
))
AlertTitle.displayName = "AlertTitle"

const AlertDescription = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('div', {
    ref: ref,
    className: cn("text-sm [&_p]:leading-relaxed", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 40}, this )
))
AlertDescription.displayName = "AlertDescription"

export { Alert, AlertTitle, AlertDescription }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
