import * as __xns0 from "@radix-ui/react-aspect-ratio"; const AspectRatioPrimitive = __cjsReq(__xns0);

const AspectRatio = AspectRatioPrimitive.Root

export { AspectRatio }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
