const _jsxFileName = "src/components/ui/progress.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";"use client"

import * as __xns0 from "react"; const React = __cjsReq(__xns0);
import * as __xns1 from "@radix-ui/react-progress"; const ProgressPrimitive = __cjsReq(__xns1);

import { cn } from "../../lib/utils.js"

const Progress = React.forwardRef(({ className, value, ...props }, ref) => (
  _jsxDEV(ProgressPrimitive.Root, {
    ref: ref,
    className: cn(
      "relative h-2 w-full overflow-hidden rounded-full bg-primary/20",
      className
    ),
    ...props, children: 
    _jsxDEV(ProgressPrimitive.Indicator, {
      className: "h-full w-full flex-1 bg-primary transition-all"    ,
      style: { transform: `translateX(-${100 - (value || 0)}%)` },}, void 0, false, {fileName: _jsxFileName, lineNumber: 16}, this )
  }, void 0, false, {fileName: _jsxFileName, lineNumber: 9}, this)
))
Progress.displayName = ProgressPrimitive.Root.displayName

export { Progress }

function __cjsReq(ns){if(ns==null)return ns;var d=ns.default;if(d===undefined)return ns;var ks=Object.keys(ns),n=0;for(var i=0;i<ks.length;i++){var k=ks[i];if(k==="default"||k==="__esModule")continue;n++;if(typeof d!=="object"&&typeof d!=="function")return ns;if(!(k in d))return ns;}return d;}
