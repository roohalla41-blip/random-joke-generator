const _jsxFileName = "src/components/ui/sidebar.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _nullishCoalesce(lhs, rhsFn) { if (lhs != null) { return lhs; } else { return rhsFn(); } } function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva } from "class-variance-authority";
import { PanelLeft } from "lucide-react"

import { useIsMobile } from "../../hooks/use-mobile.js"
import { cn } from "../../lib/utils.js"
import { Button } from "./button.js"
import { Input } from "./input.js"
import { Separator } from "./separator.js"
import { Sheet, SheetContent } from "./sheet.js"
import { Skeleton } from "./skeleton.js"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./tooltip.js"

const SIDEBAR_COOKIE_NAME = "sidebar_state"
const SIDEBAR_COOKIE_MAX_AGE = 60 * 60 * 24 * 7
const SIDEBAR_WIDTH = "16rem"
const SIDEBAR_WIDTH_MOBILE = "18rem"
const SIDEBAR_WIDTH_ICON = "3rem"
const SIDEBAR_KEYBOARD_SHORTCUT = "b"

const SidebarContext = React.createContext(null)

function useSidebar() {
  const context = React.useContext(SidebarContext)
  if (!context) {
    throw new Error("useSidebar must be used within a SidebarProvider.")
  }

  return context
}

const SidebarProvider = React.forwardRef((
  {
    defaultOpen = true,
    open: openProp,
    onOpenChange: setOpenProp,
    className,
    style,
    children,
    ...props
  },
  ref
) => {
  const isMobile = useIsMobile()
  const [openMobile, setOpenMobile] = React.useState(false)

  // This is the internal state of the sidebar.
  // We use openProp and setOpenProp for control from outside the component.
  const [_open, _setOpen] = React.useState(defaultOpen)
  const open = _nullishCoalesce(openProp, () => ( _open))
  const setOpen = React.useCallback((value) => {
    const openState = typeof value === "function" ? value(open) : value
    if (setOpenProp) {
      setOpenProp(openState)
    } else {
      _setOpen(openState)
    }

    // This sets the cookie to keep the sidebar state.
    document.cookie = `${SIDEBAR_COOKIE_NAME}=${openState}; path=/; max-age=${SIDEBAR_COOKIE_MAX_AGE}`
  }, [setOpenProp, open])

  // Helper to toggle the sidebar.
  const toggleSidebar = React.useCallback(() => {
    return isMobile
      ? setOpenMobile((open) => !open)
      : setOpen((open) => !open);
  }, [isMobile, setOpen, setOpenMobile])

  // Adds a keyboard shortcut to toggle the sidebar.
  React.useEffect(() => {
    const handleKeyDown = (event) => {
      if (
        event.key === SIDEBAR_KEYBOARD_SHORTCUT &&
        (event.metaKey || event.ctrlKey)
      ) {
        event.preventDefault()
        toggleSidebar()
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [toggleSidebar])

  // We add a state so that we can do data-state="expanded" or "collapsed".
  // This makes it easier to style the sidebar with Tailwind classes.
  const state = open ? "expanded" : "collapsed"

  const contextValue = React.useMemo(() => ({
    state,
    open,
    setOpen,
    isMobile,
    openMobile,
    setOpenMobile,
    toggleSidebar,
  }), [state, open, setOpen, isMobile, openMobile, setOpenMobile, toggleSidebar])

  return (
    (_jsxDEV(SidebarContext.Provider, { value: contextValue, children: 
      _jsxDEV(TooltipProvider, { delayDuration: 0, children: 
        _jsxDEV('div', {
          style: 
            {
              "--sidebar-width": SIDEBAR_WIDTH,
              "--sidebar-width-icon": SIDEBAR_WIDTH_ICON,
              ...style
            }
          ,
          className: cn(
            "group/sidebar-wrapper flex min-h-svh w-full has-[[data-variant=inset]]:bg-sidebar",
            className
          ),
          ref: ref,
          ...props, children: 
          children
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this))
  );
})
SidebarProvider.displayName = "SidebarProvider"

const Sidebar = React.forwardRef((
  {
    side = "left",
    variant = "sidebar",
    collapsible = "offcanvas",
    className,
    children,
    ...props
  },
  ref
) => {
  const { isMobile, state, openMobile, setOpenMobile } = useSidebar()

  if (collapsible === "none") {
    return (
      (_jsxDEV('div', {
        className: cn(
          "flex h-full w-[--sidebar-width] flex-col bg-sidebar text-sidebar-foreground",
          className
        ),
        ref: ref,
        ...props, children: 
        children
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this))
    );
  }

  if (isMobile) {
    return (
      (_jsxDEV(Sheet, { open: openMobile, onOpenChange: setOpenMobile, ...props, children: 
        _jsxDEV(SheetContent, {
          'data-sidebar': "sidebar",
          'data-mobile': "true",
          className: "w-[--sidebar-width] bg-sidebar p-0 text-sidebar-foreground [&>button]:hidden"    ,
          style: 
            {
              "--sidebar-width": SIDEBAR_WIDTH_MOBILE
            }
          ,
          side: side, children: 
          _jsxDEV('div', { className: "flex h-full w-full flex-col"   , children: children}, void 0, false, {fileName: _jsxFileName, lineNumber: 171}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 161}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this))
    );
  }

  return (
    (_jsxDEV('div', {
      ref: ref,
      className: "group peer hidden text-sidebar-foreground md:block"    ,
      'data-state': state,
      'data-collapsible': state === "collapsed" ? collapsible : "",
      'data-variant': variant,
      'data-side': side, children: [
      /* This is what handles the sidebar gap on desktop */
      _jsxDEV('div', {
        className: cn(
          "relative h-svh w-[--sidebar-width] bg-transparent transition-[width] duration-200 ease-linear",
          "group-data-[collapsible=offcanvas]:w-0",
          "group-data-[side=right]:rotate-180",
          variant === "floating" || variant === "inset"
            ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4))]"
            : "group-data-[collapsible=icon]:w-[--sidebar-width-icon]"
        ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 186}, this )
      , _jsxDEV('div', {
        className: cn(
          "fixed inset-y-0 z-10 hidden h-svh w-[--sidebar-width] transition-[left,right,width] duration-200 ease-linear md:flex",
          side === "left"
            ? "left-0 group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)]"
            : "right-0 group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)]",
          // Adjust the padding for floating and inset variants.
          variant === "floating" || variant === "inset"
            ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4)_+2px)]"
            : "group-data-[collapsible=icon]:w-[--sidebar-width-icon] group-data-[side=left]:border-r group-data-[side=right]:border-l",
          className
        ),
        ...props, children: 
        _jsxDEV('div', {
          'data-sidebar': "sidebar",
          className: "flex h-full w-full flex-col bg-sidebar group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:border group-data-[variant=floating]:border-sidebar-border group-data-[variant=floating]:shadow"        , children: 
          children
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 208}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 195}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 178}, this))
  );
})
Sidebar.displayName = "Sidebar"

const SidebarTrigger = React.forwardRef(({ className, onClick, asChild = false, ...props }, ref) => {
  const { toggleSidebar } = useSidebar()

  return (
    (_jsxDEV(Button, {
      ref: ref,
      'data-sidebar': "trigger",
      variant: "ghost",
      size: "icon",
      className: cn("h-7 w-7", className),
      onClick: (event) => {
        _optionalChain([onClick, 'optionalCall', _ => _(event)])
        toggleSidebar()
      },
      asChild: asChild,
      ...props, children: 
      asChild ? (
        _jsxDEV(PanelLeft, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 236}, this )
      ) : (
        _jsxDEV(_Fragment, { children: [
          _jsxDEV(PanelLeft, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 239}, this )
          , _jsxDEV('span', { className: "sr-only", children: "Toggle Sidebar" }, void 0, false, {fileName: _jsxFileName, lineNumber: 240}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 238}, this)
      )
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this))
  );
})
SidebarTrigger.displayName = "SidebarTrigger"

const SidebarRail = React.forwardRef(({ className, ...props }, ref) => {
  const { toggleSidebar } = useSidebar()

  return (
    (_jsxDEV('button', {
      ref: ref,
      'data-sidebar': "rail",
      'aria-label': "Toggle Sidebar" ,
      tabIndex: -1,
      onClick: toggleSidebar,
      title: "Toggle Sidebar" ,
      className: cn(
        "absolute inset-y-0 z-20 hidden w-4 -translate-x-1/2 transition-all ease-linear after:absolute after:inset-y-0 after:left-1/2 after:w-[2px] hover:after:bg-sidebar-border group-data-[side=left]:-right-4 group-data-[side=right]:left-0 sm:flex",
        "[[data-side=left]_&]:cursor-w-resize [[data-side=right]_&]:cursor-e-resize",
        "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize",
        "group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full group-data-[collapsible=offcanvas]:hover:bg-sidebar",
        "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2",
        "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2",
        className
      ),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 252}, this ))
  );
})
SidebarRail.displayName = "SidebarRail"

const SidebarInset = React.forwardRef(({ className, ...props }, ref) => {
  return (
    (_jsxDEV('main', {
      ref: ref,
      className: cn(
        "relative flex min-h-svh flex-1 flex-col bg-background",
        "peer-data-[variant=inset]:min-h-[calc(100svh-theme(spacing.4))] md:peer-data-[variant=inset]:m-2 md:peer-data-[state=collapsed]:peer-data-[variant=inset]:ml-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow",
        className
      ),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 275}, this ))
  );
})
SidebarInset.displayName = "SidebarInset"

const SidebarInput = React.forwardRef(({ className, ...props }, ref) => {
  return (
    (_jsxDEV(Input, {
      ref: ref,
      'data-sidebar': "input",
      className: cn(
        "h-8 w-full bg-background shadow-none focus-visible:ring-2 focus-visible:ring-sidebar-ring",
        className
      ),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 289}, this ))
  );
})
SidebarInput.displayName = "SidebarInput"

const SidebarHeader = React.forwardRef(({ className, ...props }, ref) => {
  return (
    (_jsxDEV('div', {
      ref: ref,
      'data-sidebar': "header",
      className: cn("flex flex-col gap-2 p-2", className),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 303}, this ))
  );
})
SidebarHeader.displayName = "SidebarHeader"

const SidebarFooter = React.forwardRef(({ className, ...props }, ref) => {
  return (
    (_jsxDEV('div', {
      ref: ref,
      'data-sidebar': "footer",
      className: cn("flex flex-col gap-2 p-2", className),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 314}, this ))
  );
})
SidebarFooter.displayName = "SidebarFooter"

const SidebarSeparator = React.forwardRef(({ className, ...props }, ref) => {
  return (
    (_jsxDEV(Separator, {
      ref: ref,
      'data-sidebar': "separator",
      className: cn("mx-2 w-auto bg-sidebar-border", className),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 325}, this ))
  );
})
SidebarSeparator.displayName = "SidebarSeparator"

const SidebarContent = React.forwardRef(({ className, ...props }, ref) => {
  return (
    (_jsxDEV('div', {
      ref: ref,
      'data-sidebar': "content",
      className: cn(
        "flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden",
        className
      ),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 336}, this ))
  );
})
SidebarContent.displayName = "SidebarContent"

const SidebarGroup = React.forwardRef(({ className, ...props }, ref) => {
  return (
    (_jsxDEV('div', {
      ref: ref,
      'data-sidebar': "group",
      className: cn("relative flex w-full min-w-0 flex-col p-2", className),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 350}, this ))
  );
})
SidebarGroup.displayName = "SidebarGroup"

const SidebarGroupLabel = React.forwardRef(({ className, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "div"

  return (
    (_jsxDEV(Comp, {
      ref: ref,
      'data-sidebar': "group-label",
      className: cn(
        "flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 outline-none ring-sidebar-ring transition-[margin,opacity] duration-200 ease-linear focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
        "group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0",
        className
      ),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 363}, this ))
  );
})
SidebarGroupLabel.displayName = "SidebarGroupLabel"

const SidebarGroupAction = React.forwardRef(({ className, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button"

  return (
    (_jsxDEV(Comp, {
      ref: ref,
      'data-sidebar': "group-action",
      className: cn(
        "absolute right-3 top-3.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
        // Increases the hit area of the button on mobile.
        "after:absolute after:-inset-2 after:md:hidden",
        "group-data-[collapsible=icon]:hidden",
        className
      ),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 380}, this ))
  );
})
SidebarGroupAction.displayName = "SidebarGroupAction"

const SidebarGroupContent = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('div', {
    ref: ref,
    'data-sidebar': "group-content",
    className: cn("w-full text-sm", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 396}, this )
))
SidebarGroupContent.displayName = "SidebarGroupContent"

const SidebarMenu = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('ul', {
    ref: ref,
    'data-sidebar': "menu",
    className: cn("flex w-full min-w-0 flex-col gap-1", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 405}, this )
))
SidebarMenu.displayName = "SidebarMenu"

const SidebarMenuItem = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('li', {
    ref: ref,
    'data-sidebar': "menu-item",
    className: cn("group/menu-item relative", className),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 414}, this )
))
SidebarMenuItem.displayName = "SidebarMenuItem"

const sidebarMenuButtonVariants = cva(
  "peer/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-none ring-sidebar-ring transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 group-has-[[data-sidebar=menu-action]]/menu-item:pr-8 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground group-data-[collapsible=icon]:!size-8 group-data-[collapsible=icon]:!p-2 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
        outline:
          "bg-background shadow-[0_0_0_1px_hsl(var(--sidebar-border))] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_hsl(var(--sidebar-accent))]",
      },
      size: {
        default: "h-8 text-sm",
        sm: "h-7 text-xs",
        lg: "h-12 text-sm group-data-[collapsible=icon]:!p-0",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

const SidebarMenuButton = React.forwardRef((
  {
    asChild = false,
    isActive = false,
    variant = "default",
    size = "default",
    tooltip,
    className,
    ...props
  },
  ref
) => {
  const Comp = asChild ? Slot : "button"
  const { isMobile, state } = useSidebar()

  const button = (
    _jsxDEV(Comp, {
      ref: ref,
      'data-sidebar': "menu-button",
      'data-size': size,
      'data-active': isActive,
      className: cn(sidebarMenuButtonVariants({ variant, size }), className),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 460}, this )
  )

  if (!tooltip) {
    return button
  }

  if (typeof tooltip === "string") {
    tooltip = {
      children: tooltip,
    }
  }

  return (
    (_jsxDEV(Tooltip, { children: [
      _jsxDEV(TooltipTrigger, { asChild: true, children: button}, void 0, false, {fileName: _jsxFileName, lineNumber: 481}, this)
      , _jsxDEV(TooltipContent, {
        side: "right",
        align: "center",
        hidden: state !== "collapsed" || isMobile,
        ...tooltip,}, void 0, false, {fileName: _jsxFileName, lineNumber: 482}, this )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 480}, this))
  );
})
SidebarMenuButton.displayName = "SidebarMenuButton"

const SidebarMenuAction = React.forwardRef(({ className, asChild = false, showOnHover = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button"

  return (
    (_jsxDEV(Comp, {
      ref: ref,
      'data-sidebar': "menu-action",
      className: cn(
        "absolute right-1 top-1.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 peer-hover/menu-button:text-sidebar-accent-foreground [&>svg]:size-4 [&>svg]:shrink-0",
        // Increases the hit area of the button on mobile.
        "after:absolute after:-inset-2 after:md:hidden",
        "peer-data-[size=sm]/menu-button:top-1",
        "peer-data-[size=default]/menu-button:top-1.5",
        "peer-data-[size=lg]/menu-button:top-2.5",
        "group-data-[collapsible=icon]:hidden",
        showOnHover &&
        "group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 data-[state=open]:opacity-100 peer-data-[active=true]/menu-button:text-sidebar-accent-foreground md:opacity-0",
        className
      ),
      ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 496}, this ))
  );
})
SidebarMenuAction.displayName = "SidebarMenuAction"

const SidebarMenuBadge = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('div', {
    ref: ref,
    'data-sidebar': "menu-badge",
    className: cn(
      "pointer-events-none absolute right-1 flex h-5 min-w-5 select-none items-center justify-center rounded-md px-1 text-xs font-medium tabular-nums text-sidebar-foreground",
      "peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[active=true]/menu-button:text-sidebar-accent-foreground",
      "peer-data-[size=sm]/menu-button:top-1",
      "peer-data-[size=default]/menu-button:top-1.5",
      "peer-data-[size=lg]/menu-button:top-2.5",
      "group-data-[collapsible=icon]:hidden",
      className
    ),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 517}, this )
))
SidebarMenuBadge.displayName = "SidebarMenuBadge"

const SidebarMenuSkeleton = React.forwardRef(({ className, showIcon = false, ...props }, ref) => {
  // Random width between 50 to 90%.
  const width = React.useMemo(() => {
    return `${Math.floor(Math.random() * 40) + 50}%`;
  }, [])

  return (
    (_jsxDEV('div', {
      ref: ref,
      'data-sidebar': "menu-skeleton",
      className: cn("flex h-8 items-center gap-2 rounded-md px-2", className),
      ...props, children: [
      showIcon && (
        _jsxDEV(Skeleton, { className: "size-4 rounded-md" , 'data-sidebar': "menu-skeleton-icon",}, void 0, false, {fileName: _jsxFileName, lineNumber: 546}, this )
      )
      , _jsxDEV(Skeleton, {
        className: "h-4 max-w-[--skeleton-width] flex-1"  ,
        'data-sidebar': "menu-skeleton-text",
        style: 
          {
            "--skeleton-width": width
          }
        ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 548}, this )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 540}, this))
  );
})
SidebarMenuSkeleton.displayName = "SidebarMenuSkeleton"

const SidebarMenuSub = React.forwardRef(({ className, ...props }, ref) => (
  _jsxDEV('ul', {
    ref: ref,
    'data-sidebar': "menu-sub",
    className: cn(
      "mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5",
      "group-data-[collapsible=icon]:hidden",
      className
    ),
    ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 562}, this )
))
SidebarMenuSub.displayName = "SidebarMenuSub"

const SidebarMenuSubItem = React.forwardRef(({ ...props }, ref) => _jsxDEV('li', { ref: ref, ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 574}, this ))
SidebarMenuSubItem.displayName = "SidebarMenuSubItem"

const SidebarMenuSubButton = React.forwardRef(
  ({ asChild = false, size = "md", isActive, className, ...props }, ref) => {
    const Comp = asChild ? Slot : "a"

    return (
      (_jsxDEV(Comp, {
        ref: ref,
        'data-sidebar': "menu-sub-button",
        'data-size': size,
        'data-active': isActive,
        className: cn(
          "flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 text-sidebar-foreground outline-none ring-sidebar-ring hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0 [&>svg]:text-sidebar-accent-foreground",
          "data-[active=true]:bg-sidebar-accent data-[active=true]:text-sidebar-accent-foreground",
          size === "sm" && "text-xs",
          size === "md" && "text-sm",
          "group-data-[collapsible=icon]:hidden",
          className
        ),
        ...props,}, void 0, false, {fileName: _jsxFileName, lineNumber: 582}, this ))
    );
  }
)
SidebarMenuSubButton.displayName = "SidebarMenuSubButton"

export {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInput,
  SidebarInset,
  SidebarMenu,
  SidebarMenuAction,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSkeleton,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarProvider,
  SidebarRail,
  SidebarSeparator,
  SidebarTrigger,
  useSidebar,
}
