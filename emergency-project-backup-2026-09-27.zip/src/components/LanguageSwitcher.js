const _jsxFileName = "src/components/LanguageSwitcher.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useRef, useEffect } from 'react';
import { Globe, Check } from 'lucide-react';
import { useLanguage, LANGUAGES } from '../lib/i18n.js';

export default function LanguageSwitcher({ compact = false }) {
  const { lang, setLang } = useLanguage();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const current = LANGUAGES.find((l) => l.code === lang) || LANGUAGES[1];

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    _jsxDEV('div', { className: "relative", ref: ref, children: [
      _jsxDEV('button', {
        onClick: () => setOpen(!open),
        className: "flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-sm font-medium hover:bg-accent transition-colors"            ,
 children: [
        _jsxDEV(Globe, { className: "h-4 w-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 25}, this )
        , _jsxDEV('span', { className: "text-lg leading-none" , children: current.flag}, void 0, false, {fileName: _jsxFileName, lineNumber: 26}, this)
        , !compact && _jsxDEV('span', { className: "hidden sm:inline" , children: current.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 27}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 21}, this)
      , open && (
        _jsxDEV('div', { className: "absolute end-0 mt-2 w-44 rounded-lg border border-border bg-popover shadow-lg z-50 overflow-hidden"          , children: 
          LANGUAGES.map((l) => (
            _jsxDEV('button', {

              onClick: () => {
                setLang(l.code);
                setOpen(false);
              },
              className: `flex items-center gap-3 w-full px-4 py-2.5 text-sm hover:bg-accent transition-colors ${
                lang === l.code ? 'bg-accent/50 font-semibold' : ''
              }`,
 children: [
              _jsxDEV('span', { className: "text-lg leading-none" , children: l.flag}, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this)
              , _jsxDEV('span', { className: "flex-1 text-start" , children: l.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this)
              , lang === l.code && _jsxDEV(Check, { className: "h-4 w-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 44}, this )
            ]}, l.code, true, {fileName: _jsxFileName, lineNumber: 32}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 30}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 20}, this)
  );
}