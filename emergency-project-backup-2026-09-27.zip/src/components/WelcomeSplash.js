const _jsxFileName = "src/components/WelcomeSplash.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { Coins } from 'lucide-react';

export default function WelcomeSplash({ onDone, message = 'به همراه ما خوش آمدید' }) {
  const [progress, setProgress] = useState(1);

  useEffect(() => {
    // Remove the HTML splash overlay so React takes over
    const el = document.getElementById('custom-splash-overlay');
    if (el) el.remove();

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => _optionalChain([onDone, 'optionalCall', _ => _()]), 200);
          return 100;
        }
        return prev + 2;
      });
    }, 30);
    return () => clearInterval(interval);
  }, [onDone]);

  return (
    _jsxDEV('div', { className: "min-h-screen bg-gradient-to-br from-background via-primary/5 to-muted/30 flex flex-col items-center justify-center p-6"         , children: [
      _jsxDEV('div', { className: "w-full max-w-sm flex flex-col items-center gap-6"     , children: [
        /* Logo */
        _jsxDEV('div', { className: "w-24 h-24 rounded-3xl bg-primary flex items-center justify-center shadow-xl"       , children: 
          _jsxDEV(Coins, { className: "w-12 h-12 text-primary-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 30}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 29}, this)

        /* Welcome text */
        , _jsxDEV('div', { className: "text-center space-y-1.5" , children: [
          _jsxDEV('h1', { className: "text-2xl font-bold" , children: message}, void 0, false, {fileName: _jsxFileName, lineNumber: 35}, this)
          , _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "در حال بارگذاری برنامه..."   }, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 34}, this)

        /* Counter 1-100 */
        , _jsxDEV('div', { className: "w-full space-y-2" , children: [
          _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
            _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: "پیشرفت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this)
            , _jsxDEV('span', { className: "text-2xl font-bold text-primary tabular-nums"   , children: [progress, "%"]}, void 0, true, {fileName: _jsxFileName, lineNumber: 43}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 41}, this)
          , _jsxDEV('div', { className: "h-2.5 rounded-full bg-muted overflow-hidden"   , children: 
            _jsxDEV('div', {
              className: "h-full bg-primary rounded-full transition-all duration-100 ease-linear"     ,
              style: { width: `${progress}%` },}, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this
            )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 45}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 40}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 27}, this)

      , _jsxDEV('p', { className: "text-xs text-muted-foreground/50 mt-10"  , children: ["© " , new Date().getFullYear(), " همراه ما"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 54}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 26}, this)
  );
}