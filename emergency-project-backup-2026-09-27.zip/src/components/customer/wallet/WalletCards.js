const _jsxFileName = "src/components/customer/wallet/WalletCards.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React from 'react';
import { Card, CardContent } from '../../ui/card.js';
import { Banknote, DollarSign, Coins, Bitcoin, ChevronLeft } from 'lucide-react';

const CURRENCIES = [
  { code: 'AFN', name: 'افغانی', symbol: '؋', Icon: Banknote, gradient: 'from-blue-500 to-blue-600' },
  { code: 'USD', name: 'دلار آمریکا', symbol: '$', Icon: DollarSign, gradient: 'from-green-500 to-green-600' },
  { code: 'IRT', name: 'تومان', symbol: 'ت', Icon: Coins, gradient: 'from-amber-500 to-amber-600' },
  { code: 'USDT', name: 'تتر', symbol: '₮', Icon: Bitcoin, gradient: 'from-teal-500 to-teal-600' },
];

const WALLET_STATUS = {
  active: { label: 'فعال', color: 'bg-success/10 text-success' },
  inactive: { label: 'غیرفعال', color: 'bg-muted text-muted-foreground' },
};

function isCredit(t) {
  return ['receive', 'recharge', 'buy', 'correction'].includes(t.type);
}

export default function WalletCards({ wallets, transactions, rates, onWalletClick }) {
  const getWallet = (code) => wallets.find((w) => w.currency === code);
  const getLastTxn = (code) => transactions.find((t) => t.currency === code);

  const calculateTotal = () => {
    if (!rates || rates.length === 0) return null;
    const rateMap = {};
    rates.forEach((r) => { rateMap[r.currency] = r; });
    let total = 0;
    for (const w of wallets) {
      if (w.currency === 'AFN') {
        total += w.balance || 0;
      } else {
        const rate = rateMap[w.currency];
        if (!rate) return null;
        total += (w.balance || 0) * (rate.sell_rate || rate.buy_rate || 1);
      }
    }
    return total;
  };

  const totalValue = calculateTotal();

  return (
    _jsxDEV('div', { className: "space-y-3", children: [
      /* Summary Card */
      _jsxDEV(Card, { className: "shadow-md border-primary/20" , children: 
        _jsxDEV(CardContent, { className: "p-4", children: [
          _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-1"  , children: "مجموع ارزش دارایی‌ها"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this)
          , totalValue !== null ? (
            _jsxDEV('p', { className: "text-xl font-bold text-foreground"  , children: [
              Math.round(totalValue).toLocaleString('fa-IR'), ' '
              , _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: "افغانی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 53}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 51}, this)
          ) : (
            _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "برای محاسبه مجموع ارزش، نرخ تبدیل کافی موجود نیست"

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 48}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 47}, this)

      /* Currency Cards */
      , _jsxDEV('div', { className: "grid grid-cols-2 md:grid-cols-4 gap-3"   , children: 
        CURRENCIES.map((curr) => {
          const wallet = getWallet(curr.code);
          const lastTxn = getLastTxn(curr.code);
          const Icon = curr.Icon;
          const status = wallet ? (WALLET_STATUS[wallet.status] || WALLET_STATUS.active) : null;
          return (
            _jsxDEV('button', {

              onClick: () => onWalletClick(curr.code),
              className: "text-right",
 children: 
              _jsxDEV(Card, { className: "shadow-sm hover:shadow-md transition-shadow h-full"   , children: 
                _jsxDEV(CardContent, { className: "p-3", children: [
                  _jsxDEV('div', { className: "flex items-center justify-between mb-2"   , children: [
                    _jsxDEV('div', { className: `w-9 h-9 rounded-lg bg-gradient-to-br ${curr.gradient} flex items-center justify-center`, children: 
                      _jsxDEV(Icon, { className: "w-5 h-5 text-white"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this)
                    , status && (
                      _jsxDEV('span', { className: `text-[8px] px-1.5 py-0.5 rounded ${status.color}`, children: 
                        status.label
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this)
                    )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 78}, this)
                  , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: curr.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)
                  , wallet ? (
                    _jsxDEV(_Fragment, { children: [
                      _jsxDEV('p', { className: "text-base font-bold text-foreground truncate"   , children: 
                        (wallet.balance || 0).toLocaleString('fa-IR')
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 91}, this)
                      , _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: [
                        curr.symbol, " " , curr.code
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 94}, this)
                      , lastTxn && (
                        _jsxDEV('p', { className: `text-[9px] mt-1 ${isCredit(lastTxn) ? 'text-success' : 'text-destructive'}`, children: [
                          isCredit(lastTxn) ? '+' : '-'
                          , (lastTxn.amount || 0).toLocaleString('fa-IR')
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 98}, this)
                      )
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 90}, this)
                  ) : (
                    _jsxDEV('p', { className: "text-[10px] text-muted-foreground leading-tight"  , children: "هنوز کیف پولی برای این ارز ثبت نشده است"

                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this)
                  )
                  , _jsxDEV('div', { className: "flex items-center justify-end gap-0.5 mt-2 pt-2 border-t border-border"       , children: [
                    _jsxDEV('span', { className: "text-[9px] text-primary font-medium"  , children: "مشاهده جزئیات" }, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this)
                    , _jsxDEV(ChevronLeft, { className: "w-3 h-3 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 109}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 77}, this)
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)
            }, curr.code, false, {fileName: _jsxFileName, lineNumber: 71}, this)
          );
        })
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 45}, this)
  );
}