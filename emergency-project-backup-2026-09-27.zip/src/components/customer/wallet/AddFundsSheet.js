const _jsxFileName = "src/components/customer/wallet/AddFundsSheet.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '../../ui/sheet.js';
import { Button } from '../../ui/button.js';
import { Input } from '../../ui/input.js';
import { Label } from '../../ui/label.js';
import { useToast } from '../../ui/use-toast.js';
import { offlineDB } from '../../../lib/offlineQueue.js';
import { callSupabase } from '../../../lib/supabaseApi.js';
import {
  Landmark, Globe, Bitcoin, CreditCard, Camera, X, CheckCircle, Loader2,
  AlertCircle, Copy,
} from 'lucide-react';
import { Image } from '../../ui/image.js';
import { AmountInput } from '../../sarraaf/Fields.js';

const CURRENCIES = [
  { code: 'AFN', label: 'افغانی' },
  { code: 'USD', label: 'دلار' },
  { code: 'IRT', label: 'تومان' },
  { code: 'USDT', label: 'تتر' },
];

const METHOD_DEFS = [
  { key: 'payment_card', label: 'کارت به کارت', icon: CreditCard, color: 'bg-purple-500' },
  { key: 'payment_bank', label: 'انتقال بانکی', icon: Landmark, color: 'bg-blue-500' },
  { key: 'payment_paypal', label: 'پی‌پل', icon: Globe, color: 'bg-indigo-500' },
  { key: 'payment_crypto', label: 'ارز دیجیتال', icon: Bitcoin, color: 'bg-amber-500' },
];

export default function AddFundsSheet({ open, onOpenChange, user }) {
  const { toast } = useToast();
  const [method, setMethod] = useState(null);
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('AFN');
  const [cardNumber, setCardNumber] = useState('');
  const [description, setDescription] = useState('');
  const [receiptUrl, setReceiptUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [methodStatuses, setMethodStatuses] = useState({});
  const [methodConfigs, setMethodConfigs] = useState({});

  useEffect(() => {
    const load = async () => {
      const statuses = {};
      const configs = {};
      try {
        const features = await offlineDB.FeatureSetting.list();
        for (const def of METHOD_DEFS) {
          const f = features.find(fx => fx.feature_key === def.key);
          statuses[def.key] = f ? (f.enabled !== false && f.status === 'active' ? 'active' : f.status || 'updating') : 'updating';
        }
        const settings = await offlineDB.AppSetting.list();
        for (const def of METHOD_DEFS) {
          const s = settings.find(sx => sx.key === `${def.key}_config`);
          configs[def.key] = _optionalChain([s, 'optionalAccess', _ => _.data]) || {};
        }
      } catch (e2) {
        // default all to updating
        for (const def of METHOD_DEFS) statuses[def.key] = 'updating';
      }
      setMethodStatuses(statuses);
      setMethodConfigs(configs);
    };
    if (open) load();
  }, [open]);

  const reset = () => {
    setMethod(null);
    setAmount('');
    setCurrency('AFN');
    setCardNumber('');
    setDescription('');
    setReceiptUrl('');
    setDone(false);
  };

  const handleClose = (v) => {
    if (!v) reset();
    onOpenChange(v);
  };

  const handleFile = async (e) => {
    const file = _optionalChain([e, 'access', _2 => _2.target, 'access', _3 => _3.files, 'optionalAccess', _4 => _4[0]]);
    if (!file) return;
    setUploading(true);
    try {
      // Convert file to base64 and upload via backend function
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          const base64Data = reader.result.split(',')[1];
          const res = await callSupabase('uploadFile', {
            file_data: base64Data,
            file_name: file.name,
            content_type: file.type,
          });
          if (_optionalChain([res, 'optionalAccess', _5 => _5.success]) && _optionalChain([res, 'optionalAccess', _6 => _6.result, 'optionalAccess', _7 => _7.file_url])) {
            setReceiptUrl(res.result.file_url);
            toast({ title: 'عکس رسید آپلود شد' });
          } else {
            toast({ title: 'خطا در آپلود عکس', variant: 'destructive' });
          }
        } catch (e3) {
          toast({ title: 'خطا در آپلود عکس', variant: 'destructive' });
        }
        setUploading(false);
      };
      reader.readAsDataURL(file);
    } catch (e4) {
      toast({ title: 'خطا در آپلود عکس', variant: 'destructive' });
      setUploading(false);
    }
  };

  const numAmount = parseFloat(amount) || 0;

  const validate = () => {
    if (numAmount <= 0) return 'مبلغ معتبر وارد کنید.';
    if (method === 'payment_card' && !receiptUrl) return 'عکس رسید را آپلود کنید.';
    return null;
  };

  const handleSubmit = async () => {
    const err = validate();
    if (err) {
      toast({ title: err, variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    try {
      const methodMap = {
        payment_card: 'card_to_card',
        payment_bank: 'bank_gateway',
        payment_paypal: 'bank_gateway',
        payment_crypto: 'bank_gateway',
      };
      await offlineDB.WalletTopupRequest.create({
        user_id: _optionalChain([user, 'optionalAccess', _8 => _8.id]) || '',
        user_name: _optionalChain([user, 'optionalAccess', _9 => _9.full_name]) || '',
        phone: _optionalChain([user, 'optionalAccess', _10 => _10.mobile]) || '',
        amount: numAmount,
        currency,
        method: methodMap[method] || 'card_to_card',
        card_number: method === 'payment_card' ? cardNumber : '',
        receipt_url: method === 'payment_card' ? receiptUrl : '',
        description: `${_optionalChain([METHOD_DEFS, 'access', _11 => _11.find, 'call', _12 => _12(m => m.key === method), 'optionalAccess', _13 => _13.label])} — ${description}`,
        status: 'pending',
      });
      setDone(true);
      toast({ title: 'درخواست شارژ ثبت شد', description: 'تا تأیید سازنده صبر کنید.' });
    } catch (e5) {
      toast({ title: 'خطا در ثبت درخواست', variant: 'destructive' });
    }
    setSubmitting(false);
  };

  const copyText = (text) => {
    _optionalChain([navigator, 'access', _14 => _14.clipboard, 'optionalAccess', _15 => _15.writeText, 'call', _16 => _16(text)]);
    toast({ title: 'کپی شد' });
  };

  const activeMethods = METHOD_DEFS.filter(m => methodStatuses[m.key] === 'active');
  const updatingMethods = METHOD_DEFS.filter(m => methodStatuses[m.key] !== 'active');

  return (
    _jsxDEV(Sheet, { open: open, onOpenChange: handleClose, children: 
      _jsxDEV(SheetContent, { side: "bottom", className: "max-h-[85vh] overflow-y-auto" , children: [
        _jsxDEV(SheetHeader, { children: [
          _jsxDEV(SheetTitle, { children: "افزودن موجودی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 171}, this)
          , _jsxDEV(SheetDescription, { children: "روش پرداخت را انتخاب کنید"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 172}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 170}, this)

        , done ? (
          _jsxDEV('div', { className: "py-8 text-center space-y-3"  , children: [
            _jsxDEV(CheckCircle, { className: "w-12 h-12 text-success mx-auto"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 177}, this )
            , _jsxDEV('p', { className: "text-sm font-medium" , children: "درخواست شارژ ثبت شد!"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this)
            , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "درخواست شما برای بررسی به سازنده ارسال شد. پس از تأیید، مبلغ به حساب شما اضافه می‌شود."

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this)
            , _jsxDEV(Button, { onClick: () => handleClose(false), className: "w-full", children: "بستن"}, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 176}, this)
        ) : !method ? (
          _jsxDEV('div', { className: "space-y-3 pt-4" , children: [
            /* Active methods */
            activeMethods.map((m) => {
              const Icon = m.icon;
              return (
                _jsxDEV('button', {

                  onClick: () => setMethod(m.key),
                  className: "w-full p-4 rounded-xl border border-border hover:border-primary hover:bg-primary/5 transition-all text-right flex items-center gap-3"           ,
 children: [
                  _jsxDEV('div', { className: `w-10 h-10 rounded-lg ${m.color} flex items-center justify-center`, children: 
                    _jsxDEV(Icon, { className: "w-5 h-5 text-white"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 196}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 195}, this)
                  , _jsxDEV('div', { className: "flex-1", children: [
                    _jsxDEV('p', { className: "text-sm font-bold" , children: m.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 199}, this)
                    , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: [
                      m.key === 'payment_card' && 'عکس رسید را آپلود کنید'
                      , m.key === 'payment_bank' && (_optionalChain([methodConfigs, 'access', _17 => _17[m.key], 'optionalAccess', _18 => _18.bank_name]) ? `بانک: ${methodConfigs[m.key].bank_name}` : 'انتقال به حساب بانکی')
                      , m.key === 'payment_paypal' && (_optionalChain([methodConfigs, 'access', _19 => _19[m.key], 'optionalAccess', _20 => _20.paypal_email]) ? methodConfigs[m.key].paypal_email : 'پرداخت از طریق پی‌پل')
                      , m.key === 'payment_crypto' && (_optionalChain([methodConfigs, 'access', _21 => _21[m.key], 'optionalAccess', _22 => _22.network]) ? `شبکه: ${methodConfigs[m.key].network}` : 'پرداخت با ارز دیجیتال')
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 200}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 198}, this)
                ]}, m.key, true, {fileName: _jsxFileName, lineNumber: 190}, this)
              );
            })

            /* Updating methods */
            , updatingMethods.length > 0 && (
              _jsxDEV('div', { className: "pt-2", children: [
                _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-2"  , children: "روش‌های در حال به‌روزرسانی:"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 214}, this)
                , updatingMethods.map((m) => {
                  const Icon = m.icon;
                  return (
                    _jsxDEV('div', { className: "w-full p-4 rounded-xl border border-border opacity-50 flex items-center gap-3 mb-2"         , children: [
                      _jsxDEV('div', { className: `w-10 h-10 rounded-lg ${m.color} flex items-center justify-center`, children: 
                        _jsxDEV(Icon, { className: "w-5 h-5 text-white"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 220}, this )
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 219}, this)
                      , _jsxDEV('div', { className: "flex-1", children: [
                        _jsxDEV('p', { className: "text-sm font-bold" , children: m.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this)
                        , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "در حال به‌روزرسانی..."  }, void 0, false, {fileName: _jsxFileName, lineNumber: 224}, this)
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 222}, this)
                      , _jsxDEV(AlertCircle, { className: "w-4 h-4 text-warning"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 226}, this )
                    ]}, m.key, true, {fileName: _jsxFileName, lineNumber: 218}, this)
                  );
                })
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 213}, this)
            )

            , activeMethods.length === 0 && (
              _jsxDEV('div', { className: "py-8 text-center" , children: [
                _jsxDEV(AlertCircle, { className: "w-10 h-10 text-muted-foreground mx-auto mb-2"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 235}, this )
                , _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "فعلاً هیچ روش پرداختی فعال نیست."     }, void 0, false, {fileName: _jsxFileName, lineNumber: 236}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 234}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 185}, this)
        ) : (
          _jsxDEV('div', { className: "space-y-4 pt-4" , children: [
            /* Method badge */
            _jsxDEV('div', { className: "flex items-center gap-2 p-2 rounded-lg bg-muted/50"     , children: [
              (() => {
                const def = METHOD_DEFS.find(m => m.key === method);
                const Icon = _optionalChain([def, 'optionalAccess', _23 => _23.icon]);
                return Icon ? _jsxDEV(Icon, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 247}, this ) : null;
              })()
              , _jsxDEV('span', { className: "text-xs font-medium" , children: _optionalChain([METHOD_DEFS, 'access', _24 => _24.find, 'call', _25 => _25(m => m.key === method), 'optionalAccess', _26 => _26.label])}, void 0, false, {fileName: _jsxFileName, lineNumber: 249}, this)
              , _jsxDEV('button', { onClick: () => setMethod(null), className: "mr-auto", children: 
                _jsxDEV(X, { className: "w-4 h-4 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 251}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 250}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 243}, this)

            /* Amount */
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "مبلغ"}, void 0, false, {fileName: _jsxFileName, lineNumber: 257}, this)
              , _jsxDEV(AmountInput, { value: amount, onChange: setAmount, placeholder: "0",}, void 0, false, {fileName: _jsxFileName, lineNumber: 258}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 256}, this)

            /* Currency */
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "ارز"}, void 0, false, {fileName: _jsxFileName, lineNumber: 263}, this)
              , _jsxDEV('div', { className: "grid grid-cols-4 gap-2 mt-1"   , children: 
                CURRENCIES.map((c) => (
                  _jsxDEV('button', { onClick: () => setCurrency(c.code),
                    className: `p-2 rounded-lg border text-center text-xs font-medium ${currency === c.code ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'}`, children: 
                    c.code
                  }, c.code, false, {fileName: _jsxFileName, lineNumber: 266}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 264}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 262}, this)

            /* Method-specific config display */
            , method !== 'payment_card' && methodConfigs[method] && (
              _jsxDEV('div', { className: "rounded-lg bg-muted/50 border border-border p-3 space-y-2"     , children: [
                _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-1"  , children: "اطلاعات پرداخت:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 277}, this)
                , method === 'payment_bank' && methodConfigs[method].bank_name && (
                  _jsxDEV(_Fragment, { children: [
                    _jsxDEV(InfoRow, { label: "بانک", value: methodConfigs[method].bank_name, onCopy: copyText,}, void 0, false, {fileName: _jsxFileName, lineNumber: 280}, this )
                    , methodConfigs[method].account_number && _jsxDEV(InfoRow, { label: "شماره حساب" , value: methodConfigs[method].account_number, onCopy: copyText,}, void 0, false, {fileName: _jsxFileName, lineNumber: 281}, this )
                    , methodConfigs[method].holder_name && _jsxDEV(InfoRow, { label: "نام صاحب" , value: methodConfigs[method].holder_name, onCopy: copyText,}, void 0, false, {fileName: _jsxFileName, lineNumber: 282}, this )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 279}, this)
                )
                , method === 'payment_paypal' && methodConfigs[method].paypal_email && (
                  _jsxDEV(InfoRow, { label: "ایمیل پی‌پل" , value: methodConfigs[method].paypal_email, onCopy: copyText,}, void 0, false, {fileName: _jsxFileName, lineNumber: 286}, this )
                )
                , method === 'payment_crypto' && (
                  _jsxDEV(_Fragment, { children: [
                    methodConfigs[method].wallet_address && _jsxDEV(InfoRow, { label: "آدرس کیف پول"  , value: methodConfigs[method].wallet_address, onCopy: copyText,}, void 0, false, {fileName: _jsxFileName, lineNumber: 290}, this )
                    , methodConfigs[method].network && _jsxDEV(InfoRow, { label: "شبکه", value: methodConfigs[method].network, onCopy: copyText,}, void 0, false, {fileName: _jsxFileName, lineNumber: 291}, this )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 289}, this)
                )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 276}, this)
            )

            /* Card-to-card specific */
            , method === 'payment_card' && (
              _jsxDEV(_Fragment, { children: [
                _jsxDEV('div', { children: [
                  _jsxDEV(Label, { className: "text-xs", children: "شماره کارت (اختیاری)"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 301}, this)
                  , _jsxDEV(Input, { placeholder: "****-****-****-****", value: cardNumber, onChange: (e) => setCardNumber(e.target.value), dir: "ltr", className: "text-sm mt-1" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 302}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 300}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { className: "text-xs", children: "عکس رسید" }, void 0, false, {fileName: _jsxFileName, lineNumber: 305}, this)
                  , receiptUrl ? (
                    _jsxDEV('div', { className: "relative mt-1" , children: [
                      _jsxDEV(Image, { src: receiptUrl, alt: "رسید", fittingType: "fit", className: "w-full h-40 object-contain rounded-lg border"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 308}, this )
                      , _jsxDEV('button', { onClick: () => setReceiptUrl(''), className: "absolute top-1 right-1 p-1 rounded-full bg-destructive text-destructive-foreground"      , children: 
                        _jsxDEV(X, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 310}, this )
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 309}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 307}, this)
                  ) : (
                    _jsxDEV('label', { className: "mt-1 flex flex-col items-center justify-center gap-2 p-6 rounded-lg border-2 border-dashed border-border cursor-pointer hover:border-primary transition-colors"             , children: [
                      uploading ? _jsxDEV(Loader2, { className: "w-6 h-6 text-primary animate-spin"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 315}, this ) : _jsxDEV(Camera, { className: "w-6 h-6 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 315}, this )
                      , _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: uploading ? 'در حال آپلود...' : 'عکس رسید را انتخاب کنید'}, void 0, false, {fileName: _jsxFileName, lineNumber: 316}, this)
                      , _jsxDEV('input', { type: "file", accept: "image/*", onChange: handleFile, className: "hidden",}, void 0, false, {fileName: _jsxFileName, lineNumber: 317}, this )
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 314}, this)
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 304}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 299}, this)
            )

            /* Description */
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "توضیحات (اختیاری)" }, void 0, false, {fileName: _jsxFileName, lineNumber: 326}, this)
              , _jsxDEV(Input, { placeholder: "توضیحات...", value: description, onChange: (e) => setDescription(e.target.value), className: "text-sm mt-1" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 327}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 325}, this)

            , _jsxDEV('div', { className: "rounded-lg bg-warning/5 border border-warning/30 p-3"    , children: 
              _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "پس از ارسال درخواست، سازنده رسید/پرداخت شما را بررسی کرده و مبلغ را به حساب شما اضافه می‌کند."

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 331}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 330}, this)

            , _jsxDEV(Button, { onClick: handleSubmit, className: "w-full", disabled: submitting || uploading || numAmount <= 0, children: [
              submitting ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 337}, this ) : null, "ثبت درخواست شارژ"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 336}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 241}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 169}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this)
  );
}

function InfoRow({ label, value, onCopy }) {
  return (
    _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
      _jsxDEV('span', { className: "text-xs text-muted-foreground w-20 shrink-0"   , children: [label, ":"]}, void 0, true, {fileName: _jsxFileName, lineNumber: 350}, this)
      , _jsxDEV('span', { className: "text-xs font-medium flex-1 truncate"   , dir: "ltr", children: value}, void 0, false, {fileName: _jsxFileName, lineNumber: 351}, this)
      , _jsxDEV('button', { onClick: () => onCopy(value), className: "p-1 rounded hover:bg-muted shrink-0"   , children: 
        _jsxDEV(Copy, { className: "w-3 h-3 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 353}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 352}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 349}, this)
  );
}