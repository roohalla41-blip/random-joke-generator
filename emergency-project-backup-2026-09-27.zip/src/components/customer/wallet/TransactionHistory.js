const _jsxFileName = "src/components/customer/wallet/TransactionHistory.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useMemo } from 'react';
import { Card, CardContent } from '../../ui/card.js';
import { Input } from '../../ui/input.js';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from '../../ui/sheet.js';
import {
  ArrowDownCircle, ArrowUpCircle, ChevronLeft, Calendar,
} from 'lucide-react';

const TXN_TYPE_LABELS = {
  receive: 'دریافت',
  pay: 'پرداخت',
  transfer: 'انتقال',
  buy: 'خرید',
  sell: 'فروش',
  convert: 'تبدیل ارز',
  recharge: 'شارژ',
  withdraw: 'برداشت',
  correction: 'اصلاح حساب',
  other: 'سایر',
};

const TXN_FILTERS = [
  { value: 'all', label: 'همه' },
  { value: 'receive', label: 'دریافت' },
  { value: 'pay', label: 'پرداخت' },
  { value: 'transfer', label: 'انتقال' },
  { value: 'buy', label: 'خرید' },
  { value: 'sell', label: 'فروش' },
  { value: 'convert', label: 'تبدیل' },
  { value: 'recharge', label: 'شارژ' },
  { value: 'withdraw', label: 'برداشت' },
  { value: 'correction', label: 'اصلاح حساب' },
  { value: 'other', label: 'سایر' },
];

const CURRENCY_FILTERS = [
  { value: 'all', label: 'همه ارزها' },
  { value: 'AFN', label: 'AFN' },
  { value: 'USD', label: 'USD' },
  { value: 'IRT', label: 'تومان' },
  { value: 'USDT', label: 'USDT' },
];

const STATUS_FILTERS = [
  { value: 'all', label: 'همه وضعیت‌ها' },
  { value: 'pending', label: 'در انتظار بررسی' },
  { value: 'approved', label: 'تأیید شده' },
  { value: 'processing', label: 'در حال انجام' },
  { value: 'completed', label: 'تکمیل شده' },
  { value: 'rejected', label: 'رد شده' },
  { value: 'cancelled', label: 'لغو شده' },
];

const STATUS_MAP = {
  pending: { label: 'در انتظار بررسی', color: 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400' },
  approved: { label: 'تأیید شده', color: 'bg-blue-100 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400' },
  processing: { label: 'در حال انجام', color: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/30 dark:text-cyan-400' },
  completed: { label: 'تکمیل شده', color: 'bg-success/15 text-success' },
  rejected: { label: 'رد شده', color: 'bg-destructive/15 text-destructive' },
  cancelled: { label: 'لغو شده', color: 'bg-muted text-muted-foreground' },
};

function isCredit(t) {
  return ['receive', 'recharge', 'buy', 'correction'].includes(t.type);
}

function getTxnTypeLabel(t) {
  return TXN_TYPE_LABELS[t.type] || 'سایر';
}

export default function TransactionHistory({ transactions }) {
  const [typeFilter, setTypeFilter] = useState('all');
  const [currencyFilter, setCurrencyFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [showDateFilter, setShowDateFilter] = useState(false);
  const [selectedTxn, setSelectedTxn] = useState(null);

  const filteredTxns = useMemo(() => {
    return transactions.filter((t) => {
      if (typeFilter !== 'all' && t.type !== typeFilter) return false;
      if (currencyFilter !== 'all' && t.currency !== currencyFilter) return false;
      if (statusFilter !== 'all' && t.status !== statusFilter) return false;
      if (dateFrom) {
        const d = new Date(t.created_date);
        const from = new Date(dateFrom);
        from.setHours(0, 0, 0, 0);
        if (d < from) return false;
      }
      if (dateTo) {
        const d = new Date(t.created_date);
        const to = new Date(dateTo);
        to.setHours(23, 59, 59, 999);
        if (d > to) return false;
      }
      if (search.trim()) {
        const q = search.toLowerCase();
        const haystack = `${t.id || ''} ${t.doc_number || ''} ${getTxnTypeLabel(t)} ${t.description || ''}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [transactions, typeFilter, currencyFilter, statusFilter, search, dateFrom, dateTo]);

  return (
    _jsxDEV('div', { className: "space-y-3", children: [
      _jsxDEV('h2', { className: "text-sm font-bold text-foreground"  , children: "گردش کیف پول"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this)

      /* Search */
      , _jsxDEV(Input, {
        placeholder: "جستجو: شماره تراکنش، شماره سند، نوع، شرح..."      ,
        value: search,
        onChange: (e) => setSearch(e.target.value),
        className: "text-xs",}, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this
      )

      /* Date Range Toggle */
      , _jsxDEV('button', {
        onClick: () => setShowDateFilter(!showDateFilter),
        className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
          showDateFilter || dateFrom || dateTo
            ? 'border-primary bg-primary/5 text-primary'
            : 'border-border text-muted-foreground'
        }`,
 children: [
        _jsxDEV(Calendar, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this ), "بازه زمانی"

      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 122}, this)
      , showDateFilter && (
        _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
          _jsxDEV(Input, { type: "date", value: dateFrom, onChange: (e) => setDateFrom(e.target.value), className: "text-xs",}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this )
          , _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: "تا"}, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this)
          , _jsxDEV(Input, { type: "date", value: dateTo, onChange: (e) => setDateTo(e.target.value), className: "text-xs",}, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 134}, this)
      )

      /* Filters */
      , _jsxDEV('div', { className: "space-y-2", children: [
        _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          TXN_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setTypeFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                typeFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 145}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this)
        , _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          CURRENCY_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setCurrencyFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                currencyFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 158}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this)
        , _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          STATUS_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setStatusFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                statusFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 171}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 169}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)

      /* Transaction List */
      , filteredTxns.length === 0 ? (
        _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-6 text-center text-sm text-muted-foreground"   , children: 
            transactions.length === 0
              ? 'هنوز تراکنشی برای نمایش وجود ندارد.'
              : 'نتیجه‌ای یافت نشد'
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 186}, this)
      ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          filteredTxns.map((t) => {
            const credit = isCredit(t);
            const date = new Date(t.created_date);
            const st = STATUS_MAP[t.status] || STATUS_MAP.pending;
            return (
              _jsxDEV(Card, {

                className: "shadow-sm cursor-pointer hover:shadow-md transition-shadow"   ,
                onClick: () => setSelectedTxn(t),
 children: 
                _jsxDEV(CardContent, { className: "p-3 flex items-center gap-3"   , children: [
                  _jsxDEV('div', { className: `w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${credit ? 'bg-success/10' : 'bg-destructive/10'}`, children: 
                    credit ? _jsxDEV(ArrowDownCircle, { className: "w-4 h-4 text-success"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 207}, this ) : _jsxDEV(ArrowUpCircle, { className: "w-4 h-4 text-destructive"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 207}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 206}, this)
                  , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
                    _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                      _jsxDEV('p', { className: "text-xs font-medium text-foreground truncate"   , children: getTxnTypeLabel(t)}, void 0, false, {fileName: _jsxFileName, lineNumber: 211}, this)
                      , _jsxDEV('span', { className: `text-[8px] px-1.5 py-0.5 rounded ${st.color}`, children: st.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 212}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 210}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground truncate"  , children: [
                      t.id
                      , date.toLocaleDateString('fa-IR')
                      , ` • ${date.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}`
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 214}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 209}, this)
                  , _jsxDEV('div', { className: "text-left shrink-0" , children: [
                    _jsxDEV('p', { className: `text-sm font-bold ${credit ? 'text-success' : 'text-destructive'}`, children: [
                      credit ? '+' : '-', (t.amount || 0).toLocaleString('fa-IR')
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 221}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: t.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 224}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 220}, this)
                  , _jsxDEV(ChevronLeft, { className: "w-4 h-4 text-muted-foreground shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 226}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 205}, this)
              }, t.id, false, {fileName: _jsxFileName, lineNumber: 200}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 194}, this)
      )

      /* Transaction Detail Sheet */
      , _jsxDEV(Sheet, { open: !!selectedTxn, onOpenChange: (open) => !open && setSelectedTxn(null), children: 
        _jsxDEV(SheetContent, { side: "bottom", className: "max-h-[85vh] overflow-y-auto" , children: [
          _jsxDEV(SheetHeader, { children: [
            _jsxDEV(SheetTitle, { children: "جزئیات تراکنش" }, void 0, false, {fileName: _jsxFileName, lineNumber: 238}, this)
            , _jsxDEV(SheetDescription, { children: selectedTxn ? getTxnTypeLabel(selectedTxn) : ''}, void 0, false, {fileName: _jsxFileName, lineNumber: 239}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 237}, this)
          , selectedTxn && (
            _jsxDEV('div', { className: "space-y-3 mt-4" , children: [
              /* Amount */
              _jsxDEV(Card, { className: "shadow-sm", children: 
                _jsxDEV(CardContent, { className: "p-4 text-center" , children: [
                  _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "مبلغ"}, void 0, false, {fileName: _jsxFileName, lineNumber: 246}, this)
                  , _jsxDEV('p', { className: `text-2xl font-bold ${isCredit(selectedTxn) ? 'text-success' : 'text-destructive'}`, children: [
                    isCredit(selectedTxn) ? '+' : '-'
                    , (selectedTxn.amount || 0).toLocaleString('fa-IR')
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 247}, this)
                  , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: selectedTxn.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 251}, this)
                  , _jsxDEV('span', { className: `inline-block mt-2 text-[9px] px-2 py-1 rounded ${(STATUS_MAP[selectedTxn.status] || STATUS_MAP.pending).color}`, children: 
                    (STATUS_MAP[selectedTxn.status] || STATUS_MAP.pending).label
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 252}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 245}, this)
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 244}, this)

              /* Details */
              , _jsxDEV(Card, { className: "shadow-sm", children: 
                _jsxDEV(CardContent, { className: "p-3 space-y-2" , children: [
                  _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "شماره تراکنش:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 262}, this)
                    , _jsxDEV('span', { className: "font-mono text-foreground text-[10px]"  , children: selectedTxn.id}, void 0, false, {fileName: _jsxFileName, lineNumber: 263}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 261}, this)
                  , selectedTxn.doc_number && (
                    _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                      _jsxDEV('span', { className: "text-muted-foreground", children: "شماره سند:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 267}, this)
                      , _jsxDEV('span', { className: "font-mono text-foreground text-[10px]"  , children: selectedTxn.doc_number}, void 0, false, {fileName: _jsxFileName, lineNumber: 268}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 266}, this)
                  )
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "نوع:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 272}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: getTxnTypeLabel(selectedTxn)}, void 0, false, {fileName: _jsxFileName, lineNumber: 273}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 271}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "ارز:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 276}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: selectedTxn.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 277}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 275}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "تاریخ:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 280}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: new Date(selectedTxn.created_date).toLocaleDateString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 281}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 279}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "ساعت:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 284}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: new Date(selectedTxn.created_date).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}, void 0, false, {fileName: _jsxFileName, lineNumber: 285}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 283}, this)
                  , selectedTxn.balance_before !== undefined && selectedTxn.balance_before !== null && (
                    _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                      _jsxDEV('span', { className: "text-muted-foreground", children: "موجودی قبل:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 289}, this)
                      , _jsxDEV('span', { className: "text-foreground", children: (selectedTxn.balance_before || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 290}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 288}, this)
                  )
                  , selectedTxn.balance_after !== undefined && selectedTxn.balance_after !== null && (
                    _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                      _jsxDEV('span', { className: "text-muted-foreground", children: "موجودی بعد:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 295}, this)
                      , _jsxDEV('span', { className: "text-foreground", children: (selectedTxn.balance_after || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 296}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 294}, this)
                  )
                  , selectedTxn.sender && (
                    _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                      _jsxDEV('span', { className: "text-muted-foreground", children: "فرستنده:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 301}, this)
                      , _jsxDEV('span', { className: "text-foreground", children: selectedTxn.sender}, void 0, false, {fileName: _jsxFileName, lineNumber: 302}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 300}, this)
                  )
                  , selectedTxn.receiver && (
                    _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                      _jsxDEV('span', { className: "text-muted-foreground", children: "گیرنده:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 307}, this)
                      , _jsxDEV('span', { className: "text-foreground", children: selectedTxn.receiver}, void 0, false, {fileName: _jsxFileName, lineNumber: 308}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 306}, this)
                  )
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "وضعیت:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 312}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: (STATUS_MAP[selectedTxn.status] || STATUS_MAP.pending).label}, void 0, false, {fileName: _jsxFileName, lineNumber: 313}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 311}, this)
                  , selectedTxn.description && (
                    _jsxDEV('div', { className: "pt-2 border-t border-border"  , children: [
                      _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-1"  , children: "شرح:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 317}, this)
                      , _jsxDEV('p', { className: "text-xs text-foreground" , children: selectedTxn.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 318}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 316}, this)
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 260}, this)
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 259}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 242}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 236}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 235}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 110}, this)
  );
}