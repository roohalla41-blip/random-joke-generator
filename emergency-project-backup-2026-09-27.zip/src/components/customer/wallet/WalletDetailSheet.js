const _jsxFileName = "src/components/customer/wallet/WalletDetailSheet.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from '../../ui/sheet.js';
import { Card, CardContent } from '../../ui/card.js';
import {
  TrendingUp, TrendingDown, ArrowLeftRight, ShoppingCart, Tag, RefreshCw, Wallet as WalletIcon,
} from 'lucide-react';

const CURRENCY_NAMES = { AFN: 'افغانی', USD: 'دلار آمریکا', IRT: 'تومان', USDT: 'تتر' };
const CURRENCY_SYMBOLS = { AFN: '؋', USD: '$', IRT: 'ت', USDT: '₮' };

function isCredit(t) {
  return ['receive', 'recharge', 'buy', 'correction'].includes(t.type);
}

const SUMMARY_ITEMS = [
  { type: 'receive', label: 'دریافت‌ها', Icon: TrendingUp, color: 'text-success', bg: 'bg-success/10' },
  { type: 'pay', label: 'پرداخت‌ها', Icon: TrendingDown, color: 'text-destructive', bg: 'bg-destructive/10' },
  { type: 'transfer', label: 'انتقال‌ها', Icon: ArrowLeftRight, color: 'text-blue-500', bg: 'bg-blue-100 dark:bg-blue-950/30' },
  { type: 'buy', label: 'خریدها', Icon: ShoppingCart, color: 'text-purple-500', bg: 'bg-purple-100 dark:bg-purple-950/30' },
  { type: 'sell', label: 'فروش‌ها', Icon: Tag, color: 'text-amber-500', bg: 'bg-amber-100 dark:bg-amber-950/30' },
  { type: 'convert', label: 'تبدیل‌ها', Icon: RefreshCw, color: 'text-cyan-500', bg: 'bg-cyan-100 dark:bg-cyan-950/30' },
];

export default function WalletDetailSheet({ open, onOpenChange, currency, wallets, transactions }) {
  const wallet = currency ? wallets.find((w) => w.currency === currency) : null;
  const currencyTxns = currency ? transactions.filter((t) => t.currency === currency) : [];

  const currencyName = currency ? CURRENCY_NAMES[currency] || currency : '';
  const currencySymbol = currency ? CURRENCY_SYMBOLS[currency] || '' : '';

  const sumByType = (type) =>
    currencyTxns.filter((t) => t.type === type).reduce((s, t) => s + (t.amount || 0), 0);

  return (
    _jsxDEV(Sheet, { open: open, onOpenChange: onOpenChange, children: 
      _jsxDEV(SheetContent, { side: "bottom", className: "max-h-[85vh] overflow-y-auto" , children: [
        _jsxDEV(SheetHeader, { children: [
          _jsxDEV(SheetTitle, { children: ["جزئیات کیف پول "   , currencyName]}, void 0, true, {fileName: _jsxFileName, lineNumber: 40}, this)
          , _jsxDEV(SheetDescription, { children: ["موجودی و گردش "   , currencyName]}, void 0, true, {fileName: _jsxFileName, lineNumber: 41}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 39}, this)

        , _jsxDEV('div', { className: "space-y-4 mt-4" , children: [
          /* Current Balance */
          _jsxDEV(Card, { className: "shadow-sm", children: 
            _jsxDEV(CardContent, { className: "p-4 text-center" , children: [
              _jsxDEV('div', { className: "w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-2"        , children: 
                _jsxDEV(WalletIcon, { className: "w-6 h-6 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this)
              , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "موجودی فعلی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 51}, this)
              , _jsxDEV('p', { className: "text-2xl font-bold text-foreground"  , children: 
                wallet ? (wallet.balance || 0).toLocaleString('fa-IR') : '0'
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 52}, this)
              , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: [currencySymbol, " " , currency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 55}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 47}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this)

          /* Summary Grid */
          , _jsxDEV('div', { className: "grid grid-cols-3 gap-2"  , children: 
            SUMMARY_ITEMS.map((item) => {
              const Icon = item.Icon;
              return (
                _jsxDEV(Card, { className: "shadow-sm", children: 
                  _jsxDEV(CardContent, { className: "p-2.5 text-center" , children: [
                    _jsxDEV('div', { className: `w-7 h-7 rounded-lg ${item.bg} flex items-center justify-center mx-auto mb-1`, children: 
                      _jsxDEV(Icon, { className: `w-4 h-4 ${item.color}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
                    , _jsxDEV('p', { className: "text-[8px] text-muted-foreground" , children: item.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this)
                    , _jsxDEV('p', { className: `text-xs font-bold ${item.color}`, children: 
                      sumByType(item.type).toLocaleString('fa-IR')
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)
                }, item.type, false, {fileName: _jsxFileName, lineNumber: 64}, this)
              );
            })
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)

          /* Recent Transactions */
          , _jsxDEV('div', { children: [
            _jsxDEV('h3', { className: "text-sm font-bold text-foreground mb-2"   , children: "آخرین تراکنش‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
            , currencyTxns.length === 0 ? (
              _jsxDEV(Card, { children: 
                _jsxDEV(CardContent, { className: "p-4 text-center text-sm text-muted-foreground"   , children: "تراکنشی برای این ارز ثبت نشده است."

                }, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this)
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this)
            ) : (
              _jsxDEV('div', { className: "space-y-2", children: 
                currencyTxns.slice(0, 10).map((t) => {
                  const credit = isCredit(t);
                  return (
                    _jsxDEV(Card, { className: "shadow-sm", children: 
                      _jsxDEV(CardContent, { className: "p-3 flex items-center gap-3"   , children: [
                        _jsxDEV('div', { className: `w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${credit ? 'bg-success/10' : 'bg-destructive/10'}`, children: 
                          credit ? _jsxDEV(TrendingUp, { className: "w-4 h-4 text-success"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this ) : _jsxDEV(TrendingDown, { className: "w-4 h-4 text-destructive"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this )
                        }, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this)
                        , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
                          _jsxDEV('p', { className: "text-xs font-medium text-foreground truncate"   , children: t.description || 'تراکنش'}, void 0, false, {fileName: _jsxFileName, lineNumber: 99}, this)
                          , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: 
                            new Date(t.created_date).toLocaleDateString('fa-IR')
                          }, void 0, false, {fileName: _jsxFileName, lineNumber: 100}, this)
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 98}, this)
                        , _jsxDEV('p', { className: `text-sm font-bold shrink-0 ${credit ? 'text-success' : 'text-destructive'}`, children: [
                          credit ? '+' : '-', (t.amount || 0).toLocaleString('fa-IR')
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 104}, this)
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 94}, this)
                    }, t.id, false, {fileName: _jsxFileName, lineNumber: 93}, this)
                  );
                })
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 80}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 44}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 38}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this)
  );
}