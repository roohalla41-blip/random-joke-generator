const _jsxFileName = "src/components/customer/games/UCCard.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React from 'react';
import { Check } from 'lucide-react';
import { Image } from '../../ui/image.js';

/**
 * کارت محصول بازی — UC پابجی، الماس IMO و سایر خدمات
 * بنر بنفش با نام بسته، تصویر محصول، قیمت خط‌خورده و قیمت نهایی، دکمه «انتخاب».
 */
export default function UCCard({ pkg, selected, onSelect }) {
  if (!pkg) return null;
  const original = pkg.original_price || pkg.price;
  const hasDiscount = pkg.original_price && pkg.original_price > pkg.price;
  const discountPct = hasDiscount
    ? Math.round(((pkg.original_price - pkg.price) / pkg.original_price) * 100)
    : 0;
  const badge = pkg.badge;

  return (
    _jsxDEV('div', {
      className: `relative bg-white rounded-2xl shadow-md overflow-hidden transition-all duration-200 ${
        selected ? 'ring-2 ring-purple-600 ring-offset-2' : ''
      } ${!pkg.is_active ? 'opacity-50' : ''}`,
 children: [
      /* Discount Badge */
      hasDiscount && (
        _jsxDEV('div', { className: "absolute top-2 left-2 z-10 bg-red-500 text-white text-[9px] font-bold px-2 py-0.5 rounded-full"          , children: [
          discountPct, "٪ تخفیف"
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 26}, this)
      )

      /* Purple Banner with amount */
      , _jsxDEV('div', { className: "bg-gradient-to-l from-purple-700 to-purple-600 px-3 py-2 text-center"     , children: 
        badge ? (
          _jsxDEV('span', { className: "text-white font-extrabold text-[13px] leading-tight block"    , children: 
            badge
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 34}, this)
        ) : (
          _jsxDEV('span', { className: "text-white font-extrabold text-base leading-tight block truncate"     , children: 
            pkg.name
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this)
        )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 32}, this)

      /* Product Image */
      , _jsxDEV('div', { className: "flex items-center justify-center py-3 bg-gradient-to-b from-amber-50/50 to-white"      , children: 
        pkg.image ? (
          _jsxDEV(Image, {
            src: pkg.image,
            alt: pkg.name,
            fittingType: "fit",
            className: "h-20 w-auto object-contain"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 47}, this
          )
        ) : (
          _jsxDEV('div', { className: "w-14 h-14 rounded-full bg-gradient-to-br from-yellow-300 via-amber-400 to-yellow-600 flex items-center justify-center shadow-lg border-2 border-yellow-500"            , children: 
            _jsxDEV('span', { className: "text-amber-900 font-extrabold text-xs"  , children: "UC"}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 54}, this)
        )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 45}, this)

      /* Title */
      , _jsxDEV('div', { className: "px-3 pb-1 text-center"  , children: 
        _jsxDEV('p', { className: "text-[11px] font-bold text-gray-800 truncate"   , children: ["خرید "
           , pkg.name
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 62}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this)

      /* Pricing — قیمت نهایی از سیستم قیمت‌گذاری */
      , _jsxDEV('div', { className: "px-3 pb-2 text-center space-y-0.5"   , children: 
        _jsxDEV('p', { className: "text-sm font-extrabold text-gray-900"  , children: [
          (pkg.price || 0).toLocaleString('fa-IR'), " " , pkg.currency === 'AFN' ? 'افغان' : 'تومان'
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 69}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this)

      /* Select Button */
      , _jsxDEV('div', { className: "px-3 pb-3" , children: 
        _jsxDEV('button', {
          onClick: () => pkg.is_active && _optionalChain([onSelect, 'optionalCall', _ => _(pkg)]),
          disabled: !pkg.is_active,
          className: `w-full py-2 rounded-full text-white text-xs font-bold flex items-center justify-center gap-1 transition-all ${
            selected
              ? 'bg-gradient-to-l from-purple-800 to-purple-700'
              : 'bg-gradient-to-l from-purple-600 to-fuchsia-600 hover:from-purple-700 hover:to-fuchsia-700 active:scale-95'
          } disabled:cursor-not-allowed`,
 children: 
          selected ? (
            _jsxDEV(_Fragment, { children: [
              _jsxDEV(Check, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this ), "انتخاب شد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 86}, this)
          ) : (
            'انتخاب'
          )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 19}, this)
  );
}