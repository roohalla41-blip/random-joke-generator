const _jsxFileName = "src/components/customer/games/ConfirmDialog.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React from 'react';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from '../../ui/sheet.js';
import { Card, CardContent } from '../../ui/card.js';
import { Button } from '../../ui/button.js';
import { Edit3, Send, Database } from 'lucide-react';

const WALLET_LABELS = {
  AFN: 'افغانی (AFN)',
  USD: 'دلار (USD)',
  IRT: 'تومان (IRT)',
  USDT: 'تتر (USDT)',
};

export default function ConfirmDialog({
  open, onOpenChange, data, onConfirm, submitting,
}) {
  if (!data) return null;

  return (
    _jsxDEV(Sheet, { open: open, onOpenChange: onOpenChange, children: 
      _jsxDEV(SheetContent, { side: "bottom", className: "max-h-[85vh] overflow-y-auto" , children: [
        _jsxDEV(SheetHeader, { children: [
          _jsxDEV(SheetTitle, { children: "بررسی و تأیید درخواست"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 25}, this)
          , _jsxDEV(SheetDescription, { children: "لطفاً اطلاعات درخواست خود را بررسی کنید"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 26}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 24}, this)

        , _jsxDEV('div', { className: "space-y-4 mt-4" , children: [
          _jsxDEV(Card, { className: "shadow-sm", children: 
            _jsxDEV(CardContent, { className: "p-3 space-y-2.5" , children: [
              _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "نام بازی/خدمت:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 33}, this)
                , _jsxDEV('span', { className: "font-medium text-foreground" , children: data.service_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 34}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 32}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "نوع محصول:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this)
                , _jsxDEV('span', { className: "font-medium text-foreground" , children: data.product_type}, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 36}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "بسته/مقدار:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this)
                , _jsxDEV('span', { className: "font-medium text-foreground" , children: data.package_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 40}, this)
              , data.account_info && Object.keys(data.account_info).length > 0 && (
                _jsxDEV('div', { className: "pt-2 border-t border-border"  , children: [
                  _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-1"  , children: "اطلاعات حساب بازی:"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this)
                  , Object.entries(data.account_info).map(([key, val]) => (
                    _jsxDEV('div', { className: "flex justify-between text-xs mb-1"   , children: [
                      _jsxDEV('span', { className: "text-muted-foreground", children: [key, ":"]}, void 0, true, {fileName: _jsxFileName, lineNumber: 49}, this)
                      , _jsxDEV('span', { className: "text-foreground text-[10px]" , dir: "ltr", children: val}, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this)
                    ]}, key, true, {fileName: _jsxFileName, lineNumber: 48}, this)
                  ))
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 45}, this)
              )
              , _jsxDEV('div', { className: "flex justify-between text-xs pt-2 border-t border-border"     , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "کیف پول پرداخت:"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
                , _jsxDEV('span', { className: "font-medium text-foreground" , children: WALLET_LABELS[data.wallet_currency] || data.wallet_currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 57}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 55}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)
                , _jsxDEV('span', { className: "font-bold text-primary" , children: [(data.amount || 0).toLocaleString('fa-IR'), " " , data.wallet_currency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 61}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 59}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "تاریخ و ساعت:"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
                , _jsxDEV('span', { className: "text-foreground text-[10px]" , children: [
                  new Date().toLocaleDateString('fa-IR'), " • "  , new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 63}, this)
              , data.description && (
                _jsxDEV('div', { className: "pt-2 border-t border-border"  , children: [
                  _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-1"  , children: "توضیحات:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this)
                  , _jsxDEV('p', { className: "text-xs text-foreground" , children: data.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 70}, this)
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 31}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 30}, this)

          , _jsxDEV('div', { className: "flex items-center gap-1.5 text-[10px] text-muted-foreground bg-muted/50 rounded-lg p-2"       , children: [
            _jsxDEV(Database, { className: "w-3 h-3 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this ), "حالت آزمایشی — Supabase متصل نیست"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 78}, this)

          , _jsxDEV('div', { className: "flex gap-2" , children: [
            _jsxDEV(Button, { variant: "outline", className: "flex-1", onClick: () => onOpenChange(false), disabled: submitting, children: [
              _jsxDEV(Edit3, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this ), "ویرایش"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 84}, this)
            , _jsxDEV(Button, { className: "flex-1", onClick: onConfirm, disabled: submitting, children: 
              submitting ? 'در حال ارسال...' : (_jsxDEV(_Fragment, { children: [_jsxDEV(Send, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this ), "تأیید و ارسال درخواست"   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 89}, this))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 83}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 29}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 23}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 22}, this)
  );
}