const _jsxFileName = "src/components/customer/games/SuccessSheet.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from '../../ui/sheet.js';
import { Card, CardContent } from '../../ui/card.js';
import { Button } from '../../ui/button.js';
import { CheckCircle2, Package, Database } from 'lucide-react';

const STATUS_LABELS = {
  new: { label: 'جدید', color: 'bg-blue-100 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400' },
  pending: { label: 'در انتظار بررسی', color: 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400' },
  approved: { label: 'تأیید شده', color: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/30 dark:text-cyan-400' },
  processing: { label: 'در حال انجام', color: 'bg-purple-100 text-purple-700 dark:bg-purple-950/30 dark:text-purple-400' },
  completed: { label: 'تکمیل شده', color: 'bg-success/15 text-success' },
  rejected: { label: 'رد شده', color: 'bg-destructive/15 text-destructive' },
  cancelled: { label: 'لغو شده', color: 'bg-muted text-muted-foreground' },
};

export default function SuccessSheet({ open, onOpenChange, request, onGoToOrders }) {
  if (!request) return null;
  const st = STATUS_LABELS[request.status] || STATUS_LABELS.new;

  return (
    _jsxDEV(Sheet, { open: open, onOpenChange: onOpenChange, children: 
      _jsxDEV(SheetContent, { side: "bottom", className: "max-h-[85vh] overflow-y-auto" , children: [
        _jsxDEV(SheetHeader, { children: [
          _jsxDEV(SheetTitle, { children: "نتیجه ثبت درخواست"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 27}, this)
          , _jsxDEV(SheetDescription, { children: "درخواست شما ثبت شد"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 28}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 26}, this)

        , _jsxDEV('div', { className: "space-y-4 mt-4" , children: [
          _jsxDEV(Card, { className: "shadow-sm border-success/30" , children: 
            _jsxDEV(CardContent, { className: "p-6 text-center" , children: [
              _jsxDEV('div', { className: "w-14 h-14 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-3"        , children: 
                _jsxDEV(CheckCircle2, { className: "w-7 h-7 text-success"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 35}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 34}, this)
              , _jsxDEV('p', { className: "text-sm font-bold text-foreground mb-1"   , children: "درخواست شما با موفقیت ثبت شد و در انتظار بررسی است."

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this)
              , _jsxDEV('span', { className: `inline-block mt-2 text-[9px] px-2 py-1 rounded ${st.color}`, children: 
                st.label
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 40}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 33}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 32}, this)

          , _jsxDEV(Card, { className: "shadow-sm", children: 
            _jsxDEV(CardContent, { className: "p-3 space-y-2" , children: [
              _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "شماره درخواست:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this)
                , _jsxDEV('span', { className: "font-mono text-primary font-bold text-[10px]"   , children: request.request_number}, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 48}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "بازی/خدمت:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 53}, this)
                , _jsxDEV('span', { className: "text-foreground", children: request.service_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 54}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 52}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "بسته:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 57}, this)
                , _jsxDEV('span', { className: "text-foreground", children: request.package_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 56}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this)
                , _jsxDEV('span', { className: "font-bold text-foreground" , children: [(request.amount || 0).toLocaleString('fa-IR'), " " , request.wallet_currency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 62}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 60}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "تاریخ:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this)
                , _jsxDEV('span', { className: "text-foreground text-[10px]" , children: new Date(request.created_date).toLocaleDateString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 64}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 47}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this)

          , _jsxDEV('div', { className: "flex items-center gap-1.5 text-[10px] text-muted-foreground bg-muted/50 rounded-lg p-2"       , children: [
            _jsxDEV(Database, { className: "w-3 h-3 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this ), "حالت آزمایشی — Supabase متصل نیست"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 71}, this)

          , _jsxDEV(Button, { className: "w-full", onClick: onGoToOrders, children: [
            _jsxDEV(Package, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this ), "مشاهده سفارش‌های من"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 76}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 31}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 25}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 24}, this)
  );
}