const _jsxFileName = "src/components/customer/transfer/TransferHistory.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useMemo } from 'react';
import { Card, CardContent } from '../../ui/card.js';
import { Input } from '../../ui/input.js';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from '../../ui/sheet.js';
import { ChevronLeft, Calendar } from 'lucide-react';

const STATUS_LABELS = {
  new: { label: 'جدید', color: 'bg-blue-100 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400' },
  pending: { label: 'در انتظار بررسی', color: 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400' },
  approved: { label: 'تأیید شده', color: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/30 dark:text-cyan-400' },
  processing: { label: 'در حال انجام', color: 'bg-purple-100 text-purple-700 dark:bg-purple-950/30 dark:text-purple-400' },
  completed: { label: 'تکمیل شده', color: 'bg-success/15 text-success' },
  rejected: { label: 'رد شده', color: 'bg-destructive/15 text-destructive' },
  cancelled: { label: 'لغو شده', color: 'bg-muted text-muted-foreground' },
};

const CURRENCY_FILTERS = [
  { value: 'all', label: 'همه ارزها' },
  { value: 'AFN', label: 'AFN' },
  { value: 'USD', label: 'USD' },
  { value: 'IRT', label: 'تومان' },
  { value: 'USDT', label: 'USDT' },
];

const STATUS_FILTERS = [
  { value: 'all', label: 'همه وضعیت‌ها' },
  { value: 'new', label: 'جدید' },
  { value: 'pending', label: 'در انتظار بررسی' },
  { value: 'approved', label: 'تأیید شده' },
  { value: 'processing', label: 'در حال انجام' },
  { value: 'completed', label: 'تکمیل شده' },
  { value: 'rejected', label: 'رد شده' },
  { value: 'cancelled', label: 'لغو شده' },
];

export default function TransferHistory({ transfers }) {
  const [search, setSearch] = useState('');
  const [currencyFilter, setCurrencyFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [showDateFilter, setShowDateFilter] = useState(false);
  const [selectedTxn, setSelectedTxn] = useState(null);

  const filtered = useMemo(() => {
    return transfers.filter((t) => {
      if (currencyFilter !== 'all' && t.currency !== currencyFilter) return false;
      if (statusFilter !== 'all' && t.status !== statusFilter) return false;
      if (dateFrom) {
        const d = new Date(t.created_date);
        const from = new Date(dateFrom);
        from.setHours(0, 0, 0, 0);
        if (d < from) return false;
      }
      if (dateTo) {
        const d = new Date(t.created_date);
        const to = new Date(dateTo);
        to.setHours(23, 59, 59, 999);
        if (d > to) return false;
      }
      if (search.trim()) {
        const q = search.toLowerCase();
        const haystack = `${t.tracking_number || ''} ${t.receiver_name || ''} ${t.sender_name || ''} ${t.description || ''}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [transfers, currencyFilter, statusFilter, search, dateFrom, dateTo]);

  return (
    _jsxDEV('div', { className: "space-y-3", children: [
      _jsxDEV('h2', { className: "text-sm font-bold text-foreground"  , children: "تاریخچه انتقال‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this)

      , _jsxDEV(Input, {
        placeholder: "جستجو: شماره پیگیری، گیرنده، فرستنده..."    ,
        value: search,
        onChange: (e) => setSearch(e.target.value),
        className: "text-xs",}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this
      )

      , _jsxDEV('button', {
        onClick: () => setShowDateFilter(!showDateFilter),
        className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
          showDateFilter || dateFrom || dateTo ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
        }`,
 children: [
        _jsxDEV(Calendar, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this ), "بازه زمانی"

      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 83}, this)
      , showDateFilter && (
        _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
          _jsxDEV(Input, { type: "date", value: dateFrom, onChange: (e) => setDateFrom(e.target.value), className: "text-xs",}, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this )
          , _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: "تا"}, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this)
          , _jsxDEV(Input, { type: "date", value: dateTo, onChange: (e) => setDateTo(e.target.value), className: "text-xs",}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 93}, this)
      )

      , _jsxDEV('div', { className: "space-y-2", children: [
        _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          CURRENCY_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setCurrencyFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                currencyFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 103}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this)
        , _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          STATUS_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setStatusFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                statusFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 116}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 100}, this)

      , filtered.length === 0 ? (
        _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-6 text-center text-sm text-muted-foreground"   , children: 
            transfers.length === 0 ? 'هنوز انتقالی برای نمایش وجود ندارد.' : 'نتیجه‌ای یافت نشد'
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)
      ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          filtered.map((t) => {
            const st = STATUS_LABELS[t.status] || STATUS_LABELS.new;
            const date = new Date(t.created_date);
            return (
              _jsxDEV(Card, { className: "shadow-sm cursor-pointer hover:shadow-md transition-shadow"   , onClick: () => setSelectedTxn(t), children: 
                _jsxDEV(CardContent, { className: "p-3 flex items-center gap-3"   , children: [
                  _jsxDEV('div', { className: `w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${st.color}`, children: 
                    _jsxDEV(ChevronLeft, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this)
                  , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
                    _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                      _jsxDEV('p', { className: "text-xs font-medium text-foreground truncate"   , children: t.receiver_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this)
                      , _jsxDEV('span', { className: `text-[8px] px-1.5 py-0.5 rounded ${st.color}`, children: st.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground truncate"  , children: [
                      t.tracking_number, " • "  , date.toLocaleDateString('fa-IR'), " • "  , date.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 151}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 146}, this)
                  , _jsxDEV('div', { className: "text-left shrink-0" , children: [
                    _jsxDEV('p', { className: "text-sm font-bold text-foreground"  , children: (t.amount || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: t.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 155}, this)
                  , _jsxDEV(ChevronLeft, { className: "w-4 h-4 text-muted-foreground shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)
              }, t.id, false, {fileName: _jsxFileName, lineNumber: 141}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this)
      )

      /* Detail Sheet */
      , _jsxDEV(Sheet, { open: !!selectedTxn, onOpenChange: (open) => !open && setSelectedTxn(null), children: 
        _jsxDEV(SheetContent, { side: "bottom", className: "max-h-[85vh] overflow-y-auto" , children: [
          _jsxDEV(SheetHeader, { children: [
            _jsxDEV(SheetTitle, { children: "جزئیات انتقال" }, void 0, false, {fileName: _jsxFileName, lineNumber: 171}, this)
            , _jsxDEV(SheetDescription, { children: _optionalChain([selectedTxn, 'optionalAccess', _ => _.receiver_name]) || ''}, void 0, false, {fileName: _jsxFileName, lineNumber: 172}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 170}, this)
          , selectedTxn && (
            _jsxDEV('div', { className: "space-y-3 mt-4" , children: [
              _jsxDEV(Card, { className: "shadow-sm", children: 
                _jsxDEV(CardContent, { className: "p-4 text-center" , children: [
                  _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "مبلغ انتقال" }, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this)
                  , _jsxDEV('p', { className: "text-2xl font-bold text-foreground"  , children: (selectedTxn.amount || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this)
                  , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: selectedTxn.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 180}, this)
                  , _jsxDEV('span', { className: `inline-block mt-2 text-[9px] px-2 py-1 rounded ${(STATUS_LABELS[selectedTxn.status] || STATUS_LABELS.new).color}`, children: 
                    (STATUS_LABELS[selectedTxn.status] || STATUS_LABELS.new).label
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 181}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 177}, this)
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 176}, this)
              , _jsxDEV(Card, { className: "shadow-sm", children: 
                _jsxDEV(CardContent, { className: "p-3 space-y-2" , children: [
                  _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "شماره پیگیری:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 189}, this)
                    , _jsxDEV('span', { className: "font-mono text-primary font-bold text-[10px]"   , children: selectedTxn.tracking_number}, void 0, false, {fileName: _jsxFileName, lineNumber: 190}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 188}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "فرستنده:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 193}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: selectedTxn.sender_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 194}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 192}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "گیرنده:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 197}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: selectedTxn.receiver_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 198}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 196}, this)
                  , selectedTxn.receiver_phone && (
                    _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                      _jsxDEV('span', { className: "text-muted-foreground", children: "موبایل گیرنده:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 202}, this)
                      , _jsxDEV('span', { className: "text-foreground", dir: "ltr", children: selectedTxn.receiver_phone}, void 0, false, {fileName: _jsxFileName, lineNumber: 203}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 201}, this)
                  )
                  , selectedTxn.destination_country && (
                    _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                      _jsxDEV('span', { className: "text-muted-foreground", children: "کشور مقصد:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 208}, this)
                      , _jsxDEV('span', { className: "text-foreground", children: selectedTxn.destination_country}, void 0, false, {fileName: _jsxFileName, lineNumber: 209}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 207}, this)
                  )
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "ارز:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 213}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: selectedTxn.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 214}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 212}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 217}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: (selectedTxn.amount || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 218}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 216}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "کارمزد:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 221}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: (selectedTxn.fee || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 222}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 220}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ نهایی:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 225}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: (selectedTxn.total_amount || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 226}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 224}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "تاریخ:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 229}, this)
                    , _jsxDEV('span', { className: "text-foreground text-[10px]" , children: new Date(selectedTxn.created_date).toLocaleDateString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 230}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 228}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "ساعت:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 233}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: new Date(selectedTxn.created_date).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}, void 0, false, {fileName: _jsxFileName, lineNumber: 234}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 232}, this)
                  , selectedTxn.description && (
                    _jsxDEV('div', { className: "pt-2 border-t border-border"  , children: [
                      _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-1"  , children: "توضیحات:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 238}, this)
                      , _jsxDEV('p', { className: "text-xs text-foreground" , children: selectedTxn.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 239}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 237}, this)
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 187}, this)
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 186}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 175}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 169}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 73}, this)
  );
}