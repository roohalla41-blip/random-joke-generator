const _jsxFileName = "src/components/customer/transfer/ConfirmDialog.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React from 'react';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from '../../ui/sheet.js';
import { Card, CardContent } from '../../ui/card.js';
import { Button } from '../../ui/button.js';
import { Edit3, Send, Database } from 'lucide-react';

const WALLET_LABELS = {
  AFN: 'افغانی (AFN)',
  USD: 'دلار (USD)',
  IRT: 'تومان (IRT)',
  USDT: 'تتر (USDT)',
};

export default function ConfirmDialog({
  open, onOpenChange, data, onConfirm, submitting,
}) {
  if (!data) return null;

  return (
    _jsxDEV(Sheet, { open: open, onOpenChange: onOpenChange, children: 
      _jsxDEV(SheetContent, { side: "bottom", className: "max-h-[85vh] overflow-y-auto" , children: [
        _jsxDEV(SheetHeader, { children: [
          _jsxDEV(SheetTitle, { children: "بررسی و تأیید درخواست انتقال"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 25}, this)
          , _jsxDEV(SheetDescription, { children: "لطفاً اطلاعات انتقال را بررسی کنید"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 26}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 24}, this)

        , _jsxDEV('div', { className: "space-y-4 mt-4" , children: [
          _jsxDEV(Card, { className: "shadow-sm", children: 
            _jsxDEV(CardContent, { className: "p-3 space-y-2.5" , children: [
              _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "فرستنده:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 33}, this)
                , _jsxDEV('span', { className: "font-medium text-foreground" , children: data.sender_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 34}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 32}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "گیرنده:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this)
                , _jsxDEV('span', { className: "font-medium text-foreground" , children: data.receiver_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 36}, this)
              , data.receiver_phone && (
                _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "شماره موبایل گیرنده:"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this)
                  , _jsxDEV('span', { className: "text-foreground", dir: "ltr", children: data.receiver_phone}, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 41}, this)
              )
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "ارز:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 47}, this)
                , _jsxDEV('span', { className: "text-foreground", children: data.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 46}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ انتقال:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 51}, this)
                , _jsxDEV('span', { className: "font-medium text-foreground" , children: (data.amount || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 52}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 50}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "کارمزد:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this)
                , _jsxDEV('span', { className: "text-foreground", children: (data.fee || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 54}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs pt-2 border-t border-border"     , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ نهایی:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this)
                , _jsxDEV('span', { className: "font-bold text-primary" , children: [(data.total_amount || 0).toLocaleString('fa-IR'), " " , data.currency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 60}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 58}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "کیف پول:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this)
                , _jsxDEV('span', { className: "text-foreground", children: WALLET_LABELS[data.wallet_currency] || data.wallet_currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 62}, this)
              , data.destination_type_name && (
                _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "مقصد:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this)
                  , _jsxDEV('span', { className: "text-foreground", children: data.destination_type_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 67}, this)
              )
              , data.destination_country && (
                _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "کشور مقصد:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this)
                  , _jsxDEV('span', { className: "text-foreground", children: data.destination_country}, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 73}, this)
              )
              , data.transfer_method && (
                _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "روش انتقال:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)
                  , _jsxDEV('span', { className: "text-foreground", children: data.transfer_method}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 79}, this)
              )
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "موجودی کیف پول:"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this)
                , _jsxDEV('span', { className: "text-foreground", children: (data.wallet_balance || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 84}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "موجودی بعد از انتقال:"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this)
                , _jsxDEV('span', { className: "text-foreground", children: (data.balance_after || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 88}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "تاریخ و ساعت:"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this)
                , _jsxDEV('span', { className: "text-foreground text-[10px]" , children: [new Date().toLocaleDateString('fa-IR'), " • "  , new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })]}, void 0, true, {fileName: _jsxFileName, lineNumber: 94}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 92}, this)
              , data.description && (
                _jsxDEV('div', { className: "pt-2 border-t border-border"  , children: [
                  _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-1"  , children: "توضیحات:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)
                  , _jsxDEV('p', { className: "text-xs text-foreground" , children: data.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 99}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 97}, this)
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 31}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 30}, this)

          , _jsxDEV('div', { className: "flex items-center gap-1.5 text-[10px] text-muted-foreground bg-muted/50 rounded-lg p-2"       , children: [
            _jsxDEV(Database, { className: "w-3 h-3 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this ), "حالت آزمایشی — Supabase متصل نیست"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 105}, this)

          , _jsxDEV('div', { className: "flex gap-2" , children: [
            _jsxDEV(Button, { variant: "outline", className: "flex-1", onClick: () => onOpenChange(false), disabled: submitting, children: [
              _jsxDEV(Edit3, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this ), "ویرایش"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 111}, this)
            , _jsxDEV(Button, { className: "flex-1", onClick: onConfirm, disabled: submitting, children: 
              submitting ? 'در حال ارسال...' : (_jsxDEV(_Fragment, { children: [_jsxDEV(Send, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this ), "تأیید و ارسال درخواست"   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 116}, this))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 110}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 29}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 23}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 22}, this)
  );
}