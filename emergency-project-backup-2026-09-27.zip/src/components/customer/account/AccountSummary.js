const _jsxFileName = "src/components/customer/account/AccountSummary.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';
import { Card, CardContent } from '../../ui/card.js';
import { TrendingUp, TrendingDown, Wallet } from 'lucide-react';

const STATUS_LABELS = {
  creditor: { label: 'طلبکار', color: 'bg-success/10 text-success', dot: 'bg-success' },
  debtor: { label: 'بدهکار', color: 'bg-destructive/10 text-destructive', dot: 'bg-destructive' },
  settled: { label: 'تسویه', color: 'bg-blue-100 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400', dot: 'bg-blue-500' },
  no_activity: { label: 'بدون گردش', color: 'bg-muted text-muted-foreground', dot: 'bg-muted-foreground' },
};

export default function AccountSummary({ balances, lastUpdated }) {
  if (!balances || balances.length === 0) {
    return (
      _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-6 text-center text-sm text-muted-foreground"   , children: "اطلاعات مالی برای نمایش وجود ندارد."

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 16}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 15}, this)
    );
  }

  return (
    _jsxDEV('div', { className: "space-y-3", children: [
      _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
        _jsxDEV('h2', { className: "text-sm font-bold text-foreground"  , children: "خلاصه وضعیت مالی"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 26}, this)
        , lastUpdated && (
          _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: ["آخرین بروزرسانی: "
              , new Date(lastUpdated).toLocaleDateString('fa-IR')
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 28}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 25}, this)

      , _jsxDEV('div', { className: "grid grid-cols-1 md:grid-cols-2 gap-2"   , children: 
        balances.map((b) => {
          const st = STATUS_LABELS[b.status] || STATUS_LABELS.no_activity;
          const isPositive = (b.balance || 0) >= 0;
          return (
            _jsxDEV(Card, { className: "shadow-sm", children: 
              _jsxDEV(CardContent, { className: "p-3 space-y-2" , children: [
                _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
                  _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                    _jsxDEV('div', { className: "w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center"      , children: 
                      _jsxDEV(Wallet, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 44}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this)
                    , _jsxDEV('span', { className: "text-xs font-bold text-foreground"  , children: b.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 42}, this)
                  , _jsxDEV('span', { className: `inline-flex items-center gap-1 px-2 py-0.5 rounded text-[9px] font-medium ${st.color}`, children: [
                    _jsxDEV('span', { className: `w-1.5 h-1.5 rounded-full ${st.dot}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this )
                    , st.label
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 48}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 41}, this)

                , _jsxDEV('div', { className: "flex items-center justify-between text-xs"   , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "مانده حساب:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this)
                  , _jsxDEV('span', { className: `font-bold ${isPositive ? 'text-success' : 'text-destructive'}`, children: 
                    (b.balance || 0).toLocaleString('fa-IR')
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 54}, this)

                , _jsxDEV('div', { className: "grid grid-cols-2 gap-2 pt-2 border-t border-border"     , children: [
                  _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
                    _jsxDEV(TrendingUp, { className: "w-3 h-3 text-success shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this )
                    , _jsxDEV('div', { children: [
                      _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "دریافتی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this)
                      , _jsxDEV('p', { className: "text-[11px] font-medium text-foreground"  , children: (b.total_in || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 64}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 62}, this)
                  , _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
                    _jsxDEV(TrendingDown, { className: "w-3 h-3 text-destructive shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this )
                    , _jsxDEV('div', { children: [
                      _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "پرداختی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this)
                      , _jsxDEV('p', { className: "text-[11px] font-medium text-foreground"  , children: (b.total_out || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 71}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 69}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 61}, this)

                , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
                  _jsxDEV('div', { children: [
                    _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "طلبکار"}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)
                    , _jsxDEV('p', { className: "text-[11px] font-medium text-success"  , children: (b.receivable || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 79}, this)
                  , _jsxDEV('div', { children: [
                    _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "بدهکار"}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this)
                    , _jsxDEV('p', { className: "text-[11px] font-medium text-destructive"  , children: (b.payable || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 83}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 78}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 40}, this)
            }, b.currency, false, {fileName: _jsxFileName, lineNumber: 39}, this)
          );
        })
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 34}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 24}, this)
  );
}