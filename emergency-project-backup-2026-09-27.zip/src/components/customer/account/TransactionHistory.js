const _jsxFileName = "src/components/customer/account/TransactionHistory.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '../../ui/card.js';
import { Input } from '../../ui/input.js';
import { Button } from '../../ui/button.js';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from '../../ui/sheet.js';
import { Calendar, X, ChevronLeft, ArrowDownUp, Wallet, Package, Database } from 'lucide-react';

const STATUS_LABELS = {
  completed: { label: 'تکمیل شده', color: 'bg-success/15 text-success' },
  pending: { label: 'در انتظار', color: 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400' },
  processing: { label: 'در حال انجام', color: 'bg-purple-100 text-purple-700 dark:bg-purple-950/30 dark:text-purple-400' },
  rejected: { label: 'رد شده', color: 'bg-destructive/15 text-destructive' },
  cancelled: { label: 'لغو شده', color: 'bg-muted text-muted-foreground' },
};

const TYPE_ICONS = {
  receive: '↓', pay: '↑', transfer: '⇄', buy_currency: '₿', sell_currency: '₿',
  convert: '⇄', topup: '+', withdraw: '-', adjustment: '↻', fee: '%', other: '•',
};

const CURRENCY_FILTERS = [
  { value: 'all', label: 'همه ارزها' },
  { value: 'AFN', label: 'AFN' },
  { value: 'USD', label: 'USD' },
  { value: 'IRT', label: 'تومان' },
  { value: 'USDT', label: 'USDT' },
];

const TYPE_FILTERS = [
  { value: 'all', label: 'همه نوع‌ها' },
  { value: 'receive', label: 'دریافت' },
  { value: 'pay', label: 'پرداخت' },
  { value: 'transfer', label: 'انتقال' },
  { value: 'buy_currency', label: 'خرید ارز' },
  { value: 'sell_currency', label: 'فروش ارز' },
  { value: 'convert', label: 'تبدیل ارز' },
  { value: 'topup', label: 'شارژ کیف پول' },
  { value: 'withdraw', label: 'برداشت' },
  { value: 'adjustment', label: 'اصلاح حساب' },
  { value: 'fee', label: 'کارمزد' },
  { value: 'other', label: 'سایر' },
];

const STATUS_FILTERS = [
  { value: 'all', label: 'همه وضعیت‌ها' },
  { value: 'completed', label: 'تکمیل شده' },
  { value: 'pending', label: 'در انتظار' },
  { value: 'processing', label: 'در حال انجام' },
  { value: 'rejected', label: 'رد شده' },
  { value: 'cancelled', label: 'لغو شده' },
];

const DIRECTION_FILTERS = [
  { value: 'all', label: 'دریافت و پرداخت' },
  { value: 'in', label: 'دریافت' },
  { value: 'out', label: 'پرداخت' },
];

const SORT_OPTIONS = [
  { value: 'newest', label: 'جدیدترین' },
  { value: 'oldest', label: 'قدیمی‌ترین' },
  { value: 'highest', label: 'بیشترین مبلغ' },
  { value: 'lowest', label: 'کمترین مبلغ' },
];

export default function TransactionHistory({ transactions }) {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [currencyFilter, setCurrencyFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [directionFilter, setDirectionFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [showDateFilter, setShowDateFilter] = useState(false);
  const [sortBy, setSortBy] = useState('newest');
  const [selectedTxn, setSelectedTxn] = useState(null);

  const filtered = useMemo(() => {
    const result = transactions.filter((t) => {
      if (currencyFilter !== 'all' && t.currency !== currencyFilter) return false;
      if (typeFilter !== 'all' && t.type !== typeFilter) return false;
      if (statusFilter !== 'all' && t.status !== statusFilter) return false;
      if (directionFilter !== 'all' && t.direction !== directionFilter) return false;
      if (dateFrom) {
        const d = new Date(t.date);
        const from = new Date(dateFrom);
        from.setHours(0, 0, 0, 0);
        if (d < from) return false;
      }
      if (dateTo) {
        const d = new Date(t.date);
        const to = new Date(dateTo);
        to.setHours(23, 59, 59, 999);
        if (d > to) return false;
      }
      if (search.trim()) {
        const q = search.toLowerCase();
        const haystack = `${t.id || ''} ${t.doc_no || ''} ${t.description || ''} ${t.type_label || ''} ${t.sender_name || ''} ${t.receiver_name || ''}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });

    return result.sort((a, b) => {
      switch (sortBy) {
        case 'oldest': return new Date(a.date) - new Date(b.date);
        case 'highest': return (b.amount || 0) - (a.amount || 0);
        case 'lowest': return (a.amount || 0) - (b.amount || 0);
        default: return new Date(b.date) - new Date(a.date);
      }
    });
  }, [transactions, currencyFilter, typeFilter, statusFilter, directionFilter, search, dateFrom, dateTo, sortBy]);

  const hasActiveFilters = search || currencyFilter !== 'all' || typeFilter !== 'all' || statusFilter !== 'all' || directionFilter !== 'all' || dateFrom || dateTo;

  const clearAllFilters = () => {
    setSearch('');
    setCurrencyFilter('all');
    setTypeFilter('all');
    setStatusFilter('all');
    setDirectionFilter('all');
    setDateFrom('');
    setDateTo('');
    setShowDateFilter(false);
  };

  // Financial summary from filtered transactions
  const summary = useMemo(() => {
    let totalIn = 0, totalOut = 0, totalTransfer = 0;
    filtered.forEach((t) => {
      if (t.type === 'transfer') {
        totalTransfer += (t.amount || 0);
      }
      if (t.direction === 'in') {
        totalIn += (t.amount || 0);
      } else {
        totalOut += (t.amount || 0);
      }
    });
    return { totalIn, totalOut, totalTransfer, count: filtered.length };
  }, [filtered]);

  return (
    _jsxDEV('div', { className: "space-y-3", children: [
      /* Header */
      _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
        _jsxDEV('h2', { className: "text-sm font-bold text-foreground"  , children: "گردش حساب" }, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this)
        , _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: [summary.count, " تراکنش" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 152}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 150}, this)

      /* Financial Summary */
      , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
        _jsxDEV(Card, { className: "shadow-sm", children: 
          _jsxDEV(CardContent, { className: "p-2.5", children: [
            _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "مجموع دریافت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this)
            , _jsxDEV('p', { className: "text-sm font-bold text-success"  , children: summary.totalIn.toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 158}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this)
        , _jsxDEV(Card, { className: "shadow-sm", children: 
          _jsxDEV(CardContent, { className: "p-2.5", children: [
            _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "مجموع پرداخت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this)
            , _jsxDEV('p', { className: "text-sm font-bold text-destructive"  , children: summary.totalOut.toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 166}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 164}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this)
        , _jsxDEV(Card, { className: "shadow-sm", children: 
          _jsxDEV(CardContent, { className: "p-2.5", children: [
            _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "مجموع انتقال" }, void 0, false, {fileName: _jsxFileName, lineNumber: 171}, this)
            , _jsxDEV('p', { className: "text-sm font-bold text-primary"  , children: summary.totalTransfer.toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 172}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 170}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 169}, this)
        , _jsxDEV(Card, { className: "shadow-sm", children: 
          _jsxDEV(CardContent, { className: "p-2.5", children: [
            _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "تعداد تراکنش‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 177}, this)
            , _jsxDEV('p', { className: "text-sm font-bold text-foreground"  , children: summary.count.toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 176}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 175}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 156}, this)

      /* Mock Mode Banner */
      , _jsxDEV('div', { className: "flex items-center gap-1.5 text-[10px] text-muted-foreground bg-muted/50 rounded-lg p-2"       , children: [
        _jsxDEV(Database, { className: "w-3 h-3 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 185}, this ), "حالت آزمایشی — Supabase متصل نیست"

      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 184}, this)

      /* Search */
      , _jsxDEV(Input, {
        placeholder: "جستجو: شماره تراکنش، شماره سند، نوع، شرح، فرستنده، گیرنده..."        ,
        value: search,
        onChange: (e) => setSearch(e.target.value),
        className: "text-xs",}, void 0, false, {fileName: _jsxFileName, lineNumber: 190}, this
      )

      /* Sort */
      , _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
        _jsxDEV(ArrowDownUp, { className: "w-3.5 h-3.5 text-muted-foreground shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 199}, this )
        , _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          SORT_OPTIONS.map((s) => (
            _jsxDEV('button', {

              onClick: () => setSortBy(s.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                sortBy === s.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              s.label
            }, s.value, false, {fileName: _jsxFileName, lineNumber: 202}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 200}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 198}, this)

      /* Date Filter Toggle */
      , _jsxDEV('button', {
        onClick: () => setShowDateFilter(!showDateFilter),
        className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
          showDateFilter || dateFrom || dateTo ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
        }`,
 children: [
        _jsxDEV(Calendar, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 222}, this ), "بازه زمانی"

      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 216}, this)
      , showDateFilter && (
        _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
          _jsxDEV(Input, { type: "date", value: dateFrom, onChange: (e) => setDateFrom(e.target.value), className: "text-xs",}, void 0, false, {fileName: _jsxFileName, lineNumber: 227}, this )
          , _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: "تا"}, void 0, false, {fileName: _jsxFileName, lineNumber: 228}, this)
          , _jsxDEV(Input, { type: "date", value: dateTo, onChange: (e) => setDateTo(e.target.value), className: "text-xs",}, void 0, false, {fileName: _jsxFileName, lineNumber: 229}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 226}, this)
      )

      /* Filter Chips */
      , _jsxDEV('div', { className: "space-y-2", children: [
        _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          CURRENCY_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setCurrencyFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                currencyFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 237}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 235}, this)
        , _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          TYPE_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setTypeFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                typeFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 250}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 248}, this)
        , _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          STATUS_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setStatusFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                statusFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 263}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 261}, this)
        , _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          DIRECTION_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setDirectionFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                directionFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 276}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 274}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 234}, this)

      , hasActiveFilters && (
        _jsxDEV('button', { onClick: clearAllFilters, className: "text-[10px] text-destructive flex items-center gap-1"    , children: [
          _jsxDEV(X, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 291}, this ), "پاک کردن فیلترها"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 290}, this)
      )

      /* Transaction List */
      , filtered.length === 0 ? (
        _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-6 text-center space-y-3"  , children: 
            transactions.length === 0 ? (
              _jsxDEV(_Fragment, { children: [
                _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "هنوز تراکنشی برای نمایش وجود ندارد."     }, void 0, false, {fileName: _jsxFileName, lineNumber: 302}, this)
                , _jsxDEV(Button, { variant: "outline", size: "sm", onClick: () => navigate('/customer'), children: "بازگشت به صفحه اصلی"

                }, void 0, false, {fileName: _jsxFileName, lineNumber: 303}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 301}, this)
            ) : (
              _jsxDEV(_Fragment, { children: [
                _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "نتیجه‌ای برای جستجوی شما پیدا نشد."     }, void 0, false, {fileName: _jsxFileName, lineNumber: 309}, this)
                , _jsxDEV(Button, { variant: "outline", size: "sm", onClick: clearAllFilters, children: [
                  _jsxDEV(X, { className: "w-3.5 h-3.5 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 311}, this ), "پاک کردن جستجو"

                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 310}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 308}, this)
            )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 299}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 298}, this)
      ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          filtered.map((t) => {
            const st = STATUS_LABELS[t.status] || STATUS_LABELS.completed;
            const date = new Date(t.date);
            const icon = TYPE_ICONS[t.type] || '•';
            const isPositive = t.direction === 'in';
            return (
              _jsxDEV(Card, { className: "shadow-sm cursor-pointer hover:shadow-md transition-shadow"   , onClick: () => setSelectedTxn(t), children: 
                _jsxDEV(CardContent, { className: "p-3 flex items-center gap-3"   , children: [
                  _jsxDEV('div', { className: `w-9 h-9 rounded-lg flex items-center justify-center shrink-0 text-sm font-bold ${isPositive ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'}`, children: 
                    icon
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 328}, this)
                  , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
                    _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                      _jsxDEV('p', { className: "text-xs font-medium text-foreground truncate"   , children: t.type_label}, void 0, false, {fileName: _jsxFileName, lineNumber: 333}, this)
                      , _jsxDEV('span', { className: `text-[8px] px-1.5 py-0.5 rounded ${st.color}`, children: st.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 334}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 332}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground truncate"  , children: [
                      t.id, " • "  , t.doc_no, " • "  , date.toLocaleDateString('fa-IR'), " • "  , date.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 336}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 331}, this)
                  , _jsxDEV('div', { className: "text-left shrink-0" , children: [
                    _jsxDEV('p', { className: `text-sm font-bold ${isPositive ? 'text-success' : 'text-destructive'}`, children: [
                      isPositive ? '+' : '-', (t.amount || 0).toLocaleString('fa-IR')
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 341}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: t.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 344}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 340}, this)
                  , _jsxDEV(ChevronLeft, { className: "w-4 h-4 text-muted-foreground shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 346}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 327}, this)
              }, t.id, false, {fileName: _jsxFileName, lineNumber: 326}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 319}, this)
      )

      /* Detail Sheet */
      , _jsxDEV(Sheet, { open: !!selectedTxn, onOpenChange: (open) => !open && setSelectedTxn(null), children: 
        _jsxDEV(SheetContent, { side: "bottom", className: "max-h-[90vh] overflow-y-auto" , children: [
          _jsxDEV(SheetHeader, { children: [
            _jsxDEV(SheetTitle, { children: "جزئیات تراکنش" }, void 0, false, {fileName: _jsxFileName, lineNumber: 358}, this)
            , _jsxDEV(SheetDescription, { children: _optionalChain([selectedTxn, 'optionalAccess', _ => _.type_label]) || ''}, void 0, false, {fileName: _jsxFileName, lineNumber: 359}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 357}, this)
          , selectedTxn && (
            _jsxDEV('div', { className: "space-y-3 mt-4" , children: [
              _jsxDEV(Card, { className: "shadow-sm", children: 
                _jsxDEV(CardContent, { className: "p-4 text-center" , children: [
                  _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "مبلغ عملیات" }, void 0, false, {fileName: _jsxFileName, lineNumber: 365}, this)
                  , _jsxDEV('p', { className: "text-2xl font-bold text-foreground"  , children: (selectedTxn.amount || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 366}, this)
                  , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: selectedTxn.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 367}, this)
                  , _jsxDEV('span', { className: `inline-block mt-2 text-[9px] px-2 py-1 rounded ${(STATUS_LABELS[selectedTxn.status] || STATUS_LABELS.completed).color}`, children: 
                    (STATUS_LABELS[selectedTxn.status] || STATUS_LABELS.completed).label
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 368}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 364}, this)
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 363}, this)
              , _jsxDEV(Card, { className: "shadow-sm", children: 
                _jsxDEV(CardContent, { className: "p-3 space-y-2" , children: [
                  _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "شماره تراکنش:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 376}, this)
                    , _jsxDEV('span', { className: "font-mono text-primary font-bold text-[10px]"   , children: selectedTxn.id}, void 0, false, {fileName: _jsxFileName, lineNumber: 377}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 375}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "شماره سند:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 380}, this)
                    , _jsxDEV('span', { className: "font-mono text-foreground text-[10px]"  , children: selectedTxn.doc_no}, void 0, false, {fileName: _jsxFileName, lineNumber: 381}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 379}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "تاریخ:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 384}, this)
                    , _jsxDEV('span', { className: "text-foreground text-[10px]" , children: new Date(selectedTxn.date).toLocaleDateString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 385}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 383}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "ساعت:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 388}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: new Date(selectedTxn.date).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}, void 0, false, {fileName: _jsxFileName, lineNumber: 389}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 387}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "نوع عملیات:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 392}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: selectedTxn.type_label}, void 0, false, {fileName: _jsxFileName, lineNumber: 393}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 391}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "ارز:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 396}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: selectedTxn.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 397}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 395}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 400}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: (selectedTxn.amount || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 401}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 399}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "مانده قبل:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 404}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: (selectedTxn.balance_before || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 405}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 403}, this)
                  , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                    _jsxDEV('span', { className: "text-muted-foreground", children: "مانده بعد:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 408}, this)
                    , _jsxDEV('span', { className: "text-foreground", children: (selectedTxn.balance_after || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 409}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 407}, this)
                  , selectedTxn.sender_name && (
                    _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                      _jsxDEV('span', { className: "text-muted-foreground", children: "فرستنده:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 413}, this)
                      , _jsxDEV('span', { className: "text-foreground", children: selectedTxn.sender_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 414}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 412}, this)
                  )
                  , selectedTxn.receiver_name && (
                    _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                      _jsxDEV('span', { className: "text-muted-foreground", children: "گیرنده:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 419}, this)
                      , _jsxDEV('span', { className: "text-foreground", children: selectedTxn.receiver_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 420}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 418}, this)
                  )
                  , selectedTxn.description && (
                    _jsxDEV('div', { className: "pt-2 border-t border-border"  , children: [
                      _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-1"  , children: "توضیحات:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 425}, this)
                      , _jsxDEV('p', { className: "text-xs text-foreground" , children: selectedTxn.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 426}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 424}, this)
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 374}, this)
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 373}, this)

              /* Related Links */
              , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
                _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-2.5 gap-1"   , onClick: () => navigate('/customer/wallet'), children: [
                  _jsxDEV(Wallet, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 435}, this )
                  , _jsxDEV('span', { className: "text-[10px]", children: "کیف پول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 436}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 434}, this)
                , selectedTxn.order_id ? (
                  _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-2.5 gap-1"   , onClick: () => navigate('/customer/orders'), children: [
                    _jsxDEV(Package, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 440}, this )
                    , _jsxDEV('span', { className: "text-[10px]", children: ["سفارش " , selectedTxn.order_id]}, void 0, true, {fileName: _jsxFileName, lineNumber: 441}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 439}, this)
                ) : (
                  _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-2.5 gap-1"   , onClick: () => navigate('/customer/account'), children: [
                    _jsxDEV(Package, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 445}, this )
                    , _jsxDEV('span', { className: "text-[10px]", children: "حساب صرافی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 446}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 444}, this)
                )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 433}, this)

              , _jsxDEV('div', { className: "flex items-center gap-1.5 text-[10px] text-muted-foreground bg-muted/50 rounded-lg p-2"       , children: [
                _jsxDEV(Database, { className: "w-3 h-3 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 452}, this ), "حالت آزمایشی — Supabase متصل نیست"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 451}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 362}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 356}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 355}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 148}, this)
  );
}