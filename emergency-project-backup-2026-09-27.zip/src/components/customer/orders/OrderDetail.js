const _jsxFileName = "src/components/customer/orders/OrderDetail.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from '../../ui/sheet.js';
import { Card, CardContent } from '../../ui/card.js';
import { Button } from '../../ui/button.js';
import { Database, Wallet, MessageSquare, CheckCircle2, XCircle, Clock, XOctagon } from 'lucide-react';
import OrderTimeline from './OrderTimeline.js';

const STATUS_LABELS = {
  new: { label: 'جدید', color: 'bg-blue-100 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400' },
  review: { label: 'در حال بررسی', color: 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400' },
  approved: { label: 'تأیید شده', color: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/30 dark:text-cyan-400' },
  processing: { label: 'در حال انجام', color: 'bg-purple-100 text-purple-700 dark:bg-purple-950/30 dark:text-purple-400' },
  completed: { label: 'تکمیل شده', color: 'bg-success/15 text-success' },
  rejected: { label: 'رد شده', color: 'bg-destructive/15 text-destructive' },
  cancelled: { label: 'لغو شده', color: 'bg-muted text-muted-foreground' },
};

const STATUS_MESSAGES = {
  new: { text: 'سفارش شما ثبت شده و در انتظار بررسی است.', icon: Clock, color: 'text-blue-600 dark:text-blue-400' },
  review: { text: 'سفارش شما در حال بررسی است.', icon: Clock, color: 'text-amber-600 dark:text-amber-400' },
  approved: { text: 'سفارش شما تأیید شده و در حال آماده‌سازی است.', icon: CheckCircle2, color: 'text-cyan-600 dark:text-cyan-400' },
  processing: { text: 'سفارش شما در حال انجام است.', icon: Clock, color: 'text-purple-600 dark:text-purple-400' },
  completed: { text: 'این سفارش با موفقیت تکمیل شده است.', icon: CheckCircle2, color: 'text-success' },
  rejected: { text: 'این سفارش رد شده است.', icon: XCircle, color: 'text-destructive' },
  cancelled: { text: 'این سفارش لغو شده است.', icon: XOctagon, color: 'text-muted-foreground' },
};

export default function OrderDetail({ open, onOpenChange, order }) {
  const navigate = useNavigate();
  if (!order) return null;
  const st = STATUS_LABELS[order.status] || STATUS_LABELS.new;
  const sm = STATUS_MESSAGES[order.status] || STATUS_MESSAGES.new;
  const StatusMsgIcon = sm.icon;

  return (
    _jsxDEV(Sheet, { open: open, onOpenChange: onOpenChange, children: 
      _jsxDEV(SheetContent, { side: "bottom", className: "max-h-[90vh] overflow-y-auto" , children: [
        _jsxDEV(SheetHeader, { children: [
          _jsxDEV(SheetTitle, { children: "جزئیات سفارش" }, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this)
          , _jsxDEV(SheetDescription, { children: order.title}, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 41}, this)

        , _jsxDEV('div', { className: "space-y-3 mt-4" , children: [
          /* Amount & Status */
          _jsxDEV(Card, { className: "shadow-sm", children: 
            _jsxDEV(CardContent, { className: "p-4 text-center" , children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "مبلغ سفارش" }, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this)
              , _jsxDEV('p', { className: "text-2xl font-bold text-foreground"  , children: (order.amount || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 51}, this)
              , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: order.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 52}, this)
              , _jsxDEV('span', { className: `inline-block mt-2 text-[9px] px-2 py-1 rounded ${st.color}`, children: 
                st.label
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 53}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 49}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this)

          /* Special Status Message */
          , _jsxDEV('div', { className: `flex items-center gap-2 rounded-lg p-3 bg-muted/50 ${sm.color}`, children: [
            _jsxDEV(StatusMsgIcon, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this )
            , _jsxDEV('p', { className: "text-xs font-medium" , children: sm.text}, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 60}, this)

          /* Timeline */
          , _jsxDEV(OrderTimeline, { timeline: order.timeline, status: order.status,}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this )

          /* Details */
          , _jsxDEV(Card, { className: "shadow-sm", children: 
            _jsxDEV(CardContent, { className: "p-3 space-y-2" , children: [
              _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "شماره سفارش:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this)
                , _jsxDEV('span', { className: "font-mono text-primary font-bold text-[10px]"   , children: order.id}, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 71}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "شماره پیگیری:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)
                , _jsxDEV('span', { className: "font-mono text-foreground text-[10px]"  , children: order.tracking_number}, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 75}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "عنوان:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)
                , _jsxDEV('span', { className: "text-foreground", children: order.title}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 79}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "نوع خدمت:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this)
                , _jsxDEV('span', { className: "text-foreground", children: order.service_type_label}, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 83}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "ایجادکننده:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)
                , _jsxDEV('span', { className: "text-foreground", children: order.created_by_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 87}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "مشتری:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 92}, this)
                , _jsxDEV('span', { className: "text-foreground", children: order.customer_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 91}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "تاریخ ایجاد:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this)
                , _jsxDEV('span', { className: "text-foreground text-[10px]" , children: [new Date(order.created_date).toLocaleDateString('fa-IR'), " • "  , new Date(order.created_date).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })]}, void 0, true, {fileName: _jsxFileName, lineNumber: 97}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "آخرین بروزرسانی:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 100}, this)
                , _jsxDEV('span', { className: "text-foreground text-[10px]" , children: [new Date(order.last_updated).toLocaleDateString('fa-IR'), " • "  , new Date(order.last_updated).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })]}, void 0, true, {fileName: _jsxFileName, lineNumber: 101}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 99}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this)
                , _jsxDEV('span', { className: "text-foreground", children: [(order.amount || 0).toLocaleString('fa-IR'), " " , order.currency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 105}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 103}, this)
              , order.fee != null && order.fee > 0 && (
                _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "کارمزد:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this)
                  , _jsxDEV('span', { className: "text-foreground", children: [(order.fee || 0).toLocaleString('fa-IR'), " " , order.currency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 110}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 108}, this)
              )
              , _jsxDEV('div', { className: "flex justify-between text-xs pt-2 border-t border-border"     , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ نهایی:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
                , _jsxDEV('span', { className: "font-bold text-primary" , children: [(order.total_amount || 0).toLocaleString('fa-IR'), " " , order.currency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 115}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 113}, this)
              , order.description && (
                _jsxDEV('div', { className: "pt-2 border-t border-border"  , children: [
                  _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-1"  , children: "توضیحات:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this)
                  , _jsxDEV('p', { className: "text-xs text-foreground" , children: order.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 118}, this)
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 70}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this)

          /* Related Links */
          , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-2.5 gap-1"   , onClick: () => navigate('/customer/wallet'), children: [
              _jsxDEV(Wallet, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this )
              , _jsxDEV('span', { className: "text-[10px]", children: "کیف پول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 128}, this)
            , _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-2.5 gap-1"   , onClick: () => navigate('/customer/messages'), children: [
              _jsxDEV(MessageSquare, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 133}, this )
              , _jsxDEV('span', { className: "text-[10px]", children: "پیام‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 134}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 132}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 127}, this)

          , _jsxDEV('div', { className: "flex items-center gap-1.5 text-[10px] text-muted-foreground bg-muted/50 rounded-lg p-2"       , children: [
            _jsxDEV(Database, { className: "w-3 h-3 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this ), "حالت آزمایشی — Supabase متصل نیست"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 138}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 46}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 40}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 39}, this)
  );
}