const _jsxFileName = "src/components/customer/orders/OrderTimeline.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';
import { Card, CardContent } from '../../ui/card.js';
import { Check } from 'lucide-react';

const STEP_ORDER = ['registered', 'review', 'approved', 'processing', 'completed'];

export default function OrderTimeline({ timeline, status }) {
  if (!timeline || timeline.length === 0) return null;

  // For rejected/cancelled, show only the done steps
  const isTerminal = status === 'rejected' || status === 'cancelled';

  return (
    _jsxDEV(Card, { className: "shadow-sm", children: 
      _jsxDEV(CardContent, { className: "p-3", children: [
        _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-3"  , children: "مراحل انجام سفارش"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 16}, this)
        , _jsxDEV('div', { className: "flex items-start justify-between"  , children: 
          timeline.map((step, idx) => {
            const isLast = idx === timeline.length - 1;
            return (
              _jsxDEV('div', { className: "flex flex-col items-center flex-1 min-w-0"    , children: [
                _jsxDEV('div', { className: "flex items-center w-full"  , children: [
                  idx > 0 && (
                    _jsxDEV('div', { className: `flex-1 h-0.5 ${timeline[idx - 1].done ? 'bg-success' : 'bg-border'}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 24}, this )
                  )
                  , _jsxDEV('div', { className: `w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                    step.done
                      ? (isTerminal && isLast ? 'bg-destructive text-destructive-foreground' : 'bg-success text-success-foreground')
                      : 'bg-muted text-muted-foreground'
                  }`, children: 
                    step.done ? _jsxDEV(Check, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 31}, this ) : _jsxDEV('span', { className: "text-[9px]", children: idx + 1}, void 0, false, {fileName: _jsxFileName, lineNumber: 31}, this)
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 26}, this)
                  , idx < timeline.length - 1 && (
                    _jsxDEV('div', { className: `flex-1 h-0.5 ${step.done ? 'bg-success' : 'bg-border'}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 34}, this )
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 22}, this)
                , _jsxDEV('p', { className: `text-[9px] mt-1 text-center ${step.done ? 'text-foreground font-medium' : 'text-muted-foreground'}`, children: 
                  step.label
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this)
                , step.date && (
                  _jsxDEV('p', { className: "text-[8px] text-muted-foreground text-center"  , children: 
                    new Date(step.date).toLocaleDateString('fa-IR')
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this)
                )
              ]}, step.step, true, {fileName: _jsxFileName, lineNumber: 21}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 17}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 15}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 14}, this)
  );
}