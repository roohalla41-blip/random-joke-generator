const _jsxFileName = "src/components/AppGate.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { useAuth } from '../lib/AuthContext.js';
import WelcomeSplash from './WelcomeSplash.js';
import { seedBase44Entities } from '../lib/seedBase44Entities.js';
import { useKeepAlive } from '../lib/useKeepAlive.js';

export default function AppGate({ children }) {
  const { isLoadingAuth, isLoadingPublicSettings } = useAuth();
  const loading = isLoadingAuth || isLoadingPublicSettings;
  const [showSplash, setShowSplash] = useState(true);

  useKeepAlive();

  useEffect(() => {
    seedBase44Entities();
  }, []);

  useEffect(() => {
    if (!loading) {
      // give splash a moment to finish its counter if it hasn't
      const t = setTimeout(() => setShowSplash(false), 300);
      return () => clearTimeout(t);
    }
  }, [loading]);

  if (showSplash && loading) {
    return _jsxDEV(WelcomeSplash, { onDone: () => setShowSplash(false),}, void 0, false, {fileName: _jsxFileName, lineNumber: 27}, this );
  }

  return children;
}