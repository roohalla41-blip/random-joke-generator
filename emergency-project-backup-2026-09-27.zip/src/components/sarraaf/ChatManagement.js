const _jsxFileName = "src/components/sarraaf/ChatManagement.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useChatGroups, useCreateGroup, useUpdateGroup, useDeleteGroup, seedDefaultGroups } from '../../lib/useChat.js';
import { useAuth } from '../../lib/AuthContext.js';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Label } from '../ui/label.js';
import { Textarea } from '../ui/textarea.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../ui/dialog.js';
import { toast } from '../ui/use-toast.js';
import { Plus, Pencil, Trash2, Globe, Lock, Users, Sparkles } from 'lucide-react';

export default function ChatManagement() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const { data: groups, isLoading } = useChatGroups();
  const createMut = useCreateGroup();
  const updateMut = useUpdateGroup();
  const deleteMut = useDeleteGroup();

  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ name: '', description: '', type: 'public', rules: '' });
  const [seeded, setSeeded] = useState(false);

  // Auto-seed two default groups on first load
  useEffect(() => {
    if (seeded || !user) return;
    (async () => {
      try {
        const created = await seedDefaultGroups(user);
        if (created.length > 0) {
          qc.invalidateQueries({ queryKey: ['chatGroups'] });
          toast({ title: 'گروه‌های پیش‌فرض', description: `${created.length} گروه پیش‌فرض ایجاد شد` });
        }
      } catch (e2) {
        // ignore
      }
      setSeeded(true);
    })();
  }, [user, seeded]);

  const openCreate = () => {
    setEditId(null);
    setForm({ name: '', description: '', type: 'public', rules: '' });
    setShowForm(true);
  };

  const openEdit = (g) => {
    setEditId(g.id);
    setForm({ name: g.name, description: g.description || '', type: g.type, rules: g.rules || '' });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.name.trim()) {
      toast({ title: 'خطا', description: 'نام گروه الزامی است', variant: 'destructive' });
      return;
    }
    try {
      if (editId) {
        await updateMut.mutateAsync({ id: editId, data: { name: form.name.trim(), description: form.description.trim(), type: form.type, rules: form.rules.trim() } });
        toast({ title: 'ویرایش شد', description: 'گروه به‌روزرسانی شد' });
      } else {
        await createMut.mutateAsync({
          name: form.name.trim(),
          description: form.description.trim(),
          type: form.type,
          rules: form.rules.trim(),
          creator_id: user.id,
          creator_name: user.full_name || user.email || 'مدیر سیستم',
          creator_managed: true,
          status: 'active',
          member_count: 1,
        });
        toast({ title: 'ایجاد شد', description: 'گروه جدید ایجاد شد' });
      }
      setShowForm(false);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleDelete = async (g) => {
    if (!confirm(`حذف گروه «${g.name}»؟ تمام پیام‌ها و اعضا حذف می‌شوند.`)) return;
    try {
      await deleteMut.mutateAsync(g.id);
      toast({ title: 'حذف شد', description: 'گروه حذف شد' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleReSeed = async () => {
    setSeeded(false);
  };

  return (
    _jsxDEV(Card, { children: [
      _jsxDEV(CardContent, { className: "p-4", children: [
        _jsxDEV('div', { className: "flex items-center justify-between mb-3"   , children: [
          _jsxDEV('h3', { className: "text-sm font-semibold flex items-center gap-2"    , children: [
            _jsxDEV(Users, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this ), "مدیریت گروه‌های چت"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 104}, this)
          , _jsxDEV('div', { className: "flex gap-1" , children: [
            _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: handleReSeed, title: "ایجاد گروه‌های پیش‌فرض"  , children: 
              _jsxDEV(Sparkles, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this)
            , _jsxDEV(Button, { size: "sm", onClick: openCreate, children: [
              _jsxDEV(Plus, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this ), "گروه جدید"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 112}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 108}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 103}, this)

        , isLoading ? (
          _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "در حال بارگذاری..."  }, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this)
        ) : !groups || groups.length === 0 ? (
          _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "گروهی وجود ندارد. روی «گروه جدید» بزنید."      }, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this)
        ) : (
          _jsxDEV('div', { className: "space-y-2", children: 
            groups.map(g => (
              _jsxDEV('div', { className: "flex items-center justify-between p-2.5 rounded-lg border"     , children: [
                _jsxDEV('div', { className: "min-w-0 flex-1" , children: [
                  _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
                    g.type === 'private' ? _jsxDEV(Lock, { className: "w-3.5 h-3.5 text-purple-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this ) : _jsxDEV(Globe, { className: "w-3.5 h-3.5 text-green-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this )
                    , _jsxDEV('span', { className: "text-sm font-medium truncate"  , children: g.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 128}, this)
                  , g.description && _jsxDEV('p', { className: "text-[10px] text-muted-foreground truncate mt-0.5"   , children: g.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 132}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 127}, this)
                , _jsxDEV('div', { className: "flex gap-1 shrink-0"  , children: [
                  _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => openEdit(g), children: 
                    _jsxDEV(Pencil, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this)
                  , _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => handleDelete(g), children: 
                    _jsxDEV(Trash2, { className: "w-3.5 h-3.5 text-destructive"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 134}, this)
              ]}, g.id, true, {fileName: _jsxFileName, lineNumber: 126}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 102}, this)

      , _jsxDEV(Dialog, { open: showForm, onOpenChange: setShowForm, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: editId ? 'ویرایش گروه' : 'گروه جدید'}, void 0, false, {fileName: _jsxFileName, lineNumber: 150}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 150}, this)
          , _jsxDEV('div', { className: "space-y-3", children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نام گروه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 153}, this)
              , _jsxDEV(Input, { value: form.name, onChange: e => setForm({ ...form, name: e.target.value }), placeholder: "نام گروه" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 154}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 152}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "توضیحات"}, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this)
              , _jsxDEV(Textarea, { value: form.description, onChange: e => setForm({ ...form, description: e.target.value }), placeholder: "توضیحات (اختیاری)" , rows: 2,}, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 156}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نوع گروه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 161}, this)
              , _jsxDEV(Select, { value: form.type, onValueChange: v => setForm({ ...form, type: v }), children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this)
                , _jsxDEV(SelectContent, { children: [
                  _jsxDEV(SelectItem, { value: "public", children: "عمومی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this)
                  , _jsxDEV(SelectItem, { value: "private", children: "خصوصی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 166}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 164}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 162}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 160}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "قوانین (اختیاری)" }, void 0, false, {fileName: _jsxFileName, lineNumber: 171}, this)
              , _jsxDEV(Textarea, { value: form.rules, onChange: e => setForm({ ...form, rules: e.target.value }), placeholder: "قوانین گروه" , rows: 2,}, void 0, false, {fileName: _jsxFileName, lineNumber: 172}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 170}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 151}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setShowForm(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 176}, this)
            , _jsxDEV(Button, { onClick: handleSave, disabled: createMut.isPending || updateMut.isPending, children: 
              createMut.isPending || updateMut.isPending ? 'در حال ذخیره...' : 'ذخیره'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 177}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 175}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 149}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 101}, this)
  );
}