const _jsxFileName = "src/components/sarraaf/PaymentMethodsManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { createSupabaseEntity } from '../../lib/supabaseApi.js';
import { Card, CardContent } from '../ui/card.js';
import { Input } from '../ui/input.js';
import { Label } from '../ui/label.js';
import { Switch } from '../ui/switch.js';
import { Button } from '../ui/button.js';
import { useToast } from '../ui/use-toast.js';
import { Landmark, Globe, Bitcoin, CreditCard, Save, Loader2 } from 'lucide-react';

const sbFeatures = createSupabaseEntity('FeatureSetting');
const sbAppSettings = createSupabaseEntity('AppSetting');

const PAYMENT_METHODS = [
  {
    key: 'payment_card',
    label: 'کارت به کارت',
    icon: CreditCard,
    color: 'bg-purple-500',
    fields: [
      { key: 'card_number', label: 'شماره کارت', placeholder: '۶۰۳۷-xxxx-xxxx-xxxx' },
      { key: 'holder_name', label: 'نام صاحب کارت', placeholder: 'نام و نام خانوادگی' },
      { key: 'bank_name', label: 'نام بانک', placeholder: 'مثال: بانک کابل' },
      { key: 'sheba', label: 'شماره شبا', placeholder: 'AFxx xxxx xxxx xxxx xxxx xxxx' },
      { key: 'account_number', label: 'شماره حساب', placeholder: 'شماره حساب جاری' },
      { key: 'expiry', label: 'تاریخ انقضا', placeholder: 'MM/YY' },
    ],
  },
  {
    key: 'payment_bank',
    label: 'انتقال بانکی (درگاه)',
    icon: Landmark,
    color: 'bg-blue-500',
    fields: [
      { key: 'bank_name', label: 'نام بانک', placeholder: 'مثال: بانک کابل' },
      { key: 'account_number', label: 'شماره حساب', placeholder: 'شماره حساب جاری' },
      { key: 'holder_name', label: 'نام صاحب حساب', placeholder: 'نام و نام خانوادگی' },
      { key: 'sheba', label: 'شماره شبا', placeholder: 'AFxx xxxx xxxx xxxx xxxx xxxx' },
      { key: 'branch', label: 'نام شعبه', placeholder: 'نام شعبه بانک' },
      { key: 'branch_code', label: 'کد شعبه', placeholder: 'کد شعبه بانک' },
      { key: 'swift_code', label: 'کد SWIFT', placeholder: 'کد بین‌المللی بانک' },
      { key: 'gateway_merchant_id', label: 'شناسه پذیرنده درگاه', placeholder: 'Merchant ID' },
      { key: 'gateway_terminal_id', label: 'شماره ترمینال درگاه', placeholder: 'Terminal ID' },
      { key: 'gateway_callback_url', label: 'آدرس بازگشت (Callback)', placeholder: 'https://...' },
    ],
  },
  {
    key: 'payment_paypal',
    label: 'پی‌پل',
    icon: Globe,
    color: 'bg-indigo-500',
    fields: [
      { key: 'paypal_email', label: 'ایمیل پی‌پل', placeholder: 'email@example.com' },
      { key: 'paypal_client_id', label: 'Client ID', placeholder: 'PayPal Client ID' },
      { key: 'paypal_merchant_id', label: 'Merchant ID', placeholder: 'PayPal Merchant ID' },
      { key: 'paypal_currency', label: 'ارز', placeholder: 'USD / EUR' },
    ],
  },
  {
    key: 'payment_crypto',
    label: 'ارز دیجیتال',
    icon: Bitcoin,
    color: 'bg-amber-500',
    fields: [
      { key: 'wallet_address', label: 'آدرس کیف پول', placeholder: 'آدرس کیف پول' },
      { key: 'network', label: 'شبکه', placeholder: 'TRC20 / ERC20 / BEP20' },
      { key: 'coin_type', label: 'نوع ارز', placeholder: 'USDT / BTC / ETH' },
      { key: 'qr_code', label: 'لینک QR کد', placeholder: 'QR Code URL' },
    ],
  },
];

export default function PaymentMethodsManager() {
  const { toast } = useToast();
  const [features, setFeatures] = useState([]);
  const [configs, setConfigs] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const feats = await sbFeatures.list('display_order', 100);
        setFeatures(feats);
        const settings = await sbAppSettings.list('-created_date', 200);
        const cfgs = {};
        for (const m of PAYMENT_METHODS) {
          const s = settings.find(sx => sx.key === `${m.key}_config`);
          try {
            cfgs[m.key] = (_optionalChain([s, 'optionalAccess', _ => _.value]) && typeof s.value === 'string') ? JSON.parse(s.value) : (_optionalChain([s, 'optionalAccess', _2 => _2.value]) || {});
          } catch (e2) {
            cfgs[m.key] = {};
          }
        }
        setConfigs(cfgs);
      } catch (e3) {
        // ignore
      }
      setLoading(false);
    };
    load();
  }, []);

  const getFeature = (key) => features.find(f => f.feature_key === key);

  const toggleMethod = async (key) => {
    const f = getFeature(key);
    const newEnabled = f ? !(f.enabled !== false) : true;
    try {
      if (!f) {
        await sbFeatures.create({
          feature_key: key,
          name: _optionalChain([PAYMENT_METHODS, 'access', _3 => _3.find, 'call', _4 => _4(m => m.key === key), 'optionalAccess', _5 => _5.label]) || key,
          enabled: true,
          status: 'active',
          free_enabled: true,
          paid_enabled: true,
        });
      } else {
        await sbFeatures.update(f.id, {
          enabled: newEnabled,
          status: newEnabled ? 'active' : 'disabled',
        });
      }
      const feats = await sbFeatures.list('display_order', 100);
      setFeatures(feats);
      toast({ title: newEnabled ? 'فعال شد' : 'غیرفعال شد' });
    } catch (e4) {
      toast({ title: 'خطا', variant: 'destructive' });
    }
  };

  const updateConfig = (methodKey, fieldKey, value) => {
    setConfigs(prev => ({
      ...prev,
      [methodKey]: { ...prev[methodKey], [fieldKey]: value },
    }));
  };

  const saveConfig = async (methodKey) => {
    setSaving(methodKey);
    try {
      const settingKey = `${methodKey}_config`;
      const existing = (await sbAppSettings.list('-created_date', 200)).find(s => s.key === settingKey);
      const jsonValue = JSON.stringify(configs[methodKey] || {});
      if (existing) {
        await sbAppSettings.update(existing.id, { value: jsonValue });
      } else {
        await sbAppSettings.create({ key: settingKey, value: jsonValue });
      }
      toast({ title: 'تنظیمات ذخیره شد' });
    } catch (e5) {
      toast({ title: 'خطا در ذخیره', variant: 'destructive' });
    }
    setSaving(null);
  };

  if (loading) {
    return (
      _jsxDEV('div', { className: "flex items-center justify-center py-8"   , children: 
        _jsxDEV(Loader2, { className: "w-5 h-5 text-muted-foreground animate-spin"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 161}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this)
    );
  }

  return (
    _jsxDEV('div', { className: "space-y-3", children: [
      _jsxDEV('p', { className: "text-xs text-muted-foreground mb-2"  , children: "روش‌های پرداخت را فعال/غیرفعال کنید و اطلاعات هر روش را پر نمایید. روش غیرفعال برای کاربران به‌صورت «در حال به‌روزرسانی» نمایش داده می‌شود."

      }, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this)
      , PAYMENT_METHODS.map((m) => {
        const Icon = m.icon;
        const f = getFeature(m.key);
        const enabled = f ? f.enabled !== false && (f.status === 'active' || !f.status) : false;
        const cfg = configs[m.key] || {};
        return (
          _jsxDEV(Card, { children: 
            _jsxDEV(CardContent, { className: "p-3 space-y-3" , children: [
              /* Header */
              _jsxDEV('div', { className: "flex items-center gap-3"  , children: [
                _jsxDEV('div', { className: `w-9 h-9 rounded-lg ${m.color} flex items-center justify-center shrink-0`, children: 
                  _jsxDEV(Icon, { className: "w-5 h-5 text-white"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 181}, this)
                , _jsxDEV('div', { className: "flex-1", children: [
                  _jsxDEV('p', { className: "text-sm font-bold" , children: m.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 185}, this)
                  , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: enabled ? 'فعال' : 'غیرفعال'}, void 0, false, {fileName: _jsxFileName, lineNumber: 186}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 184}, this)
                , _jsxDEV(Switch, { checked: enabled, onCheckedChange: () => toggleMethod(m.key),}, void 0, false, {fileName: _jsxFileName, lineNumber: 188}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 180}, this)

              /* Fields */
              , _jsxDEV('div', { className: "grid grid-cols-1 gap-2 pt-1"   , children: 
                m.fields.map((field) => (
                  _jsxDEV('div', { children: [
                    _jsxDEV(Label, { className: "text-[10px]", children: field.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 195}, this)
                    , _jsxDEV(Input, {
                      value: cfg[field.key] || '',
                      onChange: (e) => updateConfig(m.key, field.key, e.target.value),
                      placeholder: field.placeholder || field.label,
                      dir: "ltr",
                      className: "text-xs h-8 mt-0.5"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 196}, this
                    )
                  ]}, field.key, true, {fileName: _jsxFileName, lineNumber: 194}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 192}, this)

              , _jsxDEV(Button, {
                size: "sm",
                variant: "outline",
                className: "w-full h-8" ,
                onClick: () => saveConfig(m.key),
                disabled: saving === m.key,
 children: [
                saving === m.key ? _jsxDEV(Loader2, { className: "w-3 h-3 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 214}, this ) : _jsxDEV(Save, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 214}, this ), "ذخیره تنظیمات"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 207}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 178}, this)
          }, m.key, false, {fileName: _jsxFileName, lineNumber: 177}, this)
        );
      })
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 167}, this)
  );
}