const _jsxFileName = "src/components/sarraaf/PlanPricingManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _nullishCoalesce(lhs, rhsFn) { if (lhs != null) { return lhs; } else { return rhsFn(); } }// PlanPricingManager.jsx — Builder panel for managing plan prices and discount campaigns
import React, { useState, useEffect } from 'react';
import { usePricingPlans, useUpdatePlan, useDiscountCampaign, useStartCampaign, useStopCampaign } from '../../lib/usePricing.js';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Label } from '../ui/label.js';
import { toast } from '../ui/use-toast.js';
import { CreditCard, Percent, Clock, Play, Square, Save } from 'lucide-react';

const CURRENCY_LABELS = { AFN: 'افغانی', IRT: 'تومان', USD: 'دلار' };

export default function PlanPricingManager() {
  const { data: plans, isLoading } = usePricingPlans();
  const { data: campaign } = useDiscountCampaign();
  const updateMut = useUpdatePlan();
  const startMut = useStartCampaign();
  const stopMut = useStopCampaign();
  const [editing, setEditing] = useState({});

  useEffect(() => {
    if (plans) {
      const obj = {};
      plans.forEach(p => {
        obj[p.id] = { price: p.price, name: p.name, description: p.description || '' };
      });
      setEditing(obj);
    }
  }, [plans]);

  const handleSave = (plan) => {
    const edits = editing[plan.id];
    if (!edits) return;
    updateMut.mutate(
      { id: plan.id, data: { price: Number(edits.price), name: edits.name, description: edits.description } },
      {
        onSuccess: () => toast({ title: 'ذخیره شد', description: `قیمت پلن ${plan.name} به‌روزرسانی شد` }),
        onError: (e) => toast({ title: 'خطا', description: e.message, variant: 'destructive' }),
      }
    );
  };

  const handleStartCampaign = () => {
    startMut.mutate(
      { percent: 30, durationHours: 48 },
      {
        onSuccess: () => toast({ title: 'کمپین فعال شد', description: 'تخفیف ۳۰٪ برای ۴۸ ساعت روی همه پلن‌ها' }),
        onError: (e) => toast({ title: 'خطا', description: e.message, variant: 'destructive' }),
      }
    );
  };

  const handleStopCampaign = () => {
    stopMut.mutate(
      {},
      {
        onSuccess: () => toast({ title: 'کمپین متوقف شد' }),
        onError: (e) => toast({ title: 'خطا', description: e.message, variant: 'destructive' }),
      }
    );
  };

  if (isLoading) {
    return (
      _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4 text-center text-sm text-muted-foreground"   , children: "در حال بارگذاری..."  }, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this)
    );
  }

  return (
    _jsxDEV('div', { className: "space-y-3", children: [
      /* Discount Campaign */
      _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
          _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
            _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
              _jsxDEV(Percent, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this )
              , _jsxDEV('h3', { className: "text-sm font-semibold" , children: "کمپین تخفیف" }, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 77}, this)
            , campaign && !campaign.expired && campaign.active ? (
              _jsxDEV(Button, { size: "sm", variant: "destructive", onClick: handleStopCampaign, disabled: stopMut.isPending, children: [
                _jsxDEV(Square, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this ), "توقف کمپین"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 82}, this)
            ) : (
              _jsxDEV(Button, { size: "sm", onClick: handleStartCampaign, disabled: startMut.isPending, children: [
                _jsxDEV(Play, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this ), "شروع کمپین ۴۸ ساعته"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 87}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 76}, this)

          , campaign && !campaign.expired && campaign.active ? (
            _jsxDEV('div', { className: "rounded-lg bg-green-50 border border-green-200 p-3 text-xs space-y-1"      , children: [
              _jsxDEV('div', { className: "flex items-center gap-2 font-medium text-green-700"    , children: [
                _jsxDEV(Clock, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this ), "تخفیف "
                 , campaign.percent, "٪ فعال روی همه پلن‌های پولی"
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 96}, this)
              , _jsxDEV('p', { className: "text-green-600", children: ["شروع: "
                 , new Date(campaign.start_date).toLocaleString('fa-IR')
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 100}, this)
              , _jsxDEV('p', { className: "text-green-600", children: ["پایان: "
                 , new Date(campaign.end_date).toLocaleString('fa-IR')
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 103}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)
          ) : (
            _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "با شروع کمپین، تخفیف ۳۰٪ به‌مدت ۴۸ ساعت روی تمام پلن‌های پولی اعمال می‌شود و اعلانی برای همه صرافان ارسال می‌گردد."

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 75}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this)

      /* Plan Pricing */
      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
          _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            _jsxDEV(CreditCard, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this )
            , _jsxDEV('h3', { className: "text-sm font-semibold" , children: "قیمت‌گذاری پلن‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 118}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "قیمت پلن‌ها را ویرایش کنید — تغییرات فوراً برای صرافان نمایش داده می‌شود."

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this)

          , _jsxDEV('div', { className: "space-y-2", children: 
            (plans || []).map(plan => {
              const edits = editing[plan.id] || {};
              return (
                _jsxDEV('div', { className: "rounded-lg border p-3 space-y-2"   , children: [
                  _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
                    _jsxDEV('span', { className: "text-sm font-bold" , children: plan.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 132}, this)
                    , _jsxDEV('span', { className: "text-[10px] bg-muted px-1.5 py-0.5 rounded text-muted-foreground"     , children: 
                      plan.plan_key
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 133}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 131}, this)
                  , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
                    _jsxDEV('div', { children: [
                      _jsxDEV(Label, { className: "text-[10px]", children: "نام پلن" }, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this)
                      , _jsxDEV(Input, {
                        value: edits.name || '',
                        onChange: e => setEditing(s => ({ ...s, [plan.id]: { ...s[plan.id], name: e.target.value } })),
                        className: "h-8 text-sm mt-0.5"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 140}, this
                      )
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 138}, this)
                    , _jsxDEV('div', { children: [
                      _jsxDEV(Label, { className: "text-[10px]", children: ["قیمت (" , CURRENCY_LABELS[plan.currency] || 'افغانی', ")"]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
                      , _jsxDEV(Input, {
                        type: "number",
                        value: _nullishCoalesce(edits.price, () => ( 0)),
                        onChange: e => setEditing(s => ({ ...s, [plan.id]: { ...s[plan.id], price: e.target.value } })),
                        className: "h-8 text-sm mt-0.5"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this
                      )
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 146}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 137}, this)
                  , _jsxDEV('div', { children: [
                    _jsxDEV(Label, { className: "text-[10px]", children: "توضیحات"}, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this)
                    , _jsxDEV(Input, {
                      value: edits.description || '',
                      onChange: e => setEditing(s => ({ ...s, [plan.id]: { ...s[plan.id], description: e.target.value } })),
                      className: "h-8 text-xs mt-0.5"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this
                    )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 156}, this)
                  , _jsxDEV(Button, { size: "sm", className: "w-full", onClick: () => handleSave(plan), disabled: updateMut.isPending, children: [
                    _jsxDEV(Save, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this ), "ذخیره"

                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 164}, this)
                ]}, plan.id, true, {fileName: _jsxFileName, lineNumber: 130}, this)
              );
            })
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 117}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 72}, this)
  );
}