const _jsxFileName = "src/components/sarraaf/SystemOverview.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '../ui/card.js';
import { createSupabaseEntity } from '../../lib/supabaseApi.js';
import {
  Database, CheckCircle2, XCircle, HardDrive, Table, Activity,
  Server, Cloud, AlertTriangle, Loader2, RefreshCw, Box, Clock
} from 'lucide-react';

// تمام موجودیت‌های سیستم برای شمارش رکوردها
const ALL_ENTITIES = [
  { name: 'Transaction', label: 'تراکنش‌ها', icon: Activity },
  { name: 'Transfer', label: 'حواله‌ها', icon: Box },
  { name: 'Customer', label: 'مشتریان', icon: Box },
  { name: 'Agent', label: 'نمایندگی‌ها', icon: Box },
  { name: 'Currency', label: 'ارزها', icon: Box },
  { name: 'BankAccount', label: 'حساب‌های بانکی', icon: Box },
  { name: 'RateSetting', label: 'تنظیمات نرخ', icon: Box },
  { name: 'FeatureSetting', label: 'تنظیمات بخش‌ها', icon: Box },
  { name: 'SarraafProfile', label: 'پروفایل صراف‌ها', icon: Box },
  { name: 'AgencyLink', label: 'لینک‌های نمایندگی', icon: Box },
  { name: 'AuditLog', label: 'لاگ‌های ممیزی', icon: Box },
  { name: 'ChatGroup', label: 'گروه‌های چت', icon: Box },
  { name: 'GroupMember', label: 'اعضای گروه', icon: Box },
  { name: 'GroupMessage', label: 'پیام‌های گروه', icon: Box },
  { name: 'MessageReport', label: 'گزارش پیام‌ها', icon: Box },
  { name: 'UserNotification', label: 'اعلان‌های کاربر', icon: Box },
  { name: 'UserPermission', label: 'مجوزهای کاربر', icon: Box },
  { name: 'PlanQuota', label: 'سهمیه پلن', icon: Box },
  { name: 'PaymentRecord', label: 'رکوردهای پرداخت', icon: Box },
  { name: 'Wallet', label: 'کیف پول‌ها', icon: Box },
  { name: 'WalletTransaction', label: 'تراکنش‌های کیف پول', icon: Box },
  { name: 'WalletTopupRequest', label: 'درخواست‌های شارژ', icon: Box },
  { name: 'WalletBan', label: 'مسدودی کیف پول', icon: Box },
  { name: 'LedgerEntry', label: 'ثبت‌های دفتر کل', icon: Box },
  { name: 'OnlineOrder', label: 'سفارش‌های آنلاین', icon: Box },
  { name: 'OnlineProduct', label: 'محصولات آنلاین', icon: Box },
  { name: 'Seller', label: 'فروشندگان', icon: Box },
  { name: 'Package', label: 'بسته‌ها', icon: Box },
  { name: 'CustomerNotification', label: 'اعلان‌های مشتری', icon: Box },
  { name: 'CustomerTransferRequest', label: 'درخواست حواله مشتری', icon: Box },
  { name: 'CustomerLink', label: 'لینک‌های مشتری', icon: Box },
  { name: 'Announcement', label: 'اطلاعیه‌ها', icon: Box },
  { name: 'QuotaChangeLog', label: 'لاگ تغییر سهمیه', icon: Box },
  { name: 'PricingPlan', label: 'پلن‌های قیمت‌گذاری', icon: Box },
  { name: 'AppSetting', label: 'تنظیمات برنامه', icon: Box },
  { name: 'TextLabel', label: 'برچسب‌های متنی', icon: Box },
  { name: 'BackupRecord', label: 'رکوردهای بکاپ', icon: Box },
];

// محاسبه فضای مصرفی localStorage
function getStorageInfo() {
  let total = 0;
  const breakdown = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    const value = localStorage.getItem(key) || '';
    const size = new Blob([value]).size;
    total += size;
    breakdown.push({ key, size });
  }
  breakdown.sort((a, b) => b.size - a.size);
  return { total, breakdown };
}

function formatBytes(bytes) {
  if (bytes === 0) return '۰ بایت';
  if (bytes < 1024) return `${bytes.toLocaleString('fa-IR')} بایت`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1).toLocaleString('fa-IR')} کیلوبایت`;
  return `${(bytes / (1024 * 1024)).toFixed(2).toLocaleString('fa-IR')} مگابایت`;
}

function toFaNum(n) {
  return Number(n || 0).toLocaleString('fa-IR');
}

export default function SystemOverview() {
  const [connectionStatus, setConnectionStatus] = useState('checking'); // checking | connected | disconnected
  const [syncPending, setSyncPending] = useState(0);
  const [entityCounts, setEntityCounts] = useState({});
  const [storageInfo, setStorageInfo] = useState({ total: 0, breakdown: [] });
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    let cancelled = false;

    async function loadData() {
      setLoading(true);
      // 1. تست اتصال Supabase — بررسی از طریق وضعیت آنلاین و داده‌های لوکال
      try {
        const isOnline = typeof navigator !== 'undefined' && navigator.onLine;
        if (isOnline) {
          // بررسی اتصال با پینگ ساده به API
          const res = await fetch(`${window.location.origin}/functions/supabase`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'test' }),
          }).catch(() => null);
          if (!cancelled) {
            setConnectionStatus(res && res.ok ? 'connected' : 'disconnected');
          }
        } else {
          if (!cancelled) setConnectionStatus('disconnected');
        }
      } catch (e) {
        if (!cancelled) setConnectionStatus('disconnected');
      }

      // 1b. تعداد عملیات در انتظار همگام‌سازی
      try {
        const { getPendingCount } = await import('../../lib/offlineQueue.js');
        if (!cancelled) setSyncPending(getPendingCount());
      } catch (e2) {
        if (!cancelled) setSyncPending(0);
      }

      // 2. شمارش رکوردهای هر موجودیت از Supabase
      const counts = {};
      for (const entity of ALL_ENTITIES) {
        try {
          const sb = createSupabaseEntity(entity.name);
          const items = await sb.list();
          counts[entity.name] = Array.isArray(items) ? items.length : 0;
        } catch (e3) {
          counts[entity.name] = 0;
        }
      }
      if (!cancelled) setEntityCounts(counts);

      // 3. فضای ذخیره‌سازی
      if (!cancelled) setStorageInfo(getStorageInfo());

      if (!cancelled) setLoading(false);
    }

    loadData();
    return () => { cancelled = true; };
  }, [refreshKey]);

  const totalRecords = Object.values(entityCounts).reduce((a, b) => a + b, 0);
  const topStorageItems = storageInfo.breakdown.slice(0, 10);

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      /* نوار ابزار */
      _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
        _jsxDEV('h3', { className: "text-sm font-bold flex items-center gap-2"    , children: [
          _jsxDEV(Database, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this ), "نمای کلی سیستم"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
        , _jsxDEV('button', {
          onClick: () => setRefreshKey(k => k + 1),
          disabled: loading,
          className: "flex items-center gap-1 text-xs text-muted-foreground hover:text-primary transition-colors disabled:opacity-50"       ,
 children: [
          _jsxDEV(RefreshCw, { className: `w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this ), "به‌روزرسانی"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 151}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 146}, this)

      /* وضعیت اپلیکیشن */
      , _jsxDEV(Card, { className: "border-green-200 bg-green-50/50" , children: 
        _jsxDEV(CardContent, { className: "p-4", children: 
          _jsxDEV('div', { className: "flex items-start gap-3"  , children: [
            _jsxDEV('div', { className: "w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center shrink-0"       , children: 
              _jsxDEV(CheckCircle2, { className: "w-5 h-5 text-green-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 166}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this)
            , _jsxDEV('div', { className: "flex-1", children: [
              _jsxDEV('p', { className: "text-sm font-bold text-green-900"  , children: "اتصال به Supabase"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 169}, this)
              , _jsxDEV('p', { className: "text-xs text-green-700 mt-1"  , children: "تمام داده‌ها به‌صورت آنلاین در Supabase ذخیره و پردازش می‌شوند."

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 170}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 168}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 164}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 162}, this)

      /* وضعیت اتصال Supabase */
      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4", children: [
          _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
            _jsxDEV('div', { className: "flex items-center gap-3"  , children: [
              _jsxDEV('div', { className: `w-10 h-10 rounded-lg flex items-center justify-center ${
                connectionStatus === 'connected' ? 'bg-green-100' :
                connectionStatus === 'disconnected' ? 'bg-red-100' : 'bg-muted'
              }`, children: 
                connectionStatus === 'checking' ? (
                  _jsxDEV(Loader2, { className: "w-5 h-5 text-muted-foreground animate-spin"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 188}, this )
                ) : connectionStatus === 'connected' ? (
                  _jsxDEV(CheckCircle2, { className: "w-5 h-5 text-green-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 190}, this )
                ) : (
                  _jsxDEV(XCircle, { className: "w-5 h-5 text-red-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 192}, this )
                )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 183}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV('p', { className: "text-sm font-bold" , children: "اتصال به Supabase"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 196}, this)
                , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: 
                  connectionStatus === 'connected' ? 'برقرار است ✓' :
                   connectionStatus === 'disconnected' ? 'قطع شده' :
                   'در حال بررسی...'
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 197}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 195}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 182}, this)
            , _jsxDEV('div', { className: "text-left", children: [
              _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "پلن"}, void 0, false, {fileName: _jsxFileName, lineNumber: 205}, this)
              , _jsxDEV('p', { className: "text-sm font-bold text-green-600"  , children: "رایگان (Free Tier)"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 206}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 204}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 181}, this)

          , _jsxDEV('div', { className: "mt-3 pt-3 border-t grid grid-cols-3 gap-2 text-center"      , children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Cloud, { className: "w-4 h-4 mx-auto text-green-500 mb-1"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 212}, this )
              , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "دیتابیس"}, void 0, false, {fileName: _jsxFileName, lineNumber: 213}, this)
              , _jsxDEV('p', { className: `text-xs font-bold ${connectionStatus === 'connected' ? 'text-green-600' : 'text-red-600'}`, children: 
                connectionStatus === 'connected' ? 'آنلاین' : 'آفلاین'
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 214}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 211}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Server, { className: "w-4 h-4 mx-auto text-blue-500 mb-1"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 219}, this )
              , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "احراز هویت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 220}, this)
              , _jsxDEV('p', { className: "text-xs font-bold text-blue-600"  , children: "محلی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 221}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 218}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Clock, { className: "w-4 h-4 mx-auto text-amber-500 mb-1"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 224}, this )
              , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "در انتظار همگام‌سازی"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 225}, this)
              , _jsxDEV('p', { className: `text-xs font-bold ${syncPending > 0 ? 'text-amber-600' : 'text-green-600'}`, children: [
                toFaNum(syncPending), " عملیات"
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 226}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 223}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 210}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 180}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this)

      /* فضای ذخیره‌سازی */
      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4", children: [
          _jsxDEV('div', { className: "flex items-center gap-2 mb-3"   , children: [
            _jsxDEV(HardDrive, { className: "w-4 h-4 text-blue-500"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 238}, this )
            , _jsxDEV('h4', { className: "text-sm font-bold" , children: "فضای ذخیره‌سازی محلی"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 239}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 237}, this)

          , _jsxDEV('div', { className: "flex items-center justify-between mb-2"   , children: [
            _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: "فضای مصرف‌شده" }, void 0, false, {fileName: _jsxFileName, lineNumber: 243}, this)
            , _jsxDEV('span', { className: "text-sm font-bold text-blue-600"  , children: formatBytes(storageInfo.total)}, void 0, false, {fileName: _jsxFileName, lineNumber: 244}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 242}, this)

          , _jsxDEV('div', { className: "w-full h-2 rounded-full bg-muted overflow-hidden mb-1"     , children: 
            _jsxDEV('div', {
              className: "h-full bg-gradient-to-l from-blue-500 to-blue-400 rounded-full transition-all"     ,
              style: { width: `${Math.min(100, (storageInfo.total / (5 * 1024 * 1024)) * 100)}%` },}, void 0, false, {fileName: _jsxFileName, lineNumber: 248}, this
            )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 247}, this)
          , _jsxDEV('p', { className: "text-[10px] text-muted-foreground text-left"  , children: "از ۵ مگابایت localStorage"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 253}, this)

          /* جدول بزرگترین مصرف‌کننده‌ها */
          , topStorageItems.length > 0 && (
            _jsxDEV('div', { className: "mt-3 space-y-1" , children: [
              _jsxDEV('p', { className: "text-xs font-medium text-muted-foreground mb-1"   , children: "بزرگ‌ترین داده‌های ذخیره‌شده:"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 258}, this)
              , topStorageItems.map(item => (
                _jsxDEV('div', { className: "flex items-center justify-between text-xs py-1 px-2 rounded bg-muted/40"       , children: [
                  _jsxDEV('span', { className: "truncate max-w-[60%] text-muted-foreground"  , dir: "ltr", children: item.key}, void 0, false, {fileName: _jsxFileName, lineNumber: 261}, this)
                  , _jsxDEV('span', { className: "font-medium text-blue-600" , children: formatBytes(item.size)}, void 0, false, {fileName: _jsxFileName, lineNumber: 262}, this)
                ]}, item.key, true, {fileName: _jsxFileName, lineNumber: 260}, this)
              ))
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 257}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 236}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 235}, this)

      /* آمار رکوردها */
      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4", children: [
          _jsxDEV('div', { className: "flex items-center justify-between mb-3"   , children: [
            _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
              _jsxDEV(Table, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 275}, this )
              , _jsxDEV('h4', { className: "text-sm font-bold" , children: "آمار رکوردها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 276}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 274}, this)
            , _jsxDEV('span', { className: "text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded-full"      , children: ["مجموع: "
               , toFaNum(totalRecords), " رکورد"
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 278}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 273}, this)

          , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: 
            ALL_ENTITIES.map(entity => {
              const count = entityCounts[entity.name] || 0;
              return (
                _jsxDEV('div', {

                  className: `flex items-center justify-between p-2 rounded-lg border ${
                    count > 0 ? 'border-green-200 bg-green-50/30' : 'border-muted bg-muted/20'
                  }`,
 children: [
                  _jsxDEV('span', { className: "text-xs text-muted-foreground truncate"  , children: entity.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 293}, this)
                  , _jsxDEV('span', { className: `text-xs font-bold ${count > 0 ? 'text-green-600' : 'text-muted-foreground'}`, children: 
                    toFaNum(count)
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 294}, this)
                ]}, entity.name, true, {fileName: _jsxFileName, lineNumber: 287}, this)
              );
            })
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 283}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 272}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 271}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 144}, this)
  );
}