const _jsxFileName = "src/components/sarraaf/CoCreatorManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useEffect, useCallback } from 'react';
import { createSupabaseEntity } from '../../lib/supabaseApi.js';
import { useToast } from '../ui/use-toast.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Label } from '../ui/label.js';
import { Card, CardContent } from '../ui/card.js';
import { Switch } from '../ui/switch.js';
import { Trash2, Plus, Shield, UserCog, Clock } from 'lucide-react';

const sbBuilderAccess = createSupabaseEntity('BuilderAccess');

const ALL_TABS = [
  { key: 'system', label: 'سیستم' },
  { key: 'features', label: 'بخش‌ها' },
  { key: 'users', label: 'کاربران' },
  { key: 'perms', label: 'مجوزها' },
  { key: 'plans', label: 'پلن‌ها' },
  { key: 'pricing', label: 'قیمت‌گذاری' },
  { key: 'notif', label: 'اعلان‌ها' },
  { key: 'chat', label: 'چت' },
  { key: 'payments', label: 'پرداخت' },
  { key: 'withdrawals', label: 'برداشت‌ها' },
  { key: 'version', label: 'نسخه' },
  { key: 'backup', label: 'پشتیبان' },
  { key: 'backup_v2', label: 'پشتیبان v2' },
];

export default function CoCreatorManager() {
  const { toast } = useToast();
  const [accessList, setAccessList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', phone: '', notes: '', allowed_tabs: ['system', 'features', 'users'] });

  const loadAccess = useCallback(async () => {
    setLoading(true);
    try {
      const list = await sbBuilderAccess.list();
      setAccessList(list || []);
    } catch (e2) {
      toast({ title: 'خطا', description: 'بارگذاری لیست کمک‌سازنده‌ها ناموفق بود', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => { loadAccess(); }, [loadAccess]);

  const handleAdd = async () => {
    if (!form.name.trim()) {
      toast({ title: 'خطا', description: 'نام الزامی است', variant: 'destructive' });
      return;
    }
    if (!form.email.trim() && !form.phone.trim()) {
      toast({ title: 'خطا', description: 'حداقل ایمیل یا شماره الزامی است', variant: 'destructive' });
      return;
    }
    try {
      await sbBuilderAccess.create({
        name: form.name.trim(),
        email: form.email.trim().toLowerCase(),
        phone: form.phone.trim(),
        allowed_tabs: form.allowed_tabs,
        status: 'active',
        notes: form.notes.trim(),
      });
      toast({ title: 'افزوده شد', description: 'دسترسی کمک‌سازنده ثبت شد' });
      setShowForm(false);
      setForm({ name: '', email: '', phone: '', notes: '', allowed_tabs: ['system', 'features', 'users'] });
      loadAccess();
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleDelete = async (id) => {
    try {
      await sbBuilderAccess.delete(id);
      toast({ title: 'حذف شد', description: 'دسترسی کمک‌سازنده حذف شد' });
      loadAccess();
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const toggleTab = (tabKey) => {
    setForm(prev => ({
      ...prev,
      allowed_tabs: prev.allowed_tabs.includes(tabKey)
        ? prev.allowed_tabs.filter(t => t !== tabKey)
        : [...prev.allowed_tabs, tabKey],
    }));
  };

  const toggleStatus = async (item) => {
    try {
      await sbBuilderAccess.update(item.id, { status: item.status === 'active' ? 'suspended' : 'active' });
      loadAccess();
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV(Card, { children: 
      _jsxDEV(CardContent, { className: "p-4 space-y-4" , children: [
        /* Header */
        _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
          _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            _jsxDEV(UserCog, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this )
            , _jsxDEV('div', { children: [
              _jsxDEV('h3', { className: "text-sm font-bold" , children: "مدیریت کمک‌سازنده‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this)
              , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "دسترسی پنل سازنده برای ایمیل/شماره مشخص"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 112}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 110}, this)
          , _jsxDEV(Button, { size: "sm", onClick: () => setShowForm(!showForm), children: [
            _jsxDEV(Plus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this ), "افزودن"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 117}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 109}, this)

        /* Auto-logout notice */
        , _jsxDEV('div', { className: "flex items-center gap-2 p-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-[10px]"         , children: [
          _jsxDEV(Clock, { className: "w-3.5 h-3.5 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this ), "خروج خودکار: پس از ۳۰ دقیقه بی‌فعالیتی در پنل سازنده، نشست به‌صورت خودکار پایان می‌یابد."

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 124}, this)

        /* Add Form */
        , showForm && (
          _jsxDEV('div', { className: "space-y-3 p-3 rounded-xl border bg-muted/30"    , children: [
            _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { className: "text-xs", children: "نام"}, void 0, false, {fileName: _jsxFileName, lineNumber: 134}, this)
                , _jsxDEV(Input, { value: form.name, onChange: e => setForm({ ...form, name: e.target.value }), placeholder: "نام کمک‌سازنده" , className: "h-8 text-sm" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 133}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { className: "text-xs", children: "ایمیل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)
                , _jsxDEV(Input, { value: form.email, onChange: e => setForm({ ...form, email: e.target.value }), placeholder: "email@example.com", className: "h-8 text-sm" , dir: "ltr",}, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 137}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 132}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { className: "text-xs", children: "شماره موبایل" }, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this)
                , _jsxDEV(Input, { value: form.phone, onChange: e => setForm({ ...form, phone: e.target.value }), placeholder: "07xx...", className: "h-8 text-sm" , dir: "ltr",}, void 0, false, {fileName: _jsxFileName, lineNumber: 145}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 143}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { className: "text-xs", children: "یادداشت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this)
                , _jsxDEV(Input, { value: form.notes, onChange: e => setForm({ ...form, notes: e.target.value }), placeholder: "اختیاری", className: "h-8 text-sm" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs mb-1 block"  , children: "تب‌های مجاز" }, void 0, false, {fileName: _jsxFileName, lineNumber: 153}, this)
              , _jsxDEV('div', { className: "flex flex-wrap gap-1"  , children: 
                ALL_TABS.map(tab => (
                  _jsxDEV('button', {

                    type: "button",
                    onClick: () => toggleTab(tab.key),
                    className: `text-[10px] px-2 py-1 rounded-full border transition-colors ${
                      form.allowed_tabs.includes(tab.key)
                        ? 'bg-primary text-primary-foreground border-primary'
                        : 'bg-background text-muted-foreground border-border'
                    }`,
 children: 
                    tab.label
                  }, tab.key, false, {fileName: _jsxFileName, lineNumber: 156}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 154}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 152}, this)
            , _jsxDEV('div', { className: "flex gap-2" , children: [
              _jsxDEV(Button, { size: "sm", onClick: handleAdd, children: "ثبت دسترسی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 172}, this)
              , _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => setShowForm(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 173}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 171}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 131}, this)
        )

        /* List */
        , loading ? (
          _jsxDEV('p', { className: "text-xs text-muted-foreground text-center py-4"   , children: "در حال بارگذاری..."  }, void 0, false, {fileName: _jsxFileName, lineNumber: 180}, this)
        ) : accessList.length === 0 ? (
          _jsxDEV('p', { className: "text-xs text-muted-foreground text-center py-4"   , children: "هیچ کمک‌سازنده‌ای ثبت نشده است"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this)
        ) : (
          _jsxDEV('div', { className: "space-y-2", children: 
            accessList.map(item => (
              _jsxDEV('div', { className: "flex items-center justify-between p-2.5 rounded-lg border"     , children: [
                _jsxDEV('div', { className: "min-w-0", children: [
                  _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                    _jsxDEV('p', { className: "text-sm font-medium truncate"  , children: item.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 189}, this)
                    , _jsxDEV('span', { className: `text-[9px] px-1.5 py-0.5 rounded-full ${item.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`, children: 
                      item.status === 'active' ? 'فعال' : 'معلق'
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 190}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 188}, this)
                  , _jsxDEV('p', { className: "text-[10px] text-muted-foreground truncate"  , dir: "ltr", children: [
                    item.email || '—', " | "  , item.phone || '—'
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 194}, this)
                  , _jsxDEV('div', { className: "flex flex-wrap gap-0.5 mt-1"   , children: 
                    (item.allowed_tabs || []).map(t => {
                      const tab = ALL_TABS.find(x => x.key === t);
                      return tab ? _jsxDEV('span', { className: "text-[8px] px-1 py-0.5 rounded bg-primary/10 text-primary"     , children: tab.label}, t, false, {fileName: _jsxFileName, lineNumber: 200}, this) : null;
                    })
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 197}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 187}, this)
                , _jsxDEV('div', { className: "flex items-center gap-1 shrink-0"   , children: [
                  _jsxDEV(Switch, { checked: item.status === 'active', onCheckedChange: () => toggleStatus(item),}, void 0, false, {fileName: _jsxFileName, lineNumber: 205}, this )
                  , _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-7 w-7 text-destructive"  , onClick: () => handleDelete(item.id), children: 
                    _jsxDEV(Trash2, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 207}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 206}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 204}, this)
              ]}, item.id, true, {fileName: _jsxFileName, lineNumber: 186}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 184}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 107}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this)
  );
}