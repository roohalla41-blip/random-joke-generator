const _jsxFileName = "src/components/sarraaf/BackupUpgradeModal.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React from 'react';
import { useActivateBackupAddon } from '../../lib/useBackup.js';
import { useToast } from '../ui/use-toast.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../ui/dialog.js';
import { Button } from '../ui/button.js';
import { Shield, CheckCircle2, Loader2 } from 'lucide-react';

const FEATURES = [
  'بکاپ خودکار روزانه',
  'نگه‌داری ابری امن تا ۳۰ نسخه',
  'بازیابی داده‌ها با یک کلیک',
  'تاریخچه کامل بکاپ‌ها',
  'محافظت از داده‌ها در صورت خرابی دستگاه',
];

export default function BackupUpgradeModal({ open, onClose, userId, userName }) {
  const { toast } = useToast();
  const activateMut = useActivateBackupAddon();

  const handlePurchase = async () => {
    try {
      await activateMut.mutateAsync({ userId, userName, durationMonths: 12 });
      toast({
        title: 'بکاپ پولی فعال شد',
        description: 'بکاپ خودکار روزانه برای شما فعال شد',
      });
      onClose();
    } catch (e) {
      toast({ title: 'خطا', description: e.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV(Dialog, { open: open, onOpenChange: onClose, children: 
      _jsxDEV(DialogContent, { children: [
        _jsxDEV(DialogHeader, { children: 
          _jsxDEV(DialogTitle, { className: "flex items-center gap-2"  , children: [
            _jsxDEV(Shield, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this ), "نسخه پولی بکاپ"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 37}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this)
        , _jsxDEV('div', { className: "space-y-3 py-2" , children: [
          _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "با تهیه نسخه پولی بکاپ، اطلاعات شما هرگز از دست نمی‌رود."

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this)
          , _jsxDEV('div', { className: "space-y-2", children: 
            FEATURES.map((f, i) => (
              _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-success shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this )
                , _jsxDEV('span', { className: "text-sm", children: f}, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this)
              ]}, i, true, {fileName: _jsxFileName, lineNumber: 48}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this)
          , _jsxDEV('div', { className: "bg-muted/50 rounded-lg p-3 text-center"   , children: [
            _jsxDEV('p', { className: "text-2xl font-bold text-primary"  , children: "۱,۰۰۰ افغانی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this)
            , _jsxDEV('p', { className: "text-xs text-muted-foreground mt-1"  , children: "سالانه / ۱۲ ماه"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 54}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 42}, this)
        , _jsxDEV(DialogFooter, { children: [
          _jsxDEV(Button, { variant: "outline", onClick: onClose, children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)
          , _jsxDEV(Button, { onClick: handlePurchase, disabled: activateMut.isPending, children: 
            activateMut.isPending ? (
              _jsxDEV(_Fragment, { children: [_jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this ), " در حال فعال‌سازی..."   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 63}, this)
            ) : (
              _jsxDEV(_Fragment, { children: [_jsxDEV(Shield, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this ), " خرید و فعال‌سازی"   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)
            )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 59}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 35}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 34}, this)
  );
}