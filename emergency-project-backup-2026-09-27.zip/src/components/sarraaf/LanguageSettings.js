const _jsxFileName = "src/components/sarraaf/LanguageSettings.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';
import { Globe, Check } from 'lucide-react';
import { Card, CardContent } from '../ui/card.js';
import { useLanguage, LANGUAGES } from '../../lib/i18n.js';

export default function LanguageSettings() {
  const { lang, setLang } = useLanguage();

  return (
    _jsxDEV(Card, { className: "mb-4", children: 
      _jsxDEV(CardContent, { className: "p-4", children: [
        _jsxDEV('div', { className: "flex items-center gap-2 mb-3"   , children: [
          _jsxDEV(Globe, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 13}, this )
          , _jsxDEV('h3', { className: "text-sm font-bold" , children: "زبان برنامه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 14}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 12}, this)
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: 
          LANGUAGES.map((l) => (
            _jsxDEV('button', {

              onClick: () => setLang(l.code),
              className: `flex items-center gap-2 px-3 py-2.5 rounded-xl border transition-colors ${
                lang === l.code
                  ? 'border-primary bg-primary/10 text-primary font-semibold'
                  : 'border-border hover:bg-muted/50'
              }`,
 children: [
              _jsxDEV('span', { className: "text-xl leading-none" , children: l.flag}, void 0, false, {fileName: _jsxFileName, lineNumber: 27}, this)
              , _jsxDEV('span', { className: "text-sm flex-1 text-start"  , children: l.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 28}, this)
              , lang === l.code && _jsxDEV(Check, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 29}, this )
            ]}, l.code, true, {fileName: _jsxFileName, lineNumber: 18}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 16}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 11}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 10}, this)
  );
}