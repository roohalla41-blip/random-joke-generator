const _jsxFileName = "src/components/sarraaf/ReferralManager.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '../ui/card.js';
import { Switch } from '../ui/switch.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Label } from '../ui/label.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select.js';
import { useToast } from '../ui/use-toast.js';
import { getReferralConfig, updateReferralConfig } from '../../lib/referralSystem.js';
import { offlineDB } from '../../lib/offlineQueue.js';
import { formatDate } from '../../lib/sarraaf.js';
import { UserPlus, Gift, Settings, Loader2, Users, CheckCircle2, XCircle, Clock, Award } from 'lucide-react';

const STATUS_ICONS = {
  pending: { icon: Clock, color: 'text-amber-500', label: 'در انتظار' },
  verified: { icon: CheckCircle2, color: 'text-blue-500', label: 'تأییدشده' },
  completed: { icon: CheckCircle2, color: 'text-green-500', label: 'تکمیل‌شده' },
  rewarded: { icon: Award, color: 'text-green-600', label: 'پاداش‌داده‌شده' },
  cancelled: { icon: XCircle, color: 'text-red-500', label: 'لغوشده' },
};

const REWARD_TYPE_LABELS = {
  quota: 'سهمیه پیام',
  credit: 'اعتبار',
  points: 'امتیاز',
  none: 'بدون پاداش',
};

const CONDITION_LABELS = {
  email_verified: 'تأیید ایمیل دعوت‌شده',
  registration: 'فقط ثبت‌نام',
  first_transaction: 'اولین تراکنش دعوت‌شده',
};

export default function ReferralManager() {
  const { toast } = useToast();
  const [config, setConfig] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const loadAll = async () => {
    setLoading(true);
    try {
      const cfg = await getReferralConfig();
      setConfig(cfg);
      const refs = await offlineDB.Referral.list('-created_date', 200);
      setHistory(refs || []);
    } catch (e2) {
      // ignore
    }
    setLoading(false);
  };

  useEffect(() => { loadAll(); }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateReferralConfig(config);
      toast({ title: 'ذخیره شد', description: 'تنظیمات سیستم دعوت به‌روزرسانی شد' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
    setSaving(false);
  };

  if (loading || !config) {
    return (
      _jsxDEV(Card, { children: _jsxDEV(CardContent, { className: "p-8 flex items-center justify-center"   , children: 
        _jsxDEV(Loader2, { className: "w-6 h-6 animate-spin text-muted-foreground"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)
    );
  }

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      /* Configuration Card */
      _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4 space-y-4" , children: [
          _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            _jsxDEV(Settings, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this )
            , _jsxDEV('h3', { className: "text-sm font-bold" , children: "تنظیمات سیستم دعوت"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 81}, this)

          /* Enable/Disable */
          , _jsxDEV('div', { className: "flex items-center justify-between p-3 rounded-lg border"     , children: [
            _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-sm font-medium" , children: "فعال‌سازی سیستم دعوت"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this)
              , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "فعال یا غیرفعال کردن قابلیت دعوت کاربران"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 88}, this)
            , _jsxDEV(Switch, {
              checked: config.enabled,
              onCheckedChange: (v) => setConfig({ ...config, enabled: v }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 92}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 87}, this)

          , config.enabled && (
            _jsxDEV(_Fragment, { children: [
              /* Reward type */
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "نوع پاداش" }, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this)
                , _jsxDEV(Select, {
                  value: config.reward_type,
                  onValueChange: (v) => setConfig({ ...config, reward_type: v }),
 children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this)
                  , _jsxDEV(SelectContent, { children: [
                    _jsxDEV(SelectItem, { value: "quota", children: "سهمیه پیام" }, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this)
                    , _jsxDEV(SelectItem, { value: "credit", children: "اعتبار حساب" }, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this)
                    , _jsxDEV(SelectItem, { value: "points", children: "امتیاز"}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this)
                    , _jsxDEV(SelectItem, { value: "none", children: "بدون پاداش" }, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 108}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 103}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 101}, this)

              /* Reward amount */
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "مقدار پاداش" }, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this)
                , _jsxDEV(Input, {
                  type: "number",
                  value: config.reward_amount,
                  onChange: (e) => setConfig({ ...config, reward_amount: parseInt(e.target.value) || 0 }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this
                )
                , _jsxDEV('p', { className: "text-[10px] text-muted-foreground mt-1"  , children: "مقدار پاداش برای هر دعوت موفق"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 118}, this)

              /* Condition */
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "شرط دریافت پاداش"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)
                , _jsxDEV(Select, {
                  value: config.condition,
                  onValueChange: (v) => setConfig({ ...config, condition: v }),
 children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this)
                  , _jsxDEV(SelectContent, { children: [
                    _jsxDEV(SelectItem, { value: "registration", children: "فقط ثبت‌نام" }, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this)
                    , _jsxDEV(SelectItem, { value: "email_verified", children: "تأیید ایمیل دعوت‌شده"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)
                    , _jsxDEV(SelectItem, { value: "first_transaction", children: "اولین تراکنش دعوت‌شده"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 136}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 131}, this)
                , _jsxDEV('p', { className: "text-[10px] text-muted-foreground mt-1"  , children: "پاداش پس از تحقق این شرط به دعوت‌کننده داده می‌شود"         }, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 129}, this)

              /* Max referrals */
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "حداکثر دعوت برای هر کاربر"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this)
                , _jsxDEV(Input, {
                  type: "number",
                  value: config.max_referrals_per_user,
                  onChange: (e) => setConfig({ ...config, max_referrals_per_user: parseInt(e.target.value) || 0 }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this
                )
                , _jsxDEV('p', { className: "text-[10px] text-muted-foreground mt-1"  , children: "0 = نامحدود"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 153}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 146}, this)

              /* Anti-abuse toggles */
              , _jsxDEV('div', { className: "space-y-2", children: [
                _jsxDEV('div', { className: "flex items-center justify-between p-2.5 rounded-lg border"     , children: [
                  _jsxDEV('div', { children: [
                    _jsxDEV('p', { className: "text-sm font-medium" , children: "جلوگیری از دعوت خود"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "کاربر نتواند با کد خودش ثبت‌نام کند"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 161}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 159}, this)
                  , _jsxDEV(Switch, {
                    checked: config.prevent_self_referral,
                    onCheckedChange: (v) => setConfig({ ...config, prevent_self_referral: v }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 158}, this)
                , _jsxDEV('div', { className: "flex items-center justify-between p-2.5 rounded-lg border"     , children: [
                  _jsxDEV('div', { children: [
                    _jsxDEV('p', { className: "text-sm font-medium" , children: "جلوگیری از دعوت تکراری"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 170}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "هر کاربر فقط یک بار دعوت شود"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 171}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 169}, this)
                  , _jsxDEV(Switch, {
                    checked: config.prevent_duplicate_invitee,
                    onCheckedChange: (v) => setConfig({ ...config, prevent_duplicate_invitee: v }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 173}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 168}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 157}, this)

              , _jsxDEV(Button, { onClick: handleSave, disabled: saving, className: "w-full", children: 
                saving ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 181}, this ) : 'ذخیره تنظیمات'
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 180}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 99}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 80}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this)

      /* Referral History */
      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4", children: [
          _jsxDEV('div', { className: "flex items-center gap-2 mb-3"   , children: [
            _jsxDEV(Users, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 192}, this )
            , _jsxDEV('h3', { className: "text-sm font-bold" , children: "سابقه دعوت‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 193}, this)
            , _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: ["(", history.length, ")"]}, void 0, true, {fileName: _jsxFileName, lineNumber: 194}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 191}, this)

          , history.length === 0 ? (
            _jsxDEV('div', { className: "text-center py-6" , children: [
              _jsxDEV(UserPlus, { className: "w-8 h-8 text-muted-foreground/30 mx-auto mb-2"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 199}, this )
              , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "هنوز دعوتی ثبت نشده است"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 200}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 198}, this)
          ) : (
            _jsxDEV('div', { className: "space-y-2 max-h-96 overflow-y-auto scrollbar-thin"   , children: 
              history.map((r) => {
                const si = STATUS_ICONS[r.status] || STATUS_ICONS.pending;
                const SIcon = si.icon;
                return (
                  _jsxDEV('div', { className: "flex items-center justify-between p-2.5 rounded-lg border text-xs"      , children: [
                    _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
                      _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
                        _jsxDEV(SIcon, { className: `w-3.5 h-3.5 ${si.color}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 211}, this )
                        , _jsxDEV('span', { className: "font-medium truncate" , children: r.invitee_name || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 212}, this)
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 210}, this)
                      , _jsxDEV('p', { className: "text-[10px] text-muted-foreground mt-0.5"  , children: [
                        r.inviter_name || '—', " → "  , r.invitee_type === 'customer' ? 'مشتری' : 'صراف'
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 214}, this)
                      , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: formatDate(r.created_date)}, void 0, false, {fileName: _jsxFileName, lineNumber: 217}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 209}, this)
                    , _jsxDEV('div', { className: "text-left shrink-0" , children: [
                      _jsxDEV('span', { className: `text-[10px] font-medium ${si.color}`, children: si.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 220}, this)
                      , r.reward_given && (
                        _jsxDEV('p', { className: "text-[10px] text-green-600" , children: [
                          _jsxDEV(Gift, { className: "w-3 h-3 inline"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this ), " " , r.reward_amount, " " , REWARD_TYPE_LABELS[r.reward_type]
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 222}, this)
                      )
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 219}, this)
                  ]}, r.id, true, {fileName: _jsxFileName, lineNumber: 208}, this)
                );
              })
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 203}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 190}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 189}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 77}, this)
  );
}