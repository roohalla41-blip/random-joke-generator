const _jsxFileName = "src/components/sarraaf/TermsManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Textarea } from '../ui/textarea.js';
import { getTerms, saveTerms } from '../../lib/termsService.js';
import { ScrollText, Save, Loader2 } from 'lucide-react';
import { useToast } from '../ui/use-toast.js';

export default function TermsManager() {
  const { toast } = useToast();
  const [sarraaf, setSarraaf] = useState('');
  const [customer, setCustomer] = useState('');
  const [version, setVersion] = useState(1);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const t = await getTerms();
      setSarraaf(t.sarraaf);
      setCustomer(t.customer);
      setVersion(t.version);
      setLoading(false);
    })();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const newVersion = await saveTerms(sarraaf, customer, version);
      setVersion(newVersion);
      toast({ title: 'قوانین ذخیره شد', description: `نسخه ${newVersion} — کاربران باید دوباره بپذیرند` });
    } catch (e2) {
      toast({ title: 'خطا در ذخیره قوانین', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4 flex items-center justify-center gap-2 text-sm text-muted-foreground"      , children: [
          _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 44}, this ), "در حال بارگذاری..."

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 43}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this)
    );
  }

  return (
    _jsxDEV(Card, { children: 
      _jsxDEV(CardContent, { className: "p-4 space-y-4" , children: [
        _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
          _jsxDEV(ScrollText, { className: "w-4 h-4 text-primary shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this )
          , _jsxDEV('h3', { className: "text-sm font-bold" , children: "قوانین و مقررات برنامه"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 54}, this)

        , _jsxDEV('div', { children: [
          _jsxDEV('label', { className: "text-xs font-medium mb-1 block"   , children: "قوانین صرافان" }, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)
          , _jsxDEV(Textarea, {
            value: sarraaf,
            onChange: (e) => setSarraaf(e.target.value),
            rows: 8,
            className: "text-sm",
            placeholder: "متن قوانین صرافان..."  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 59}, this)

        , _jsxDEV('div', { children: [
          _jsxDEV('label', { className: "text-xs font-medium mb-1 block"   , children: "قوانین مشتریان" }, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this)
          , _jsxDEV(Textarea, {
            value: customer,
            onChange: (e) => setCustomer(e.target.value),
            rows: 8,
            className: "text-sm",
            placeholder: "متن قوانین مشتریان..."  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 70}, this)

        , _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
          _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: ["نسخه فعلی: "  , version]}, void 0, true, {fileName: _jsxFileName, lineNumber: 82}, this)
          , _jsxDEV(Button, { onClick: handleSave, disabled: saving, size: "sm", children: [
            saving ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this ) : _jsxDEV(Save, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this ), "ذخیره قوانین"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 83}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 81}, this)
        , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "پس از ذخیره، نسخه قوانین افزایش می‌یابد و همه کاربران باید دوباره قوانین را بپذیرند."

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 53}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 52}, this)
  );
}