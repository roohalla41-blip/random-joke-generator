const _jsxFileName = "src/components/sarraaf/ContactInfo.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';
import { Mail, Phone, Globe, MessageCircle, Send, Instagram, Facebook } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '../ui/card.js';
import { getContactSettings, getContactUrl } from '../../lib/contactSettings.js';
import { useToast } from '../ui/use-toast.js';

const ICON_MAP = { Phone, Mail, Globe, MessageCircle, Send, Instagram, Facebook };

export default function ContactInfo() {
  const { toast } = useToast();
  const { data: contacts, isLoading } = useQuery({
    queryKey: ['contactSettings'],
    queryFn: getContactSettings,
  });

  // Show all active contacts — links are managed from the builder panel
  const visible = (contacts || []).filter(c => c.is_active);

  function handleClick(type, value) {
    if (!value) {
      toast({ title: 'لینک تنظیم نشده', description: 'این لینک هنوز توسط مدیر سیستم تنظیم نشده است' });
      return;
    }
    const url = getContactUrl(type, value);
    if (url === '#') return;
    window.open(url, '_blank');
  }

  if (isLoading || visible.length === 0) return null;

  return (
    _jsxDEV(Card, { children: 
      _jsxDEV(CardContent, { className: "p-3", children: [
        _jsxDEV('p', { className: "text-xs font-semibold text-muted-foreground mb-2"   , children: "لینک‌های ارتباطی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 35}, this)
        , _jsxDEV('div', { className: "grid grid-cols-4 gap-2"  , children: 
          visible.map((c) => {
            const Icon = ICON_MAP[c.icon] || Phone;
            return (
              _jsxDEV('button', {

                onClick: () => handleClick(c.type, c.value),
                className: "flex flex-col items-center gap-1 p-2 rounded-xl border border-border hover:bg-muted/50 transition-colors"         ,
 children: [
                _jsxDEV(Icon, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 45}, this )
                , _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: c.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this)
              ]}, c.type, true, {fileName: _jsxFileName, lineNumber: 40}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 34}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 33}, this)
  );
}