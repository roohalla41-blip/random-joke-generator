const _jsxFileName = "src/components/sarraaf/EmergencyBackupV2.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState } from 'react';
import { Download, FileText, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { Button } from '../ui/button.js';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card.js';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert.js';
import { generateEmergencyBackupPdfV2 } from '../../lib/emergencyBackupPdfV2.js';

export default function EmergencyBackupV2() {
  const [generating, setGenerating] = useState(false);
  const [fileName, setFileName] = useState('');
  const [error, setError] = useState('');

  const handleGenerate = async () => {
    setGenerating(true);
    setError('');
    setFileName('');
    try {
      // Small delay to show loading state
      await new Promise(resolve => setTimeout(resolve, 100));
      const name = generateEmergencyBackupPdfV2();
      setFileName(name);
    } catch (e) {
      setError(e.message || 'خطا در تولید PDF');
    } finally {
      setGenerating(false);
    }
  };

  return (
    _jsxDEV('div', { className: "space-y-6 max-w-3xl mx-auto"  , children: [
      /* Header */
      _jsxDEV('div', { className: "text-center space-y-2" , children: [
        _jsxDEV('div', { className: "inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 dark:bg-red-900/30 mb-2"        , children: 
          _jsxDEV(AlertTriangle, { className: "w-8 h-8 text-red-600 dark:text-red-400"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 34}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 33}, this)
        , _jsxDEV('h2', { className: "text-2xl font-bold" , children: "پشتیبان اضطراری — نسخه ۰۱"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this)
        , _jsxDEV('p', { className: "text-muted-foreground text-sm" , children: "Snapshot کامل از وضعیت فعلی پروژه «حساب صراف»"

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 32}, this)

      /* Status Alert */
      , _jsxDEV(Alert, { variant: "default", className: "border-amber-300 bg-amber-50 dark:bg-amber-950/30 dark:border-amber-800"   , children: [
        _jsxDEV(Clock, { className: "w-4 h-4 text-amber-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 44}, this )
        , _jsxDEV(AlertTitle, { className: "text-amber-700 dark:text-amber-400" , children: "پروژه در حال توسعه"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 45}, this)
        , _jsxDEV(AlertDescription, { className: "text-amber-700 dark:text-amber-300 text-sm"  , children: "این پروژه هنوز کامل و نهایی نشده است. این سند فقط Snapshot اضطراری از وضعیت فعلی است. هر زمان بخش‌های جدیدی به پروژه اضافه شد، باید نسخه جدیدی از این سند تولید شود."


        }, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 43}, this)

      /* PDF Contents */
      , _jsxDEV(Card, { children: [
        _jsxDEV(CardHeader, { children: 
          _jsxDEV(CardTitle, { className: "flex items-center gap-2 text-lg"   , children: [
            _jsxDEV(FileText, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this ), "محتوای PDF (۲۸ بخش)"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 55}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 54}, this)
        , _jsxDEV(CardContent, { children: 
          _jsxDEV('div', { className: "grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-muted-foreground"     , children: [
            _jsxDEV('div', { children: "۱. مشخصات و نسخه پروژه"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this)
            , _jsxDEV('div', { children: "۲. تاریخ و ساعت تولید"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this)
            , _jsxDEV('div', { children: "۳. وضعیت فعلی و میزان تکمیل"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
            , _jsxDEV('div', { children: "۴. پشته فناوری و وابستگی‌ها"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this)
            , _jsxDEV('div', { children: "۵. معماری سیستم"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
            , _jsxDEV('div', { children: "۶. ساختار پوشه‌ها"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this)
            , _jsxDEV('div', { children: "۷. مسیرهای React Router"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this)
            , _jsxDEV('div', { children: "۸. وضعیت Backend"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this)
            , _jsxDEV('div', { children: "۹. وضعیت API Layer"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)
            , _jsxDEV('div', { children: "۱۰. ساختار Supabase"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this)
            , _jsxDEV('div', { children: "۱۱. Entity Schemaها"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this)
            , _jsxDEV('div', { children: "۱۲. Double-entry Ledger"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)
            , _jsxDEV('div', { children: "۱۳. مدل امنیتی"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this)
            , _jsxDEV('div', { children: "۱۴. وضعیت پنل Creator"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
            , _jsxDEV('div', { children: "۱۵. وضعیت پنل Customer"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)
            , _jsxDEV('div', { children: "۱۶. وضعیت سیستم چت"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)
            , _jsxDEV('div', { children: "۱۷. وضعیت i18n"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this)
            , _jsxDEV('div', { children: "۱۸. وابستگی‌های Base44"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this)
            , _jsxDEV('div', { children: "۱۹. تمام تناقض‌ها (۱۰ مورد)"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)
            , _jsxDEV('div', { children: "۲۰. فایل‌های کامل"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
            , _jsxDEV('div', { children: "۲۱. فایل‌های ناقص (خلاصه)"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this)
            , _jsxDEV('div', { children: "۲۲. فایل‌های مشاهده‌نشده"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this)
            , _jsxDEV('div', { children: "۲۳. موارد حیاتی مفقود"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this)
            , _jsxDEV('div', { children: "۲۴. موارد Backup داده‌ها"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this)
            , _jsxDEV('div', { children: "۲۵. تفاوت بازسازی و بازیابی"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this)
            , _jsxDEV('div', { children: "۲۶. موارد پیش از Migration"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this)
            , _jsxDEV('div', { children: "۲۷. دستورالعمل استفاده"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)
            , _jsxDEV('div', { children: "۲۸. Prompt بازسازی اضطراری"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 61}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 53}, this)

      /* Key Warnings */
      , _jsxDEV(Card, { className: "border-red-200 dark:border-red-900" , children: 
        _jsxDEV(CardContent, { className: "pt-6 space-y-3" , children: [
          _jsxDEV('div', { className: "flex items-start gap-2 text-sm"   , children: [
            _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-red-600 mt-0.5 shrink-0"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this )
            , _jsxDEV('span', { children: "این PDF فقط مستندات و ساختار پروژه است و جایگزین Backup واقعی دیتابیس، Supabase Auth، Storage و داده‌های کاربران نیست."                   }, void 0, false, {fileName: _jsxFileName, lineNumber: 99}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 97}, this)
          , _jsxDEV('div', { className: "flex items-start gap-2 text-sm"   , children: [
            _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-red-600 mt-0.5 shrink-0"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this )
            , _jsxDEV('span', { children: "۱۰ تناقض شناسایی‌شده در PDF ثبت شده‌اند و هیچ‌کدام حل یا انتخاب نشده‌اند."            }, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 101}, this)
          , _jsxDEV('div', { className: "flex items-start gap-2 text-sm"   , children: [
            _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-red-600 mt-0.5 shrink-0"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this )
            , _jsxDEV('span', { children: "فایل‌های ناقص و مشاهده‌نشده با وضعیت «ناقص/مفقود» ثبت شده‌اند."        }, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 105}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 96}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this)

      /* Generate Button */
      , _jsxDEV('div', { className: "flex flex-col items-center gap-4"   , children: [
        _jsxDEV(Button, {
          onClick: handleGenerate,
          disabled: generating,
          size: "lg",
          className: "w-full sm:w-auto min-w-[280px]"  ,
 children: 
          generating ? (
            _jsxDEV(_Fragment, { children: [
              _jsxDEV('div', { className: "w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this ), "در حال تولید PDF..."

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 121}, this)
          ) : (
            _jsxDEV(_Fragment, { children: [
              _jsxDEV(Download, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this ), "ایجاد و دانلود PDF اضطراری"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 126}, this)
          )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)

        , error && (
          _jsxDEV(Alert, { variant: "destructive", className: "w-full", children: [
            _jsxDEV(AlertTriangle, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this )
            , _jsxDEV(AlertTitle, { children: "خطا"}, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this)
            , _jsxDEV(AlertDescription, { children: error}, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 134}, this)
        )

        , fileName && (
          _jsxDEV(Alert, { className: "w-full border-green-300 bg-green-50 dark:bg-green-950/30 dark:border-green-800"    , children: [
            _jsxDEV(CheckCircle, { className: "w-4 h-4 text-green-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this )
            , _jsxDEV(AlertTitle, { className: "text-green-700 dark:text-green-400" , children: "PDF با موفقیت تولید شد"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this)
            , _jsxDEV(AlertDescription, { className: "text-green-700 dark:text-green-300" , children: ["فایل "
               , _jsxDEV('strong', { children: fileName}, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this), " دانلود شد."
              , _jsxDEV('br', {}, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this )
              , _jsxDEV('span', { className: "text-xs", children: "اگر دانلود خودکار نشد، فایل را از پنجره دانلود مرورگر بررسی کنید."           }, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 145}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 113}, this)

      /* Info */
      , _jsxDEV('p', { className: "text-center text-xs text-muted-foreground"  , children: ["نام فایل: sarraaf-emergency-backup-v01-YYYY-MM-DD-HHMM.pdf"

        , _jsxDEV('br', {}, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this ), "این سند شامل ۲۸ بخش کامل از وضعیت فعلی پروژه است."

      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 155}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 30}, this)
  );
}