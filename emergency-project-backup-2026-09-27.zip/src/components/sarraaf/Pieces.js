const _jsxFileName = "src/components/sarraaf/Pieces.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React from 'react';
import { cn } from '../../lib/utils.js';
import { Card, CardContent } from '../ui/card.js';
import { Loader2 } from 'lucide-react';

export function PageHeader({ title, subtitle, icon: Icon, actions, children }) {
  return (
    _jsxDEV('div', { className: "flex items-center justify-between gap-3 mb-5"    , children: [
      _jsxDEV('div', { className: "flex items-center gap-2.5 min-w-0"   , children: [
        Icon && (
          _jsxDEV('div', { className: "w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0"       , children: 
            _jsxDEV(Icon, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 12}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 11}, this)
        )
        , _jsxDEV('div', { className: "min-w-0", children: [
          _jsxDEV('h1', { className: "text-lg font-bold text-foreground truncate leading-tight"    , children: title}, void 0, false, {fileName: _jsxFileName, lineNumber: 16}, this)
          , subtitle && _jsxDEV('p', { className: "text-xs text-muted-foreground truncate mt-0.5"   , children: subtitle}, void 0, false, {fileName: _jsxFileName, lineNumber: 17}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 15}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 9}, this)
      , actions && _jsxDEV('div', { className: "flex items-center gap-2 shrink-0"   , children: actions}, void 0, false, {fileName: _jsxFileName, lineNumber: 20}, this)
      , children
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 8}, this)
  );
}

export function SectionCard({ title, icon: Icon, children, className, actions }) {
  return (
    _jsxDEV(Card, { className: cn('overflow-hidden shadow-card', className), children: [
      (title || Icon) && (
        _jsxDEV('div', { className: "flex items-center justify-between px-4 py-3 border-b bg-muted/40"      , children: [
          _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            Icon && _jsxDEV(Icon, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 32}, this )
            , title && _jsxDEV('h3', { className: "text-sm font-semibold text-foreground"  , children: title}, void 0, false, {fileName: _jsxFileName, lineNumber: 33}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 31}, this)
          , actions
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 30}, this)
      )
      , _jsxDEV(CardContent, { className: "p-4", children: children}, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 28}, this)
  );
}

export function StatCard({ label, value, sub, icon: Icon, gradient }) {
  return (
    _jsxDEV(Card, { className: "overflow-hidden border-0 shadow-card"  , children: 
      _jsxDEV(CardContent, { className: cn('p-3.5 text-white relative', gradient && `bg-gradient-to-br ${gradient}`), children: [
        _jsxDEV('div', { className: "flex items-start justify-between mb-1.5"   , children: [
          _jsxDEV('span', { className: "text-[11px] font-medium opacity-90 leading-tight"   , children: label}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this)
          , Icon && (
            _jsxDEV('div', { className: "w-7 h-7 rounded-lg bg-white/15 flex items-center justify-center shrink-0"       , children: 
              _jsxDEV(Icon, { className: "w-4 h-4 opacity-90"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 51}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 47}, this)
        , _jsxDEV('p', { className: "text-xl font-bold leading-tight tracking-tight"   , children: value}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this)
        , sub && _jsxDEV('p', { className: "text-[10px] opacity-75 mt-0.5"  , children: sub}, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 46}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 45}, this)
  );
}

export function BalanceCard({ label, amounts, accent = 'text-primary' }) {
  return (
    _jsxDEV(Card, { className: "overflow-hidden shadow-card" , children: 
      _jsxDEV(CardContent, { className: "p-4", children: [
        _jsxDEV('p', { className: "text-xs text-muted-foreground mb-2 font-medium"   , children: label}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
        , Object.entries(amounts).length === 0 ? (
          _jsxDEV('p', { className: "text-sm font-semibold text-muted-foreground"  , children: "۰"}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this)
        ) : (
          _jsxDEV('div', { className: "space-y-1.5", children: 
            Object.entries(amounts).map(([cur, val]) => (
              _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
                _jsxDEV('span', { className: cn('text-sm font-bold tabular-nums', accent), children: 
                  new Intl.NumberFormat('en-US').format(Math.round(val || 0))
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)
                , _jsxDEV('span', { className: "text-xs text-muted-foreground font-medium"  , children: cur}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)
              ]}, cur, true, {fileName: _jsxFileName, lineNumber: 72}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
  );
}

export function StatusBadge({ status, labels, variant }) {
  const v = variant || (status === 'active' || status === 'paid' || status === 'approved' || status === 'completed' ? 'success' : status === 'pending' || status === 'registered' ? 'warning' : status === 'cancelled' || status === 'rejected' || status === 'suspended' ? 'destructive' : 'secondary');
  return (
    _jsxDEV('span', { className: cn(
      'inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium',
      v === 'success' && 'bg-success/15 text-success',
      v === 'warning' && 'bg-warning/15 text-warning',
      v === 'destructive' && 'bg-destructive/15 text-destructive',
      v === 'secondary' && 'bg-muted text-muted-foreground',
    ), children: 
      _optionalChain([labels, 'optionalAccess', _ => _[status]]) || status
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this)
  );
}

export function EditedBadge({ edited }) {
  if (!edited) return null;
  return (
    _jsxDEV('span', { className: "inline-flex items-center px-1.5 py-0.5 rounded text-[10px] bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 font-medium"          , children: "ویرایش‌شده"

    }, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this)
  );
}

export function EmptyState({ icon: Icon, title, description }) {
  return (
    _jsxDEV('div', { className: "flex flex-col items-center justify-center py-12 text-center"     , children: [
      Icon && (
        _jsxDEV('div', { className: "w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mb-3"       , children: 
          _jsxDEV(Icon, { className: "w-7 h-7 text-muted-foreground/50"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
      )
      , _jsxDEV('p', { className: "text-sm font-medium text-muted-foreground"  , children: title}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this)
      , description && _jsxDEV('p', { className: "text-xs text-muted-foreground/70 mt-1 max-w-[200px]"   , children: description}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 112}, this)
  );
}

export function LoadingState() {
  return (
    _jsxDEV('div', { className: "flex items-center justify-center py-12"   , children: 
      _jsxDEV(Loader2, { className: "w-6 h-6 animate-spin text-primary"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this )
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this)
  );
}

export function TransactionRow({ tx, onClick, labels }) {
  return (
    _jsxDEV('div', {
      onClick: onClick,
      className: cn(
        'flex items-center justify-between gap-2 py-2.5 px-3 rounded-lg border border-transparent transition-all',
        onClick && 'cursor-pointer hover:bg-muted/50 hover:border-border'
      ),
 children: [
      _jsxDEV('div', { className: "flex items-center gap-2.5 min-w-0"   , children: 
        _jsxDEV('div', { className: "min-w-0", children: [
          _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
            _jsxDEV('span', { className: "text-sm font-medium text-foreground truncate"   , children: 
              _optionalChain([labels, 'optionalAccess', _2 => _2[tx.type]]) || tx.type
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this)
            , _jsxDEV(EditedBadge, { edited: tx.edited,}, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 143}, this)
          , tx.description && (
            _jsxDEV('p', { className: "text-xs text-muted-foreground truncate mt-0.5"   , children: tx.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 150}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this)
      , _jsxDEV('div', { className: "text-left shrink-0" , children: [
        _jsxDEV('p', { className: "text-sm font-bold tabular-nums text-foreground"   , children: 
          new Intl.NumberFormat('en-US').format(Math.round(tx.amount || 0))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 155}, this)
        , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: tx.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 154}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 134}, this)
  );
}