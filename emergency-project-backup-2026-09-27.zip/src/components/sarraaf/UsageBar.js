const _jsxFileName = "src/components/sarraaf/UsageBar.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";// UsageBar.jsx — Thin progress bar showing quota usage (green/yellow/red)
import React from 'react';
import { formatNumber } from '../../lib/sarraaf.js';

export default function UsageBar({ label, used, limit, unit }) {
  if (limit < 0 || limit === Infinity) return null;
  const pct = limit > 0 ? Math.min(100, (used / limit) * 100) : 0;
  const color = pct >= 100 ? 'bg-red-500' : pct >= 80 ? 'bg-amber-500' : 'bg-green-500';
  return (
    _jsxDEV('div', { className: "space-y-1", children: [
      _jsxDEV('div', { className: "flex items-center justify-between text-[10px]"   , children: [
        _jsxDEV('span', { className: "text-muted-foreground", children: label}, void 0, false, {fileName: _jsxFileName, lineNumber: 12}, this)
        , _jsxDEV('span', { className: "font-medium", children: [
          formatNumber(used), " / "  , formatNumber(limit)
          , unit && _jsxDEV('span', { className: "text-muted-foreground mr-1" , children: unit}, void 0, false, {fileName: _jsxFileName, lineNumber: 15}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 13}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 11}, this)
      , _jsxDEV('div', { className: "w-full h-1.5 bg-muted rounded-full overflow-hidden"    , children: 
        _jsxDEV('div', { className: `h-full ${color} rounded-full transition-all`, style: { width: `${pct}%` },}, void 0, false, {fileName: _jsxFileName, lineNumber: 19}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 18}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 10}, this)
  );
}