const _jsxFileName = "src/components/sarraaf/Fields.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState, useMemo, useEffect } from 'react';
import { Input } from '../ui/input.js';
import { Label } from '../ui/label.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select.js';
import { toEnglishDigits } from '../../lib/sarraaf.js';
import { DEFAULT_CURRENCIES } from '../../lib/defaultCurrencies.js';

export function Field({ label, required, children, className }) {
  return (
    _jsxDEV('div', { className: className, children: [
      label && (
        _jsxDEV(Label, { className: "mb-1 block" , children: [
          label, " " , required && _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 13}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 12}, this)
      )
      , children
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 10}, this)
  );
}

export function AmountInput({ value, onChange, placeholder = 'مبلغ', disabled }) {
  const [display, setDisplay] = useState(value ? new Intl.NumberFormat('en-US').format(value) : '');

  useEffect(() => {
    const formatted = value ? new Intl.NumberFormat('en-US').format(value) : '';
    setDisplay(formatted);
  }, [value]);

  const handle = (e) => {
    const raw = toEnglishDigits(e.target.value).replace(/[^\d.]/g, '');
    setDisplay(raw ? new Intl.NumberFormat('en-US').format(parseFloat(raw)) : '');
    onChange(raw ? parseFloat(raw) : 0);
  };
  return (
    _jsxDEV(Input, {
      type: "text",
      inputMode: "numeric",
      value: display,
      onChange: handle,
      placeholder: placeholder,
      disabled: disabled,
      className: "text-left font-mono" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 35}, this
    )
  );
}

// Sort currencies: AFN first, USD second, then others by sort_order
function sortCurrencies(list) {
  return [...list].sort((a, b) => {
    if (a.code === 'AFN') return -1;
    if (b.code === 'AFN') return 1;
    if (a.code === 'USD') return -1;
    if (b.code === 'USD') return 1;
    return (a.sort_order || 0) - (b.sort_order || 0);
  });
}

export function CurrencySelect({ value, onChange, currencies, disabled }) {
  const list = sortCurrencies((currencies && currencies.length > 0 ? currencies : DEFAULT_CURRENCIES).filter(c => c.is_active !== false));
  const fiatList = list.filter(c => c.type !== 'crypto');
  const cryptoList = list.filter(c => c.type === 'crypto');
  return (
    _jsxDEV(Select, { value: value, onValueChange: onChange, disabled: disabled, children: [
      _jsxDEV(SelectTrigger, { children: 
        _jsxDEV(SelectValue, { placeholder: "انتخاب ارز" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
      , _jsxDEV(SelectContent, { children: [
        fiatList.length > 0 && (
          _jsxDEV(_Fragment, { children: [
            _jsxDEV('div', { className: "px-2 py-1 text-[10px] font-medium text-muted-foreground pointer-events-none"     , children: "ارزهای رایج" }, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)
            , fiatList.map(c => (
              _jsxDEV(SelectItem, { value: c.code, children: [
                c.symbol ? `${c.symbol}` : c.code, " — "  , c.name
              ]}, c.code, true, {fileName: _jsxFileName, lineNumber: 72}, this)
            ))
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 69}, this)
        )
        , cryptoList.length > 0 && (
          _jsxDEV(_Fragment, { children: [
            _jsxDEV('div', { className: "px-2 py-1 text-[10px] font-medium text-muted-foreground pointer-events-none"     , children: "دارایی‌های دیجیتال" }, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)
            , cryptoList.map(c => (
              _jsxDEV(SelectItem, { value: c.code, children: [
                c.symbol ? `${c.symbol}` : c.code, " — "  , c.name
              ]}, c.code, true, {fileName: _jsxFileName, lineNumber: 82}, this)
            ))
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 79}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 67}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 63}, this)
  );
}

export function CounterAccountSelect({ value, onChange, bankAccounts, agents, type, onTypeChange }) {
  const accounts = useMemo(() => {
    if (type === 'bank') return bankAccounts || [];
    if (type === 'agent') return agents || [];
    return [];
  }, [type, bankAccounts, agents]);

  return (
    _jsxDEV('div', { className: "space-y-2", children: [
      _jsxDEV(Select, { value: type || 'none', onValueChange: onTypeChange, children: [
        _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, { placeholder: "حساب مقابل" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this)
        , _jsxDEV(SelectContent, { children: [
          _jsxDEV(SelectItem, { value: "none", children: "هیچ"}, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this)
          , _jsxDEV(SelectItem, { value: "cash", children: "صندوق"}, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this)
          , _jsxDEV(SelectItem, { value: "bank", children: "بانک"}, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this)
          , _jsxDEV(SelectItem, { value: "agent", children: "نماینده"}, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 104}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 102}, this)
      , type !== 'none' && type !== 'cash' && accounts.length > 0 && (
        _jsxDEV(Select, { value: value || '', onValueChange: onChange, children: [
          _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, { placeholder: "انتخاب حساب" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this)
          , _jsxDEV(SelectContent, { children: 
            accounts.map(a => (
              _jsxDEV(SelectItem, { value: a.id, children: [
                a.bank_name || a.name, " " , a.holder ? `- ${a.holder}` : ''
              ]}, a.id, true, {fileName: _jsxFileName, lineNumber: 116}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 112}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 101}, this)
  );
}

export function AgentSelect({ value, onChange, agents }) {
  return (
    _jsxDEV(Select, { value: value || '', onValueChange: onChange, children: [
      _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, { placeholder: "نماینده",}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)
      , _jsxDEV(SelectContent, { children: 
        (agents || []).map(a => (
          _jsxDEV(SelectItem, { value: a.id, children: [a.name, " " , a.code ? `(${a.code})` : '']}, a.id, true, {fileName: _jsxFileName, lineNumber: 133}, this)
        ))
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 129}, this)
  );
}

export function parseCounter(type, id) {
  return { counter_type: type || 'none', counter_id: id || null };
}