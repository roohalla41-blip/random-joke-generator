const _jsxFileName = "src/components/sarraaf/FeedbackButton.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { Button } from '../ui/button.js';
import { Textarea } from '../ui/textarea.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog.js';
import { Star, MessageSquarePlus } from 'lucide-react';
import { submitFeedback } from '../../lib/supportSystem.js';
import { useToast } from '../ui/use-toast.js';
import { useAuth } from '../../lib/AuthContext.js';

export default function FeedbackButton() {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState('suggestion');
  const [message, setMessage] = useState('');
  const [rating, setRating] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  async function handleSubmit() {
    if (!message) {
      toast({ title: 'خطا', description: 'پیام خود را وارد کنید', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    await submitFeedback({
      userId: _optionalChain([user, 'optionalAccess', _ => _.id]) || '',
      exchangeCode: _optionalChain([user, 'optionalAccess', _2 => _2.exchange_code]) || '',
      type,
      message,
      rating,
    });
    toast({ title: 'ممنون!', description: 'بازخورد شما ثبت شد' });
    setMessage('');
    setRating(0);
    setType('suggestion');
    setOpen(false);
    setSubmitting(false);
  }

  return (
    _jsxDEV(Dialog, { open: open, onOpenChange: setOpen, children: [
      _jsxDEV(DialogTrigger, { asChild: true, children: 
        _jsxDEV(Button, { variant: "outline", size: "sm", className: "w-full", children: [
          _jsxDEV(MessageSquarePlus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 45}, this ), "ثبت بازخورد"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 44}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this)
      , _jsxDEV(DialogContent, { children: [
        _jsxDEV(DialogHeader, { children: 
          _jsxDEV(DialogTitle, { children: "بازخورد شما" }, void 0, false, {fileName: _jsxFileName, lineNumber: 51}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this)
        , _jsxDEV('div', { className: "space-y-3", children: [
          _jsxDEV(Select, { value: type, onValueChange: setType, children: [
            _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this)
            , _jsxDEV(SelectContent, { children: [
              _jsxDEV(SelectItem, { value: "suggestion", children: "پیشنهاد"}, void 0, false, {fileName: _jsxFileName, lineNumber: 57}, this)
              , _jsxDEV(SelectItem, { value: "bug", children: "گزارش باگ" }, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this)
              , _jsxDEV(SelectItem, { value: "rating", children: "امتیاز و نظر"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 56}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 54}, this)

          , type === 'rating' && (
            _jsxDEV('div', { className: "flex items-center gap-1 justify-center"   , children: 
              [1, 2, 3, 4, 5].map(n => (
                _jsxDEV('button', { onClick: () => setRating(n), children: 
                  _jsxDEV(Star, { className: `w-6 h-6 ${n <= rating ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground'}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this )
                }, n, false, {fileName: _jsxFileName, lineNumber: 66}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
          )

          , _jsxDEV(Textarea, {
            value: message,
            onChange: (e) => setMessage(e.target.value),
            placeholder: "پیام خود را بنویسید..."   ,
            className: "min-h-[80px]",}, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this
          )

          , _jsxDEV(Button, { onClick: handleSubmit, disabled: submitting, className: "w-full", children: "ارسال"

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 53}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 49}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 42}, this)
  );
}