const _jsxFileName = "src/components/sarraaf/TripleBackup.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState } from 'react';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert.js';
import { Download, Loader2, FileText, FileArchive, Database, CheckCircle, AlertTriangle } from 'lucide-react';
import { generateTripleBackupPdf } from '../../lib/tripleBackupPdf.js';
import { generateTripleBackupZip } from '../../lib/tripleBackupZip.js';
import { generateTripleBackupSupabase } from '../../lib/tripleBackupSupabase.js';

export default function TripleBackup() {
  const [pdfLoading, setPdfLoading] = useState(false);
  const [zipLoading, setZipLoading] = useState(false);
  const [supabaseLoading, setSupabaseLoading] = useState(false);
  const [pdfResult, setPdfResult] = useState('');
  const [zipResult, setZipResult] = useState('');
  const [supabaseResult, setSupabaseResult] = useState('');
  const [error, setError] = useState('');

  const now = new Date().toLocaleString('fa-IR');

  const handlePdf = async () => {
    setPdfLoading(true);
    setError('');
    setPdfResult('');
    try {
      const name = generateTripleBackupPdf();
      setPdfResult(name);
    } catch (e) {
      setError('PDF: ' + (e.message || 'خطا'));
    } finally {
      setPdfLoading(false);
    }
  };

  const handleZip = async () => {
    setZipLoading(true);
    setError('');
    setZipResult('');
    try {
      const name = await generateTripleBackupZip();
      setZipResult(name);
    } catch (e) {
      setError('ZIP: ' + (e.message || 'خطا'));
    } finally {
      setZipLoading(false);
    }
  };

  const handleSupabase = async () => {
    setSupabaseLoading(true);
    setError('');
    setSupabaseResult('');
    try {
      const name = await generateTripleBackupSupabase();
      setSupabaseResult(name);
    } catch (e) {
      setError('Supabase: ' + (e.message || 'خطا'));
    } finally {
      setSupabaseLoading(false);
    }
  };

  return (
    _jsxDEV('div', { className: "space-y-4 max-w-3xl mx-auto"  , children: [
      _jsxDEV('div', { className: "text-center space-y-2" , children: [
        _jsxDEV('h2', { className: "text-xl font-bold" , children: "پشتیبان‌گیری اضطراری — سه خروجی مستقل"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
        , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: ["تاریخ: " , now]}, void 0, true, {fileName: _jsxFileName, lineNumber: 67}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)

      /* PDF Card */
      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
          _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            _jsxDEV(FileText, { className: "w-5 h-5 text-red-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this )
            , _jsxDEV('h3', { className: "text-sm font-semibold" , children: "📄 دانلود PDF اضطراری"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 73}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground leading-relaxed"  , children: "نقشه و مستندات کامل پروژه — شامل ۱۲ نقشه معماری، Frontend، Backend، Database، RLS، امنیت، منطق مالی، وابستگی‌های Base44 و Supabase."


          }, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)
          , _jsxDEV(Button, { onClick: handlePdf, disabled: pdfLoading, className: "w-full gap-2" , size: "lg", children: 
            pdfLoading ? (
              _jsxDEV(_Fragment, { children: [_jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this ), " در حال تولید PDF..."    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 83}, this)
            ) : (
              _jsxDEV(_Fragment, { children: [_jsxDEV(Download, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this ), " دانلود PDF اضطراری"   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 85}, this)
            )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
          , pdfResult && (
            _jsxDEV('div', { className: "flex items-center gap-2 text-xs text-green-600"    , children: [
              _jsxDEV(CheckCircle, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this ), " " , pdfResult
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 89}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 72}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this)

      /* ZIP Card */
      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
          _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            _jsxDEV(FileArchive, { className: "w-5 h-5 text-blue-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 100}, this )
            , _jsxDEV('h3', { className: "text-sm font-semibold" , children: "📦 دانلود ZIP پروژه"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 99}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground leading-relaxed"  , children: "Emergency Project Backup — شامل تمام سورس‌کد، صفحات، کامپوننت‌ها، توابع بک‌اند، فایل‌های پیکربندی، SQLها و مستندات. هیچ Secret یا Credential در ZIP قرار نمی‌گیرد."



          }, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this)
          , _jsxDEV(Button, { onClick: handleZip, disabled: zipLoading, className: "w-full gap-2" , size: "lg", children: 
            zipLoading ? (
              _jsxDEV(_Fragment, { children: [_jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this ), " در حال تولید ZIP..."    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 110}, this)
            ) : (
              _jsxDEV(_Fragment, { children: [_jsxDEV(Download, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this ), " دانلود ZIP پروژه"   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 112}, this)
            )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this)
          , zipResult && (
            _jsxDEV('div', { className: "flex items-center gap-2 text-xs text-green-600"    , children: [
              _jsxDEV(CheckCircle, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 117}, this ), " " , zipResult
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 116}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 98}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)

      /* Supabase Card */
      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
          _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            _jsxDEV(Database, { className: "w-5 h-5 text-green-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this )
            , _jsxDEV('h3', { className: "text-sm font-semibold" , children: "🗄️ دانلود Backup Supabase"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 128}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 126}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground leading-relaxed"  , children: "Supabase Emergency Backup — شامل Tables، Columns، Views، RLS Policies، Indexes، Auth Structure، Storage و SQL اضطراری برای بازسازی."


          }, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)
          , _jsxDEV(Button, { onClick: handleSupabase, disabled: supabaseLoading, className: "w-full gap-2" , size: "lg", children: 
            supabaseLoading ? (
              _jsxDEV(_Fragment, { children: [_jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this ), " در حال تولید Backup..."    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 136}, this)
            ) : (
              _jsxDEV(_Fragment, { children: [_jsxDEV(Download, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this ), " دانلود Backup Supabase"   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 138}, this)
            )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 134}, this)
          , supabaseResult && (
            _jsxDEV('div', { className: "flex items-center gap-2 text-xs text-green-600"    , children: [
              _jsxDEV(CheckCircle, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this ), " " , supabaseResult
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 125}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this)

      , error && (
        _jsxDEV(Alert, { variant: "destructive", children: [
          _jsxDEV(AlertTriangle, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this )
          , _jsxDEV(AlertTitle, { children: "خطا"}, void 0, false, {fileName: _jsxFileName, lineNumber: 152}, this)
          , _jsxDEV(AlertDescription, { children: error}, void 0, false, {fileName: _jsxFileName, lineNumber: 153}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 150}, this)
      )

      , _jsxDEV('p', { className: "text-center text-[10px] text-muted-foreground"  , children: "هر سه خروجی مستقل هستند و می‌توانید هر کدام را جداگانه دانلود کنید. هیچ تغییری در ساختار پروژه ایجاد نمی‌شود."


      }, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 64}, this)
  );
}