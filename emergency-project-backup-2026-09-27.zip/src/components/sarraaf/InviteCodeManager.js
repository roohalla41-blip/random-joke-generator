const _jsxFileName = "src/components/sarraaf/InviteCodeManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { offlineDB } from '../../lib/offlineQueue.js';
import { callSupabase } from '../../lib/supabaseApi.js';
import { generateUniqueInviteCode } from '../../lib/referralSystem.js';
import { useAuth } from '../../lib/AuthContext.js';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Label } from '../ui/label.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../ui/dialog.js';
import { toast } from '../ui/use-toast.js';
import { Gift, Copy, Plus, Store } from 'lucide-react';

const SETTING_KEY = 'standalone_invite_codes';

export default function InviteCodeManager() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [codes, setCodes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showCreateExchange, setShowCreateExchange] = useState(false);
  const [generatedCode, setGeneratedCode] = useState(null);
  const [exForm, setExForm] = useState({
    exchange_name: '',
    full_name: '',
    mobile: '',
    username: '',
    password: '',
    exchange_code: '',
  });
  const [creating, setCreating] = useState(false);

  // Load standalone invite codes from AppSetting
  useEffect(() => {
    loadCodes();
  }, []);

  const loadCodes = async () => {
    try {
      const settings = await offlineDB.AppSetting.filter({ key: SETTING_KEY });
      if (settings && settings.length > 0 && settings[0].data) {
        setCodes(settings[0].data);
      }
    } catch (e2) {
      // ignore
    }
  };

  const saveCodes = async (newCodes) => {
    const settings = await offlineDB.AppSetting.filter({ key: SETTING_KEY });
    if (settings && settings.length > 0) {
      await offlineDB.AppSetting.update(settings[0].id, { data: newCodes });
    } else {
      await offlineDB.AppSetting.create({ key: SETTING_KEY, value: 'invite_codes', data: newCodes });
    }
    setCodes(newCodes);
  };

  const handleGenerateCode = async () => {
    setLoading(true);
    try {
      const code = await generateUniqueInviteCode('SR');
      const entry = {
        code,
        created_at: new Date().toISOString(),
        created_by: _optionalChain([user, 'optionalAccess', _ => _.full_name]) || _optionalChain([user, 'optionalAccess', _2 => _2.email]) || 'مدیر سیستم',
        used: false,
      };
      const newCodes = [entry, ...codes];
      await saveCodes(newCodes);
      setGeneratedCode(code);
      toast({ title: 'کد دعوت تولید شد', description: code });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
    setLoading(false);
  };

  const handleCopy = (code) => {
    try {
      navigator.clipboard.writeText(code);
      toast({ title: 'کپی شد', description: code });
    } catch (e3) {
      toast({ title: 'خطا', description: 'کپی ناموفق بود', variant: 'destructive' });
    }
  };

  const handleCreateExchange = async () => {
    const { exchange_name, full_name, mobile, username, password, exchange_code } = exForm;
    if (!exchange_name || !full_name || !mobile || !username || !password || !exchange_code) {
      toast({ title: 'خطا', description: 'تمام فیلدها الزامی هستند', variant: 'destructive' });
      return;
    }
    setCreating(true);
    try {
      const res = await callSupabase('createExchange', {
        exchange_name,
        full_name,
        mobile,
        username,
        password,
        exchange_code,
      });
      if (!_optionalChain([res, 'optionalAccess', _3 => _3.success])) {
        toast({ title: 'خطا', description: _optionalChain([res, 'optionalAccess', _4 => _4.error]) || 'ایجاد صراف ناموفق بود', variant: 'destructive' });
        setCreating(false);
        return;
      }

      // Generate invite code for the new exchange
      const inviteCode = await generateUniqueInviteCode('SR');

      // Create SarraafProfile locally
      await offlineDB.SarraafProfile.create({
        code: exchange_code,
        user_id: String(_optionalChain([res, 'access', _5 => _5.user, 'optionalAccess', _6 => _6.id]) || ''),
        email: _optionalChain([res, 'access', _7 => _7.user, 'optionalAccess', _8 => _8.email]) || '',
        exchange_name,
        name: full_name,
        phone: mobile,
        plan: 'free',
        quota_limit: 100,
        quota_used: 0,
        payment_status: 'none',
        status: 'active',
        last_login: new Date().toISOString(),
        referral_enabled: true,
        referral_code: inviteCode,
      });

      qc.invalidateQueries({ queryKey: ['allSarraafProfiles'] });
      toast({
        title: 'صراف ایجاد شد',
        description: `کد دعوت: ${inviteCode}`,
      });
      setShowCreateExchange(false);
      setExForm({ exchange_name: '', full_name: '', mobile: '', username: '', password: '', exchange_code: '' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
    setCreating(false);
  };

  return (
    _jsxDEV(Card, { className: "mb-4", children: [
      _jsxDEV(CardContent, { className: "p-4", children: [
        _jsxDEV('div', { className: "flex items-center justify-between mb-3"   , children: [
          _jsxDEV('h3', { className: "text-sm font-semibold flex items-center gap-2"    , children: [
            _jsxDEV(Gift, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 150}, this ), "کدهای دعوت"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 149}, this)
          , _jsxDEV('div', { className: "flex gap-1" , children: [
            _jsxDEV(Button, { size: "sm", variant: "outline", onClick: handleGenerateCode, disabled: loading, children: [
              _jsxDEV(Gift, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 155}, this ), "تولید کد دعوت"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 154}, this)
            , _jsxDEV(Button, { size: "sm", onClick: () => setShowCreateExchange(true), children: [
              _jsxDEV(Store, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this ), "صراف جدید"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 158}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 153}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 148}, this)

        , codes.length === 0 ? (
          _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "کد دعوتی تولید نشده است."    }, void 0, false, {fileName: _jsxFileName, lineNumber: 166}, this)
        ) : (
          _jsxDEV('div', { className: "space-y-1.5", children: 
            codes.map((c, i) => (
              _jsxDEV('div', { className: "flex items-center justify-between p-2 rounded-lg border"     , children: [
                _jsxDEV('div', { className: "min-w-0 flex-1" , children: [
                  _jsxDEV('span', { className: "text-sm font-mono font-medium"  , children: c.code}, void 0, false, {fileName: _jsxFileName, lineNumber: 172}, this)
                  , c.used && _jsxDEV('span', { className: "text-[10px] text-muted-foreground mr-2"  , children: "(استفاده شده)" }, void 0, false, {fileName: _jsxFileName, lineNumber: 173}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 171}, this)
                , _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => handleCopy(c.code), children: 
                  _jsxDEV(Copy, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 176}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 175}, this)
              ]}, i, true, {fileName: _jsxFileName, lineNumber: 170}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)

      /* Create Exchange Dialog */
      , _jsxDEV(Dialog, { open: showCreateExchange, onOpenChange: setShowCreateExchange, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "صراف جدید" }, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this)
          , _jsxDEV('div', { className: "space-y-3", children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نام صرافی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 190}, this)
              , _jsxDEV(Input, { value: exForm.exchange_name, onChange: e => setExForm({ ...exForm, exchange_name: e.target.value }), placeholder: "نام صرافی" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 191}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 189}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نام مسئول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 194}, this)
              , _jsxDEV(Input, { value: exForm.full_name, onChange: e => setExForm({ ...exForm, full_name: e.target.value }), placeholder: "نام و نام خانوادگی"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 195}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 193}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "موبایل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 198}, this)
              , _jsxDEV(Input, { value: exForm.mobile, onChange: e => setExForm({ ...exForm, mobile: e.target.value }), placeholder: "07xxxxxxxxx",}, void 0, false, {fileName: _jsxFileName, lineNumber: 199}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 197}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نام کاربری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 202}, this)
              , _jsxDEV(Input, { value: exForm.username, onChange: e => setExForm({ ...exForm, username: e.target.value }), placeholder: "نام کاربری" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 203}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 201}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "رمز عبور" }, void 0, false, {fileName: _jsxFileName, lineNumber: 206}, this)
              , _jsxDEV(Input, { type: "password", value: exForm.password, onChange: e => setExForm({ ...exForm, password: e.target.value }), placeholder: "رمز عبور" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 207}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 205}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "کد صرافی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 210}, this)
              , _jsxDEV(Input, { value: exForm.exchange_code, onChange: e => setExForm({ ...exForm, exchange_code: e.target.value }), placeholder: "EX-XXXXX",}, void 0, false, {fileName: _jsxFileName, lineNumber: 211}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 209}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 188}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setShowCreateExchange(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 215}, this)
            , _jsxDEV(Button, { onClick: handleCreateExchange, disabled: creating, children: 
              creating ? 'در حال ایجاد...' : 'ایجاد صراف'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 216}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 214}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 186}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 185}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 146}, this)
  );
}