const _jsxFileName = "src/components/sarraaf/EmergencyBackup.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState } from 'react';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Download, Loader2, AlertTriangle, FileText, FileArchive } from 'lucide-react';
import { callSupabase } from '../../lib/supabaseApi.js';
import { generateEmergencyPdf } from '../../lib/emergencyBackupPdf.js';

export default function EmergencyBackup() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [lastGenerated, setLastGenerated] = useState('');

  const handleGenerate = async () => {
    setLoading(true);
    setError('');
    try {
      // Try to fetch live schema (optional — falls back to static data if unavailable)
      let schema = null;
      try {
        const result = await callSupabase('getDatabaseSchema', {});
        if (result.success && result.schema) {
          schema = result.schema;
        }
      } catch (e2) {
        // Backend action may not be deployed yet — generate with static data
      }

      // Generate PDF (works with or without live schema)
      const filename = generateEmergencyPdf(schema);
      setLastGenerated(filename);
    } catch (e) {
      setError(e.message || 'Failed to generate PDF');
    } finally {
      setLoading(false);
    }
  };

  return (
    _jsxDEV(Card, { children: 
      _jsxDEV(CardContent, { className: "p-4 space-y-4" , children: [
        _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
          _jsxDEV(AlertTriangle, { className: "w-5 h-5 text-amber-500"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this )
          , _jsxDEV('h3', { className: "text-sm font-semibold" , children: "پشتیبان اضطراری پروژه"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 41}, this)

        , _jsxDEV('p', { className: "text-xs text-muted-foreground leading-relaxed"  , children: "این بخش یک فایل PDF کامل از ساختار پروژه تولید می‌کند که شامل تمام صفحات، مسیرها، اسکیمای دیتابیس، مدل امنیتی، وابستگی‌های Base44 و راهنمای بازسازی است. در صورت خرابی یا قطع دسترسی به Base44، با این PDF و اتصال به Supabase می‌توان کل پروژه را بازسازی کرد."




        }, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this)

        , _jsxDEV('div', { className: "rounded-lg border border-amber-200 bg-amber-50 p-3 dark:border-amber-900 dark:bg-amber-950/30"      , children: 
          _jsxDEV('p', { className: "text-xs text-amber-800 dark:text-amber-200"  , children: [
            _jsxDEV('strong', { children: "توجه:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this), " این فایل شامل اطلاعات فنی حساس است (نام جداول، ستون‌ها، Policyها) اما هیچ کلید محرمانه‌ای در آن قرار نمی‌گیرد. فایل را در محل امن ذخیره کنید."


          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 54}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 53}, this)

        , _jsxDEV('div', { className: "space-y-2", children: [
          _jsxDEV('h4', { className: "text-xs font-semibold" , children: "محتوای PDF شامل:"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this)
          , _jsxDEV('ul', { className: "text-xs text-muted-foreground space-y-1 list-disc pr-4"    , children: [
            _jsxDEV('li', { children: "فناوری‌ها و نسخه‌ها (Technology Stack)"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
            , _jsxDEV('li', { children: "نقشه معماری سیستم (Architecture Map)"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this)
            , _jsxDEV('li', { children: "ساختار پوشه‌ها و فایل‌ها"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
            , _jsxDEV('li', { children: "تمام مسیرهای React Router"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this)
            , _jsxDEV('li', { children: "اسکیمای زنده دیتابیس (جداول، ستون‌ها، Viewها، Policyها)"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this)
            , _jsxDEV('li', { children: "مدل امنیتی (HMAC، PBKDF2، RLS، Tenant Isolation)"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this)
            , _jsxDEV('li', { children: "وابستگی‌های Base44 و روش جداسازی"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)
            , _jsxDEV('li', { children: "منطق مالی (Double-entry ledger، RPCها)"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this)
            , _jsxDEV('li', { children: "دستورالعمل بازسازی مرحله‌به‌مرحله"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this)
            , _jsxDEV('li', { children: "Prompt کامل برای هوش مصنوعی جهت بازسازی"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 63}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 61}, this)

        , _jsxDEV(Button, {
          onClick: handleGenerate,
          disabled: loading,
          className: "w-full gap-2" ,
          size: "lg",
 children: 
          loading ? (
            _jsxDEV(_Fragment, { children: [
              _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this ), "در حال تولید PDF..."

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 84}, this)
          ) : (
            _jsxDEV(_Fragment, { children: [
              _jsxDEV(Download, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this ), "ایجاد و دانلود PDF کامل بازسازی پروژه"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 89}, this)
          )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)

        , error && (
          _jsxDEV('div', { className: "rounded-lg border border-red-200 bg-red-50 p-3 dark:border-red-900 dark:bg-red-950/30"      , children: 
            _jsxDEV('p', { className: "text-xs text-red-700 dark:text-red-300"  , children: error}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)
        )

        , lastGenerated && !loading && (
          _jsxDEV('div', { className: "rounded-lg border border-green-200 bg-green-50 p-3 dark:border-green-900 dark:bg-green-950/30"      , children: 
            _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
              _jsxDEV(FileText, { className: "w-4 h-4 text-green-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this )
              , _jsxDEV('p', { className: "text-xs text-green-700 dark:text-green-300"  , children: ["فایل با موفقیت تولید شد: "
                     , _jsxDEV('strong', { children: lastGenerated}, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 106}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 104}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this)
        )

        , _jsxDEV('p', { className: "text-[10px] text-muted-foreground text-center"  , children: "هر بار که روی دکمه کلیک کنید، آخرین وضعیت واقعی پروژه بررسی و PDF جدید تولید می‌شود."

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this)

        /* ZIP Source Code Backup */
        , _jsxDEV('div', { className: "rounded-lg border border-blue-200 bg-blue-50 p-4 dark:border-blue-900 dark:bg-blue-950/30 space-y-3"       , children: [
          _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            _jsxDEV(FileArchive, { className: "w-5 h-5 text-blue-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this )
            , _jsxDEV('h4', { className: "text-sm font-semibold" , children: "دانلود ZIP سورس‌کد پروژه"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 119}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground leading-relaxed"  , children: "فایل ZIP شامل تمام سورس‌کد واقعی پروژه (۳۱۹ فایل) است: صفحات، کامپوننت‌ها، توابع بک‌اند، فایل‌های SQL، تنظیمات پروژه و فایل MANIFEST. node_modules و فایل‌های حاوی Secret در ZIP قرار نگرفته‌اند."



          }, void 0, false, {fileName: _jsxFileName, lineNumber: 123}, this)
          , _jsxDEV('a', { href: "/hesab-sarraf-source-backup-v01.zip", download: true, children: 
            _jsxDEV(Button, { variant: "outline", className: "w-full gap-2 border-blue-300 text-blue-700 hover:bg-blue-100 dark:border-blue-800 dark:text-blue-300 dark:hover:bg-blue-950/50"       , children: [
              _jsxDEV(FileArchive, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this ), "دانلود hesab-sarraf-source-backup-v01.zip"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 129}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 128}, this)
          , _jsxDEV('a', { href: "/BACKUP-MANIFEST.txt", download: true, className: "block", children: 
            _jsxDEV(Button, { variant: "ghost", size: "sm", className: "w-full gap-2 text-blue-600"  , children: [
              _jsxDEV(FileText, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this ), "مشاهده فهرست فایل‌ها (BACKUP-MANIFEST.txt)"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 135}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 134}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 118}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 40}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 39}, this)
  );
}