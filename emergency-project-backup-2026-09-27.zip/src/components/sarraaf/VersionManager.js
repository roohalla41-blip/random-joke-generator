const _jsxFileName = "src/components/sarraaf/VersionManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Label } from '../ui/label.js';
import { Textarea } from '../ui/textarea.js';
import { Switch } from '../ui/switch.js';
import { Loader2, Upload, AlertTriangle, CheckCircle } from 'lucide-react';
import { getCurrentVersionInfo, publishVersion, APP_VERSION } from '../../lib/versionManager.js';
import { useToast } from '../ui/use-toast.js';

export default function VersionManager() {
  const [versionInfo, setVersionInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [publishing, setPublishing] = useState(false);
  const [form, setForm] = useState({ version: '', releaseNotes: '', downloadUrl: '', isMandatory: false });
  const { toast } = useToast();

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    const info = await getCurrentVersionInfo();
    setVersionInfo(info);
    setForm({
      version: info.version || '',
      releaseNotes: info.release_notes || '',
      downloadUrl: info.download_url || '',
      isMandatory: info.is_mandatory || false,
    });
    setLoading(false);
  }

  async function handlePublish() {
    if (!form.version) {
      toast({ title: 'خطا', description: 'شماره نسخه الزامی است', variant: 'destructive' });
      return;
    }
    setPublishing(true);
    try {
      await publishVersion({
        version: form.version,
        releaseNotes: form.releaseNotes,
        downloadUrl: form.downloadUrl,
        isMandatory: form.isMandatory,
      });
      toast({ title: 'موفق', description: 'نسخه جدید منتشر شد و به کاربران اطلاع داده شد' });
      load();
    } catch (e2) {
      toast({ title: 'خطا', description: 'انتشار نسخه ناموفق بود', variant: 'destructive' });
    }
    setPublishing(false);
  }

  if (loading) {
    return (
      _jsxDEV('div', { className: "flex items-center justify-center py-8"   , children: 
        _jsxDEV(Loader2, { className: "w-5 h-5 animate-spin text-primary"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this)
    );
  }

  return (
    _jsxDEV(Card, { children: [
      _jsxDEV(CardHeader, { children: 
        _jsxDEV(CardTitle, { className: "text-sm flex items-center gap-2"   , children: [
          _jsxDEV(Upload, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this ), "مدیریت نسخه برنامه"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 68}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this)
      , _jsxDEV(CardContent, { className: "space-y-3", children: [
        _jsxDEV('div', { className: "flex items-center gap-2 p-2 rounded-lg bg-muted/50"     , children: [
          _optionalChain([versionInfo, 'optionalAccess', _ => _.version]) === APP_VERSION ? (
            _jsxDEV(CheckCircle, { className: "w-4 h-4 text-green-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this )
          ) : (
            _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-amber-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this )
          )
          , _jsxDEV('span', { className: "text-xs", children: ["نسخه فعلی دستگاه: "
               , APP_VERSION, " — نسخه منتشرشده: "    , _optionalChain([versionInfo, 'optionalAccess', _2 => _2.version]) || '—'
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 80}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 74}, this)

        , _jsxDEV('div', { children: [
          _jsxDEV(Label, { className: "text-xs", children: "شماره نسخه جدید"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this)
          , _jsxDEV(Input, {
            value: form.version,
            onChange: (e) => setForm({ ...form, version: e.target.value }),
            placeholder: "1.0.1",
            className: "h-8 text-sm mt-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 85}, this)

        , _jsxDEV('div', { children: [
          _jsxDEV(Label, { className: "text-xs", children: "یادداشت انتشار" }, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this)
          , _jsxDEV(Textarea, {
            value: form.releaseNotes,
            onChange: (e) => setForm({ ...form, releaseNotes: e.target.value }),
            placeholder: "تغییرات و بهبودهای نسخه جدید..."    ,
            className: "text-sm mt-1 min-h-[60px]"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)

        , _jsxDEV('div', { children: [
          _jsxDEV(Label, { className: "text-xs", children: "لینک دانلود" }, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this)
          , _jsxDEV(Input, {
            value: form.downloadUrl,
            onChange: (e) => setForm({ ...form, downloadUrl: e.target.value }),
            placeholder: "https://...",
            className: "h-8 text-sm mt-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 105}, this)

        , _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
          _jsxDEV(Switch, {
            checked: form.isMandatory,
            onCheckedChange: (v) => setForm({ ...form, isMandatory: v }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this
          )
          , _jsxDEV(Label, { className: "text-xs", children: "آپدیت اجباری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 115}, this)

        , _jsxDEV(Button, { onClick: handlePublish, disabled: publishing, className: "w-full", size: "sm", children: [
          publishing ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this ) : _jsxDEV(Upload, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this ), "انتشار نسخه جدید"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 123}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 73}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 66}, this)
  );
}