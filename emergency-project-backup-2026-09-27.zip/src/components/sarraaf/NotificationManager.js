const _jsxFileName = "src/components/sarraaf/NotificationManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { useAllNotifications, useSendNotification, useDeleteNotification, useAllSarraafProfiles } from '../../lib/useAdmin.js';
import { useAuth } from '../../lib/AuthContext.js';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Textarea } from '../ui/textarea.js';
import { Label } from '../ui/label.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../ui/dialog.js';
import { toast } from '../ui/use-toast.js';
import { Bell, Plus, Trash2, Send } from 'lucide-react';

const NOTIFICATION_TEMPLATES = [
  { kind: 'paid_purchase', title: 'خرید نسخه پولی', message: 'درخواست خرید نسخه پولی دریافت شد. پس از تأیید، حساب شما فعال خواهد شد.' },
  { kind: 'paid_activated', title: 'فعال شدن نسخه پولی', message: 'نسخه پولی حساب شما فعال شد. از امکانات ویژه لذت ببرید.' },
  { kind: 'paid_expired', title: 'پایان اعتبار نسخه پولی', message: 'اعتبار نسخه پولی شما به پایان رسید. حساب شما به نسخه رایگان بازگشت.' },
  { kind: 'general', title: 'اطلاعیه عمومی', message: 'اطلاعیه جدیدی از سیستم همراه ما.' },
  { kind: 'account_limitation', title: 'محدودیت حساب', message: 'حساب شما با محدودیت مواجه شده است. برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.' },
  { kind: 'feature_toggle', title: 'تغییر وضعیت قابلیت', message: 'یکی از قابلیت‌های حساب شما تغییر یافت.' },
  { kind: 'app_update', title: 'آپدیت برنامه', message: 'نسخه جدید برنامه منتشر شده است. لطفاً برنامه را به‌روزرسانی کنید.' },
  { kind: 'custom', title: 'پیام سفارشی', message: '' },
];

export default function NotificationManager() {
  const { user } = useAuth();
  const { data: notifications, isLoading } = useAllNotifications();
  const { data: profiles } = useAllSarraafProfiles();
  const sendMut = useSendNotification();
  const deleteMut = useDeleteNotification();

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ targetRole: 'all', targetUserId: '', title: '', message: '', kind: 'general', actionUrl: '', actionLabel: '' });

  const openCreate = () => {
    setForm({ targetRole: 'all', targetUserId: '', title: '', message: '', kind: 'general', actionUrl: '', actionLabel: '' });
    setShowForm(true);
  };

  const applyTemplate = (kind) => {
    const tpl = NOTIFICATION_TEMPLATES.find(t => t.kind === kind);
    if (tpl) setForm({ ...form, kind, title: tpl.title, message: tpl.message });
  };

  const handleSend = async () => {
    if (!form.title.trim() || !form.message.trim()) {
      toast({ title: 'خطا', description: 'عنوان و متن پیام الزامی است', variant: 'destructive' });
      return;
    }
    const targetProfile = _optionalChain([profiles, 'optionalAccess', _ => _.find, 'call', _2 => _2(p => p.user_id === form.targetUserId)]);
    try {
      await sendMut.mutateAsync({
        targetUserId: form.targetRole === 'specific' ? form.targetUserId : '',
        targetUserName: _optionalChain([targetProfile, 'optionalAccess', _3 => _3.name]) || '',
        targetRole: form.targetRole === 'specific' ? 'sarraaf' : form.targetRole,
        title: form.title.trim(),
        message: form.message.trim(),
        kind: form.kind,
        actionUrl: form.actionUrl.trim(),
        actionLabel: form.actionLabel.trim() || (form.kind === 'app_update' ? 'دانلود آپدیت' : ''),
        sentByName: _optionalChain([user, 'optionalAccess', _4 => _4.full_name]) || _optionalChain([user, 'optionalAccess', _5 => _5.email]) || 'مدیر سیستم',
      });
      toast({ title: 'ارسال شد', description: 'پیام به کاربر ارسال شد' });
      setShowForm(false);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteMut.mutateAsync(id);
      toast({ title: 'حذف شد' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV(Card, { children: [
      _jsxDEV(CardContent, { className: "p-4", children: [
        _jsxDEV('div', { className: "flex items-center justify-between mb-3"   , children: [
          _jsxDEV('h3', { className: "text-sm font-semibold flex items-center gap-2"    , children: [
            _jsxDEV(Bell, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this ), "پیام‌ها و اطلاع‌رسانی"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 83}, this)
          , _jsxDEV(Button, { size: "sm", onClick: openCreate, children: [
            _jsxDEV(Plus, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this ), "پیام جدید"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 87}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 82}, this)

        , isLoading ? (
          _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "در حال بارگذاری..."  }, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this)
        ) : !notifications || notifications.length === 0 ? (
          _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "پیامی وجود ندارد"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this)
        ) : (
          _jsxDEV('div', { className: "space-y-2 max-h-[400px] overflow-y-auto scrollbar-thin"   , children: 
            notifications.map(n => (
              _jsxDEV('div', { className: "p-2.5 rounded-lg border"  , children: 
                _jsxDEV('div', { className: "flex items-start justify-between gap-2"   , children: [
                  _jsxDEV('div', { className: "min-w-0 flex-1" , children: [
                    _jsxDEV('p', { className: "text-sm font-medium truncate"  , children: n.title}, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground mt-0.5 line-clamp-2"   , children: n.message}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this)
                    , _jsxDEV('div', { className: "flex flex-wrap gap-x-2 gap-y-0.5 mt-1 text-[9px] text-muted-foreground"      , children: [
                      _jsxDEV('span', { children: ["گیرنده: " , n.target_role === 'all' ? 'همه' : n.target_user_name || '—']}, void 0, true, {fileName: _jsxFileName, lineNumber: 106}, this)
                      , _jsxDEV('span', { children: ["نوع: " , n.kind]}, void 0, true, {fileName: _jsxFileName, lineNumber: 107}, this)
                      , n.sent_by_name && _jsxDEV('span', { children: ["ارسال‌کننده: " , n.sent_by_name]}, void 0, true, {fileName: _jsxFileName, lineNumber: 108}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 105}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 102}, this)
                  , _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => handleDelete(n.id), children: 
                    _jsxDEV(Trash2, { className: "w-3 h-3 text-destructive"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 101}, this)
              }, n.id, false, {fileName: _jsxFileName, lineNumber: 100}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 81}, this)

      , _jsxDEV(Dialog, { open: showForm, onOpenChange: setShowForm, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "ارسال پیام" }, void 0, false, {fileName: _jsxFileName, lineNumber: 123}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 123}, this)
          , _jsxDEV('div', { className: "space-y-3", children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نوع پیام (قالب آماده)"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this)
              , _jsxDEV(Select, { value: form.kind, onValueChange: applyTemplate, children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 128}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 128}, this)
                , _jsxDEV(SelectContent, { children: 
                  NOTIFICATION_TEMPLATES.map(t => (
                    _jsxDEV(SelectItem, { value: t.kind, children: t.title}, t.kind, false, {fileName: _jsxFileName, lineNumber: 131}, this)
                  ))
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 127}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 125}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "گیرنده"}, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this)
              , _jsxDEV(Select, { value: form.targetRole, onValueChange: v => setForm({ ...form, targetRole: v }), children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this)
                , _jsxDEV(SelectContent, { children: [
                  _jsxDEV(SelectItem, { value: "all", children: "همه کاربران" }, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this)
                  , _jsxDEV(SelectItem, { value: "sarraaf", children: "همه صرافان" }, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this)
                  , _jsxDEV(SelectItem, { value: "customer", children: "همه مشتریان" }, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this)
                  , _jsxDEV(SelectItem, { value: "employee", children: "همه کارمندان" }, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this)
                  , _jsxDEV(SelectItem, { value: "specific", children: "کاربر خاص" }, void 0, false, {fileName: _jsxFileName, lineNumber: 145}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 140}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 138}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 136}, this)
            , form.targetRole === 'specific' && (
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "انتخاب کاربر" }, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this)
                , _jsxDEV(Select, { value: form.targetUserId, onValueChange: v => setForm({ ...form, targetUserId: v }), children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, { placeholder: "انتخاب کاربر" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 153}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 153}, this)
                  , _jsxDEV(SelectContent, { children: 
                    (profiles || []).map(p => (
                      _jsxDEV(SelectItem, { value: p.user_id, children: [p.name, " (" , p.code, ")"]}, p.id, true, {fileName: _jsxFileName, lineNumber: 156}, this)
                    ))
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 154}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 152}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 150}, this)
            )
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "عنوان"}, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this)
              , _jsxDEV(Input, { value: form.title, onChange: e => setForm({ ...form, title: e.target.value }), placeholder: "عنوان پیام" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 164}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 162}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "متن پیام" }, void 0, false, {fileName: _jsxFileName, lineNumber: 167}, this)
              , _jsxDEV(Textarea, { value: form.message, onChange: e => setForm({ ...form, message: e.target.value }), placeholder: "متن پیام" , rows: 4,}, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 166}, this)
            , form.kind === 'app_update' && (
              _jsxDEV('div', { className: "space-y-2 p-3 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800"       , children: [
                _jsxDEV('p', { className: "text-xs font-medium text-amber-700 dark:text-amber-400"   , children: "لینک آپدیت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 172}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { children: "آدرس دانلود" }, void 0, false, {fileName: _jsxFileName, lineNumber: 174}, this)
                  , _jsxDEV(Input, { value: form.actionUrl, onChange: e => setForm({ ...form, actionUrl: e.target.value }), placeholder: "https://your-domain.com", dir: "ltr",}, void 0, false, {fileName: _jsxFileName, lineNumber: 175}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 173}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { children: "متن دکمه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this)
                  , _jsxDEV(Input, { value: form.actionLabel, onChange: e => setForm({ ...form, actionLabel: e.target.value }), placeholder: "دانلود آپدیت" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 177}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 171}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 124}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setShowForm(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 185}, this)
            , _jsxDEV(Button, { onClick: handleSend, disabled: sendMut.isPending, children: [
              _jsxDEV(Send, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this )
              , sendMut.isPending ? 'در حال ارسال...' : 'ارسال'
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 186}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 184}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 122}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 80}, this)
  );
}