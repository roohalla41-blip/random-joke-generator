const _jsxFileName = "src/components/sarraaf/UserManagement.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useMemo } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useAllSarraafProfiles, useAllCustomers, useAllTransactions, useAllMessages, useActivatePaidPlan, useExpirePaidPlan, useUpdateSarraafProfile } from '../../lib/useAdmin.js';
import { getPlanStatus, getPlanDisplay } from '../../lib/permissions.js';
import { useAuth } from '../../lib/AuthContext.js';
import { callSupabase } from '../../lib/supabaseApi.js';
import { RefreshCw } from 'lucide-react';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../ui/dialog.js';
import { Label } from '../ui/label.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select.js';
import { toast } from '../ui/use-toast.js';
import { Search, Crown, Clock, UserX, UserCheck, Users, Activity, MessageSquare, Store } from 'lucide-react';
import { generateUniqueInviteCode } from '../../lib/referralSystem.js';
import InviteCodeManager from './InviteCodeManager.js';

// ── Sync users from Supabase server to Base44 entities ──
// Creates SarraafProfile for sarraaf users and Customer for customer users
// that exist on the server but don't have local records yet.
export async function syncUsersFromServer() {
  const auth_token = typeof localStorage !== 'undefined' ? localStorage.getItem('auth_token') : '';
  const [usersRes, exRes] = await Promise.all([
    callSupabase('listUsers', { auth_token }),
    callSupabase('listExchanges', { auth_token }),
  ]);
  const users = _optionalChain([usersRes, 'optionalAccess', _ => _.users]) || [];
  const exchanges = _optionalChain([exRes, 'optionalAccess', _2 => _2.exchanges]) || [];

  const { offlineDB } = await import('../../lib/offlineQueue.js');
  const existingProfiles = await offlineDB.SarraafProfile.list('-created_date', 500);
  const existingCustomers = await offlineDB.Customer.list('-created_date', 500);
  const profileUserIds = new Set(existingProfiles.map(p => String(p.user_id || '')));
  const profileEmails = new Set(existingProfiles.map(p => (p.email || '').toLowerCase()).filter(Boolean));
  const customerPhones = new Set(existingCustomers.map(c => (c.phone || '').trim()));

  let created = 0;

  // 1) Sync from Supabase users table
  for (const u of users) {
    const uid = String(u.id || '');
    const role = u.role || '';
    const email = (u.email || '').toLowerCase();
    // Sarraaf users — create SarraafProfile if missing (also check by email for Gmail users)
    if ((role === 'exchange' || role === 'sarraaf') && !profileUserIds.has(uid) && !(email && profileEmails.has(email))) {
      const ex = exchanges.find(e => String(e.user_id || '') === uid) || exchanges.find(e => e.exchange_name && u.full_name && u.full_name.includes(e.exchange_name));
      try {
        const inviteCode = await generateUniqueInviteCode('SR');
        await offlineDB.SarraafProfile.create({
          code: _optionalChain([ex, 'optionalAccess', _3 => _3.exchange_code]) || `EX-${uid.slice(-5)}`,
          user_id: uid,
          email: u.email || '',
          exchange_name: _optionalChain([ex, 'optionalAccess', _4 => _4.exchange_name]) || '',
          name: u.full_name || u.username || 'صراف',
          phone: u.mobile || '',
          plan: 'free',
          quota_limit: 100,
          quota_used: 0,
          payment_status: 'none',
          status: u.status === 'suspended' ? 'suspended' : 'active',
          last_login: u.last_login || u.created_date || new Date().toISOString(),
          referral_enabled: true,
          referral_code: inviteCode,
        });
        created++;
      } catch (e2) { /* ignore individual failures */ }
    }
    // Customer users — create Customer if missing
    if (role === 'customer' && u.mobile && !customerPhones.has(u.mobile.trim())) {
      try {
        await offlineDB.Customer.create({
          name: u.full_name || 'مشتری',
          phone: u.mobile,
          code: `CUS-${uid.slice(-6)}`,
          status: u.status === 'active' ? 'active' : 'inactive',
          customer_type: 'permanent',
          notes: `همگام‌سازی از سرور — ${new Date().toLocaleDateString('fa-IR')}`,
        });
        created++;
      } catch (e3) { /* ignore individual failures */ }
    }
  }

  // Note: Base44 User entity sync removed — all users now come from Supabase users table via listUsers action.

  return { created };
}

function toFa(n) {
  return Number(n || 0).toLocaleString('fa-IR');
}

export default function UserManagement() {
  const { user } = useAuth();
  const { data: profiles, isLoading: loadingSarraaf } = useAllSarraafProfiles();
  const { data: customers, isLoading: loadingCustomer } = useAllCustomers();
  const { data: transactions } = useAllTransactions();
  const { data: messages } = useAllMessages();
  const activateMut = useActivatePaidPlan();
  const expireMut = useExpirePaidPlan();
  const updateMut = useUpdateSarraafProfile();

  const [tab, setTab] = useState('sarraaf');
  const [search, setSearch] = useState('');
  const [filterPlan, setFilterPlan] = useState('all');
  const [editProfile, setEditProfile] = useState(null);
  const [planForm, setPlanForm] = useState({ plan: 'pro', startDate: '', endDate: '', durationMonths: 1 });
  const [syncing, setSyncing] = useState(false);
  const qc = useQueryClient();

  // Build usage stats map: user_id → { txCount, msgCount }
  const usageMap = useMemo(() => {
    const map = {};
    for (const tx of (transactions || [])) {
      const uid = tx.created_by_id || tx.customer_id || '';
      if (uid) {
        if (!map[uid]) map[uid] = { txCount: 0, msgCount: 0 };
        map[uid].txCount++;
      }
    }
    for (const msg of (messages || [])) {
      const uid = msg.sender_id || '';
      if (uid) {
        if (!map[uid]) map[uid] = { txCount: 0, msgCount: 0 };
        map[uid].msgCount++;
      }
    }
    return map;
  }, [transactions, messages]);

  const filteredSarraaf = useMemo(() => {
    let list = profiles || [];
    if (search) {
      const s = search.toLowerCase();
      list = list.filter(p =>
        (p.name || '').toLowerCase().includes(s) ||
        (p.code || '').toLowerCase().includes(s) ||
        (p.phone || '').includes(s)
      );
    }
    if (filterPlan !== 'all') {
      list = list.filter(p => getPlanStatus(p) === filterPlan);
    }
    return list;
  }, [profiles, search, filterPlan]);

  const filteredCustomers = useMemo(() => {
    let list = customers || [];
    if (search) {
      const s = search.toLowerCase();
      list = list.filter(c =>
        (c.name || '').toLowerCase().includes(s) ||
        (c.phone || '').includes(s) ||
        (c.code || '').toLowerCase().includes(s)
      );
    }
    return list;
  }, [customers, search]);

  const openActivate = (profile) => {
    setEditProfile(profile);
    const today = new Date().toISOString().slice(0, 10);
    const end = new Date();
    end.setFullYear(end.getFullYear() + 1);
    end.setDate(end.getDate() - 1);
    setPlanForm({ plan: 'pro', startDate: today, endDate: end.toISOString().slice(0, 10), durationMonths: 12 });
  };

  const handleDurationChange = (months) => {
    const start = new Date(planForm.startDate || new Date().toISOString().slice(0, 10));
    const end = new Date(start);
    end.setMonth(end.getMonth() + months);
    end.setDate(end.getDate() - 1);
    setPlanForm({ ...planForm, durationMonths: months, endDate: end.toISOString().slice(0, 10) });
  };

  const handleActivate = async () => {
    if (!editProfile) return;
    try {
      await activateMut.mutateAsync({
        profile: editProfile,
        plan: planForm.plan,
        startDate: planForm.startDate,
        endDate: planForm.endDate,
        confirmedByName: _optionalChain([user, 'optionalAccess', _5 => _5.full_name]) || _optionalChain([user, 'optionalAccess', _6 => _6.email]) || 'مدیر سیستم',
      });
      toast({ title: 'فعال شد', description: 'نسخه پولی برای کاربر فعال شد' });
      setEditProfile(null);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleExpire = async (profile) => {
    if (!confirm(`پایان اعتبار نسخه پولی ${profile.name}؟`)) return;
    try {
      await expireMut.mutateAsync({
        profile,
        sentByName: _optionalChain([user, 'optionalAccess', _7 => _7.full_name]) || _optionalChain([user, 'optionalAccess', _8 => _8.email]) || 'مدیر سیستم',
      });
      toast({ title: 'منقضی شد', description: 'حساب کاربر به نسخه رایگان بازگشت' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleToggleStatus = async (profile) => {
    try {
      await updateMut.mutateAsync({
        id: profile.id,
        data: { status: profile.status === 'active' ? 'suspended' : 'active' },
      });
      toast({ title: 'تغییر وضعیت', description: profile.status === 'active' ? 'حساب معلق شد' : 'حساب فعال شد' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleSyncFromServer = async () => {
    setSyncing(true);
    try {
      const result = await syncUsersFromServer();
      toast({ title: 'همگام‌سازی شد', description: `${toFa(result.created)} کاربر جدید از سرور اضافه شد` });
      qc.invalidateQueries({ queryKey: ['allSarraafProfiles'] });
      qc.invalidateQueries({ queryKey: ['allCustomersAdmin'] });
    } catch (err) {
      toast({ title: 'خطا', description: err.message || 'همگام‌سازی ناموفق بود', variant: 'destructive' });
    }
    setSyncing(false);
  };

  const planBadge = (p) => {
    const d = getPlanDisplay(p);
    return (
      _jsxDEV('span', { className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium ${d.bg} ${d.color}`, children: [
        d.icon, " " , d.label
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 236}, this)
    );
  };

  const isLoading = loadingSarraaf || loadingCustomer;

  return (
    _jsxDEV('div', { children: [
      _jsxDEV(InviteCodeManager, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 246}, this )
      , _jsxDEV(Card, { children: [
        _jsxDEV(CardContent, { className: "p-4", children: [
        _jsxDEV('div', { className: "flex items-center justify-between mb-3"   , children: [
          _jsxDEV('h3', { className: "text-sm font-semibold flex items-center gap-2"    , children: [
            _jsxDEV(Crown, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 251}, this ), "مدیریت کاربران و اشتراک"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 250}, this)
          , _jsxDEV(Button, { size: "sm", variant: "outline", onClick: handleSyncFromServer, disabled: syncing, children: [
            _jsxDEV(RefreshCw, { className: `w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 255}, this )
            , syncing ? 'در حال همگام‌سازی...' : 'همگام‌سازی از سرور'
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 254}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 249}, this)

        /* Tab switcher: Sarraaf / Customer */
        , _jsxDEV('div', { className: "flex gap-1 p-1 rounded-xl bg-muted mb-3"     , children: [
          _jsxDEV('button', {
            onClick: () => setTab('sarraaf'),
            className: `flex-1 py-2 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${tab === 'sarraaf' ? 'bg-card shadow text-foreground' : 'text-muted-foreground'}`,
 children: [
            _jsxDEV(Store, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 266}, this ), "صراف‌ها ("
             , toFa((profiles || []).length), ")"
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 262}, this)
          , _jsxDEV('button', {
            onClick: () => setTab('customer'),
            className: `flex-1 py-2 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${tab === 'customer' ? 'bg-card shadow text-foreground' : 'text-muted-foreground'}`,
 children: [
            _jsxDEV(Users, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 273}, this ), "مشتریان ("
             , toFa((customers || []).length), ")"
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 269}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 261}, this)

        , _jsxDEV('div', { className: "flex gap-2 mb-3"  , children: [
          _jsxDEV('div', { className: "relative flex-1" , children: [
            _jsxDEV(Search, { className: "absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 280}, this )
            , _jsxDEV(Input, {
              value: search,
              onChange: e => setSearch(e.target.value),
              placeholder: "جستجو نام / کد / تلفن"     ,
              className: "pr-8",}, void 0, false, {fileName: _jsxFileName, lineNumber: 281}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 279}, this)
          , tab === 'sarraaf' && (
            _jsxDEV(Select, { value: filterPlan, onValueChange: setFilterPlan, children: [
              _jsxDEV(SelectTrigger, { className: "w-32", children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 290}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 290}, this)
              , _jsxDEV(SelectContent, { children: [
                _jsxDEV(SelectItem, { value: "all", children: "همه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 292}, this)
                , _jsxDEV(SelectItem, { value: "free", children: "رایگان"}, void 0, false, {fileName: _jsxFileName, lineNumber: 293}, this)
                , _jsxDEV(SelectItem, { value: "paid_active", children: "پولی فعال" }, void 0, false, {fileName: _jsxFileName, lineNumber: 294}, this)
                , _jsxDEV(SelectItem, { value: "paid_expired", children: "منقضی‌شده"}, void 0, false, {fileName: _jsxFileName, lineNumber: 295}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 291}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 289}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 278}, this)

        , isLoading ? (
          _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "در حال بارگذاری..."  }, void 0, false, {fileName: _jsxFileName, lineNumber: 302}, this)
        ) : tab === 'sarraaf' ? (
          filteredSarraaf.length === 0 ? (
            _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "صرافی یافت نشد"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 305}, this)
          ) : (
            _jsxDEV('div', { className: "space-y-2", children: 
              filteredSarraaf.map(p => {
                const usage = usageMap[p.user_id || p.id] || { txCount: 0, msgCount: 0 };
                return (
                  _jsxDEV('div', { className: "p-3 rounded-lg border space-y-2"   , children: [
                    _jsxDEV('div', { className: "flex items-start justify-between gap-2"   , children: 
                      _jsxDEV('div', { className: "min-w-0 flex-1" , children: [
                        _jsxDEV('div', { className: "flex items-center gap-2 flex-wrap"   , children: [
                          _jsxDEV('span', { className: "text-sm font-medium truncate"  , children: p.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 315}, this)
                          , planBadge(p)
                          , p.status === 'suspended' && (
                            _jsxDEV('span', { className: "text-[10px] px-2 py-0.5 rounded-full bg-red-50 text-red-600"     , children: "معلق"}, void 0, false, {fileName: _jsxFileName, lineNumber: 318}, this)
                          )
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 314}, this)
                        , _jsxDEV('div', { className: "flex flex-wrap gap-x-3 gap-y-0.5 mt-1 text-[10px] text-muted-foreground"      , children: [
                          _jsxDEV('span', { children: ["کد: " , p.code]}, void 0, true, {fileName: _jsxFileName, lineNumber: 322}, this)
                          , p.phone && _jsxDEV('span', { children: ["تلفن: " , p.phone]}, void 0, true, {fileName: _jsxFileName, lineNumber: 323}, this)
                          , p.exchange_name && _jsxDEV('span', { children: ["صرافی: " , p.exchange_name]}, void 0, true, {fileName: _jsxFileName, lineNumber: 324}, this)
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 321}, this)
                        , _jsxDEV('div', { className: "flex flex-wrap gap-x-3 gap-y-0.5 mt-0.5 text-[10px] text-muted-foreground"      , children: [
                          _jsxDEV('span', { children: ["سهمیه: " , toFa(p.quota_used), " / "  , toFa(p.quota_limit)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 327}, this)
                          , p.paid_start_date && _jsxDEV('span', { children: ["شروع: " , p.paid_start_date]}, void 0, true, {fileName: _jsxFileName, lineNumber: 328}, this)
                          , p.paid_end_date && _jsxDEV('span', { children: ["پایان: " , p.paid_end_date]}, void 0, true, {fileName: _jsxFileName, lineNumber: 329}, this)
                          , p.last_login && _jsxDEV('span', { children: ["آخرین ورود: "  , new Date(p.last_login).toLocaleDateString('fa-IR')]}, void 0, true, {fileName: _jsxFileName, lineNumber: 330}, this)
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 326}, this)
                        /* Usage stats */
                        , _jsxDEV('div', { className: "flex gap-2 mt-1.5"  , children: [
                          _jsxDEV('span', { className: "inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary"        , children: [
                            _jsxDEV(Activity, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 335}, this )
                            , toFa(usage.txCount), " تراکنش"
                          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 334}, this)
                          , _jsxDEV('span', { className: "inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-blue-50 text-blue-600"        , children: [
                            _jsxDEV(MessageSquare, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 339}, this )
                            , toFa(usage.msgCount), " پیام"
                          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 338}, this)
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 333}, this)
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 313}, this)
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 312}, this)
                    , _jsxDEV('div', { className: "flex gap-1 flex-wrap"  , children: [
                      _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => openActivate(p), children: [
                        _jsxDEV(Crown, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 347}, this ), "ارتقا به پولی"

                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 346}, this)
                      , getPlanStatus(p) !== 'free' && (
                        _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => handleExpire(p), children: [
                          _jsxDEV(Clock, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 352}, this ), "پایان اعتبار"

                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 351}, this)
                      )
                      , _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => handleToggleStatus(p), children: [
                        p.status === 'active' ? _jsxDEV(UserX, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 357}, this ) : _jsxDEV(UserCheck, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 357}, this )
                        , p.status === 'active' ? 'تعلیق' : 'فعال‌سازی'
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 356}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 345}, this)
                  ]}, p.id, true, {fileName: _jsxFileName, lineNumber: 311}, this)
                );
              })
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 307}, this)
          )
        ) : (
          /* Customer list */
          filteredCustomers.length === 0 ? (
            _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "مشتری یافت نشد"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 369}, this)
          ) : (
            _jsxDEV('div', { className: "space-y-2", children: 
              filteredCustomers.map(c => {
                const usage = usageMap[c.id] || { txCount: 0, msgCount: 0 };
                return (
                  _jsxDEV('div', { className: "p-3 rounded-lg border space-y-2"   , children: 
                    _jsxDEV('div', { className: "flex items-start justify-between gap-2"   , children: 
                      _jsxDEV('div', { className: "min-w-0 flex-1" , children: [
                        _jsxDEV('div', { className: "flex items-center gap-2 flex-wrap"   , children: [
                          _jsxDEV('span', { className: "text-sm font-medium truncate"  , children: c.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 379}, this)
                          , _jsxDEV('span', { className: "text-[10px] px-2 py-0.5 rounded-full bg-blue-50 text-blue-600"     , children: "مشتری"}, void 0, false, {fileName: _jsxFileName, lineNumber: 380}, this)
                          , c.status === 'inactive' && (
                            _jsxDEV('span', { className: "text-[10px] px-2 py-0.5 rounded-full bg-red-50 text-red-600"     , children: "غیرفعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 382}, this)
                          )
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 378}, this)
                        , _jsxDEV('div', { className: "flex flex-wrap gap-x-3 gap-y-0.5 mt-1 text-[10px] text-muted-foreground"      , children: [
                          _jsxDEV('span', { children: ["کد: " , c.code || '—']}, void 0, true, {fileName: _jsxFileName, lineNumber: 386}, this)
                          , c.phone && _jsxDEV('span', { children: ["تلفن: " , c.phone]}, void 0, true, {fileName: _jsxFileName, lineNumber: 387}, this)
                          , c.customer_type && _jsxDEV('span', { children: ["نوع: " , c.customer_type === 'permanent' ? 'ثابت' : c.customer_type === 'temporary' ? 'موقت' : 'متفرقه']}, void 0, true, {fileName: _jsxFileName, lineNumber: 388}, this)
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 385}, this)
                        /* Usage stats */
                        , _jsxDEV('div', { className: "flex gap-2 mt-1.5"  , children: [
                          _jsxDEV('span', { className: "inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary"        , children: [
                            _jsxDEV(Activity, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 393}, this )
                            , toFa(usage.txCount), " تراکنش"
                          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 392}, this)
                          , _jsxDEV('span', { className: "inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-blue-50 text-blue-600"        , children: [
                            _jsxDEV(MessageSquare, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 397}, this )
                            , toFa(usage.msgCount), " پیام"
                          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 396}, this)
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 391}, this)
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 377}, this)
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 376}, this)
                  }, c.id, false, {fileName: _jsxFileName, lineNumber: 375}, this)
                );
              })
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 371}, this)
          )
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 248}, this)

      , _jsxDEV(Dialog, { open: !!editProfile, onOpenChange: () => setEditProfile(null), children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: ["فعال‌سازی نسخه پولی — "    , _optionalChain([editProfile, 'optionalAccess', _9 => _9.name])]}, void 0, true, {fileName: _jsxFileName, lineNumber: 413}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 413}, this)
          , _jsxDEV('div', { className: "space-y-3", children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نوع پلن" }, void 0, false, {fileName: _jsxFileName, lineNumber: 416}, this)
              , _jsxDEV(Select, { value: planForm.plan, onValueChange: v => setPlanForm({ ...planForm, plan: v }), children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 418}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 418}, this)
                , _jsxDEV(SelectContent, { children: [
                  _jsxDEV(SelectItem, { value: "basic", children: "پایه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 420}, this)
                  , _jsxDEV(SelectItem, { value: "pro", children: "حرفه‌ای"}, void 0, false, {fileName: _jsxFileName, lineNumber: 421}, this)
                  , _jsxDEV(SelectItem, { value: "special", children: "ویژه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 422}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 419}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 417}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 415}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "تاریخ شروع" }, void 0, false, {fileName: _jsxFileName, lineNumber: 428}, this)
                , _jsxDEV(Input, { type: "date", value: planForm.startDate, onChange: e => setPlanForm({ ...planForm, startDate: e.target.value }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 429}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 427}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "تاریخ پایان" }, void 0, false, {fileName: _jsxFileName, lineNumber: 432}, this)
                , _jsxDEV(Input, { type: "date", value: planForm.endDate, onChange: e => setPlanForm({ ...planForm, endDate: e.target.value }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 433}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 431}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 426}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "مدت اشتراک" }, void 0, false, {fileName: _jsxFileName, lineNumber: 437}, this)
              , _jsxDEV(Select, { value: String(planForm.durationMonths), onValueChange: v => handleDurationChange(parseInt(v)), children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 439}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 439}, this)
                , _jsxDEV(SelectContent, { children: [
                  _jsxDEV(SelectItem, { value: "12", children: "یک ساله" }, void 0, false, {fileName: _jsxFileName, lineNumber: 441}, this)
                  , _jsxDEV(SelectItem, { value: "6", children: "شش ماهه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 442}, this)
                  , _jsxDEV(SelectItem, { value: "3", children: "سه ماهه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 443}, this)
                  , _jsxDEV(SelectItem, { value: "1", children: "یک ماهه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 444}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 440}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 438}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 436}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 414}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setEditProfile(null), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 450}, this)
            , _jsxDEV(Button, { onClick: handleActivate, disabled: activateMut.isPending, children: 
              activateMut.isPending ? 'در حال فعال‌سازی...' : 'فعال‌سازی نسخه پولی'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 451}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 449}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 412}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 411}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 247}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 245}, this)
  );
}