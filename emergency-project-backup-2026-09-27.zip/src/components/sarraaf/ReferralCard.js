const _jsxFileName = "src/components/sarraaf/ReferralCard.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { Card, CardContent } from '../ui/card.js';
import { Switch } from '../ui/switch.js';
import { Button } from '../ui/button.js';
import { useToast } from '../ui/use-toast.js';
import { UserPlus, Gift, Copy, Share2, CheckCircle2, Users } from 'lucide-react';

// هدیه پیام فقط وقتی صراف دعوت‌شده با ایمیل تأیید شود (تقلب ممکن نیست)
const VERIFIED_SARRAAF_BONUS = 100;

export default function ReferralCard({ profile, onToggle, loading }) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const enabled = _optionalChain([profile, 'optionalAccess', _ => _.referral_enabled]) || false;
  const code = _optionalChain([profile, 'optionalAccess', _2 => _2.referral_code]) || _optionalChain([profile, 'optionalAccess', _3 => _3.code]) || '';
  const inviteCount = _optionalChain([profile, 'optionalAccess', _4 => _4.referral_count]) || 0;
  const bonusQuota = _optionalChain([profile, 'optionalAccess', _5 => _5.referral_bonus_quota]) || 0;

  const shareUrl = enabled && code
    ? `${window.location.origin}/register?ref=${code}`
    : '';

  const handleCopy = () => {
    if (!code) return;
    navigator.clipboard.writeText(shareUrl || code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: 'کپی شد', description: 'لینک دعوت کپی شد' });
  };

  const handleShare = async () => {
    if (!shareUrl) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'دعوت به حساب صراف',
          text: 'با کد دعوت من ثبت‌نام کنید و سهمیه بیشتری بگیرید',
          url: shareUrl,
        });
      } catch (e) {
        // کاربر لغو کرد
      }
    } else {
      handleCopy();
    }
  };

  return (
    _jsxDEV(Card, { className: enabled ? 'border-primary/40' : '', children: 
      _jsxDEV(CardContent, { className: "p-4 space-y-4" , children: [
        /* Header with toggle */
        _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
          _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            _jsxDEV('div', { className: "w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center"      , children: 
              _jsxDEV(UserPlus, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('h3', { className: "text-sm font-semibold" , children: "کد دعوت دوستان"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this)
              , _jsxDEV('p', { className: "text-[11px] text-muted-foreground" , children: "با دعوت دوستان سهمیه پیام بگیرید"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 58}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 54}, this)
          , _jsxDEV(Switch, {
            checked: enabled,
            onCheckedChange: (v) => onToggle(v),
            disabled: loading,}, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 53}, this)

        /* When enabled */
        , enabled ? (
          _jsxDEV(_Fragment, { children: [
            /* Referral code */
            _jsxDEV('div', { className: "p-3 rounded-lg bg-muted/50 border border-dashed border-primary/30"     , children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-1"  , children: "کد دعوت شما"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
              , _jsxDEV('div', { className: "flex items-center justify-between gap-2"   , children: [
                _jsxDEV('span', { className: "text-lg font-bold tracking-widest text-primary"   , children: code}, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)
                , _jsxDEV(Button, { size: "sm", variant: "ghost", className: "h-7 px-2" , onClick: handleCopy, children: 
                  copied ? _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-success"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this ) : _jsxDEV(Copy, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 76}, this)
              , shareUrl && (
                _jsxDEV('p', { className: "text-[9px] text-muted-foreground mt-1 break-all"   , children: shareUrl}, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this)
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 74}, this)

            /* Share button */
            , _jsxDEV(Button, { variant: "outline", className: "w-full", onClick: handleShare, children: [
              _jsxDEV(Share2, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this ), "اشتراک‌گذاری لینک دعوت"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 88}, this)

            /* Bonus rule — verified sarraaf referral */
            , _jsxDEV('div', { className: "p-3 rounded-lg bg-success/10 text-center"   , children: [
              _jsxDEV(Gift, { className: "w-5 h-5 mx-auto text-success mb-1"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this )
              , _jsxDEV('p', { className: "text-sm font-bold text-success"  , children: ["+", VERIFIED_SARRAAF_BONUS, " پیام" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 96}, this)
              , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "برای هر صراف دعوت‌شده با ایمیل تأییدشده"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 94}, this)

            /* Stats */
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2 pt-1"   , children: [
              _jsxDEV('div', { className: "text-center", children: [
                _jsxDEV('div', { className: "flex items-center justify-center gap-1 mb-0.5"    , children: [
                  _jsxDEV(Users, { className: "w-3 h-3 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this )
                  , _jsxDEV('span', { className: "text-lg font-bold" , children: inviteCount}, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 103}, this)
                , _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "صرافان دعوت‌شده" }, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 102}, this)
              , _jsxDEV('div', { className: "text-center", children: [
                _jsxDEV('div', { className: "flex items-center justify-center gap-1 mb-0.5"    , children: [
                  _jsxDEV(Gift, { className: "w-3 h-3 text-success"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this )
                  , _jsxDEV('span', { className: "text-lg font-bold text-success"  , children: bonusQuota}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 110}, this)
                , _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "پیام هدیه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 109}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 101}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 72}, this)
        ) : (
          _jsxDEV('div', { className: "text-center py-2" , children: 
            _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: ["کد دعوت غیرفعال است. با فعال کردن، صرافان دیگر را دعوت کنید. برای هر صراف دعوت‌شده که با ایمیل تأیید شود،"


              , _jsxDEV('span', { className: "text-success font-bold" , children: [" +" , VERIFIED_SARRAAF_BONUS, " پیام "  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 123}, this), "هدیه می‌گیرید — چون تأیید با ایمیل است، تقلب ممکن نیست."

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 120}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 51}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this)
  );
}