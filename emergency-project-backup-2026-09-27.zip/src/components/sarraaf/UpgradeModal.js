const _jsxFileName = "src/components/sarraaf/UpgradeModal.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }// UpgradeModal.jsx — Two-path upgrade: invite friends or buy paid plan
import React, { useState } from 'react';
import { usePricingPlans, useDiscountCampaign } from '../../lib/usePricing.js';
import { useActivatePaidPlan } from '../../lib/useAdmin.js';
import { useToggleReferral } from '../../lib/useSarraaf.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog.js';
import { Button } from '../ui/button.js';
import { formatNumber, toPersianDigits } from '../../lib/sarraaf.js';
import { calculateDiscountedPrice, getTimeRemaining } from '../../lib/pricingService.js';
import { Check, Crown, Sparkles, X, Clock, UserPlus, Gift, ArrowRight } from 'lucide-react';

const PLAN_ICONS = { basic: Crown, pro: Sparkles, special: Crown };
const PLAN_GRADIENTS = {
  basic: 'from-blue-500 to-blue-600',
  pro: 'from-purple-500 to-purple-600',
  special: 'from-amber-500 to-amber-600',
};

const VERIFIED_SARRAAF_BONUS = 100;

// Feature hints: what each section unlocks in paid plans
const FEATURE_HINTS = {
  customers: { title: 'مشتریان نامحدود', desc: 'افزودن مشتریان نامحدود به‌جای سقف رایگان' },
  transfer: { title: 'حواله نامحدود', desc: 'ثبت حواله روزانه نامحدود' },
  trade: { title: 'معاملات نامحدود', desc: 'خرید و فروش بدون محدودیت ماهانه' },
  backup: { title: 'بکاپ ابری', desc: 'بکاپ‌گیری ابری و بازیابی داده‌ها' },
  reports: { title: 'گزارش‌های پیشرفته', desc: 'گزارش‌های کامل مالی و عملیاتی' },
  chat: { title: 'چت صراف‌ها', desc: 'دسترسی به بازار نرخ و چت صراف‌با‌صراف' },
  default: { title: 'ویژگی‌های ویژه', desc: 'محدودیت‌های طرح رایگان را بردارید' },
};

function CountdownTimer({ endDate }) {
  const [time, setTime] = useState(() => getTimeRemaining(endDate));
  React.useEffect(() => {
    const t = setInterval(() => setTime(getTimeRemaining(endDate)), 1000);
    return () => clearInterval(t);
  }, [endDate]);
  if (!time || time.expired) return null;
  return (
    _jsxDEV('div', { className: "flex items-center gap-1 text-xs font-bold text-red-600"     , children: [
      _jsxDEV(Clock, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this )
      , _jsxDEV('span', { children: [toPersianDigits(String(time.hours).padStart(2, '0')), ":", toPersianDigits(String(time.minutes).padStart(2, '0')), ":", toPersianDigits(String(time.seconds).padStart(2, '0'))]}, void 0, true, {fileName: _jsxFileName, lineNumber: 42}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 40}, this)
  );
}

export default function UpgradeModal({ open, onClose, profile, featureHint }) {
  const { data: plans } = usePricingPlans();
  const { data: campaign } = useDiscountCampaign();
  const activateMut = useActivatePaidPlan();
  const toggleMut = useToggleReferral();
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [tab, setTab] = useState('paths'); // 'paths' | 'plans' | 'referral'

  const hint = FEATURE_HINTS[featureHint] || FEATURE_HINTS.default;

  const handleUpgrade = (plan) => {
    setSelectedPlan(plan.plan_key);
    const startDate = new Date().toISOString().split('T')[0];
    const endDate = new Date(Date.now() + plan.duration_months * 30 * 24 * 3600 * 1000).toISOString().split('T')[0];
    activateMut.mutate(
      { profile, plan: plan.plan_key, startDate, endDate, confirmedByName: _optionalChain([profile, 'optionalAccess', _ => _.name]) || 'صراف' },
      { onSuccess: () => onClose() }
    );
  };

  const handleToggleReferral = (enabled) => {
    toggleMut.mutate({ profileId: profile.id, enabled });
  };

  const referralEnabled = _optionalChain([profile, 'optionalAccess', _2 => _2.referral_enabled]) || false;
  const referralCode = _optionalChain([profile, 'optionalAccess', _3 => _3.referral_code]) || _optionalChain([profile, 'optionalAccess', _4 => _4.code]) || '';
  const shareUrl = referralEnabled && referralCode
    ? `${window.location.origin}/register?ref=${referralCode}`
    : '';

  return (
    _jsxDEV(Dialog, { open: open, onOpenChange: (o) => !o && onClose(), children: 
      _jsxDEV(DialogContent, { className: "max-w-md max-h-[85vh] overflow-y-auto scrollbar-thin"   , children: [
        _jsxDEV(DialogHeader, { children: 
          _jsxDEV(DialogTitle, { className: "flex items-center justify-between"  , children: [
            _jsxDEV('span', { children: "ارتقای حساب" }, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this)
            , _jsxDEV('button', { onClick: onClose, className: "p-1 rounded hover:bg-muted"  , children: 
              _jsxDEV(X, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 81}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)

        /* Feature hint banner */
        , featureHint && (
          _jsxDEV('div', { className: "rounded-lg bg-primary/10 border border-primary/20 p-3 text-center"     , children: [
            _jsxDEV('p', { className: "text-sm font-bold text-primary"  , children: hint.title}, void 0, false, {fileName: _jsxFileName, lineNumber: 92}, this)
            , _jsxDEV('p', { className: "text-[11px] text-muted-foreground" , children: hint.desc}, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 91}, this)
        )

        /* Paths view */
        , tab === 'paths' && (
          _jsxDEV('div', { className: "space-y-3", children: [
            _jsxDEV('button', {
              onClick: () => setTab('plans'),
              className: "w-full text-right rounded-xl border-2 border-border p-4 hover:border-primary transition-colors"       ,
 children: 
              _jsxDEV('div', { className: "flex items-center gap-3"  , children: [
                _jsxDEV('div', { className: "w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center"        , children: 
                  _jsxDEV(Crown, { className: "w-5 h-5 text-white"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this)
                , _jsxDEV('div', { className: "flex-1", children: [
                  _jsxDEV('p', { className: "text-sm font-bold" , children: "ارتقا به نسخه پولی"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this)
                  , _jsxDEV('p', { className: "text-[11px] text-muted-foreground" , children: "پلن‌های پایه، حرفه‌ای و ویژه"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 108}, this)
                , _jsxDEV(ArrowRight, { className: "w-4 h-4 text-muted-foreground rotate-180"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 104}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 100}, this)

            , _jsxDEV('button', {
              onClick: () => setTab('referral'),
              className: "w-full text-right rounded-xl border-2 border-border p-4 hover:border-success transition-colors"       ,
 children: 
              _jsxDEV('div', { className: "flex items-center gap-3"  , children: [
                _jsxDEV('div', { className: "w-10 h-10 rounded-lg bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center"        , children: 
                  _jsxDEV(UserPlus, { className: "w-5 h-5 text-white"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this)
                , _jsxDEV('div', { className: "flex-1", children: [
                  _jsxDEV('p', { className: "text-sm font-bold" , children: "دعوت دوستان صراف"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this)
                  , _jsxDEV('p', { className: "text-[11px] text-muted-foreground" , children: ["برای هر صراف تأییدشده +"    , VERIFIED_SARRAAF_BONUS, " پیام" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 126}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 124}, this)
                , _jsxDEV(ArrowRight, { className: "w-4 h-4 text-muted-foreground rotate-180"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 128}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 120}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 99}, this)
        )

        /* Paid plans view */
        , tab === 'plans' && (
          _jsxDEV('div', { className: "space-y-2", children: [
            _jsxDEV('button', { onClick: () => setTab('paths'), className: "text-xs text-muted-foreground mb-2 flex items-center gap-1"     , children: [
              _jsxDEV(ArrowRight, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this ), " بازگشت"
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 137}, this)

            , campaign && !campaign.expired && campaign.active && (
              _jsxDEV('div', { className: "rounded-lg bg-gradient-to-r from-red-500 to-orange-500 text-white p-3 text-center space-y-1"       , children: [
                _jsxDEV('p', { className: "text-sm font-bold" , children: ["🎉 تخفیف "  , toPersianDigits(campaign.percent), "٪ ویژه!" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 143}, this)
                , _jsxDEV('p', { className: "text-[10px] opacity-90" , children: "روی تمام پلن‌های پولی"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this)
                , _jsxDEV(CountdownTimer, { endDate: campaign.end_date,}, void 0, false, {fileName: _jsxFileName, lineNumber: 145}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)
            )

            , (plans || []).map(plan => {
              const Icon = PLAN_ICONS[plan.plan_key] || Crown;
              const pricing = calculateDiscountedPrice(plan.price, campaign);
              const isSelected = selectedPlan === plan.plan_key;
              return (
                _jsxDEV('div', { className: `rounded-xl border-2 p-3 transition-all ${isSelected ? 'border-primary shadow-md' : 'border-border'}`, children: [
                  _jsxDEV('div', { className: "flex items-center gap-2 mb-2"   , children: [
                    _jsxDEV('div', { className: `w-8 h-8 rounded-lg bg-gradient-to-br ${PLAN_GRADIENTS[plan.plan_key] || 'from-blue-500 to-blue-600'} flex items-center justify-center`, children: 
                      _jsxDEV(Icon, { className: "w-4 h-4 text-white"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this)
                    , _jsxDEV('div', { className: "flex-1", children: [
                      _jsxDEV('p', { className: "text-sm font-bold" , children: plan.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this)
                      , plan.description && _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: plan.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 161}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 159}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 155}, this)

                  , _jsxDEV('div', { className: "flex items-center gap-2 mb-2"   , children: [
                    pricing.discounted ? (
                      _jsxDEV(_Fragment, { children: [
                        _jsxDEV('span', { className: "text-lg font-bold text-primary"  , children: formatNumber(pricing.final)}, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this)
                        , _jsxDEV('span', { className: "text-sm text-muted-foreground line-through"  , children: formatNumber(plan.price)}, void 0, false, {fileName: _jsxFileName, lineNumber: 169}, this)
                        , _jsxDEV('span', { className: "text-[10px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded-full font-bold"      , children: [toPersianDigits(pricing.percent), "٪ تخفیف" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 170}, this)
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 167}, this)
                    ) : (
                      _jsxDEV('span', { className: "text-lg font-bold text-primary"  , children: formatNumber(plan.price)}, void 0, false, {fileName: _jsxFileName, lineNumber: 173}, this)
                    )
                    , _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: "افغانی / ماه"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 175}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 165}, this)

                  , _jsxDEV('ul', { className: "space-y-1 mb-3" , children: 
                    (plan.features || []).map((feat, i) => (
                      _jsxDEV('li', { className: "flex items-center gap-1.5 text-[11px]"   , children: [
                        _jsxDEV(Check, { className: "w-3 h-3 text-green-600 shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 181}, this )
                        , _jsxDEV('span', { children: feat}, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this)
                      ]}, i, true, {fileName: _jsxFileName, lineNumber: 180}, this)
                    ))
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this)

                  , _jsxDEV(Button, { className: "w-full", size: "sm", disabled: activateMut.isPending && isSelected, onClick: () => handleUpgrade(plan), children: 
                    activateMut.isPending && isSelected ? 'در حال فعال‌سازی...' : `ارتقا به ${plan.name}`
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this)
                ]}, plan.id, true, {fileName: _jsxFileName, lineNumber: 154}, this)
              );
            })
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 136}, this)
        )

        /* Referral view */
        , tab === 'referral' && (
          _jsxDEV('div', { className: "space-y-3", children: [
            _jsxDEV('button', { onClick: () => setTab('paths'), className: "text-xs text-muted-foreground mb-2 flex items-center gap-1"     , children: [
              _jsxDEV(ArrowRight, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 200}, this ), " بازگشت"
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 199}, this)

            , _jsxDEV('div', { className: "rounded-xl border-2 border-border p-4 space-y-3"    , children: [
              _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
                _jsxDEV('span', { className: "text-sm font-semibold" , children: "فعال‌سازی دعوت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 205}, this)
                , _jsxDEV('button', {
                  onClick: () => handleToggleReferral(!referralEnabled),
                  disabled: toggleMut.isPending,
                  className: `relative w-11 h-6 rounded-full transition-colors ${referralEnabled ? 'bg-success' : 'bg-muted'}`,
 children: 
                  _jsxDEV('span', { className: `absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${referralEnabled ? 'right-0.5' : 'right-5'}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 211}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 206}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 204}, this)

              , referralEnabled ? (
                _jsxDEV(_Fragment, { children: [
                  _jsxDEV('div', { className: "rounded-lg bg-muted p-3 text-center"   , children: [
                    _jsxDEV('p', { className: "text-[10px] text-muted-foreground mb-1"  , children: "کد دعوت شما"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 218}, this)
                    , _jsxDEV('p', { className: "text-lg font-bold tracking-wider text-primary"   , children: referralCode}, void 0, false, {fileName: _jsxFileName, lineNumber: 219}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 217}, this)
                  , _jsxDEV('div', { className: "grid grid-cols-2 gap-2 text-center"   , children: [
                    _jsxDEV('div', { className: "p-2 rounded-lg bg-muted"  , children: [
                      _jsxDEV('p', { className: "text-base font-bold" , children: _optionalChain([profile, 'optionalAccess', _5 => _5.referral_count]) || 0}, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this)
                      , _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "صرافان دعوت‌شده" }, void 0, false, {fileName: _jsxFileName, lineNumber: 224}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 222}, this)
                    , _jsxDEV('div', { className: "p-2 rounded-lg bg-muted"  , children: [
                      _jsxDEV('p', { className: "text-base font-bold text-success"  , children: _optionalChain([profile, 'optionalAccess', _6 => _6.referral_bonus_quota]) || 0}, void 0, false, {fileName: _jsxFileName, lineNumber: 227}, this)
                      , _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "پیام هدیه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 228}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 226}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 221}, this)
                  , shareUrl && (
                    _jsxDEV(Button, {
                      className: "w-full",
                      size: "sm",
                      onClick: () => {
                        _optionalChain([navigator, 'access', _7 => _7.clipboard, 'optionalAccess', _8 => _8.writeText, 'call', _9 => _9(shareUrl)]);
                      },
 children: [
                      _jsxDEV(Gift, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 239}, this ), " کپی لینک دعوت"
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 232}, this)
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 216}, this)
              ) : (
                _jsxDEV('p', { className: "text-xs text-muted-foreground text-center py-2"   , children: ["با فعال کردن، صرافان دیگر را دعوت کنید. برای هر صراف دعوت‌شده با ایمیل تأییدشده،"

                  , _jsxDEV('span', { className: "text-success font-bold" , children: [" +" , VERIFIED_SARRAAF_BONUS, " پیام "  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 246}, this), "هدیه می‌گیرید."

                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 244}, this)
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 203}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 198}, this)
        )

        , _jsxDEV('p', { className: "text-[10px] text-center text-muted-foreground mt-2"   , children: "پس از ارتقا یا دعوت، سهمیه شما به‌صورت خودکار به‌روزرسانی می‌شود."

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 254}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 79}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this)
  );
}