const _jsxFileName = "src/components/sarraaf/BankGatewayManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { useFeatures } from '../../lib/useSarraaf.js';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Label } from '../ui/label.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select.js';
import { Switch } from '../ui/switch.js';
import { Badge } from '../ui/badge.js';
import { CreditCard, Plus, Lock, AlertCircle, Shield } from 'lucide-react';
import { toast } from '../ui/use-toast.js';
import { AmountInput } from './Fields.js';

const PROVIDERS = [
  { value: 'bank_gateway', label: 'درگاه بانکی' },
  { value: 'stripe', label: 'Stripe' },
  { value: 'paypal', label: 'PayPal' },
  { value: 'crypto', label: 'ارز دیجیتال' },
  { value: 'other', label: 'سایر' },
];

const STATUS_LABELS = {
  pending: 'در انتظار',
  configured: 'پیکربندی شده',
  active: 'فعال',
  disabled: 'غیرفعال',
};

const STATUS_COLORS = {
  pending: 'bg-muted text-muted-foreground',
  configured: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  active: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
  disabled: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
};

export default function BankGatewayManager() {
  const { data: features } = useFeatures();
  const [gateways, setGateways] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    gateway_key: '',
    name: '',
    provider: 'bank_gateway',
    currency: 'AFN',
    merchant_id: '',
    callback_url: '',
    webhook_url: '',
    min_amount: 0,
    max_amount: 0,
    fee_percent: 0,
    fee_fixed: 0,
    test_mode: true,
    notes: '',
  });

  useEffect(() => {
    loadGateways();
  }, []);

  const loadGateways = async () => {
    setLoading(true);
    try {
      const { supabaseDB } = await import('../../lib/supabaseDB.js');
      const data = await supabaseDB.BankGateway.list();
      setGateways(data || []);
    } catch (e2) {
      setGateways([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!form.gateway_key || !form.name) {
      toast({ title: 'خطا', description: 'شناسه و نام درگاه الزامی است', variant: 'destructive' });
      return;
    }
    try {
      const { supabaseDB } = await import('../../lib/supabaseDB.js');
      await supabaseDB.BankGateway.create({
        ...form,
        active: false,
        status: 'configured',
      });
      toast({ title: 'موفق', description: 'تنظیمات درگاه ذخیره شد (غیرفعال)' });
      setShowForm(false);
      setForm({
        gateway_key: '', name: '', provider: 'bank_gateway', currency: 'AFN',
        merchant_id: '', callback_url: '', webhook_url: '',
        min_amount: 0, max_amount: 0, fee_percent: 0, fee_fixed: 0,
        test_mode: true, notes: '',
      });
      loadGateways();
    } catch (err) {
      toast({ title: 'خطا', description: 'خطا در ذخیره تنظیمات', variant: 'destructive' });
    }
  };

  const toggleGateway = async (gw) => {
    try {
      const { supabaseDB } = await import('../../lib/supabaseDB.js');
      await supabaseDB.BankGateway.update(gw.id, { active: !gw.active });
      toast({ title: 'موفق', description: gw.active ? 'درگاه غیرفعال شد' : 'درگاه فعال شد' });
      loadGateways();
    } catch (e3) {
      toast({ title: 'خطا', description: 'خطا در تغییر وضعیت', variant: 'destructive' });
    }
  };

  return (
    _jsxDEV('div', { className: "space-y-3", children: [
      /* Security notice */
      _jsxDEV('div', { className: "flex items-start gap-2 p-2.5 rounded-lg bg-blue-50 dark:bg-blue-900/10 text-blue-700 dark:text-blue-400 text-xs"         , children: [
        _jsxDEV(Shield, { className: "w-4 h-4 shrink-0 mt-0.5"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this )
        , _jsxDEV('p', { children: "کلیدهای محرمانه بانکی هرگز در دیتابیس ذخیره نمی‌شوند. فقط مرجع آن‌ها ثبت می‌گردد."            }, void 0, false, {fileName: _jsxFileName, lineNumber: 117}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 115}, this)

      /* Existing gateways */
      , loading ? (
        _jsxDEV('p', { className: "text-xs text-muted-foreground text-center py-4"   , children: "در حال بارگذاری..."  }, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this)
      ) : gateways.length === 0 ? (
        _jsxDEV('div', { className: "text-center py-6" , children: [
          _jsxDEV(CreditCard, { className: "w-8 h-8 mx-auto text-muted-foreground/50 mb-2"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this )
          , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "هنوز درگاهی پیکربندی نشده است"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 124}, this)
      ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          gateways.map(gw => (
            _jsxDEV('div', { className: "flex items-center justify-between p-2.5 rounded-lg border"     , children: [
              _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
                _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
                  _jsxDEV('span', { className: "text-sm font-medium truncate"  , children: gw.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 134}, this)
                  , _jsxDEV('span', { className: `text-[10px] font-bold px-1.5 py-0.5 rounded-full ${STATUS_COLORS[gw.status] || ''}`, children: 
                    STATUS_LABELS[gw.status] || gw.status
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 133}, this)
                , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: [
                  _optionalChain([PROVIDERS, 'access', _ => _.find, 'call', _2 => _2(p => p.value === gw.provider), 'optionalAccess', _3 => _3.label]) || gw.provider, " • "  , gw.currency
                  , gw.test_mode && ' • تست'
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 139}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 132}, this)
              , _jsxDEV(Switch, {
                checked: gw.active,
                onCheckedChange: () => toggleGateway(gw),}, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this
              )
            ]}, gw.id, true, {fileName: _jsxFileName, lineNumber: 131}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this)
      )

      /* Add gateway form */
      , showForm ? (
        _jsxDEV('form', { onSubmit: handleSave, className: "space-y-2.5 p-3 rounded-lg border bg-muted/20"    , children: [
          _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "شناسه درگاه *"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this)
              , _jsxDEV(Input, { value: form.gateway_key, onChange: e => setForm({ ...form, gateway_key: e.target.value }), placeholder: "bank_afghanistan", required: true, className: "text-xs h-8" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 157}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "نام *" }, void 0, false, {fileName: _jsxFileName, lineNumber: 162}, this)
              , _jsxDEV(Input, { value: form.name, onChange: e => setForm({ ...form, name: e.target.value }), placeholder: "بانک افغانستان" , required: true, className: "text-xs h-8" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 161}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 156}, this)
          , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "نوع درگاه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this)
              , _jsxDEV(Select, { value: form.provider, onValueChange: v => setForm({ ...form, provider: v }), children: [
                _jsxDEV(SelectTrigger, { className: "h-8 text-xs" , children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 170}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 170}, this)
                , _jsxDEV(SelectContent, { children: PROVIDERS.map(p => _jsxDEV(SelectItem, { value: p.value, children: p.label}, p.value, false, {fileName: _jsxFileName, lineNumber: 171}, this))}, void 0, false, {fileName: _jsxFileName, lineNumber: 171}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 169}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 167}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "ارز"}, void 0, false, {fileName: _jsxFileName, lineNumber: 175}, this)
              , _jsxDEV(Select, { value: form.currency, onValueChange: v => setForm({ ...form, currency: v }), children: [
                _jsxDEV(SelectTrigger, { className: "h-8 text-xs" , children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 177}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 177}, this)
                , _jsxDEV(SelectContent, { children: [
                  _jsxDEV(SelectItem, { value: "AFN", children: "AFN"}, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this)
                  , _jsxDEV(SelectItem, { value: "USD", children: "USD"}, void 0, false, {fileName: _jsxFileName, lineNumber: 180}, this)
                  , _jsxDEV(SelectItem, { value: "IRT", children: "IRT"}, void 0, false, {fileName: _jsxFileName, lineNumber: 181}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 178}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 176}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 174}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 166}, this)
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "شناسه پذیرنده" }, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this)
            , _jsxDEV(Input, { value: form.merchant_id, onChange: e => setForm({ ...form, merchant_id: e.target.value }), placeholder: "merchant-xxx", className: "text-xs h-8" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 188}, this )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 186}, this)
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "آدرس بازگشت (Callback URL)"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 191}, this)
            , _jsxDEV(Input, { value: form.callback_url, onChange: e => setForm({ ...form, callback_url: e.target.value }), placeholder: "https://...", className: "text-xs h-8" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 192}, this )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 190}, this)
          , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "حداقل مبلغ" }, void 0, false, {fileName: _jsxFileName, lineNumber: 196}, this)
              , _jsxDEV(AmountInput, { value: form.min_amount, onChange: v => setForm({ ...form, min_amount: v }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 197}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 195}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "حداکثر مبلغ" }, void 0, false, {fileName: _jsxFileName, lineNumber: 200}, this)
              , _jsxDEV(AmountInput, { value: form.max_amount, onChange: v => setForm({ ...form, max_amount: v }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 201}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 199}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 194}, this)
          , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "کارمزد درصدی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 206}, this)
              , _jsxDEV(AmountInput, { value: form.fee_percent, onChange: v => setForm({ ...form, fee_percent: v }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 207}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 205}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "کارمزد ثابت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 210}, this)
              , _jsxDEV(AmountInput, { value: form.fee_fixed, onChange: v => setForm({ ...form, fee_fixed: v }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 211}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 209}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 204}, this)
          , _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            _jsxDEV(Switch, { checked: form.test_mode, onCheckedChange: v => setForm({ ...form, test_mode: v }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 215}, this )
            , _jsxDEV(Label, { className: "text-xs", children: "حالت آزمایشی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 216}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 214}, this)
          , _jsxDEV('div', { className: "flex items-start gap-1.5 text-[10px] text-muted-foreground"    , children: [
            _jsxDEV(Lock, { className: "w-3 h-3 mt-0.5 shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 219}, this )
            , _jsxDEV('p', { children: "کلید محرمانه (Secret Key) به‌صورت امن در Secret Manager ذخیره می‌شود و در اینجا نمایش داده نمی‌شود."                }, void 0, false, {fileName: _jsxFileName, lineNumber: 220}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 218}, this)
          , _jsxDEV('div', { className: "flex gap-2 pt-1"  , children: [
            _jsxDEV(Button, { type: "submit", size: "sm", className: "text-xs", children: "ذخیره تنظیمات" }, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this)
            , _jsxDEV(Button, { type: "button", size: "sm", variant: "outline", onClick: () => setShowForm(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 224}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 222}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 155}, this)
      ) : (
        _jsxDEV(Button, { size: "sm", variant: "outline", className: "w-full", onClick: () => setShowForm(true), children: [
          _jsxDEV(Plus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 229}, this ), " افزودن درگاه"
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 228}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 113}, this)
  );
}