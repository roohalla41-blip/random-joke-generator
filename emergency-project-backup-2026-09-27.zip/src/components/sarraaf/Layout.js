const _jsxFileName = "src/components/sarraaf/Layout.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext.js';
import { useFeatures, useSarraafProfile } from '../../lib/useSarraaf.js';
import { visibleNavItems } from '../../lib/features.js';
import { shouldExpirePaidPlan } from '../../lib/permissions.js';
import { callSupabase } from '../../lib/supabaseApi.js';
import { useUpgrade } from '../../lib/UpgradeContext.js';
import SyncIndicator from '../SyncIndicator.js';
import { Crown } from 'lucide-react';
import { cn } from '../../lib/utils.js';
import {
  LayoutDashboard, Users, ArrowLeftRight, Repeat, Send, Download,
  Banknote, Landmark, Coins, FileText, TrendingUp, Settings, Shield,
  Network, Share2, BookOpen, BookCopy, ScrollText, ArrowRightLeft,
  ShoppingBag, Search, MoreVertical, X, MessageSquare, Wallet, Bell,
  Store, MessageSquareMore, DatabaseBackup, Copy, Headphones, CreditCard
} from 'lucide-react';
import { getAllowedNavItems, isManagementRole } from '../../lib/rbac.js';
import ExchangeMark from '../ExchangeMark.js';
import TermsGate from '../TermsGate.js';

const NAV_ITEMS = [
  { featureKey: 'dashboard', label: 'داشبورد', path: '/dashboard', icon: LayoutDashboard, order: 0 },
  { featureKey: 'customers', label: 'مشتریان', path: '/customers', icon: Users, order: 1 },
  { featureKey: 'dadogereft', label: 'داد و گرفت', path: '/dadogereft', icon: ArrowLeftRight, order: 2 },
  { featureKey: 'trade', label: 'خرید/فروش', path: '/trade', icon: Repeat, order: 3 },
  { featureKey: 'transfer_send', label: 'حواله ارسال', path: '/transfers/send', icon: Send, order: 4 },
  { featureKey: 'transfer_receive', label: 'حواله دریافت', path: '/transfers/receive', icon: Download, order: 5 },
  { featureKey: 'cash', label: 'صندوق', path: '/cash', icon: Banknote, order: 6 },
  { featureKey: 'bank', label: 'بانک', path: '/bank', icon: Landmark, order: 7 },
  { featureKey: 'currencies', label: 'ارز و نرخ', path: '/currencies', icon: Coins, order: 8 },
  { featureKey: 'reports', label: 'گزارش‌ها', path: '/reports', icon: FileText, order: 9 },
  { featureKey: 'profit_loss', label: 'سود و زیان', path: '/profit-loss', icon: TrendingUp, order: 10 },
  { featureKey: 'debtors', label: 'بدهکاران', path: '/debtors', icon: Wallet, order: 12 },
  { featureKey: 'agents', label: 'نمایندگی‌ها', path: '/agents', icon: Network, order: 13 },
  { featureKey: 'agency_network', label: 'شبکه نمایندگی', path: '/agency-network', icon: Share2, order: 14 },
  { featureKey: 'transfer_book', label: 'دفتر حواله', path: '/transfer-book', icon: BookOpen, order: 15 },
  { featureKey: 'journal', label: 'دفتر روزنامه', path: '/journal', icon: BookCopy, order: 16 },
  { featureKey: 'general_ledger', label: 'دفتر کل', path: '/general-ledger', icon: ScrollText, order: 17 },
  { featureKey: 'convert', label: 'تبدیل ارز', path: '/convert', icon: ArrowRightLeft, order: 18 },
  { featureKey: 'online_products', label: 'محصولات آنلاین', path: '/online-products', icon: ShoppingBag, order: 19 },
  { featureKey: 'payment_gateway', label: 'درگاه پرداخت', path: '/payment-gateway', icon: CreditCard, order: 19.5 },
  { featureKey: 'settings', label: 'تنظیمات', path: '/settings', icon: Settings, order: 11 },
  { featureKey: 'sarraaf_market', label: 'بازار نرخ', path: '/sarraaf-market', icon: Store, order: 20 },
  { featureKey: 'sarraaf_chat', label: 'چت صراف‌ها', path: '/sarraaf-chat', icon: MessageSquareMore, order: 21 },
  { featureKey: 'chat_groups', label: 'چت و گروه‌ها', path: '/chat', icon: MessageSquare, order: 22 },
  { featureKey: 'backup', label: 'بکاپ و بازیابی', path: '/backup', icon: DatabaseBackup, order: 23 },
  { featureKey: 'support', label: 'پشتیبانی آنلاین', path: '/support', icon: Headphones, order: 24 },
];

const BOTTOM_NAV = [
  { featureKey: 'dashboard', label: 'خانه', path: '/dashboard', icon: LayoutDashboard },
  { featureKey: 'customers', label: 'مشتریان', path: '/customers', icon: Users },
  { featureKey: 'trade', label: 'خرید/فروش', path: '/trade', icon: Repeat },
  { featureKey: 'transfer_book', label: 'حواله', path: '/transfer-book', icon: BookOpen },
  { featureKey: 'settings', label: 'تنظیمات', path: '/settings', icon: Settings },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const { data: features } = useFeatures();
  const { data: profile } = useSarraafProfile(_optionalChain([user, 'optionalAccess', _ => _.id]));
  const [moreOpen, setMoreOpen] = useState(false);
  const { openUpgrade } = useUpgrade();

  const userRole = _optionalChain([user, 'optionalAccess', _2 => _2.role]) || 'user';
  const featureFiltered = visibleNavItems(features || [], NAV_ITEMS, profile || user);
  const items = getAllowedNavItems(userRole, featureFiltered);
  const bottomItems = items.filter(i => BOTTOM_NAV.some(b => b.featureKey === i.featureKey));
  const bottomPaths = new Set(BOTTOM_NAV.map(b => b.featureKey));
  const moreItems = items.filter(i => !bottomPaths.has(i.featureKey));

  // Auto-expire paid plan if end date has passed
  useEffect(() => {
    if (!profile) return;
    if (shouldExpirePaidPlan(profile)) {
      callSupabase('crud', {
        table: 'exchanges',
        operation: 'update',
        id: String(profile.id),
        data: { plan: 'free', payment_status: 'expired' },
      }).catch((err) => console.error('Failed to expire paid plan:', err.message));
    }
  }, [_optionalChain([profile, 'optionalAccess', _3 => _3.id]), _optionalChain([profile, 'optionalAccess', _4 => _4.plan]), _optionalChain([profile, 'optionalAccess', _5 => _5.paid_end_date])]);

  const handleLogout = () => {
    logout();
  };

  return (
    _jsxDEV(TermsGate, { role: userRole, children: 
    _jsxDEV('div', { className: "min-h-screen bg-background flex"  , children: [
      /* Desktop Sidebar */
      _jsxDEV('aside', { className: "hidden lg:flex w-64 flex-col border-l bg-sidebar border-sidebar-border shrink-0"       , children: [
        _jsxDEV('div', { className: "p-4 border-b border-sidebar-border"  , children: 
          _jsxDEV('div', { className: "flex items-center justify-between gap-2"   , children: [
            _jsxDEV('div', { className: "flex items-center gap-2 min-w-0"   , children: [
              _jsxDEV('div', { className: "shrink-0", children: 
                _jsxDEV(ExchangeMark, { size: "sm",}, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this)
              , _jsxDEV('div', { className: "min-w-0", children: [
                _jsxDEV('p', { className: "text-sm font-bold truncate"  , children: _optionalChain([profile, 'optionalAccess', _6 => _6.exchange_name]) || _optionalChain([profile, 'optionalAccess', _7 => _7.name]) || 'حساب صراف'}, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this)
                , _optionalChain([profile, 'optionalAccess', _8 => _8.code]) && (
                  _jsxDEV('div', { className: "flex items-center gap-1"  , children: [
                    _jsxDEV('p', { className: "text-xs text-muted-foreground tracking-wider truncate"   , dir: "ltr", children: profile.code}, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this)
                    , _jsxDEV('button', {
                      onClick: () => {
                        _optionalChain([navigator, 'access', _9 => _9.clipboard, 'optionalAccess', _10 => _10.writeText, 'call', _11 => _11(profile.code)]);
                      },
                      className: "p-0.5 rounded text-muted-foreground hover:text-primary transition-colors shrink-0"     ,
 children: 
                      _jsxDEV(Copy, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 107}, this)
                )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 104}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 100}, this)
            , _jsxDEV('div', { className: "flex items-center gap-1 shrink-0"   , children: [
              _jsxDEV(SyncIndicator, { compact: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this )
              , _jsxDEV(Link, { to: "/online-products", className: "p-1.5 rounded-lg text-muted-foreground hover:bg-sidebar-accent transition-colors"    , children: 
                _jsxDEV(ShoppingBag, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 123}, this)
              , _jsxDEV(Link, { to: "/notifications", className: "p-1.5 rounded-lg text-muted-foreground hover:bg-sidebar-accent transition-colors"    , children: 
                _jsxDEV(Bell, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this)
              , _jsxDEV('button', { onClick: () => openUpgrade(), className: "p-1.5 rounded-lg text-primary hover:bg-primary/10 transition-colors"    , children: 
                _jsxDEV(Crown, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this)
              , isManagementRole(userRole) && (
                _jsxDEV(_Fragment, { children: [
                  _jsxDEV(Link, { to: userRole === 'creator' ? '/builder' : '/dashboard', className: "p-1.5 rounded-lg text-primary hover:bg-primary/10 transition-colors"    , children: 
                    _jsxDEV(Shield, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 134}, this)
                  , userRole === 'creator' && (
                    _jsxDEV(Link, { to: "/main-settings", className: "p-1.5 rounded-lg text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"     , children: 
                      _jsxDEV(Settings, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 133}, this)
              )
              , _jsxDEV('button', { onClick: handleLogout, className: "p-1.5 rounded-lg text-destructive hover:bg-destructive/10 transition-colors"    , children: 
                _jsxDEV(X, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 145}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 121}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 99}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)

        , _jsxDEV('div', { className: "px-3 py-2 border-b border-sidebar-border"   , children: 
          _jsxDEV('div', { className: "relative", children: [
            _jsxDEV(Search, { className: "absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 153}, this )
            , _jsxDEV('input', {
            type: "text",
            placeholder: "جستجو...",
            className: "w-full pr-8 pl-3 py-1.5 text-sm rounded-lg bg-muted border border-transparent focus:border-primary outline-none"          ,
            onFocus: () => navigate('/customers'),}, void 0, false, {fileName: _jsxFileName, lineNumber: 154}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 152}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this)

        , _jsxDEV('nav', { className: "flex-1 overflow-y-auto scrollbar-thin py-2"   , children: 
          items.map(item => {
            const Icon = item.icon;
            const active = location.pathname === item.path || location.pathname.startsWith(item.path + '/');
            return (
              _jsxDEV(Link, {

                to: item.path,
                className: cn(
                  'flex items-center gap-2 px-4 py-2.5 text-sm transition-colors',
                  active
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground font-medium border-r-2 border-sidebar-primary'
                    : 'text-sidebar-foreground/80 hover:bg-sidebar-accent/50'
                ),
 children: [
                _jsxDEV(Icon, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this )
                , _jsxDEV('span', { className: "truncate", children: item.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this)
              ]}, item.featureKey, true, {fileName: _jsxFileName, lineNumber: 168}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this)

        , _jsxDEV('div', { className: "p-3 border-t border-sidebar-border"  , children: 
          _jsxDEV(SyncIndicator, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 186}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 185}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 97}, this)

      /* Main Content */
      , _jsxDEV('div', { className: "flex-1 flex flex-col min-w-0"   , children: [
        /* Mobile Header — clean, minimal: identity + hamburger */
        _jsxDEV('header', { className: "lg:hidden sticky top-0 z-30 bg-card border-b"     , children: 
          _jsxDEV('div', { className: "flex items-center justify-between gap-2 px-4 py-3"     , children: [
            /* Exchange identity */
            _jsxDEV('div', { className: "flex items-center gap-2 min-w-0"   , children: [
              _jsxDEV('div', { className: "shrink-0", children: 
                _jsxDEV(ExchangeMark, { size: "sm",}, void 0, false, {fileName: _jsxFileName, lineNumber: 198}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 197}, this)
              , _jsxDEV('div', { className: "min-w-0", children: [
                _jsxDEV('p', { className: "text-sm font-bold truncate leading-tight"   , children: _optionalChain([profile, 'optionalAccess', _12 => _12.exchange_name]) || _optionalChain([profile, 'optionalAccess', _13 => _13.name]) || 'حساب صراف'}, void 0, false, {fileName: _jsxFileName, lineNumber: 201}, this)
                , _optionalChain([profile, 'optionalAccess', _14 => _14.code]) && (
                  _jsxDEV('div', { className: "flex items-center gap-1"  , children: [
                    _jsxDEV('p', { className: "text-[10px] text-muted-foreground tracking-wider truncate"   , dir: "ltr", children: profile.code}, void 0, false, {fileName: _jsxFileName, lineNumber: 204}, this)
                    , _jsxDEV('button', {
                      onClick: () => _optionalChain([navigator, 'access', _15 => _15.clipboard, 'optionalAccess', _16 => _16.writeText, 'call', _17 => _17(profile.code)]),
                      className: "p-0.5 rounded text-muted-foreground hover:text-primary transition-colors shrink-0"     ,
 children: 
                      _jsxDEV(Copy, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 209}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 205}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 203}, this)
                )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 200}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 196}, this)

            /* Sync indicator + Notifications + Hamburger menu */
            , _jsxDEV('div', { className: "flex items-center gap-1 shrink-0"   , children: [
              _jsxDEV(SyncIndicator, { compact: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 218}, this )
              , _jsxDEV(Link, { to: "/notifications", className: "w-9 h-9 rounded-lg hover:bg-muted flex items-center justify-center transition-colors"       , children: 
                _jsxDEV(Bell, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 220}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 219}, this)
              , _jsxDEV('button', {
                onClick: () => setMoreOpen(true),
                className: "w-9 h-9 rounded-lg hover:bg-muted flex items-center justify-center transition-colors"       ,
 children: 
                _jsxDEV(MoreVertical, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 226}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 222}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 217}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 194}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 193}, this)

        , _jsxDEV('main', { className: "flex-1 overflow-y-auto pb-20 lg:pb-12"   , children: 
          _jsxDEV('div', { className: "max-w-5xl mx-auto p-3 lg:p-6"   , children: 
            _jsxDEV(Outlet, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 234}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 233}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 232}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 191}, this)

      /* Mobile Bottom Nav — 5 tabs */
      , _jsxDEV('nav', { className: "lg:hidden fixed bottom-0 inset-x-0 z-30 bg-card border-t flex items-center justify-around px-1 pt-1 pb-0 safe-bottom"             , children: 
        bottomItems.map(item => {
          const Icon = item.icon;
          const active = location.pathname === item.path || location.pathname.startsWith(item.path + '/');
          return (
            _jsxDEV(Link, {

              to: item.path,
              className: cn(
                'flex flex-col items-center gap-0.5 px-2 pt-1 pb-1 rounded-lg flex-1 transition-colors',
                active ? 'text-primary bg-primary/10' : 'text-muted-foreground'
              ),
 children: [
              _jsxDEV(Icon, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 253}, this )
              , _jsxDEV('span', { className: "text-[10px] font-medium" , children: item.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 254}, this)
            ]}, item.featureKey, true, {fileName: _jsxFileName, lineNumber: 245}, this)
          );
        })
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 240}, this)

      /* Hamburger Menu Drawer */
      , moreOpen && (
        _jsxDEV('div', { className: "lg:hidden fixed inset-0 z-50 bg-black/50"    , onClick: () => setMoreOpen(false), children: 
          _jsxDEV('div', { className: "absolute top-0 left-0 bottom-0 w-72 bg-card shadow-xl overflow-y-auto scrollbar-thin"        , onClick: e => e.stopPropagation(), children: [
            /* Drawer header with identity */
            _jsxDEV('div', { className: "p-4 border-b bg-gradient-to-l from-primary to-primary/80"    , children: 
              _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
                _jsxDEV('div', { className: "flex items-center gap-2 min-w-0"   , children: [
                  _jsxDEV('div', { className: "shrink-0", children: 
                    _jsxDEV(ExchangeMark, { size: "sm", dark: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 269}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 268}, this)
                  , _jsxDEV('div', { className: "min-w-0", children: [
                    _jsxDEV('p', { className: "text-sm font-bold text-white truncate"   , children: _optionalChain([profile, 'optionalAccess', _18 => _18.exchange_name]) || _optionalChain([profile, 'optionalAccess', _19 => _19.name]) || 'حساب صراف'}, void 0, false, {fileName: _jsxFileName, lineNumber: 272}, this)
                    , _optionalChain([profile, 'optionalAccess', _20 => _20.code]) && (
                      _jsxDEV('p', { className: "text-[10px] text-white/70 tracking-wider truncate"   , dir: "ltr", children: profile.code}, void 0, false, {fileName: _jsxFileName, lineNumber: 274}, this)
                    )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 271}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 267}, this)
                , _jsxDEV('button', { onClick: () => setMoreOpen(false), className: "p-1.5 rounded-lg text-white/80 hover:bg-white/10"   , children: 
                  _jsxDEV(X, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 279}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 278}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 266}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 265}, this)

            /* All nav items */
            , _jsxDEV('nav', { className: "p-2", children: 
              moreItems.map(item => {
                const Icon = item.icon;
                const active = location.pathname === item.path || location.pathname.startsWith(item.path + '/');
                return (
                  _jsxDEV(Link, {

                    to: item.path,
                    onClick: () => setMoreOpen(false),
                    className: cn(
                      'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors',
                      active ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-muted'
                    ),
 children: [
                    _jsxDEV(Icon, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 299}, this )
                    , _jsxDEV('span', { className: "truncate", children: item.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 300}, this)
                  ]}, item.featureKey, true, {fileName: _jsxFileName, lineNumber: 290}, this)
                );
              })
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 285}, this)

            /* Management actions */
            , _jsxDEV('div', { className: "p-2 border-t mt-2 space-y-1"   , children: [
              _jsxDEV('div', { className: "flex items-center justify-between px-3 py-2"    , children: [
                _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: "همگام‌سازی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 309}, this)
                , _jsxDEV(SyncIndicator, { compact: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 310}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 308}, this)
              , _jsxDEV(Link, { to: "/online-products", onClick: () => setMoreOpen(false), className: "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"         , children: [
                _jsxDEV(ShoppingBag, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 313}, this )
                , _jsxDEV('span', { children: "محصولات آنلاین" }, void 0, false, {fileName: _jsxFileName, lineNumber: 314}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 312}, this)
              , _jsxDEV(Link, { to: "/notifications", onClick: () => setMoreOpen(false), className: "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-900/20"         , children: [
                _jsxDEV(Bell, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 317}, this )
                , _jsxDEV('span', { children: "اعلان‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 318}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 316}, this)
              , _jsxDEV('button', { onClick: () => { setMoreOpen(false); openUpgrade(); }, className: "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-yellow-600 hover:bg-yellow-50 dark:hover:bg-yellow-900/20"          , children: [
                _jsxDEV(Crown, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 321}, this )
                , _jsxDEV('span', { children: "ارتقا به نسخه پولی"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 322}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 320}, this)
              , userRole === 'creator' && (
                _jsxDEV(_Fragment, { children: [
                  _jsxDEV(Link, { to: "/builder", onClick: () => setMoreOpen(false), className: "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-violet-600 hover:bg-violet-50 dark:hover:bg-violet-900/20"         , children: [
                    _jsxDEV(Shield, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 327}, this )
                    , _jsxDEV('span', { children: "پنل سازنده" }, void 0, false, {fileName: _jsxFileName, lineNumber: 328}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 326}, this)
                  , _jsxDEV(Link, { to: "/main-settings", onClick: () => setMoreOpen(false), className: "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20"         , children: [
                    _jsxDEV(Settings, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 331}, this )
                    , _jsxDEV('span', { children: "تنظیمات اصلی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 332}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 330}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 325}, this)
              )
              , _jsxDEV('button', { onClick: () => { setMoreOpen(false); handleLogout(); }, className: "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-destructive hover:bg-destructive/10"         , children: [
                _jsxDEV(X, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 337}, this )
                , _jsxDEV('span', { children: "خروج"}, void 0, false, {fileName: _jsxFileName, lineNumber: 338}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 336}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 307}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 263}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 262}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this)
  );
}