const _jsxFileName = "src/components/sarraaf/PriceEditDialog.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '../ui/dialog.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Label } from '../ui/label.js';
import { Switch } from '../ui/switch.js';
import { computeFinalPrice } from '../../lib/pricingService.js';

const CURRENCY_LABELS = {
  AFN: 'افغانی',
  IRT: 'تومان',
  USD: 'دلار',
};

/**
 * دیالوگ ویرایش قیمت محصول — با پیش‌نمایش زنده قیمت نهایی.
 * فقط یکی از حالت‌های «افزایش درصدی» یا «کاهش درصدی» قابل انتخاب است.
 */
export default function PriceEditDialog({ product, onSave, onClose }) {
  const [form, setForm] = useState({
    name: '',
    category: '',
    service_name: '',
    product_type: '',
    base_price: 0,
    currency: 'AFN',
    pricing_mode: 'markup',
    pricing_percent: 0,
    is_active: true,
    description: '',
  });

  useEffect(() => {
    if (product) {
      setForm({
        name: product.name || '',
        category: product.category || '',
        service_name: product.service_name || '',
        product_type: product.product_type || '',
        base_price: product.base_price || 0,
        currency: product.currency || 'AFN',
        pricing_mode: product.pricing_mode || 'markup',
        pricing_percent: product.pricing_percent || 0,
        is_active: product.is_active !== false,
        description: product.description || '',
      });
    }
  }, [product]);

  if (!product) return null;

  const finalPrice = computeFinalPrice(
    Number(form.base_price) || 0,
    form.pricing_mode,
    Number(form.pricing_percent) || 0
  );

  const set = (key, val) => setForm((f) => ({ ...f, [key]: val }));

  const handleSave = () => {
    onSave(product.id, {
      name: form.name,
      base_price: Number(form.base_price) || 0,
      currency: form.currency,
      pricing_mode: form.pricing_mode,
      pricing_percent: Number(form.pricing_percent) || 0,
      is_active: form.is_active,
      description: form.description,
    });
  };

  const sign = form.pricing_mode === 'markup' ? '+' : '-';

  return (
    _jsxDEV(Dialog, { open: !!product, onOpenChange: (o) => !o && onClose(), children: 
      _jsxDEV(DialogContent, { className: "max-w-md", children: [
        _jsxDEV(DialogHeader, { children: 
          _jsxDEV(DialogTitle, { children: "ویرایش قیمت محصول"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this)

        , _jsxDEV('div', { className: "space-y-3 max-h-[60vh] overflow-y-auto scrollbar-thin pl-1"    , children: [
          _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "نام محصول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this)
            , _jsxDEV(Input, {
              value: form.name,
              onChange: (e) => set('name', e.target.value),
              className: "mt-1 h-9" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 84}, this)

          , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "دسته‌بندی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this)
              , _jsxDEV(Input, {
                value: form.category,
                disabled: true,
                className: "mt-1 h-9 bg-muted text-xs"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 94}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "نوع محصول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this)
              , _jsxDEV(Input, {
                value: form.product_type,
                onChange: (e) => set('product_type', e.target.value),
                className: "mt-1 h-9 text-xs"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 102}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 93}, this)

          , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "قیمت پایه (خرید)"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
              , _jsxDEV(Input, {
                type: "number",
                value: form.base_price,
                onChange: (e) => set('base_price', e.target.value),
                className: "mt-1 h-9" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 113}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "واحد پول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 123}, this)
              , _jsxDEV('select', {
                value: form.currency,
                onChange: (e) => set('currency', e.target.value),
                className: "mt-1 h-9 w-full rounded-md border border-input bg-transparent px-2 text-sm"        ,
 children: 
                Object.entries(CURRENCY_LABELS).map(([k, v]) => (
                  _jsxDEV('option', { value: k, children: v}, k, false, {fileName: _jsxFileName, lineNumber: 130}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 122}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 112}, this)

          /* روش قیمت‌گذاری — فقط یکی */
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "روش قیمت‌گذاری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2 mt-1"   , children: [
              _jsxDEV('button', {
                type: "button",
                onClick: () => set('pricing_mode', 'markup'),
                className: `py-2 rounded-md text-xs font-medium border transition ${
                  form.pricing_mode === 'markup'
                    ? 'bg-green-600 text-white border-green-600'
                    : 'bg-white text-gray-600 border-gray-300'
                }`,
 children: "افزایش درصدی (+)"

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 140}, this)
              , _jsxDEV('button', {
                type: "button",
                onClick: () => set('pricing_mode', 'discount'),
                className: `py-2 rounded-md text-xs font-medium border transition ${
                  form.pricing_mode === 'discount'
                    ? 'bg-red-600 text-white border-red-600'
                    : 'bg-white text-gray-600 border-gray-300'
                }`,
 children: "کاهش درصدی (−)"

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 139}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 137}, this)

          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: ["درصد "
               , form.pricing_mode === 'markup' ? 'افزایش' : 'کاهش', " (٪)"
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 166}, this)
            , _jsxDEV(Input, {
              type: "number",
              min: "0",
              max: "100",
              value: form.pricing_percent,
              onChange: (e) => set('pricing_percent', e.target.value),
              className: "mt-1 h-9" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 169}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 165}, this)

          /* پیش‌نمایش قیمت نهایی */
          , _jsxDEV('div', { className: "rounded-lg bg-blue-50 border border-blue-200 p-3 space-y-1"     , children: [
            _jsxDEV('p', { className: "text-[11px] text-blue-700 font-medium"  , children: "پیش‌نمایش قیمت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 181}, this)
            , _jsxDEV('div', { className: "flex items-center justify-between text-xs"   , children: [
              _jsxDEV('span', { className: "text-gray-500", children: "قیمت پایه:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 183}, this)
              , _jsxDEV('span', { className: "font-semibold", children: [
                (Number(form.base_price) || 0).toLocaleString('fa-IR'), " " , CURRENCY_LABELS[form.currency] || ''
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 184}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 182}, this)
            , _jsxDEV('div', { className: "flex items-center justify-between text-xs"   , children: [
              _jsxDEV('span', { className: "text-gray-500", children: "درصد تغییر:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 189}, this)
              , _jsxDEV('span', { className: `font-semibold ${form.pricing_mode === 'markup' ? 'text-green-600' : 'text-red-600'}`, children: [
                sign, Number(form.pricing_percent) || 0, "٪"
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 190}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 188}, this)
            , _jsxDEV('div', { className: "flex items-center justify-between text-sm pt-1 border-t border-blue-200"      , children: [
              _jsxDEV('span', { className: "text-gray-700 font-medium" , children: "قیمت نهایی فروش:"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 195}, this)
              , _jsxDEV('span', { className: "font-extrabold text-blue-800" , children: [
                finalPrice.toLocaleString('fa-IR'), " " , CURRENCY_LABELS[form.currency] || ''
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 196}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 194}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 180}, this)

          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "توضیحات (اختیاری)" }, void 0, false, {fileName: _jsxFileName, lineNumber: 203}, this)
            , _jsxDEV(Input, {
              value: form.description,
              onChange: (e) => set('description', e.target.value),
              className: "mt-1 h-9 text-xs"  ,
              placeholder: "یادداشت داخلی..." ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 204}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 202}, this)

          , _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
            _jsxDEV(Label, { className: "text-xs", children: "وضعیت محصول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 213}, this)
            , _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
              _jsxDEV('span', { className: "text-xs text-gray-500" , children: form.is_active ? 'فعال' : 'غیرفعال'}, void 0, false, {fileName: _jsxFileName, lineNumber: 215}, this)
              , _jsxDEV(Switch, {
                checked: form.is_active,
                onCheckedChange: (v) => set('is_active', v),}, void 0, false, {fileName: _jsxFileName, lineNumber: 216}, this
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 214}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 212}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 83}, this)

        , _jsxDEV(DialogFooter, { className: "gap-2", children: [
          _jsxDEV(Button, { variant: "outline", size: "sm", onClick: onClose, children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 225}, this)
          , _jsxDEV(Button, { size: "sm", onClick: handleSave, children: "ذخیره"}, void 0, false, {fileName: _jsxFileName, lineNumber: 226}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 224}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 78}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)
  );
}