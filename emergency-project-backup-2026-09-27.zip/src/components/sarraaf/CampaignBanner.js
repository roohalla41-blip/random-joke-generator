const _jsxFileName = "src/components/sarraaf/CampaignBanner.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }// CampaignBanner.jsx — Countdown banner shown on dashboard when discount is active
import React, { useState, useEffect } from 'react';
import { useDiscountCampaign } from '../../lib/usePricing.js';
import { getTimeRemaining } from '../../lib/pricingService.js';
import { toPersianDigits } from '../../lib/sarraaf.js';
import { Clock, X } from 'lucide-react';

export default function CampaignBanner({ onUpgrade }) {
  const { data: campaign } = useDiscountCampaign();
  const [time, setTime] = useState(() => getTimeRemaining(_optionalChain([campaign, 'optionalAccess', _ => _.end_date])));
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (!_optionalChain([campaign, 'optionalAccess', _2 => _2.end_date])) return;
    setTime(getTimeRemaining(campaign.end_date));
    const t = setInterval(() => setTime(getTimeRemaining(campaign.end_date)), 1000);
    return () => clearInterval(t);
  }, [_optionalChain([campaign, 'optionalAccess', _3 => _3.end_date])]);

  if (!campaign || campaign.expired || !campaign.active || dismissed) return null;

  return (
    _jsxDEV('div', { className: "rounded-xl bg-gradient-to-r from-red-500 to-orange-500 text-white p-3 mb-4"      , children: 
      _jsxDEV('div', { className: "flex items-center justify-between gap-2"   , children: [
        _jsxDEV('div', { className: "flex-1", children: [
          _jsxDEV('p', { className: "text-sm font-bold" , children: ["🎉 تخفیف "  , toPersianDigits(campaign.percent), "٪ ویژه!" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 26}, this)
          , _jsxDEV('p', { className: "text-[10px] opacity-90 mt-0.5"  , children: "روی تمام پلن‌های پولی — فرصت محدود"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 27}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 25}, this)
        , _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
          time && !time.expired && (
            _jsxDEV('div', { className: "flex items-center gap-1 text-sm font-bold bg-white/20 rounded-lg px-2 py-1"        , children: [
              _jsxDEV(Clock, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 32}, this )
              , _jsxDEV('span', { children: [
                toPersianDigits(String(time.hours).padStart(2, '0')), ":", toPersianDigits(String(time.minutes).padStart(2, '0')), ":", toPersianDigits(String(time.seconds).padStart(2, '0'))
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 33}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 31}, this)
          )
          , _jsxDEV('button', {
            onClick: onUpgrade,
            className: "bg-white text-red-600 text-xs font-bold rounded-lg px-3 py-1.5 hover:bg-white/90 transition-colors"        ,
 children: "ارتقا"

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this)
          , _jsxDEV('button', { onClick: () => setDismissed(true), className: "p-1 hover:bg-white/20 rounded"  , children: 
            _jsxDEV(X, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 45}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 44}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 29}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 24}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 23}, this)
  );
}