const _jsxFileName = "src/components/sarraaf/MultiExchangeManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Loader2, Link2, Users } from 'lucide-react';
import { getUserExchanges, requestJoinExchange } from '../../lib/multiExchange.js';
import { useToast } from '../ui/use-toast.js';
import { useAuth } from '../../lib/AuthContext.js';

export default function MultiExchangeManager() {
  const { user } = useAuth();
  const [exchanges, setExchanges] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showJoin, setShowJoin] = useState(false);
  const [joinCode, setJoinCode] = useState('');
  const [joining, setJoining] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (_optionalChain([user, 'optionalAccess', _ => _.id])) load();
  }, [_optionalChain([user, 'optionalAccess', _2 => _2.id])]);

  async function load() {
    setLoading(true);
    const list = await getUserExchanges(user.id);
    setExchanges(list);
    setLoading(false);
  }

  async function handleJoin() {
    if (!joinCode) {
      toast({ title: 'خطا', description: 'کد صرافی را وارد کنید', variant: 'destructive' });
      return;
    }
    setJoining(true);
    const res = await requestJoinExchange({
      userId: user.id,
      userName: user.full_name || user.email,
      exchangeCode: joinCode,
      role: 'employee',
    });
    if (res.success) {
      toast({ title: 'موفق', description: 'درخواست شما ثبت شد و در انتظار تأیید است' });
      setJoinCode('');
      setShowJoin(false);
      load();
    } else {
      toast({ title: 'خطا', description: res.error === 'exchange_not_found' ? 'صرافی یافت نشد' : 'قبلاً متصل شده‌اید', variant: 'destructive' });
    }
    setJoining(false);
  }

  const primary = exchanges.find(e => e.status === 'active') || exchanges[0];

  if (loading) {
    return (
      _jsxDEV('div', { className: "flex items-center justify-center py-8"   , children: 
        _jsxDEV(Loader2, { className: "w-5 h-5 animate-spin text-primary"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 57}, this)
    );
  }

  return (
    _jsxDEV(Card, { children: [
      _jsxDEV(CardHeader, { children: 
        _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
          _jsxDEV(CardTitle, { className: "text-sm flex items-center gap-2"   , children: [
            _jsxDEV(Link2, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this ), "صرافی‌های متصل"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 67}, this)
          , _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => setShowJoin(!showJoin), children: 
            showJoin ? 'بستن' : 'اتصال به صرافی'
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 66}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this)
      , _jsxDEV(CardContent, { className: "space-y-3", children: [
        showJoin && (
          _jsxDEV('div', { className: "flex gap-2 p-3 rounded-lg border border-border"     , children: [
            _jsxDEV(Input, {
              value: joinCode,
              onChange: (e) => setJoinCode(e.target.value),
              placeholder: "کد صرافی (مثلاً EX-10001)"   ,
              className: "h-8 text-sm" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this
            )
            , _jsxDEV(Button, { size: "sm", onClick: handleJoin, disabled: joining, children: 
              joining ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this ) : 'اتصال'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 78}, this)
        )

        , exchanges.length === 0 ? (
          _jsxDEV('p', { className: "text-center text-xs text-muted-foreground py-4"   , children: "صرافی متصل نیست"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 92}, this)
        ) : (
          _jsxDEV('div', { className: "space-y-2", children: 
            exchanges.map((ex) => (
              _jsxDEV('div', { className: "flex items-center gap-2 p-2 rounded-lg border border-border"      , children: [
                _jsxDEV('div', { className: "w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"       , children: 
                  _jsxDEV(Users, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)
                , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
                  _jsxDEV('p', { className: "text-xs font-medium truncate"  , children: ex.exchange_name || ex.exchange_code}, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this)
                  , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: [ex.role === 'admin' ? 'مدیر' : 'کارمند', " — "  , ex.exchange_code]}, void 0, true, {fileName: _jsxFileName, lineNumber: 102}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 100}, this)
                , _jsxDEV('span', { className: `text-[10px] px-1.5 py-0.5 rounded ${ex.status === 'active' ? 'bg-green-100 text-green-700' : ex.status === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`, children: 
                  ex.status === 'active' ? 'فعال' : ex.status === 'pending' ? 'در انتظار' : 'مسدود'
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this)
              ]}, ex.id, true, {fileName: _jsxFileName, lineNumber: 96}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 76}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 64}, this)
  );
}