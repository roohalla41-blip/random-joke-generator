const _jsxFileName = "src/components/sarraaf/PermissionManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { useAllPermissions, useAllSarraafProfiles, useUpdatePermission, useCreatePermission } from '../../lib/useAdmin.js';
import { useAuth } from '../../lib/AuthContext.js';
import { FEATURE_CATALOG } from '../../lib/features.js';
import { ROLE_HIERARCHY } from '../../lib/permissions.js';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Switch } from '../ui/switch.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select.js';
import { toast } from '../ui/use-toast.js';
import { Lock, Plus } from 'lucide-react';

const PERMISSION_ACTIONS = [
  { key: 'can_view', label: 'مشاهده' },
  { key: 'can_create', label: 'ایجاد' },
  { key: 'can_edit', label: 'ویرایش' },
  { key: 'can_delete', label: 'حذف' },
  { key: 'can_print', label: 'چاپ' },
  { key: 'can_report', label: 'گزارش' },
  { key: 'can_settings', label: 'تنظیمات' },
];

export default function PermissionManager() {
  const { user } = useAuth();
  const { data: profiles } = useAllSarraafProfiles();
  const { data: permissions, isLoading } = useAllPermissions();
  const updateMut = useUpdatePermission();
  const createMut = useCreatePermission();

  const [selectedUserId, setSelectedUserId] = useState('');
  const [selectedSection, setSelectedSection] = useState('dashboard');

  const myRole = _optionalChain([user, 'optionalAccess', _ => _.role]) || 'admin';
  const myLevel = ROLE_HIERARCHY[myRole] || 0;

  const userPerms = (permissions || []).filter(p => p.user_id === selectedUserId);

  const handleToggle = async (perm, actionKey) => {
    if (!perm) return;
    try {
      await updateMut.mutateAsync({
        id: perm.id,
        data: { [actionKey]: !perm[actionKey] },
      });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleAddPermission = async (section) => {
    if (!selectedUserId) {
      toast({ title: 'خطا', description: 'ابتدا کاربر را انتخاب کنید', variant: 'destructive' });
      return;
    }
    const profile = _optionalChain([profiles, 'optionalAccess', _2 => _2.find, 'call', _3 => _3(p => p.user_id === selectedUserId)]);
    try {
      await createMut.mutateAsync({
        user_id: selectedUserId,
        user_name: _optionalChain([profile, 'optionalAccess', _4 => _4.name]) || '',
        role: _optionalChain([profile, 'optionalAccess', _5 => _5.plan]) ? 'sarraaf' : 'customer',
        section,
        can_view: true,
        can_create: false,
        can_edit: false,
        can_delete: false,
        can_print: false,
        can_report: false,
        can_settings: false,
      });
      toast({ title: 'افزوده شد', description: 'دسترسی برای بخش ایجاد شد' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV(Card, { children: 
      _jsxDEV(CardContent, { className: "p-4", children: [
        _jsxDEV('h3', { className: "text-sm font-semibold mb-3 flex items-center gap-2"     , children: [
          _jsxDEV(Lock, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this ), "سطح دسترسی و مجوزها"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 79}, this)

        , _jsxDEV('div', { className: "flex gap-2 mb-3"  , children: [
          _jsxDEV(Select, { value: selectedUserId, onValueChange: setSelectedUserId, children: [
            _jsxDEV(SelectTrigger, { className: "flex-1", children: _jsxDEV(SelectValue, { placeholder: "انتخاب کاربر" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this)
            , _jsxDEV(SelectContent, { children: 
              (profiles || []).map(p => (
                _jsxDEV(SelectItem, { value: p.user_id, children: [p.name, " (" , p.code, ")"]}, p.id, true, {fileName: _jsxFileName, lineNumber: 89}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 85}, this)
          , _jsxDEV(Select, { value: selectedSection, onValueChange: setSelectedSection, children: [
            _jsxDEV(SelectTrigger, { className: "w-40", children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this)
            , _jsxDEV(SelectContent, { children: 
              FEATURE_CATALOG.map(f => (
                _jsxDEV(SelectItem, { value: f.feature_key, children: f.name}, f.feature_key, false, {fileName: _jsxFileName, lineNumber: 97}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 93}, this)
          , _jsxDEV(Button, { size: "sm", onClick: () => handleAddPermission(selectedSection), children: 
            _jsxDEV(Plus, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 84}, this)

        , !selectedUserId ? (
          _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "یک کاربر انتخاب کنید"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this)
        ) : userPerms.length === 0 ? (
          _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "هیچ دسترسی برای این کاربر تعریف نشده. با دکمه + اضافه کنید."           }, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this)
        ) : (
          _jsxDEV('div', { className: "space-y-2 max-h-[400px] overflow-y-auto scrollbar-thin"   , children: 
            userPerms.map(perm => (
              _jsxDEV('div', { className: "p-2.5 rounded-lg border"  , children: [
                _jsxDEV('p', { className: "text-xs font-medium mb-2"  , children: perm.section}, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
                , _jsxDEV('div', { className: "grid grid-cols-4 gap-2"  , children: 
                  PERMISSION_ACTIONS.map(action => (
                    _jsxDEV('div', { className: "flex items-center gap-1"  , children: [
                      _jsxDEV(Switch, {
                        checked: perm[action.key] === true,
                        onCheckedChange: () => handleToggle(perm, action.key),}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this
                      )
                      , _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: action.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this)
                    ]}, action.key, true, {fileName: _jsxFileName, lineNumber: 117}, this)
                  ))
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this)
              ]}, perm.id, true, {fileName: _jsxFileName, lineNumber: 113}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 78}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)
  );
}