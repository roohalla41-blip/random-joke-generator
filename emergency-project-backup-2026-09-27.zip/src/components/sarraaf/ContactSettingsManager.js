const _jsxFileName = "src/components/sarraaf/ContactSettingsManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card.js';
import { Input } from '../ui/input.js';
import { Switch } from '../ui/switch.js';
import { Button } from '../ui/button.js';
import { Loader2, Save, Phone, Mail, Globe, MessageCircle, Send, Instagram, Facebook } from 'lucide-react';
import { getContactSettings, saveContactSettings } from '../../lib/contactSettings.js';

const ICON_MAP = { Phone, Mail, Globe, MessageCircle, Send, Instagram, Facebook };

export default function ContactSettingsManager() {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    const list = await getContactSettings();
    setContacts(list);
    setLoading(false);
  }

  async function handleSave() {
    setSaving(true);
    await saveContactSettings(contacts);
    setSaving(false);
  }

  function updateField(idx, field, value) {
    const updated = [...contacts];
    updated[idx] = { ...updated[idx], [field]: value };
    setContacts(updated);
  }

  if (loading) {
    return (
      _jsxDEV('div', { className: "flex items-center justify-center py-8"   , children: 
        _jsxDEV(Loader2, { className: "w-5 h-5 animate-spin text-primary"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this)
    );
  }

  return (
    _jsxDEV(Card, { children: [
      _jsxDEV(CardHeader, { children: 
        _jsxDEV(CardTitle, { className: "text-sm", children: "لینک‌های ارتباطی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this)
      , _jsxDEV(CardContent, { className: "space-y-3", children: [
        contacts.map((c, idx) => {
          const Icon = ICON_MAP[c.icon] || Phone;
          return (
            _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
              _jsxDEV('div', { className: "w-8 h-8 rounded-lg bg-muted flex items-center justify-center shrink-0"       , children: 
                _jsxDEV(Icon, { className: "w-4 h-4 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 57}, this)
              , _jsxDEV('div', { className: "flex-1 min-w-0" , children: 
                _jsxDEV(Input, {
                  placeholder: c.label,
                  value: c.value,
                  onChange: (e) => updateField(idx, 'value', e.target.value),
                  className: "h-8 text-sm" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this
                )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)
              , _jsxDEV(Switch, {
                checked: c.is_active,
                onCheckedChange: (v) => updateField(idx, 'is_active', v),}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this
              )
            ]}, c.type, true, {fileName: _jsxFileName, lineNumber: 56}, this)
          );
        })
        , _jsxDEV(Button, { onClick: handleSave, disabled: saving, className: "w-full", size: "sm", children: [
          saving ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this ) : _jsxDEV(Save, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this ), "ذخیره"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 75}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 52}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 48}, this)
  );
}