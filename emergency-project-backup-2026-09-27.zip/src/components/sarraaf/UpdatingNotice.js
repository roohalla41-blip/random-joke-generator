const _jsxFileName = "src/components/sarraaf/UpdatingNotice.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';
import { Loader2 } from 'lucide-react';

export default function UpdatingNotice({ message }) {
  return (
    _jsxDEV('div', { className: "mt-6 flex items-center justify-center gap-2 py-4 px-4 rounded-xl bg-muted/50 border border-dashed border-muted-foreground/20"           , children: [
      _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin text-muted-foreground"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 7}, this )
      , _jsxDEV('p', { className: "text-xs text-muted-foreground text-center"  , children: 
        message || 'این بخش در حال به‌روزرسانی است و به‌زودی تکمیل خواهد شد.'
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 8}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 6}, this)
  );
}