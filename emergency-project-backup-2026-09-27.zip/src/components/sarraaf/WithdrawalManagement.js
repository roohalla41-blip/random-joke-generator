const _jsxFileName = "src/components/sarraaf/WithdrawalManagement.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { listWithdrawals, approveWithdrawal, rejectWithdrawal } from '../../lib/customerApi.js';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Badge } from '../ui/badge.js';
import { Loader2, CheckCircle2, XCircle, Clock } from 'lucide-react';

const STATUS_LABELS = {
  pending: { label: 'در انتظار', variant: 'warning' },
  approved: { label: 'تأییدشده', variant: 'success' },
  rejected: { label: 'ردشده', variant: 'destructive' },
  completed: { label: 'تکمیل‌شده', variant: 'info' },
};

const METHOD_LABELS = {
  bank_transfer: 'انتقال بانکی',
  cash: 'نقدی',
  agent: 'نمایندگی',
};

export default function WithdrawalManagement() {
  const qc = useQueryClient();
  const { data: withdrawals = [], isLoading } = useQuery({
    queryKey: ['adminWithdrawals'],
    queryFn: listWithdrawals,
  });

  const [rejectingId, setRejectingId] = useState(null);
  const [rejectReason, setRejectReason] = useState('');

  const approveMut = useMutation({
    mutationFn: approveWithdrawal,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['adminWithdrawals'] }),
  });
  const rejectMut = useMutation({
    mutationFn: ({ id, reason }) => rejectWithdrawal(id, reason),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['adminWithdrawals'] });
      setRejectingId(null);
      setRejectReason('');
    },
  });

  if (isLoading) {
    return (
      _jsxDEV('div', { className: "flex items-center justify-center py-8"   , children: 
        _jsxDEV(Loader2, { className: "w-5 h-5 animate-spin text-primary"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 47}, this)
    );
  }

  const pending = withdrawals.filter(w => w.status === 'pending');
  const processed = withdrawals.filter(w => w.status !== 'pending');

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      _jsxDEV('div', { className: "flex items-center gap-2 mb-2"   , children: [
        _jsxDEV(Clock, { className: "w-4 h-4 text-amber-500"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this )
        , _jsxDEV('h3', { className: "text-sm font-semibold" , children: ["درخواست‌های برداشت ("  , pending.length, " در انتظار)"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 60}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 58}, this)

      , pending.length === 0 && (
        _jsxDEV('p', { className: "text-xs text-muted-foreground text-center py-4"   , children: "درخواست برداشت در انتظاری وجود ندارد"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
      )

      , pending.map((w) => (
        _jsxDEV(Card, { className: "shadow-sm", children: 
          _jsxDEV(CardContent, { className: "p-3 space-y-2" , children: [
            _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV('p', { className: "text-sm font-bold" , children: [Number(w.amount || 0).toLocaleString(), " " , w.currency || 'AFN']}, void 0, true, {fileName: _jsxFileName, lineNumber: 72}, this)
                , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: METHOD_LABELS[w.method] || w.method}, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 71}, this)
              , _jsxDEV(Badge, { variant: "warning", children: _optionalChain([STATUS_LABELS, 'access', _ => _.pending, 'optionalAccess', _2 => _2.label])}, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 70}, this)
            , w.destination && (
              _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: ["مقصد: " , w.destination]}, void 0, true, {fileName: _jsxFileName, lineNumber: 78}, this)
            )
            , w.description && (
              _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: w.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
            )
            , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: ["کاربر: " , w.user_name || w.user_id]}, void 0, true, {fileName: _jsxFileName, lineNumber: 83}, this)

            , rejectingId === w.id ? (
              _jsxDEV('div', { className: "space-y-2", children: [
                _jsxDEV('textarea', {
                  className: "w-full text-xs border rounded p-2 bg-transparent"     ,
                  placeholder: "دلیل رد..." ,
                  value: rejectReason,
                  onChange: (e) => setRejectReason(e.target.value),
                  rows: 2,}, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this
                )
                , _jsxDEV('div', { className: "flex gap-2" , children: [
                  _jsxDEV(Button, {
                    size: "sm",
                    variant: "destructive",
                    disabled: rejectMut.isPending,
                    onClick: () => rejectMut.mutate({ id: w.id, reason: rejectReason }),
 children: [
                    rejectMut.isPending ? _jsxDEV(Loader2, { className: "w-3 h-3 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this ) : _jsxDEV(XCircle, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this ), "تأیید رد"

                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)
                  , _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => { setRejectingId(null); setRejectReason(''); }, children: "انصراف"

                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 94}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 86}, this)
            ) : (
              _jsxDEV('div', { className: "flex gap-2" , children: [
                _jsxDEV(Button, {
                  size: "sm",
                  disabled: approveMut.isPending,
                  onClick: () => approveMut.mutate(w.id),
 children: [
                  approveMut.isPending ? _jsxDEV(Loader2, { className: "w-3 h-3 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this ) : _jsxDEV(CheckCircle2, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this ), "تأیید"

                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 111}, this)
                , _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => setRejectingId(w.id), children: [
                  _jsxDEV(XCircle, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this ), "رد"

                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 119}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 110}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 69}, this)
        }, w.id, false, {fileName: _jsxFileName, lineNumber: 68}, this)
      ))

      , processed.length > 0 && (
        _jsxDEV(_Fragment, { children: [
          _jsxDEV('h4', { className: "text-xs font-semibold text-muted-foreground mt-4 mb-2"    , children: "پردازش‌شده‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this)
          , processed.slice(0, 10).map((w) => (
            _jsxDEV(Card, { className: "shadow-sm opacity-70" , children: 
              _jsxDEV(CardContent, { className: "p-3 flex items-center justify-between"   , children: [
                _jsxDEV('div', { children: [
                  _jsxDEV('p', { className: "text-sm font-bold" , children: [Number(w.amount || 0).toLocaleString(), " " , w.currency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 136}, this)
                  , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: w.reviewer_name || ''}, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 135}, this)
                , _jsxDEV(Badge, { variant: _optionalChain([STATUS_LABELS, 'access', _3 => _3[w.status], 'optionalAccess', _4 => _4.variant]) || 'outline', children: 
                  _optionalChain([STATUS_LABELS, 'access', _5 => _5[w.status], 'optionalAccess', _6 => _6.label]) || w.status
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 134}, this)
            }, w.id, false, {fileName: _jsxFileName, lineNumber: 133}, this)
          ))
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 130}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 57}, this)
  );
}