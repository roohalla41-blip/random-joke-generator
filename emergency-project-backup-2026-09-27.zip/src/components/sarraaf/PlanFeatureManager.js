const _jsxFileName = "src/components/sarraaf/PlanFeatureManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { useFeatures, useToggleFeature } from '../../lib/useSarraaf.js';
import { useUpdateFeaturePlan, useCreateFeature, usePlanQuotas, useCreatePlanQuota, useUpdatePlanQuota } from '../../lib/useAdmin.js';
import { FEATURE_CATALOG, CRITICAL_FEATURES } from '../../lib/features.js';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Switch } from '../ui/switch.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../ui/dialog.js';
import { Label } from '../ui/label.js';
import { toast } from '../ui/use-toast.js';
import { ShieldCheck, Plus, Lock, Globe } from 'lucide-react';

export default function PlanFeatureManager() {
  const { data: features } = useFeatures();
  const { data: planQuotas } = usePlanQuotas();
  const toggleMut = useToggleFeature();
  const planMut = useUpdateFeaturePlan();
  const createQuotaMut = useCreatePlanQuota();
  const updateQuotaMut = useUpdatePlanQuota();
  const createFeatureMut = useCreateFeature();

  const [showAdd, setShowAdd] = useState(false);
  const [newFeature, setNewFeature] = useState({ feature_key: '', name: '', icon: 'Settings', location: 'page' });
  const [quotaModal, setQuotaModal] = useState(null);
  const [quotaForm, setQuotaForm] = useState({ plan: 'free', feature_key: '', max_transactions: -1, max_customers: -1, max_messages: -1, max_prints: -1 });

  const handleToggle = async (f) => {
    if (CRITICAL_FEATURES.includes(f.feature_key)) return;
    const current = _optionalChain([features, 'optionalAccess', _ => _.find, 'call', _2 => _2(fx => fx.feature_key === f.feature_key)]);
    if (!current) {
      try {
        await createFeatureMut.mutateAsync({
          feature_key: f.feature_key,
          name: f.name,
          icon: f.icon,
          location: f.location,
          display_order: f.display_order,
          enabled: true,
          status: f.default_status || 'active',
          free_enabled: true,
          paid_enabled: true,
        });
      } catch (err) {
        toast({ title: 'خطا', description: err.message, variant: 'destructive' });
      }
      return;
    }
    toggleMut.mutate({ id: current.id, enabled: !current.enabled });
  };

  const handlePlanToggle = async (f, field) => {
    const current = _optionalChain([features, 'optionalAccess', _3 => _3.find, 'call', _4 => _4(fx => fx.feature_key === f.feature_key)]);
    if (!current) {
      try {
        await createFeatureMut.mutateAsync({
          feature_key: f.feature_key,
          name: f.name,
          icon: f.icon,
          location: f.location,
          display_order: f.display_order,
          enabled: true,
          status: f.default_status || 'active',
          free_enabled: field !== 'free',
          paid_enabled: field !== 'paid',
        });
      } catch (err) {
        toast({ title: 'خطا', description: err.message, variant: 'destructive' });
      }
      return;
    }
    try {
      await planMut.mutateAsync({
        id: current.id,
        free_enabled: field === 'free' ? !current.free_enabled : current.free_enabled !== false,
        paid_enabled: field === 'paid' ? !current.paid_enabled : current.paid_enabled !== false,
      });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const openQuotaModal = (featureKey) => {
    setQuotaForm({ plan: 'free', feature_key: featureKey, max_transactions: -1, max_customers: -1, max_messages: -1, max_prints: -1 });
    setQuotaModal(featureKey);
  };

  const handleSaveQuota = async () => {
    try {
      const existing = _optionalChain([planQuotas, 'optionalAccess', _5 => _5.find, 'call', _6 => _6(q => q.plan === quotaForm.plan && q.feature_key === quotaForm.feature_key)]);
      if (existing) {
        await updateQuotaMut.mutateAsync({ id: existing.id, data: quotaForm });
      } else {
        await createQuotaMut.mutateAsync(quotaForm);
      }
      toast({ title: 'ذخیره شد', description: 'سهمیه به‌روزرسانی شد' });
      setQuotaModal(null);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleAddFeature = async () => {
    if (!newFeature.feature_key.trim() || !newFeature.name.trim()) {
      toast({ title: 'خطا', description: 'کلید و نام الزامی است', variant: 'destructive' });
      return;
    }
    try {
      await createFeatureMut.mutateAsync({
        ...newFeature,
        display_order: 99,
        enabled: true,
        free_enabled: true,
        paid_enabled: true,
      });
      toast({ title: 'افزوده شد', description: 'قابلیت جدید ایجاد شد' });
      setShowAdd(false);
      setNewFeature({ feature_key: '', name: '', icon: 'Settings', location: 'page' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV('div', { className: "space-y-3", children: [
      /* Feature Plan Access */
      _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4", children: [
          _jsxDEV('div', { className: "flex items-center justify-between mb-3"   , children: [
            _jsxDEV('h3', { className: "text-sm font-semibold flex items-center gap-2"    , children: [
              _jsxDEV(ShieldCheck, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this ), "دسترسی قابلیت‌ها بر اساس نسخه"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 130}, this)
            , _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => setShowAdd(true), children: [
              _jsxDEV(Plus, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this ), "قابلیت جدید"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 134}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 129}, this)

          , _jsxDEV('div', { className: "space-y-2", children: 
            FEATURE_CATALOG.map(f => {
              const dbFeature = _optionalChain([features, 'optionalAccess', _7 => _7.find, 'call', _8 => _8(fx => fx.feature_key === f.feature_key)]);
              const enabled = dbFeature ? dbFeature.enabled !== false : true;
              const freeEnabled = dbFeature ? dbFeature.free_enabled !== false : true;
              const paidEnabled = dbFeature ? dbFeature.paid_enabled !== false : true;
              const isCritical = CRITICAL_FEATURES.includes(f.feature_key);
              return (
                _jsxDEV('div', { className: "p-2.5 rounded-lg border"  , children: [
                  _jsxDEV('div', { className: "flex items-center justify-between mb-2"   , children: [
                    _jsxDEV('span', { className: "text-sm font-medium" , children: f.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 150}, this)
                    , _jsxDEV('span', { className: "text-[9px] text-muted-foreground" , children: f.feature_key}, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 149}, this)
                  , _jsxDEV('div', { className: "flex items-center gap-4 flex-wrap"   , children: [
                    _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
                      _jsxDEV(Switch, { checked: enabled, disabled: isCritical, onCheckedChange: () => handleToggle(f),}, void 0, false, {fileName: _jsxFileName, lineNumber: 155}, this )
                      , _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: "فعال کلی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 154}, this)
                    , _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
                      _jsxDEV(Switch, { checked: freeEnabled, disabled: isCritical, onCheckedChange: () => handlePlanToggle(f, 'free'),}, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this )
                      , _jsxDEV('span', { className: "text-[10px] text-blue-600" , children: "رایگان"}, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 158}, this)
                    , _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
                      _jsxDEV(Switch, { checked: paidEnabled, disabled: isCritical, onCheckedChange: () => handlePlanToggle(f, 'paid'),}, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this )
                      , _jsxDEV('span', { className: "text-[10px] text-green-600" , children: "پولی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 164}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 162}, this)
                    , _jsxDEV(Button, { size: "sm", variant: "ghost", className: "h-7 text-[10px]" , onClick: () => openQuotaModal(f.feature_key), children: "سهمیه"

                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 166}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 153}, this)
                ]}, f.feature_key, true, {fileName: _jsxFileName, lineNumber: 148}, this)
              );
            })
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 140}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 128}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this)

      /* Plan Quotas Overview */
      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4", children: [
          _jsxDEV('h3', { className: "text-sm font-semibold mb-3"  , children: "سهمیه‌های تعریف‌شده" }, void 0, false, {fileName: _jsxFileName, lineNumber: 180}, this)
          , !planQuotas || planQuotas.length === 0 ? (
            _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "سهمیه‌ای تعریف نشده. از دکمه «سهمیه» کنار هر قابلیت اضافه کنید."          }, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this)
          ) : (
            _jsxDEV('div', { className: "space-y-1.5", children: 
              planQuotas.map(q => (
                _jsxDEV('div', { className: "flex items-center justify-between p-2 rounded-lg bg-muted/50 text-xs"      , children: [
                  _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                    q.plan === 'free' ? _jsxDEV(Globe, { className: "w-3 h-3 text-blue-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 188}, this ) : _jsxDEV(Lock, { className: "w-3 h-3 text-green-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 188}, this )
                    , _jsxDEV('span', { children: q.feature_key}, void 0, false, {fileName: _jsxFileName, lineNumber: 189}, this)
                    , _jsxDEV('span', { className: "text-muted-foreground", children: q.plan === 'free' ? 'رایگان' : 'پولی'}, void 0, false, {fileName: _jsxFileName, lineNumber: 190}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 187}, this)
                  , _jsxDEV('div', { className: "flex gap-2 text-[10px] text-muted-foreground"   , children: [
                    _jsxDEV('span', { children: ["تراکنش: " , q.max_transactions < 0 ? 'نامحدود' : q.max_transactions]}, void 0, true, {fileName: _jsxFileName, lineNumber: 193}, this)
                    , _jsxDEV('span', { children: ["مشتری: " , q.max_customers < 0 ? 'نامحدود' : q.max_customers]}, void 0, true, {fileName: _jsxFileName, lineNumber: 194}, this)
                    , _jsxDEV('span', { children: ["پیام: " , q.max_messages < 0 ? 'نامحدود' : q.max_messages]}, void 0, true, {fileName: _jsxFileName, lineNumber: 195}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 192}, this)
                ]}, q.id, true, {fileName: _jsxFileName, lineNumber: 186}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 184}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 179}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this)

      /* Add Feature Dialog */
      , _jsxDEV(Dialog, { open: showAdd, onOpenChange: setShowAdd, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "قابلیت جدید" }, void 0, false, {fileName: _jsxFileName, lineNumber: 207}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 207}, this)
          , _jsxDEV('div', { className: "space-y-3", children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "کلید قابلیت (انگلیسی)"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 210}, this)
              , _jsxDEV(Input, { value: newFeature.feature_key, onChange: e => setNewFeature({ ...newFeature, feature_key: e.target.value }), placeholder: "my_feature",}, void 0, false, {fileName: _jsxFileName, lineNumber: 211}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 209}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نام نمایشی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 214}, this)
              , _jsxDEV(Input, { value: newFeature.name, onChange: e => setNewFeature({ ...newFeature, name: e.target.value }), placeholder: "نام قابلیت" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 215}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 213}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "محل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 218}, this)
              , _jsxDEV(Input, { value: newFeature.location, onChange: e => setNewFeature({ ...newFeature, location: e.target.value }), placeholder: "nav / action / page"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 219}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 217}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 208}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setShowAdd(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this)
            , _jsxDEV(Button, { onClick: handleAddFeature, disabled: createFeatureMut.isPending, children: "افزودن"}, void 0, false, {fileName: _jsxFileName, lineNumber: 224}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 222}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 206}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 205}, this)

      /* Quota Dialog */
      , _jsxDEV(Dialog, { open: !!quotaModal, onOpenChange: () => setQuotaModal(null), children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: ["سهمیه: " , quotaModal]}, void 0, true, {fileName: _jsxFileName, lineNumber: 232}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 232}, this)
          , _jsxDEV('div', { className: "space-y-3", children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "پلن"}, void 0, false, {fileName: _jsxFileName, lineNumber: 235}, this)
              , _jsxDEV('div', { className: "flex gap-2" , children: [
                _jsxDEV(Button, { size: "sm", variant: quotaForm.plan === 'free' ? 'default' : 'outline', onClick: () => setQuotaForm({ ...quotaForm, plan: 'free' }), children: "رایگان"}, void 0, false, {fileName: _jsxFileName, lineNumber: 237}, this)
                , _jsxDEV(Button, { size: "sm", variant: quotaForm.plan === 'paid' ? 'default' : 'outline', onClick: () => setQuotaForm({ ...quotaForm, plan: 'paid' }), children: "پولی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 238}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 236}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 234}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "حد تراکنش (-1 = نامحدود)"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 243}, this)
                , _jsxDEV(Input, { type: "number", value: quotaForm.max_transactions, onChange: e => setQuotaForm({ ...quotaForm, max_transactions: parseInt(e.target.value) || -1 }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 244}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 242}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "حد مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 247}, this)
                , _jsxDEV(Input, { type: "number", value: quotaForm.max_customers, onChange: e => setQuotaForm({ ...quotaForm, max_customers: parseInt(e.target.value) || -1 }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 248}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 246}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "حد پیام" }, void 0, false, {fileName: _jsxFileName, lineNumber: 251}, this)
                , _jsxDEV(Input, { type: "number", value: quotaForm.max_messages, onChange: e => setQuotaForm({ ...quotaForm, max_messages: parseInt(e.target.value) || -1 }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 252}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 250}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "حد چاپ" }, void 0, false, {fileName: _jsxFileName, lineNumber: 255}, this)
                , _jsxDEV(Input, { type: "number", value: quotaForm.max_prints, onChange: e => setQuotaForm({ ...quotaForm, max_prints: parseInt(e.target.value) || -1 }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 256}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 254}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 241}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 233}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setQuotaModal(null), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 261}, this)
            , _jsxDEV(Button, { onClick: handleSaveQuota, disabled: createQuotaMut.isPending || updateQuotaMut.isPending, children: "ذخیره"}, void 0, false, {fileName: _jsxFileName, lineNumber: 262}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 260}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 231}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 230}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 125}, this)
  );
}