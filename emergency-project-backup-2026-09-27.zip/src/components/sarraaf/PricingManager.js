const _jsxFileName = "src/components/sarraaf/PricingManager.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../lib/AuthContext.js';
import {
  getAllProducts, seedProducts, updateProduct, deleteProduct,
  toggleProductActive, getChangeHistory, addProduct, getCategories,
} from '../../lib/pricingService.js';
import { Card, CardContent } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Label } from '../ui/label.js';
import { Switch } from '../ui/switch.js';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '../ui/dialog.js';
import {
  Tag, Plus, Search, Pencil, Trash2, History, TrendingUp, TrendingDown, Package,
} from 'lucide-react';
import PriceEditDialog from './PriceEditDialog.js';

const CURRENCY_LABELS = { AFN: 'افغانی', IRT: 'تومان', USD: 'دلار' };

/**
 * مدیریت قیمت خدمات و محصولات دیجیتال — پنل سازنده
 * سازنده می‌تواند قیمت پایه، درصد افزایش/کاهش و وضعیت هر محصول را مدیریت کند.
 * قیمت نهایی به‌صورت خودکار محاسبه و در پنل مشتری نمایش داده می‌شود.
 */
export default function PricingManager() {
  const { user } = useAuth();
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState('all');
  const [editProduct, setEditProduct] = useState(null);
  const [addOpen, setAddOpen] = useState(false);
  const [historyProduct, setHistoryProduct] = useState(null);

  const refresh = useCallback(() => {
    seedProducts();
    setProducts(getAllProducts());
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const categories = getCategories();

  const filtered = products.filter((p) => {
    const matchSearch = !search || p.name.includes(search) || (p.service_name || '').includes(search);
    const matchCat = filterCat === 'all' || p.category === filterCat;
    return matchSearch && matchCat;
  });

  const handleSave = (id, data) => {
    updateProduct(id, data, _optionalChain([user, 'optionalAccess', _ => _.full_name]) || 'سازنده');
    setEditProduct(null);
    refresh();
  };

  const handleToggle = (id) => {
    toggleProductActive(id, _optionalChain([user, 'optionalAccess', _2 => _2.full_name]) || 'سازنده');
    refresh();
  };

  const handleDelete = (id) => {
    if (confirm('آیا از حذف این محصول مطمئن هستید؟')) {
      deleteProduct(id);
      refresh();
    }
  };

  return (
    _jsxDEV(Card, { children: [
      _jsxDEV(CardContent, { className: "p-4 space-y-4" , children: [
        /* Header */
        _jsxDEV('div', { className: "flex items-center justify-between flex-wrap gap-2"    , children: [
          _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            _jsxDEV(Tag, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this )
            , _jsxDEV('h3', { className: "text-sm font-bold" , children: "مدیریت قیمت خدمات و محصولات"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 74}, this)
          , _jsxDEV(Button, { size: "sm", onClick: () => setAddOpen(true), children: [
            _jsxDEV(Plus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this ), "افزودن محصول جدید"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 78}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 73}, this)

        /* Filters */
        , _jsxDEV('div', { className: "flex gap-2 flex-wrap"  , children: [
          _jsxDEV('div', { className: "relative flex-1 min-w-[120px]"  , children: [
            _jsxDEV(Search, { className: "w-4 h-4 absolute right-2 top-1/2 -translate-y-1/2 text-gray-400"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this )
            , _jsxDEV(Input, {
              value: search,
              onChange: (e) => setSearch(e.target.value),
              placeholder: "جستجوی محصول..." ,
              className: "pr-8 h-9 text-sm"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 86}, this)
          , _jsxDEV('select', {
            value: filterCat,
            onChange: (e) => setFilterCat(e.target.value),
            className: "h-9 rounded-md border border-input bg-transparent px-2 text-sm"      ,
 children: [
            _jsxDEV('option', { value: "all", children: "همه دسته‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 100}, this)
            , categories.map((c) => (
              _jsxDEV('option', { value: c.key, children: c.name}, c.key, false, {fileName: _jsxFileName, lineNumber: 102}, this)
            ))
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 85}, this)

        /* Stats */
        , _jsxDEV('div', { className: "grid grid-cols-3 gap-2 text-center"   , children: [
          _jsxDEV('div', { className: "rounded-lg bg-muted p-2"  , children: [
            _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "کل محصولات" }, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this)
            , _jsxDEV('p', { className: "text-lg font-bold" , children: products.length.toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 109}, this)
          , _jsxDEV('div', { className: "rounded-lg bg-green-50 p-2"  , children: [
            _jsxDEV('p', { className: "text-[10px] text-green-600" , children: "فعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
            , _jsxDEV('p', { className: "text-lg font-bold text-green-700"  , children: 
              products.filter((p) => p.is_active).length.toLocaleString('fa-IR')
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 113}, this)
          , _jsxDEV('div', { className: "rounded-lg bg-amber-50 p-2"  , children: [
            _jsxDEV('p', { className: "text-[10px] text-amber-600" , children: "غیرفعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this)
            , _jsxDEV('p', { className: "text-lg font-bold text-amber-700"  , children: 
              products.filter((p) => !p.is_active).length.toLocaleString('fa-IR')
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 119}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 108}, this)

        /* Product List */
        , _jsxDEV('div', { className: "space-y-2", children: [
          filtered.length === 0 && (
            _jsxDEV('div', { className: "text-center py-8 text-sm text-muted-foreground"   , children: [
              _jsxDEV(Package, { className: "w-8 h-8 mx-auto mb-2 opacity-40"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this ), "محصولی یافت نشد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 130}, this)
          )
          , filtered.map((p) => (
            _jsxDEV('div', {

              className: `rounded-lg border p-3 ${p.is_active ? 'bg-white' : 'bg-gray-50 opacity-60'}`,
 children: 
              _jsxDEV('div', { className: "flex items-start justify-between gap-2"   , children: [
                _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
                  _jsxDEV('div', { className: "flex items-center gap-2 flex-wrap"   , children: [
                    _jsxDEV('span', { className: "text-sm font-semibold truncate"  , children: p.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this)
                    , _jsxDEV('span', { className: "text-[10px] bg-muted px-1.5 py-0.5 rounded text-muted-foreground"     , children: 
                      p.category_name
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this)
                    , p.pricing_mode === 'markup' ? (
                      _jsxDEV('span', { className: "text-[10px] text-green-600 flex items-center gap-0.5"    , children: [
                        _jsxDEV(TrendingUp, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this ), " +" , p.pricing_percent, "٪"
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 148}, this)
                    ) : (
                      _jsxDEV('span', { className: "text-[10px] text-red-600 flex items-center gap-0.5"    , children: [
                        _jsxDEV(TrendingDown, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 153}, this ), " −" , p.pricing_percent, "٪"
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 152}, this)
                    )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)
                  , _jsxDEV('div', { className: "flex items-center gap-3 mt-1 text-xs text-gray-500"     , children: [
                    _jsxDEV('span', { children: ["پایه: " , (p.base_price || 0).toLocaleString('fa-IR')]}, void 0, true, {fileName: _jsxFileName, lineNumber: 158}, this)
                    , _jsxDEV('span', { children: "→"}, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this)
                    , _jsxDEV('span', { className: "font-bold text-blue-700" , children: [
                      (p.final_price || 0).toLocaleString('fa-IR'), " " , CURRENCY_LABELS[p.currency] || ''
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 160}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 157}, this)
                  , p.description && (
                    _jsxDEV('p', { className: "text-[10px] text-gray-400 mt-1 truncate"   , children: p.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this)
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 141}, this)
                , _jsxDEV('div', { className: "flex items-center gap-1"  , children: [
                  _jsxDEV(Switch, {
                    checked: p.is_active,
                    onCheckedChange: () => handleToggle(p.id),}, void 0, false, {fileName: _jsxFileName, lineNumber: 169}, this
                  )
                  , _jsxDEV(Button, {
                    variant: "ghost", size: "icon", className: "h-7 w-7" ,
                    onClick: () => setHistoryProduct(p),
                    title: "سابقه تغییرات" ,
 children: 
                    _jsxDEV(History, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 173}, this)
                  , _jsxDEV(Button, {
                    variant: "ghost", size: "icon", className: "h-7 w-7" ,
                    onClick: () => setEditProduct(p),
                    title: "ویرایش قیمت" ,
 children: 
                    _jsxDEV(Pencil, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 185}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 180}, this)
                  , _jsxDEV(Button, {
                    variant: "ghost", size: "icon", className: "h-7 w-7 text-red-500"  ,
                    onClick: () => handleDelete(p.id),
                    title: "حذف",
 children: 
                    _jsxDEV(Trash2, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 192}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 168}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 140}, this)
            }, p.id, false, {fileName: _jsxFileName, lineNumber: 136}, this)
          ))
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 128}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 71}, this)

      /* Edit Dialog */
      , editProduct && (
        _jsxDEV(PriceEditDialog, {
          product: editProduct,
          onSave: handleSave,
          onClose: () => setEditProduct(null),}, void 0, false, {fileName: _jsxFileName, lineNumber: 203}, this
        )
      )

      /* Add Product Dialog */
      , addOpen && (
        _jsxDEV(AddProductDialog, {
          onClose: () => setAddOpen(false),
          onAdd: (data) => {
            addProduct(data);
            setAddOpen(false);
            refresh();
          },}, void 0, false, {fileName: _jsxFileName, lineNumber: 212}, this
        )
      )

      /* History Dialog */
      , historyProduct && (
        _jsxDEV(HistoryDialog, {
          product: historyProduct,
          onClose: () => setHistoryProduct(null),}, void 0, false, {fileName: _jsxFileName, lineNumber: 224}, this
        )
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 70}, this)
  );
}

// ── دیالوگ افزودن محصول جدید ──
function AddProductDialog({ onClose, onAdd }) {
  const [form, setForm] = useState({
    name: '',
    category: 'custom',
    category_name: 'سایر',
    service_name: '',
    product_type: 'Service',
    base_price: 0,
    currency: 'AFN',
    pricing_mode: 'markup',
    pricing_percent: 0,
    is_active: true,
    description: '',
  });

  const set = (key, val) => setForm((f) => ({ ...f, [key]: val }));

  return (
    _jsxDEV(Dialog, { open: true, onOpenChange: (o) => !o && onClose(), children: 
      _jsxDEV(DialogContent, { className: "max-w-md", children: [
        _jsxDEV(DialogHeader, { children: 
          _jsxDEV(DialogTitle, { children: "افزودن محصول جدید"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 255}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 254}, this)
        , _jsxDEV('div', { className: "space-y-3 max-h-[60vh] overflow-y-auto scrollbar-thin pl-1"    , children: [
          _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "نام محصول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 259}, this)
            , _jsxDEV(Input, {
              value: form.name,
              onChange: (e) => set('name', e.target.value),
              className: "mt-1 h-9" ,
              placeholder: "مثال: بسته اینترنت جدید"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 260}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 258}, this)
          , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "دسته‌بندی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 269}, this)
              , _jsxDEV(Input, {
                value: form.category_name,
                onChange: (e) => {
                  set('category_name', e.target.value);
                  set('category', e.target.value);
                },
                className: "mt-1 h-9 text-xs"  ,
                placeholder: "مثال: بازی‌ها" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 270}, this
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 268}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "نوع محصول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 281}, this)
              , _jsxDEV(Input, {
                value: form.product_type,
                onChange: (e) => set('product_type', e.target.value),
                className: "mt-1 h-9 text-xs"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 282}, this
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 280}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 267}, this)
          , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "قیمت پایه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 291}, this)
              , _jsxDEV(Input, {
                type: "number",
                value: form.base_price,
                onChange: (e) => set('base_price', e.target.value),
                className: "mt-1 h-9" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 292}, this
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 290}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "واحد پول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 300}, this)
              , _jsxDEV('select', {
                value: form.currency,
                onChange: (e) => set('currency', e.target.value),
                className: "mt-1 h-9 w-full rounded-md border border-input bg-transparent px-2 text-sm"        ,
 children: 
                Object.entries(CURRENCY_LABELS).map(([k, v]) => (
                  _jsxDEV('option', { value: k, children: v}, k, false, {fileName: _jsxFileName, lineNumber: 307}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 301}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 299}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 289}, this)
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "روش قیمت‌گذاری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 313}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2 mt-1"   , children: [
              _jsxDEV('button', {
                type: "button",
                onClick: () => set('pricing_mode', 'markup'),
                className: `py-2 rounded-md text-xs font-medium border transition ${
                  form.pricing_mode === 'markup'
                    ? 'bg-green-600 text-white border-green-600'
                    : 'bg-white text-gray-600 border-gray-300'
                }`,
 children: "افزایش درصدی"

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 315}, this)
              , _jsxDEV('button', {
                type: "button",
                onClick: () => set('pricing_mode', 'discount'),
                className: `py-2 rounded-md text-xs font-medium border transition ${
                  form.pricing_mode === 'discount'
                    ? 'bg-red-600 text-white border-red-600'
                    : 'bg-white text-gray-600 border-gray-300'
                }`,
 children: "کاهش درصدی"

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 326}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 314}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 312}, this)
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "درصد (٪)" }, void 0, false, {fileName: _jsxFileName, lineNumber: 340}, this)
            , _jsxDEV(Input, {
              type: "number",
              min: "0",
              max: "100",
              value: form.pricing_percent,
              onChange: (e) => set('pricing_percent', e.target.value),
              className: "mt-1 h-9" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 341}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 339}, this)
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "توضیحات (اختیاری)" }, void 0, false, {fileName: _jsxFileName, lineNumber: 351}, this)
            , _jsxDEV(Input, {
              value: form.description,
              onChange: (e) => set('description', e.target.value),
              className: "mt-1 h-9 text-xs"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 352}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 350}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 257}, this)
        , _jsxDEV(DialogFooter, { className: "gap-2", children: [
          _jsxDEV(Button, { variant: "outline", size: "sm", onClick: onClose, children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 360}, this)
          , _jsxDEV(Button, {
            size: "sm",
            onClick: () => onAdd(form),
            disabled: !form.name,
 children: "افزودن محصول"

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 361}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 359}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 253}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 252}, this)
  );
}

// ── دیالوگ سابقه تغییرات ──
function HistoryDialog({ product, onClose }) {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    setHistory(getChangeHistory(product.id));
  }, [product.id]);

  return (
    _jsxDEV(Dialog, { open: true, onOpenChange: (o) => !o && onClose(), children: 
      _jsxDEV(DialogContent, { className: "max-w-md", children: [
        _jsxDEV(DialogHeader, { children: 
          _jsxDEV(DialogTitle, { children: "سابقه تغییرات قیمت"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 386}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 385}, this)
        , _jsxDEV('div', { className: "space-y-2 max-h-[60vh] overflow-y-auto scrollbar-thin"   , children: [
          _jsxDEV('p', { className: "text-sm font-medium" , children: product.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 389}, this)
          , history.length === 0 ? (
            _jsxDEV('p', { className: "text-center text-sm text-muted-foreground py-6"   , children: "تغییراتی ثبت نشده است"

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 391}, this)
          ) : (
            history.map((h) => (
              _jsxDEV('div', { className: "rounded-lg border p-2 text-xs space-y-1"    , children: [
                _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
                  _jsxDEV('span', { className: "text-gray-500", children: 
                    new Date(h.timestamp).toLocaleString('fa-IR')
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 398}, this)
                  , _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: h.changed_by}, void 0, false, {fileName: _jsxFileName, lineNumber: 401}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 397}, this)
                , _jsxDEV('div', { className: "flex items-center gap-2 flex-wrap"   , children: [
                  _jsxDEV('span', { className: "text-gray-500", children: "قیمت:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 404}, this)
                  , _jsxDEV('span', { className: "line-through text-gray-400" , children: 
                    (h.old_final_price || 0).toLocaleString('fa-IR')
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 405}, this)
                  , _jsxDEV('span', { children: "→"}, void 0, false, {fileName: _jsxFileName, lineNumber: 408}, this)
                  , _jsxDEV('span', { className: "font-bold text-blue-700" , children: 
                    (h.new_final_price || 0).toLocaleString('fa-IR')
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 409}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 403}, this)
                , _jsxDEV('div', { className: "text-[10px] text-gray-400" , children: ["درصد: "
                   , h.old_percent, "٪ (" , h.old_mode === 'markup' ? 'افزایش' : 'کاهش', ") → "
                   , h.new_percent, "٪ (" , h.new_mode === 'markup' ? 'افزایش' : 'کاهش', ")"
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 413}, this)
              ]}, h.id, true, {fileName: _jsxFileName, lineNumber: 396}, this)
            ))
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 388}, this)
        , _jsxDEV(DialogFooter, { children: 
          _jsxDEV(Button, { variant: "outline", size: "sm", onClick: onClose, children: "بستن"}, void 0, false, {fileName: _jsxFileName, lineNumber: 422}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 421}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 384}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 383}, this)
  );
}