const _jsxFileName = "src/components/sarraaf/SupportPanel.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card.js';
import { Button } from '../ui/button.js';
import { Input } from '../ui/input.js';
import { Label } from '../ui/label.js';
import { Textarea } from '../ui/textarea.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select.js';
import { Loader2, Send, MessageSquare, Clock } from 'lucide-react';
import { createTicket, getTickets, addTicketMessage, getTicketMessages, TICKET_CATEGORIES, TICKET_PRIORITIES, TICKET_STATUSES } from '../../lib/supportSystem.js';
import { useToast } from '../ui/use-toast.js';
import { useAuth } from '../../lib/AuthContext.js';

export default function SupportPanel() {
  const { user } = useAuth();
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ subject: '', description: '', category: 'general', priority: 'normal' });
  const { toast } = useToast();

  useEffect(() => {
    load();
  }, [_optionalChain([user, 'optionalAccess', _ => _.id])]);

  async function load() {
    if (!_optionalChain([user, 'optionalAccess', _2 => _2.id])) return;
    setLoading(true);
    const list = await getTickets(user.id);
    setTickets(list);
    setLoading(false);
  }

  async function handleCreate() {
    if (!form.subject || !form.description) {
      toast({ title: 'خطا', description: 'موضوع و توضیحات الزامی است', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    await createTicket({
      userId: user.id,
      exchangeCode: user.exchange_code || '',
      ...form,
    });
    toast({ title: 'موفق', description: 'تیکت شما ثبت شد' });
    setForm({ subject: '', description: '', category: 'general', priority: 'normal' });
    setShowForm(false);
    setSubmitting(false);
    load();
  }

  async function loadMessages(ticketId) {
    const msgs = await getTicketMessages(ticketId);
    setMessages(msgs);
  }

  async function handleSendMessage() {
    if (!newMessage || !selectedTicket) return;
    await addTicketMessage({
      ticketId: selectedTicket.id,
      senderId: user.id,
      senderName: user.full_name || user.email,
      message: newMessage,
    });
    setNewMessage('');
    loadMessages(selectedTicket.id);
  }

  const statusLabel = (s) => _optionalChain([TICKET_STATUSES, 'access', _3 => _3.find, 'call', _4 => _4(x => x.value === s), 'optionalAccess', _5 => _5.label]) || s;

  if (loading) {
    return (
      _jsxDEV('div', { className: "flex items-center justify-center py-8"   , children: 
        _jsxDEV(Loader2, { className: "w-5 h-5 animate-spin text-primary"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)
    );
  }

  if (selectedTicket) {
    return (
      _jsxDEV(Card, { children: [
        _jsxDEV(CardHeader, { children: 
          _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
            _jsxDEV(CardTitle, { className: "text-sm", children: selectedTicket.subject}, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this)
            , _jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => setSelectedTicket(null), children: "بستن"}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 86}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this)
        , _jsxDEV(CardContent, { className: "space-y-3", children: [
          _jsxDEV('div', { className: "space-y-2 max-h-[300px] overflow-y-auto scrollbar-thin"   , children: [
            messages.map((m) => (
              _jsxDEV('div', { className: `flex ${m.sender_id === user.id ? 'justify-end' : 'justify-start'}`, children: 
                _jsxDEV('div', { className: `max-w-[75%] rounded-lg px-3 py-2 text-xs ${m.sender_id === user.id ? 'bg-primary text-primary-foreground' : 'bg-muted'}`, children: [
                  _jsxDEV('p', { className: "font-medium mb-1" , children: m.sender_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this)
                  , _jsxDEV('p', { children: m.message}, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)
              }, m.id, false, {fileName: _jsxFileName, lineNumber: 94}, this)
            ))
            , messages.length === 0 && _jsxDEV('p', { className: "text-center text-xs text-muted-foreground py-4"   , children: "پیامی وجود ندارد"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 92}, this)
          , _jsxDEV('div', { className: "flex gap-2" , children: [
            _jsxDEV(Input, {
              value: newMessage,
              onChange: (e) => setNewMessage(e.target.value),
              placeholder: "پاسخ...",
              className: "h-8 text-sm" ,
              onKeyDown: (e) => e.key === 'Enter' && handleSendMessage(),}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this
            )
            , _jsxDEV(Button, { size: "icon", onClick: handleSendMessage, children: 
              _jsxDEV(Send, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 103}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 91}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 84}, this)
    );
  }

  return (
    _jsxDEV(Card, { children: [
      _jsxDEV(CardHeader, { children: 
        _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
          _jsxDEV(CardTitle, { className: "text-sm flex items-center gap-2"   , children: [
            _jsxDEV(MessageSquare, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this ), "پشتیبانی"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 124}, this)
          , _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => setShowForm(!showForm), children: 
            showForm ? 'بستن' : 'تیکت جدید'
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 128}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 123}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this)
      , _jsxDEV(CardContent, { className: "space-y-3", children: [
        showForm && (
          _jsxDEV('div', { className: "space-y-2 p-3 rounded-lg border border-border"    , children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "موضوع"}, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this)
              , _jsxDEV(Input, { value: form.subject, onChange: (e) => setForm({ ...form, subject: e.target.value }), className: "h-8 text-sm mt-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 136}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs", children: "توضیحات"}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this)
              , _jsxDEV(Textarea, { value: form.description, onChange: (e) => setForm({ ...form, description: e.target.value }), className: "text-sm mt-1 min-h-[60px]"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 140}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { className: "text-xs", children: "دسته‌بندی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this)
                , _jsxDEV(Select, { value: form.category, onValueChange: (v) => setForm({ ...form, category: v }), children: [
                  _jsxDEV(SelectTrigger, { className: "h-8 text-sm mt-1"  , children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this)
                  , _jsxDEV(SelectContent, { children: 
                    TICKET_CATEGORIES.map(c => _jsxDEV(SelectItem, { value: c.value, children: c.label}, c.value, false, {fileName: _jsxFileName, lineNumber: 150}, this))
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 145}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { className: "text-xs", children: "اولویت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 155}, this)
                , _jsxDEV(Select, { value: form.priority, onValueChange: (v) => setForm({ ...form, priority: v }), children: [
                  _jsxDEV(SelectTrigger, { className: "h-8 text-sm mt-1"  , children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this)
                  , _jsxDEV(SelectContent, { children: 
                    TICKET_PRIORITIES.map(p => _jsxDEV(SelectItem, { value: p.value, children: p.label}, p.value, false, {fileName: _jsxFileName, lineNumber: 159}, this))
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 156}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 154}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 144}, this)
            , _jsxDEV(Button, { onClick: handleCreate, disabled: submitting, className: "w-full", size: "sm", children: [
              submitting ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this ) : _jsxDEV(Send, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this ), "ثبت تیکت"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 164}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 135}, this)
        )

        , tickets.length === 0 ? (
          _jsxDEV('p', { className: "text-center text-xs text-muted-foreground py-6"   , children: "تیکتی ثبت نشده است"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 172}, this)
        ) : (
          _jsxDEV('div', { className: "space-y-2", children: 
            tickets.map((t) => (
              _jsxDEV('button', {

                onClick: () => { setSelectedTicket(t); loadMessages(t.id); },
                className: "w-full text-right p-2.5 rounded-lg border border-border hover:bg-muted/50 transition-colors"       ,
 children: [
                _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
                  _jsxDEV('span', { className: "text-xs font-medium truncate"  , children: t.subject}, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this)
                  , _jsxDEV('span', { className: `text-[10px] px-1.5 py-0.5 rounded ${t.status === 'open' ? 'bg-blue-100 text-blue-700' : t.status === 'resolved' ? 'bg-green-100 text-green-700' : 'bg-muted text-muted-foreground'}`, children: 
                    statusLabel(t.status)
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 183}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 181}, this)
                , _jsxDEV('div', { className: "flex items-center gap-1 mt-1"   , children: [
                  _jsxDEV(Clock, { className: "w-3 h-3 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 188}, this )
                  , _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: t.ticket_number}, void 0, false, {fileName: _jsxFileName, lineNumber: 189}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 187}, this)
              ]}, t.id, true, {fileName: _jsxFileName, lineNumber: 176}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 174}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 133}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 121}, this)
  );
}