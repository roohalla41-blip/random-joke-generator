const _jsxFileName = "src/components/UserNotRegisteredError.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';

const UserNotRegisteredError = () => {
  return (
    _jsxDEV('div', { className: "flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-white to-slate-50"       , children: 
      _jsxDEV('div', { className: "max-w-md w-full p-8 bg-white rounded-lg shadow-lg border border-slate-100"       , children: 
        _jsxDEV('div', { className: "text-center", children: [
          _jsxDEV('div', { className: "inline-flex items-center justify-center w-16 h-16 mb-6 rounded-full bg-orange-100"       , children: 
            _jsxDEV('svg', { className: "w-8 h-8 text-orange-600"  , fill: "none", stroke: "currentColor", viewBox: "0 0 24 24"   , children: 
              _jsxDEV('path', { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"             ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 10}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 9}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 8}, this)
          , _jsxDEV('h1', { className: "text-3xl font-bold text-slate-900 mb-4"   , children: "Access Restricted" }, void 0, false, {fileName: _jsxFileName, lineNumber: 13}, this)
          , _jsxDEV('p', { className: "text-slate-600 mb-8" , children: "You are not registered to use this application. Please contact the app administrator to request access."

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 14}, this)
          , _jsxDEV('div', { className: "p-4 bg-slate-50 rounded-md text-sm text-slate-600"    , children: [
            _jsxDEV('p', { children: "If you believe this is an error, you can:"        }, void 0, false, {fileName: _jsxFileName, lineNumber: 18}, this)
            , _jsxDEV('ul', { className: "list-disc list-inside mt-2 space-y-1"   , children: [
              _jsxDEV('li', { children: "Verify you are logged in with the correct account"        }, void 0, false, {fileName: _jsxFileName, lineNumber: 20}, this)
              , _jsxDEV('li', { children: "Contact the app administrator for access"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 21}, this)
              , _jsxDEV('li', { children: "Try logging out and back in again"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 22}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 19}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 17}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 7}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 6}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 5}, this)
  );
};

export default UserNotRegisteredError;
