const _jsxFileName = "src/components/FeaturesManagement.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState } from 'react';
import { useFeatures } from '../hooks/useFeatures.js';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card.js';
import { Button } from './ui/button.js';
import { Input } from './ui/input.js';
import { Badge } from './ui/badge.js';
import { Switch } from './ui/switch.js';
import { Power, Edit, Check, X, ArrowUp, ArrowDown, Loader2 } from 'lucide-react';

export default function FeaturesManagement({ lang }) {
  const isEnglish = lang === 'english';
  const { features, loading, toggleFeature, renameFeature, reorderFeature } = useFeatures();
  const [editing, setEditing] = useState(null);
  const [editName, setEditName] = useState('');

  const sorted = [...features].sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

  const startEdit = (f) => {
    setEditing(f.feature_key);
    setEditName(f.feature_name);
  };

  const saveEdit = () => {
    if (editName.trim()) {
      renameFeature(editing, editName.trim());
    }
    setEditing(null);
    setEditName('');
  };

  const moveUp = (f, idx) => {
    if (idx === 0) return;
    reorderFeature(f.feature_key, f.sort_order - 1);
  };

  const moveDown = (f, idx) => {
    if (idx === sorted.length - 1) return;
    reorderFeature(f.feature_key, f.sort_order + 1);
  };

  return (
    _jsxDEV(Card, { children: [
      _jsxDEV(CardHeader, { children: 
        _jsxDEV(CardTitle, { className: "text-base flex items-center gap-2"   , children: [
          _jsxDEV(Power, { className: "w-4 h-4 text-indigo-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 45}, this )
          , isEnglish ? 'Feature Management' : 'مدیریت قابلیت‌ها'
          , _jsxDEV(Badge, { variant: "secondary", className: "text-xs", children: features.length}, void 0, false, {fileName: _jsxFileName, lineNumber: 47}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 44}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this)
      , _jsxDEV(CardContent, { children: [
        loading ? (
          _jsxDEV('div', { className: "flex items-center justify-center py-8"   , children: 
            _jsxDEV(Loader2, { className: "w-6 h-6 animate-spin text-slate-400"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 53}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 52}, this)
        ) : sorted.length === 0 ? (
          _jsxDEV('p', { className: "text-center text-sm text-slate-400 py-6"   , children: 
            isEnglish ? 'No features configured' : 'قابلیتی تنظیم نشده است'
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
        ) : (
          _jsxDEV('div', { className: "space-y-2", children: 
            sorted.map((f, idx) => (
              _jsxDEV('div', { className: "flex items-center gap-3 p-3 rounded-lg bg-slate-50 border border-slate-100"       , children: [
                _jsxDEV('div', { className: "flex flex-col gap-0.5"  , children: [
                  _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-6 w-6 p-0"  , onClick: () => moveUp(f, idx), disabled: idx === 0, children: 
                    _jsxDEV(ArrowUp, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
                  , _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-6 w-6 p-0"  , onClick: () => moveDown(f, idx), disabled: idx === sorted.length - 1, children: 
                    _jsxDEV(ArrowDown, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 63}, this)

                , _jsxDEV('div', { className: "flex-1 min-w-0" , children: 
                  editing === f.feature_key ? (
                    _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                      _jsxDEV(Input, {
                        value: editName,
                        onChange: (e) => setEditName(e.target.value),
                        onKeyDown: (e) => e.key === 'Enter' && saveEdit(),
                        className: "h-8 text-sm" ,
                        autoFocus: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this
                      )
                      , _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-8 w-8 p-0"  , onClick: saveEdit, children: 
                        _jsxDEV(Check, { className: "w-4 h-4 text-emerald-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this )
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this)
                      , _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-8 w-8 p-0"  , onClick: () => setEditing(null), children: 
                        _jsxDEV(X, { className: "w-4 h-4 text-red-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this )
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 74}, this)
                  ) : (
                    _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                      _jsxDEV('span', { className: "text-sm font-medium text-slate-800"  , children: f.feature_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 91}, this)
                      , _jsxDEV(Badge, { variant: "outline", className: "text-[10px] font-mono" , children: f.feature_key}, void 0, false, {fileName: _jsxFileName, lineNumber: 92}, this)
                      , f.category === 'customer' && (
                        _jsxDEV(Badge, { variant: "secondary", className: "text-[10px]", children: isEnglish ? 'Customer' : 'مشتری'}, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this)
                      )
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 90}, this)
                  )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this)

                , editing !== f.feature_key && (
                  _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-8 w-8 p-0"  , onClick: () => startEdit(f), children: 
                    _jsxDEV(Edit, { className: "w-4 h-4 text-slate-500"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this)
                )

                , _jsxDEV(Switch, {
                  checked: f.status === 'active',
                  onCheckedChange: (checked) => toggleFeature(f.feature_key, checked ? 'active' : 'inactive'),}, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this
                )
              ]}, f.feature_key, true, {fileName: _jsxFileName, lineNumber: 62}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)
        )
        , _jsxDEV('p', { className: "text-xs text-slate-400 mt-4"  , children: 
          isEnglish
            ? 'Toggle features on/off, rename, and reorder. Changes apply instantly to the exchange panel.'
            : 'قابلیت‌ها را فعال/غیرفعال کنید، نام تغییر دهید و مرتب کنید. تغییرات بلافاصله در پنل صراف اعمال می‌شود.'
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 50}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 42}, this)
  );
}