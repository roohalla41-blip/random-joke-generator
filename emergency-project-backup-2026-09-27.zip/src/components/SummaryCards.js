const _jsxFileName = "src/components/SummaryCards.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { useAuth } from '../lib/AuthContext.js';
import { useLanguage } from '../lib/i18n.js';
import { offlineDB } from '../lib/offlineQueue.js';
import { Card, CardContent } from './ui/card.js';
import { Wallet, TrendingUp, Send, Users, Loader2 } from 'lucide-react';

const DEFAULT_CURRENCIES = ['AFN', 'USD', 'IRR', 'TMN', 'KLD', 'EUR'];

export default function SummaryCards() {
  const { user } = useAuth();
  const { t, lang } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [treasury, setTreasury] = useState({});
  const [todayProfit, setTodayProfit] = useState(0);
  const [todayTransfers, setTodayTransfers] = useState(0);
  const [customers, setCustomers] = useState(0);

  useEffect(() => {
    const code = _optionalChain([user, 'optionalAccess', _ => _.exchange_code]);
    if (!code) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const today = new Date();
        const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate()).toISOString();
        const [txs, transfers, custs] = await Promise.all([
          offlineDB.list('Transaction').catch(() => []),
          offlineDB.list('Transfer').catch(() => []),
          offlineDB.list('Customer').catch(() => []),
        ]);
        if (cancelled) return;
        const bal = {};
        (txs || []).forEach(t => {
          const c = t.currency || 'AFN';
          bal[c] = (bal[c] || 0) + (t.amount || 0);
        });
        const todayTrans = (transfers || []).filter(t => t.created_date && new Date(t.created_date) >= todayStart).length;
        const profit = (txs || []).filter(t => t.type === 'trade' && t.created_date && new Date(t.created_date) >= todayStart)
          .reduce((s, t) => s + ((t.sell_amount - t.buy_amount) || 0), 0);
        setTreasury(bal);
        setTodayProfit(profit);
        setTodayTransfers(todayTrans);
        setCustomers((custs || []).length);
      } catch (e) {
        // ignore — values stay at defaults
      }
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [_optionalChain([user, 'optionalAccess', _2 => _2.exchange_code])]);

  const treasuryTotal = Object.values(treasury).reduce((s, v) => s + (v || 0), 0);

  const cards = [
    {
      icon: Wallet,
      label: t('treasury.current_balance'),
      value: loading ? null : `${formatNum(treasuryTotal)}`,
      sub: loading ? '' : `${Object.keys(treasury).length || DEFAULT_CURRENCIES.length} ${t('common.currency')}`,
      gradient: 'from-success to-success/80',
    },
    {
      icon: TrendingUp,
      label: lang === 'english' ? "Today's Profit" : 'سود امروز',
      value: loading ? null : `${formatNum(todayProfit)}`,
      sub: '',
      gradient: 'from-primary to-primary/80',
    },
    {
      icon: Send,
      label: lang === 'english' ? "Today's Transfers" : 'حواله امروز',
      value: loading ? null : `${todayTransfers}`,
      sub: '',
      gradient: 'from-chart-2 to-chart-2/80',
    },
    {
      icon: Users,
      label: t('menu.customers'),
      value: loading ? null : `${customers}`,
      sub: '',
      gradient: 'from-warning to-warning/80',
    },
  ];

  return (
    _jsxDEV('div', { className: "grid grid-cols-2 sm:grid-cols-4 gap-3"   , children: 
      cards.map((c, i) => {
        const Icon = c.icon;
        return (
          _jsxDEV(Card, { className: "overflow-hidden border-0 shadow-sm"  , children: 
            _jsxDEV(CardContent, { className: `p-4 bg-gradient-to-br ${c.gradient} text-white`, children: [
              _jsxDEV('div', { className: "flex items-center justify-between mb-2"   , children: [
                _jsxDEV('span', { className: "text-xs font-medium opacity-90"  , children: c.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)
                , _jsxDEV(Icon, { className: "w-4 h-4 opacity-80"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 96}, this)
              , loading ? (
                _jsxDEV(Loader2, { className: "w-5 h-5 animate-spin opacity-70"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this )
              ) : (
                _jsxDEV(_Fragment, { children: [
                  _jsxDEV('p', { className: "text-2xl font-bold leading-tight"  , children: c.value}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this)
                  , c.sub && _jsxDEV('p', { className: "text-xs opacity-75 mt-0.5"  , children: c.sub}, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 103}, this)
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)
          }, i, false, {fileName: _jsxFileName, lineNumber: 94}, this)
        );
      })
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this)
  );
}

function formatNum(n) {
  return new Intl.NumberFormat('en-US').format(Math.round(n || 0));
}