const _jsxFileName = "src/main.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.js'
/* XCODX inlined CSS: src/index.css */
;(function(){
  if (typeof document === "undefined") return;
  var __id = "xcodx-css-63182685";
  if (document.getElementById(__id)) return;
  var __el = document.createElement("style");
  __el.id = __id;
  var __css = "@import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap');\n\n@tailwind base;\n@tailwind components;\n@tailwind utilities;\n\n@layer base {\n  :root {\n    /* ── Surfaces ── */\n    --background: 220 25% 97%;\n    --foreground: 222 47% 11%;\n    --card: 0 0% 100%;\n    --card-foreground: 222 47% 11%;\n    --popover: 0 0% 100%;\n    --popover-foreground: 222 47% 11%;\n    --muted: 220 20% 94%;\n    --muted-foreground: 220 10% 46%;\n    --accent: 220 20% 94%;\n    --accent-foreground: 222 47% 11%;\n\n    /* ── Brand: Professional Indigo ── */\n    --primary: 235 70% 56%;\n    --primary-foreground: 0 0% 100%;\n    --secondary: 220 18% 90%;\n    --secondary-foreground: 222 47% 11%;\n\n    /* ── Semantic ── */\n    --destructive: 0 72% 51%;\n    --destructive-foreground: 0 0% 100%;\n    --success: 152 56% 40%;\n    --success-foreground: 0 0% 100%;\n    --warning: 36 92% 50%;\n    --warning-foreground: 0 0% 100%;\n    --info: 199 80% 48%;\n    --info-foreground: 0 0% 100%;\n\n    /* ── Borders & Inputs ── */\n    --border: 220 18% 88%;\n    --input: 220 18% 88%;\n    --ring: 235 70% 56%;\n\n    /* ── Charts ── */\n    --chart-1: 235 70% 56%;\n    --chart-2: 152 56% 40%;\n    --chart-3: 36 92% 50%;\n    --chart-4: 280 60% 55%;\n    --chart-5: 340 70% 55%;\n\n    --radius: 0.625rem;\n\n    /* ── Typography ── */\n    --font-heading: 'Vazirmatn', ui-sans-serif, system-ui, sans-serif;\n    --font-body: 'Vazirmatn', ui-sans-serif, system-ui, sans-serif;\n    --font-display: 'Vazirmatn', ui-sans-serif, system-ui, sans-serif;\n    --font-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace;\n\n    /* ── Sidebar ── */\n    --sidebar-background: 0 0% 100%;\n    --sidebar-foreground: 222 47% 11%;\n    --sidebar-primary: 235 70% 56%;\n    --sidebar-primary-foreground: 0 0% 100%;\n    --sidebar-accent: 220 20% 94%;\n    --sidebar-accent-foreground: 222 47% 11%;\n    --sidebar-border: 220 18% 88%;\n    --sidebar-ring: 235 70% 56%;\n  }\n\n  .dark {\n    /* ── Surfaces ── */\n    --background: 224 32% 9%;\n    --foreground: 210 30% 96%;\n    --card: 222 28% 12%;\n    --card-foreground: 210 30% 96%;\n    --popover: 222 28% 12%;\n    --popover-foreground: 210 30% 96%;\n    --muted: 220 20% 16%;\n    --muted-foreground: 215 18% 60%;\n    --accent: 220 20% 16%;\n    --accent-foreground: 210 30% 96%;\n\n    /* ── Brand ── */\n    --primary: 235 70% 62%;\n    --primary-foreground: 0 0% 100%;\n    --secondary: 220 18% 18%;\n    --secondary-foreground: 210 30% 96%;\n\n    /* ── Semantic ── */\n    --destructive: 0 63% 45%;\n    --destructive-foreground: 0 0% 98%;\n    --success: 152 50% 45%;\n    --success-foreground: 0 0% 100%;\n    --warning: 36 92% 55%;\n    --warning-foreground: 0 0% 100%;\n    --info: 199 80% 52%;\n    --info-foreground: 0 0% 100%;\n\n    /* ── Borders & Inputs ── */\n    --border: 220 18% 20%;\n    --input: 220 18% 20%;\n    --ring: 235 70% 62%;\n\n    /* ── Charts ── */\n    --chart-1: 235 70% 62%;\n    --chart-2: 152 50% 45%;\n    --chart-3: 36 92% 55%;\n    --chart-4: 280 60% 60%;\n    --chart-5: 340 70% 55%;\n\n    /* ── Sidebar ── */\n    --sidebar-background: 222 28% 12%;\n    --sidebar-foreground: 210 30% 96%;\n    --sidebar-primary: 235 70% 62%;\n    --sidebar-primary-foreground: 0 0% 100%;\n    --sidebar-accent: 220 20% 16%;\n    --sidebar-accent-foreground: 210 30% 96%;\n    --sidebar-border: 220 18% 20%;\n    --sidebar-ring: 235 70% 62%;\n  }\n}\n\n@layer base {\n  * {\n    @apply border-border outline-ring/50;\n  }\n\n  html,\n  body {\n    overscroll-behavior-y: none;\n  }\n\n  body {\n    @apply bg-background text-foreground font-body antialiased;\n  }\n\n  button,\n  a,\n  [role=\"button\"],\n  svg,\n  icon {\n    -webkit-user-select: none;\n    user-select: none;\n    -webkit-tap-highlight-color: transparent;\n  }\n}\n\n@layer utilities {\n  .scrollbar-thin {\n    scrollbar-width: thin;\n  }\n  .scrollbar-thin::-webkit-scrollbar {\n    width: 4px;\n    height: 4px;\n  }\n  .scrollbar-thin::-webkit-scrollbar-thumb {\n    @apply bg-muted-foreground/30 rounded-full;\n  }\n  .scrollbar-thin::-webkit-scrollbar-track {\n    @apply bg-transparent;\n  }\n\n  /* Professional card shadows */\n  .shadow-card {\n    box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.06), 0 1px 2px 0 rgb(0 0 0 / 0.04);\n  }\n  .shadow-card-hover {\n    box-shadow: 0 4px 12px 0 rgb(0 0 0 / 0.08), 0 2px 4px 0 rgb(0 0 0 / 0.04);\n  }\n  .dark .shadow-card {\n    box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.3), 0 1px 2px 0 rgb(0 0 0 / 0.2);\n  }\n  .dark .shadow-card-hover {\n    box-shadow: 0 4px 12px 0 rgb(0 0 0 / 0.4), 0 2px 4px 0 rgb(0 0 0 / 0.3);\n  }\n}"; try { if (/url\(/i.test(__css) && import.meta.url) { var __base = new URL("../src/", import.meta.url); var __root = new URL("../", import.meta.url); __css = __css.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, function (m, q, ref) { if (/^(?:data:|blob:|https?:|\/\/|#)/i.test(ref)) return m; try { var u = ref.charAt(0) === "/" ? new URL(ref.slice(1), __root) : new URL(ref, __base); return 'url("' + u.href + '")'; } catch (e) { return m; } }); } } catch (e) {}
  __el.textContent = __css;
  document.head.appendChild(__el);
})();

// Global error handler — catches errors that escape React's error boundary
// (e.g. errors thrown by providers wrapping the boundary)
window.addEventListener('error', (event) => {
  console.error('Global error:', event.error || event.message);
  showFatalError(_optionalChain([event, 'access', _ => _.error, 'optionalAccess', _2 => _2.message]) || event.message || 'Unknown error');
});
window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled promise rejection:', event.reason);
});

function showFatalError(message) {
  const root = document.getElementById('root');
  if (root && root.children.length === 0) {
    root.innerHTML = `
      <div dir="rtl" style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem;font-family:sans-serif;background:#f8fafc;">
        <div style="max-width:28rem;width:100%;text-align:center;padding:1.5rem;background:white;border-radius:0.75rem;box-shadow:0 4px 6px -1px rgba(0,0,0,0.1);">
          <h1 style="font-size:1.25rem;font-weight:bold;color:#dc2626;margin-bottom:0.5rem;">خطای بارگذاری برنامه</h1>
          <p style="font-size:0.875rem;color:#64748b;margin-bottom:1rem;">برنامه با خطا مواجه شد. لطفاً صفحه را بازخوانی کنید.</p>
          <pre style="font-size:0.75rem;color:#475569;background:#f1f5f9;padding:0.5rem;border-radius:0.375rem;overflow:auto;text-align:right;direction:ltr;white-space:pre-wrap;word-break:break-all;">${(message || '').toString().slice(0, 500)}</pre>
          <button onclick="location.reload()" style="margin-top:1rem;padding:0.5rem 1rem;background:#3b46f6;color:white;border:none;border-radius:0.375rem;cursor:pointer;font-size:0.875rem;">بازخوانی</button>
        </div>
      </div>
    `;
  }
}

ReactDOM.createRoot(document.getElementById('root')).render(
  _jsxDEV(App, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 33}, this )
)