const _jsxFileName = "src/App.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import { Toaster } from "./components/ui/toaster.js"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from './lib/query-client.js'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import { AuthProvider } from './lib/AuthContext.js';
import { LanguageProvider } from './lib/i18n.js';
import { UpgradeProvider } from './lib/UpgradeContext.js';
import ScrollToTop from './components/ScrollToTop.js';
import AppGate from './components/AppGate.js';
import ErrorBoundary from './components/ErrorBoundary.js';
import ProtectedRoute from './components/ProtectedRoute.js';
import AdminRoute from './components/AdminRoute.js';
// Page imports
import Welcome from './pages/Welcome.js';
import Login from './pages/Login.js';
import Register from './pages/Register.js';
import ForgotPassword from './pages/ForgotPassword.js';
import ResetPassword from './pages/ResetPassword.js';
import Dashboard from './pages/Dashboard.js';
import Customers from './pages/Customers.js';
import CustomerDetail from './pages/CustomerDetail.js';
import Dadogereft from './pages/Dadogereft.js';
import Trade from './pages/Trade.js';
import Transfer from './pages/Transfer.js';
import Cash from './pages/Cash.js';
import Bank from './pages/Bank.js';
import Currencies from './pages/Currencies.js';
import Reports from './pages/Reports.js';
import ProfitLoss from './pages/ProfitLoss.js';
import Settings from './pages/Settings.js';
import MainSettings from './pages/MainSettings.js';
import Agents from './pages/Agents.js';
import Debtors from './pages/Debtors.js';
import Notifications from './pages/Notifications.js';
import AgencyNetwork from './pages/AgencyNetwork.js';
import AgencyChooser from './pages/AgencyChooser.js';
import ChatGroups from './pages/ChatGroups.js';
import ChatGroupDetail from './pages/ChatGroupDetail.js';
import SarraafMarket from './pages/SarraafMarket.js';
import SarraafChat from './pages/SarraafChat.js';
import Backup from './pages/Backup.js';
import CustomerChat from './pages/CustomerChat.js';
import TransferBook from './pages/TransferBook.js';
import Journal from './pages/Journal.js';
import GeneralLedger from './pages/GeneralLedger.js';
import JournalEntry from './pages/JournalEntry.js';
import BalanceSheet from './pages/BalanceSheet.js';
import Reconciliation from './pages/Reconciliation.js';
import CurrencyConvert from './pages/CurrencyConvert.js';
import OnlineProducts from './pages/OnlineProducts.js';
import PaymentGateway from './pages/PaymentGateway.js';
import SarraafWallet from './pages/sarraaf/SarraafWallet.js';
import SarraafRecharge from './pages/sarraaf/SarraafRecharge.js';
import SarraafGames from './pages/sarraaf/SarraafGames.js';
import BuilderPanel from './pages/BuilderPanel.js';
import SarraafSupport from './pages/SarraafSupport.js';
import CustomerLayout from './components/CustomerLayout.js';
import CustomerHome from './pages/customer/CustomerHome.js';
import CustomerWallet from './pages/customer/CustomerWallet.js';
import CustomerRecharge from './pages/customer/CustomerRecharge.js';
import CustomerGames from './pages/customer/CustomerGames.js';
import CustomerTransfer from './pages/customer/CustomerTransfer.js';
import CustomerWithdraw from './pages/customer/CustomerWithdraw.js';
import CustomerSupport from './pages/customer/CustomerSupport.js';
import CustomerAccount from './pages/customer/CustomerAccount.js';
import CustomerOrders from './pages/customer/CustomerOrders.js';
import CustomerMessages from './pages/customer/CustomerMessages.js';
import CustomerNotifications from './pages/customer/CustomerNotifications.js';
import CustomerProfile from './pages/customer/CustomerProfile.js';
import Receipt from './pages/Receipt.js';
import PageNotFound from './lib/PageNotFound.js';
import SetupDatabase from './pages/SetupDatabase.js';
// Layout
import Layout from './components/sarraaf/Layout.js';

const AppRoutes = () => {
  return (
    _jsxDEV(Routes, { children: [
      /* Public */
      _jsxDEV(Route, { path: "/", element: _jsxDEV(Welcome, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this )
      , _jsxDEV(Route, { path: "/setup-database", element: _jsxDEV(SetupDatabase, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this )
      , _jsxDEV(Route, { path: "/login", element: _jsxDEV(Login, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this )
      , _jsxDEV(Route, { path: "/register", element: _jsxDEV(Register, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this )
      , _jsxDEV(Route, { path: "/forgot-password", element: _jsxDEV(ForgotPassword, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this )
      , _jsxDEV(Route, { path: "/reset-password", element: _jsxDEV(ResetPassword, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this )

      /* Sarraaf Panel — gated by auth + role */
      , _jsxDEV(Route, { element: _jsxDEV(ProtectedRoute, { unauthenticatedElement: _jsxDEV(Navigate, { to: "/login", replace: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this ), allowedRoles: ['creator', 'admin', 'sarraaf', 'employee'],}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this ), children: 
        _jsxDEV(Route, { element: _jsxDEV(Layout, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this ), children: [
          _jsxDEV(Route, { path: "/dashboard", element: _jsxDEV(Dashboard, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this )
          , _jsxDEV(Route, { path: "/customers", element: _jsxDEV(Customers, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 91}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 91}, this )
          , _jsxDEV(Route, { path: "/customers/:id", element: _jsxDEV(CustomerDetail, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 92}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 92}, this )
          , _jsxDEV(Route, { path: "/dadogereft", element: _jsxDEV(Dadogereft, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this )
          , _jsxDEV(Route, { path: "/trade", element: _jsxDEV(Trade, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this )
          , _jsxDEV(Route, { path: "/transfers/:direction", element: _jsxDEV(Transfer, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this )
          , _jsxDEV(Route, { path: "/cash", element: _jsxDEV(Cash, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this )
          , _jsxDEV(Route, { path: "/bank", element: _jsxDEV(Bank, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this )
          , _jsxDEV(Route, { path: "/currencies", element: _jsxDEV(Currencies, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this )
          , _jsxDEV(Route, { path: "/reports", element: _jsxDEV(Reports, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 99}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 99}, this )
          , _jsxDEV(Route, { path: "/profit-loss", element: _jsxDEV(ProfitLoss, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 100}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 100}, this )
          , _jsxDEV(Route, { path: "/settings", element: _jsxDEV(Settings, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this )
          , _jsxDEV(Route, { path: "/transfer-book", element: _jsxDEV(TransferBook, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this )
          , _jsxDEV(Route, { path: "/journal", element: _jsxDEV(Journal, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this )
          , _jsxDEV(Route, { path: "/general-ledger", element: _jsxDEV(GeneralLedger, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this )
          , _jsxDEV(Route, { path: "/journal-entry", element: _jsxDEV(JournalEntry, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this )
          , _jsxDEV(Route, { path: "/balance-sheet", element: _jsxDEV(BalanceSheet, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this )
          , _jsxDEV(Route, { path: "/reconciliation", element: _jsxDEV(Reconciliation, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this )
          , _jsxDEV(Route, { path: "/convert", element: _jsxDEV(CurrencyConvert, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this )
          , _jsxDEV(Route, { path: "/online-products", element: _jsxDEV(OnlineProducts, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this )
          , _jsxDEV(Route, { path: "/payment-gateway", element: _jsxDEV(PaymentGateway, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this )
          , _jsxDEV(Route, { path: "/online-products/wallet", element: _jsxDEV(SarraafWallet, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this )
          , _jsxDEV(Route, { path: "/online-products/recharge", element: _jsxDEV(SarraafRecharge, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this )
          , _jsxDEV(Route, { path: "/online-products/games", element: _jsxDEV(SarraafGames, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this )
          , _jsxDEV(Route, { path: "/agents", element: _jsxDEV(Agents, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this )
          , _jsxDEV(Route, { path: "/debtors", element: _jsxDEV(Debtors, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this )
          , _jsxDEV(Route, { path: "/notifications", element: _jsxDEV(Notifications, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this )
          , _jsxDEV(Route, { path: "/agency-network", element: _jsxDEV(AgencyNetwork, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 117}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 117}, this )
          , _jsxDEV(Route, { path: "/agency", element: _jsxDEV(AgencyChooser, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this )
          , _jsxDEV(Route, { path: "/chat", element: _jsxDEV(ChatGroups, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this )
          , _jsxDEV(Route, { path: "/chat/group/:id", element: _jsxDEV(ChatGroupDetail, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this )
          , _jsxDEV(Route, { path: "/sarraaf-market", element: _jsxDEV(SarraafMarket, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this )
          , _jsxDEV(Route, { path: "/sarraaf-chat", element: _jsxDEV(SarraafChat, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this )
          , _jsxDEV(Route, { path: "/backup", element: _jsxDEV(Backup, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 123}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 123}, this )
          , _jsxDEV(Route, { path: "/support", element: _jsxDEV(SarraafSupport, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 89}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)

      /* Builder Panel — creator + admin + co-creators */
      , _jsxDEV(Route, { element: _jsxDEV(AdminRoute, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this ), children: [
        _jsxDEV(Route, { path: "/builder", element: _jsxDEV(BuilderPanel, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this )
        , _jsxDEV(Route, { path: "/main-settings", element: _jsxDEV(MainSettings, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 129}, this)

      /* Customer Panel */
      , _jsxDEV(Route, { element: _jsxDEV(ProtectedRoute, { requiredRole: "customer", unauthenticatedElement: _jsxDEV(Navigate, { to: "/login", replace: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this ), children: 
        _jsxDEV(Route, { element: _jsxDEV(CustomerLayout, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this ), children: [
          _jsxDEV(Route, { path: "/customer", element: _jsxDEV(CustomerHome, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this )
          , _jsxDEV(Route, { path: "/customer/wallet", element: _jsxDEV(CustomerWallet, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this )
          , _jsxDEV(Route, { path: "/customer/recharge", element: _jsxDEV(CustomerRecharge, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this )
          , _jsxDEV(Route, { path: "/customer/games", element: _jsxDEV(CustomerGames, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 140}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 140}, this )
          , _jsxDEV(Route, { path: "/customer/transfer", element: _jsxDEV(CustomerTransfer, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this )
          , _jsxDEV(Route, { path: "/customer/withdraw", element: _jsxDEV(CustomerWithdraw, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this )
          , _jsxDEV(Route, { path: "/customer/support", element: _jsxDEV(CustomerSupport, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this )
          , _jsxDEV(Route, { path: "/customer/account", element: _jsxDEV(CustomerAccount, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this )
          , _jsxDEV(Route, { path: "/customer/orders", element: _jsxDEV(CustomerOrders, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 145}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 145}, this )
          , _jsxDEV(Route, { path: "/customer/messages", element: _jsxDEV(CustomerMessages, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this )
          , _jsxDEV(Route, { path: "/customer/notifications", element: _jsxDEV(CustomerNotifications, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this )
          , _jsxDEV(Route, { path: "/customer/profile", element: _jsxDEV(CustomerProfile, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this )
          , _jsxDEV(Route, { path: "/customer/chat", element: _jsxDEV(CustomerChat, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 136}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this)

      /* Receipt — any authenticated user */
      , _jsxDEV(Route, { element: _jsxDEV(ProtectedRoute, { unauthenticatedElement: _jsxDEV(Navigate, { to: "/login", replace: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 154}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 154}, this ), children: 
        _jsxDEV(Route, { path: "/receipt", element: _jsxDEV(Receipt, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 155}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 155}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 154}, this)

      , _jsxDEV(Route, { path: "*", element: _jsxDEV(PageNotFound, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this ),}, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 78}, this)
  );
};

function App() {
  return (
    _jsxDEV(ErrorBoundary, { children: 
      _jsxDEV(AuthProvider, { children: 
        _jsxDEV(LanguageProvider, { children: 
          _jsxDEV(QueryClientProvider, { client: queryClientInstance, children: 
            _jsxDEV(UpgradeProvider, { children: [
              _jsxDEV(Router, { children: [
                _jsxDEV(ScrollToTop, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 171}, this )
                , _jsxDEV(ErrorBoundary, { children: 
                  _jsxDEV(AppGate, { children: 
                    _jsxDEV(AppRoutes, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 174}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 173}, this)
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 172}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 170}, this)
              , _jsxDEV(Toaster, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 169}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 167}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 166}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this)
  )
}

export default App