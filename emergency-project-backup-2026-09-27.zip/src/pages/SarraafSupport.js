const _jsxFileName = "src/pages/SarraafSupport.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card.js';
import { LifeBuoy, Headphones, MessageSquare } from 'lucide-react';
import ContactInfo from '../components/sarraaf/ContactInfo.js';
import SupportPanel from '../components/sarraaf/SupportPanel.js';
import ReferralCard from '../components/sarraaf/ReferralCard.js';
import FeedbackButton from '../components/sarraaf/FeedbackButton.js';
import { useSarraafProfile, useToggleReferral } from '../lib/useSarraaf.js';
import { useAuth } from '../lib/AuthContext.js';

export default function SarraafSupport() {
  const { user } = useAuth();
  const { data: profile } = useSarraafProfile(_optionalChain([user, 'optionalAccess', _ => _.id]));
  const toggleMut = useToggleReferral();

  const handleToggle = (enabled) => {
    if (!profile) return;
    toggleMut.mutate({ profileId: profile.id, enabled });
  };

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      /* Header */
      _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
        _jsxDEV('div', { className: "w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"       , children: 
          _jsxDEV(Headphones, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 26}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 25}, this)
        , _jsxDEV('div', { children: [
          _jsxDEV('h1', { className: "text-lg font-bold" , children: "پشتیبانی آنلاین" }, void 0, false, {fileName: _jsxFileName, lineNumber: 29}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "درخواست پشتیبانی و تماس با تیم"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 30}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 28}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 24}, this)

      /* Quick Contact */
      , _jsxDEV(Card, { children: [
        _jsxDEV(CardHeader, { className: "pb-3", children: 
          _jsxDEV(CardTitle, { className: "text-sm flex items-center gap-2"   , children: [
            _jsxDEV(LifeBuoy, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this ), "تماس سریع"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 37}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this)
        , _jsxDEV(CardContent, { children: 
          _jsxDEV(ContactInfo, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 35}, this)

      /* Online Support Tickets */
      , _jsxDEV(SupportPanel, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this )

      /* Referral — share invite link */
      , _jsxDEV(ReferralCard, {
        profile: profile,
        onToggle: handleToggle,
        loading: toggleMut.isPending,}, void 0, false, {fileName: _jsxFileName, lineNumber: 51}, this
      )

      /* Feedback */
      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4", children: [
          _jsxDEV('div', { className: "flex items-center gap-2 mb-2"   , children: [
            _jsxDEV(MessageSquare, { className: "w-4 h-4 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this )
            , _jsxDEV('h3', { className: "text-xs font-semibold text-muted-foreground"  , children: "بازخورد و پیشنهاد"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 60}, this)
          , _jsxDEV(FeedbackButton, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 59}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 22}, this)
  );
}