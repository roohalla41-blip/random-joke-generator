const _jsxFileName = "src/pages/Settings.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '../components/ui/card.js';
import {
  Settings as SettingsIcon, Coins, Crown,
  DatabaseBackup, ChevronLeft, FlaskConical, Store
} from 'lucide-react';
import ReferralCard from '../components/sarraaf/ReferralCard.js';
import ContactInfo from '../components/sarraaf/ContactInfo.js';
import SupportPanel from '../components/sarraaf/SupportPanel.js';
import FeedbackButton from '../components/sarraaf/FeedbackButton.js';
import MultiExchangeManager from '../components/sarraaf/MultiExchangeManager.js';
import LanguageSettings from '../components/sarraaf/LanguageSettings.js';
import TermsManager from '../components/sarraaf/TermsManager.js';
import { useSarraafProfile, useToggleReferral } from '../lib/useSarraaf.js';
import { useUpgrade } from '../lib/UpgradeContext.js';
import { useAuth } from '../lib/AuthContext.js';
import { getAllowedSettingsMenu, isManagementRole } from '../lib/rbac.js';

const ALL_MENU_ITEMS = [
  { label: 'مدیریت ارزها', path: '/currencies', icon: Coins, color: 'text-amber-600' },
  { label: 'محصولات آنلاین', path: '/online-products', icon: Store, color: 'text-pink-600' },
  { label: 'بکاپ و بازیابی', path: '/backup', icon: DatabaseBackup, color: 'text-violet-600' },
];

export default function Settings() {
  const { user } = useAuth();
  const { user: authUser } = useAuth();
  const { data: profile } = useSarraafProfile(_optionalChain([user, 'optionalAccess', _ => _.id]));
  const toggleMut = useToggleReferral();
  const { openUpgrade } = useUpgrade();

  const userRole = _optionalChain([authUser, 'optionalAccess', _2 => _2.role]) || 'user';
  const menuItems = ALL_MENU_ITEMS.filter(item =>
    getAllowedSettingsMenu(userRole).some(m => m.path === item.path)
  );

  const handleToggle = (enabled) => {
    if (!profile) return;
    toggleMut.mutate({ profileId: profile.id, enabled });
  };

  return (
    _jsxDEV(_Fragment, { children: [
      /* Header */
      _jsxDEV('div', { className: "flex items-center gap-2 mb-4"   , children: [
        _jsxDEV(SettingsIcon, { className: "w-5 h-5 text-primary shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 47}, this )
        , _jsxDEV('h1', { className: "text-lg font-bold" , children: "تنظیمات"}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 46}, this)

      /* Upgrade card */
      , _jsxDEV(Card, { className: "mb-4 overflow-hidden border-0 shadow-sm"   , children: 
        _jsxDEV(CardContent, { className: "p-4 bg-gradient-to-br from-primary to-indigo-600 text-white"    , children: 
          _jsxDEV('div', { className: "flex items-center gap-3"  , children: [
            _jsxDEV('div', { className: "w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0"       , children: 
              _jsxDEV(Crown, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this)
            , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
              _jsxDEV('p', { className: "text-sm font-bold" , children: "ارتقا به نسخه پولی"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this)
              , _jsxDEV('p', { className: "text-xs text-white/80" , children: "امکانات بیشتر و حذف برند سازنده"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 58}, this)
            , _jsxDEV('button', {
              onClick: () => openUpgrade(),
              className: "px-3 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-xs font-medium transition-colors shrink-0"        ,
 children: "ارتقا"

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 54}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 53}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 52}, this)

      /* Referral card */
      , _jsxDEV('div', { className: "mb-4", children: 
        _jsxDEV(ReferralCard, {
          profile: profile,
          onToggle: handleToggle,
          loading: toggleMut.isPending,}, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this
        )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)

      /* Multi-exchange manager */
      , _jsxDEV('div', { className: "mb-4", children: 
        _jsxDEV(MultiExchangeManager, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this)

      /* Language settings */
      , _jsxDEV('div', { className: "mb-4", children: 
        _jsxDEV(LanguageSettings, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this)

      /* Contact links — read-only icons, managed from builder panel */
      , _jsxDEV('div', { className: "mb-4", children: 
        _jsxDEV(ContactInfo, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 92}, this)

      /* Support panel */
      , _jsxDEV('div', { className: "mb-4", children: 
        _jsxDEV(SupportPanel, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)

      /* Vertical menu list */
      , _jsxDEV(Card, { className: "overflow-hidden", children: 
        _jsxDEV(CardContent, { className: "p-0", children: 
          menuItems.map((item, idx) => {
            const Icon = item.icon;
            return (
              _jsxDEV(Link, {

                to: item.path,
                className: `flex items-center gap-3 px-4 py-3.5 hover:bg-muted/50 transition-colors ${
                  idx < menuItems.length - 1 ? 'border-b border-border' : ''
                }`,
 children: [
                _jsxDEV(Icon, { className: `w-5 h-5 shrink-0 ${item.color}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this )
                , _jsxDEV('span', { className: "text-sm font-medium flex-1"  , children: item.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this)
                , _jsxDEV(ChevronLeft, { className: "w-4 h-4 text-muted-foreground shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this )
              ]}, item.path, true, {fileName: _jsxFileName, lineNumber: 107}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this)

      /* Terms manager — admin/creator only */
      , isManagementRole(userRole) && (
        _jsxDEV('div', { className: "mb-4", children: 
          _jsxDEV(TermsManager, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this)
      )

      /* About section */
      , _jsxDEV(Card, { className: "mt-4", children: 
        _jsxDEV(CardContent, { className: "p-4", children: [
          _jsxDEV('div', { className: "flex items-center gap-2 mb-1"   , children: [
            _jsxDEV(FlaskConical, { className: "w-4 h-4 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 134}, this )
            , _jsxDEV('h3', { className: "text-xs font-semibold text-muted-foreground"  , children: "نسخه برنامه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 133}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "همراه ما — سامانه مدیریت عملیات صرافی"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground mt-0.5"  , children: "نسخه ۱.۰.۰" }, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)
          , _jsxDEV('div', { className: "mt-3", children: 
            _jsxDEV(FeedbackButton, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 140}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 132}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 44}, this)
  );
}