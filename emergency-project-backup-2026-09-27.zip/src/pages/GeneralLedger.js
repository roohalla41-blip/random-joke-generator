const _jsxFileName = "src/pages/GeneralLedger.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useMemo } from 'react';
import { useTransactions, useCurrencies, useRateSettings, useCustomers, useEditTransaction, useSoftDeleteTransaction, useCreateCustomer, usePostDocument } from '../lib/useSarraaf.js';
import { useAuth } from '../lib/AuthContext.js';
import { PageHeader, LoadingState, EmptyState, StatusBadge } from '../components/sarraaf/Pieces.js';
import { trialBalanceBase } from '../lib/ledger.js';
import { formatDate, formatNumber, TX_TYPE_LABELS, todayJalali, nextDocumentNo } from '../lib/sarraaf.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Textarea } from '../components/ui/textarea.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog.js';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogAction, AlertDialogCancel } from '../components/ui/alert-dialog.js';
import { ScrollText, Printer, FileSpreadsheet, Plus, Pencil, Trash2, ChevronDown, ChevronUp, Contact, AlertTriangle } from 'lucide-react';
import { toast } from '../components/ui/use-toast.js';
import { AmountInput } from '../components/sarraaf/Fields.js';

const CUSTOMER_SIDE_LABELS = {
  debit: 'بدهکار',
  credit: 'بستانکار',
  none: '—',
};

export default function GeneralLedger() {
  const { user } = useAuth();
  const { data: txs, isLoading } = useTransactions();
  const { data: currencies } = useCurrencies();
  const { data: rateSettings } = useRateSettings();
  const { data: customers } = useCustomers();
  const editMut = useEditTransaction();
  const deleteMut = useSoftDeleteTransaction();
  const createCustomerMut = useCreateCustomer();
  const postDocMut = usePostDocument();

  const [search, setSearch] = useState('');
  const [currencyFilter, setCurrencyFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [showDeleted, setShowDeleted] = useState(false);
  const [expandedId, setExpandedId] = useState(null);

  // Add transaction dialog
  const [addOpen, setAddOpen] = useState(false);
  const [addForm, setAddForm] = useState({
    date: todayJalali(),
    type: 'manual',
    currency: 'AFN',
    amount: 0,
    customer_side: 'none',
    description: '',
    customer_id: '',
    customer_name: '',
    customer_phone: '',
  });

  // Edit dialog
  const [editTx, setEditTx] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [editNote, setEditNote] = useState('');

  // Delete dialog
  const [deleteTx, setDeleteTx] = useState(null);
  const [deleteNote, setDeleteNote] = useState('');

  // Customer picker from contacts
  const [customerDialogOpen, setCustomerDialogOpen] = useState(false);
  const [customerForm, setCustomerForm] = useState({ name: '', phone: '', code: '', customer_type: 'permanent', notes: '' });

  const activeTxs = useMemo(() => (txs || []).filter(t => showDeleted ? true : !t.deleted), [txs, showDeleted]);

  const filtered = activeTxs.filter(t => {
    if (currencyFilter !== 'all' && t.currency !== currencyFilter) return false;
    if (typeFilter !== 'all' && t.type !== typeFilter) return false;
    if (search) {
      const s = search.toLowerCase();
      return (t.description || '').toLowerCase().includes(s)
        || (t.document_no || '').toLowerCase().includes(s)
        || (t.customer_name || '').toLowerCase().includes(s)
        || (t.customer_phone || '').toLowerCase().includes(s);
    }
    return true;
  });

  const trial = txs ? trialBalanceBase(activeTxs, rateSettings || {}, currencies || []) : null;

  const exportExcel = () => {
    const rows = filtered.map(t => ({
      'تاریخ': t.date, 'شماره سند': t.document_no, 'نوع': TX_TYPE_LABELS[t.type] || t.type,
      'ارز': t.currency, 'مبلغ': t.amount, 'مشتری': t.customer_name || '', 'موبایل': t.customer_phone || '',
      'توضیحات': t.description || '', 'ویرایش‌شده': t.edited ? 'بله' : 'خیر', 'حذف‌شده': t.deleted ? 'بله' : 'خیر',
    }));
    const csv = '\uFEFF' + Object.keys(rows[0] || {}).join(',') + '\n' + rows.map(r => Object.values(r).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'general-ledger.csv'; a.click();
  };

  // ── Contact picker ──
  const pickFromContacts = async () => {
    if ('contacts' in navigator && 'select' in navigator.contacts) {
      try {
        const contacts = await navigator.contacts.select(['name', 'tel'], { multiple: false });
        if (contacts && contacts.length > 0) {
          const c = contacts[0];
          const name = (c.name && c.name[0]) || '';
          const phone = (c.tel && c.tel[0]) || '';
          setCustomerForm(prev => ({ ...prev, name, phone }));
        }
      } catch (e) {
        toast({ title: 'خطا', description: 'دسترسی به مخاطبین ناموفق بود', variant: 'destructive' });
      }
    } else {
      toast({ title: 'خطا', description: 'مرورگر شما از انتخاب مخاطب پشتیبانی نمی‌کند', variant: 'destructive' });
    }
  };

  const handleCreateCustomer = async (e) => {
    e.preventDefault();
    if (!customerForm.name) return;
    const created = await createCustomerMut.mutateAsync(customerForm);
    setAddForm(prev => ({
      ...prev,
      customer_id: _optionalChain([created, 'optionalAccess', _ => _.id]) || '',
      customer_name: customerForm.name,
      customer_phone: customerForm.phone,
      description: prev.description || `تحویل وجه به ${customerForm.name}${customerForm.phone ? `\nشماره موبایل: ${customerForm.phone}` : ''}`,
    }));
    setCustomerDialogOpen(false);
    setCustomerForm({ name: '', phone: '', code: '', customer_type: 'permanent', notes: '' });
    toast({ title: 'موفق', description: 'مشتری اضافه شد' });
  };

  // ── Add transaction ──
  const handleAddTx = async (e) => {
    e.preventDefault();
    const docNo = await nextDocumentNo('DV');
    const lines = [{
      date: addForm.date,
      document_no: docNo,
      type: addForm.type,
      currency: addForm.currency,
      amount: Number(addForm.amount) || 0,
      customer_side: addForm.customer_side,
      customer_id: addForm.customer_id || undefined,
      customer_name: addForm.customer_name || undefined,
      customer_phone: addForm.customer_phone || undefined,
      description: addForm.description || undefined,
    }];
    await postDocMut.mutateAsync(lines);
    setAddOpen(false);
    setAddForm({
      date: todayJalali(),
      type: 'manual',
      currency: 'AFN',
      amount: 0,
      customer_side: 'none',
      description: '',
      customer_id: '',
      customer_name: '',
      customer_phone: '',
    });
    toast({ title: 'موفق', description: 'سند ثبت شد' });
  };

  const selectExistingCustomer = (c) => {
    setAddForm(prev => ({
      ...prev,
      customer_id: c.id,
      customer_name: c.name,
      customer_phone: c.phone || '',
      description: prev.description || `تحویل وجه به ${c.name}${c.phone ? `\nشماره موبایل: ${c.phone}` : ''}`,
    }));
  };

  // ── Edit transaction ──
  const openEdit = (t) => {
    setEditTx(t);
    setEditForm({
      date: t.date || todayJalali(),
      type: t.type || 'manual',
      currency: t.currency || 'AFN',
      amount: t.amount || 0,
      customer_side: t.customer_side || 'none',
      description: t.description || '',
      customer_name: t.customer_name || '',
      customer_phone: t.customer_phone || '',
    });
    setEditNote('');
  };

  const handleEdit = async (e) => {
    e.preventDefault();
    await editMut.mutateAsync({
      id: editTx.id,
      data: {
        date: editForm.date,
        type: editForm.type,
        currency: editForm.currency,
        amount: Number(editForm.amount) || 0,
        customer_side: editForm.customer_side,
        description: editForm.description,
        customer_name: editForm.customer_name,
        customer_phone: editForm.customer_phone,
        edit_note: editNote,
        edited_by_name: _optionalChain([user, 'optionalAccess', _2 => _2.full_name]) || '',
      },
    });
    setEditTx(null);
    toast({ title: 'موفق', description: 'سند ویرایش شد. سند اصلی در دیتابیس حفظ شده است.' });
  };

  // ── Soft-delete transaction ──
  const handleDelete = async () => {
    await deleteMut.mutateAsync({
      id: deleteTx.id,
      note: deleteNote,
      userName: _optionalChain([user, 'optionalAccess', _3 => _3.full_name]) || '',
    });
    setDeleteTx(null);
    setDeleteNote('');
    toast({ title: 'موفق', description: 'سند حذف شد. این سند به‌عنوان سند رسمی در دیتابیس باقی می‌ماند.' });
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "دفتر کل" , icon: ScrollText,
        actions: 
          _jsxDEV('div', { className: "flex gap-1" , children: [
            _jsxDEV(Button, { size: "sm", onClick: () => setAddOpen(true), children: [
              _jsxDEV(Plus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 229}, this )
              , _jsxDEV('span', { className: "hidden sm:inline" , children: "سند جدید" }, void 0, false, {fileName: _jsxFileName, lineNumber: 230}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 228}, this)
            , _jsxDEV(Button, { size: "sm", variant: "outline", onClick: exportExcel, children: _jsxDEV(FileSpreadsheet, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 232}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 232}, this)
            , _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => window.print(), children: _jsxDEV(Printer, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 233}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 233}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 227}, this)
        ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 225}, this
      )

      /* Trial balance summary */
      , trial && (
        _jsxDEV('div', { className: "grid grid-cols-2 gap-3 mb-4"   , children: [
          _jsxDEV('div', { className: "p-3 rounded-lg bg-success/10 text-center"   , children: [
            _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "بدهکار کل" }, void 0, false, {fileName: _jsxFileName, lineNumber: 242}, this)
            , _jsxDEV('p', { className: "text-lg font-bold text-success"  , children: formatNumber(trial.totalDebit)}, void 0, false, {fileName: _jsxFileName, lineNumber: 243}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 241}, this)
          , _jsxDEV('div', { className: "p-3 rounded-lg bg-primary/10 text-center"   , children: [
            _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "بستانکار کل" }, void 0, false, {fileName: _jsxFileName, lineNumber: 246}, this)
            , _jsxDEV('p', { className: "text-lg font-bold text-primary"  , children: formatNumber(trial.totalCredit)}, void 0, false, {fileName: _jsxFileName, lineNumber: 247}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 245}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 240}, this)
      )

      /* Filters */
      , _jsxDEV('div', { className: "flex gap-2 mb-3 flex-wrap"   , children: [
        _jsxDEV(Input, { value: search, onChange: e => setSearch(e.target.value), placeholder: "جستجو...", className: "flex-1 min-w-[120px]" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 254}, this )
        , _jsxDEV(Select, { value: currencyFilter, onValueChange: setCurrencyFilter, children: [
          _jsxDEV(SelectTrigger, { className: "w-24", children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 256}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 256}, this)
          , _jsxDEV(SelectContent, { children: [_jsxDEV(SelectItem, { value: "all", children: "همه ارز" }, void 0, false, {fileName: _jsxFileName, lineNumber: 257}, this), _jsxDEV(SelectItem, { value: "AFN", children: "AFN"}, void 0, false, {fileName: _jsxFileName, lineNumber: 257}, this), _jsxDEV(SelectItem, { value: "USD", children: "USD"}, void 0, false, {fileName: _jsxFileName, lineNumber: 257}, this), _jsxDEV(SelectItem, { value: "IRT", children: "IRT"}, void 0, false, {fileName: _jsxFileName, lineNumber: 257}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 257}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 255}, this)
        , _jsxDEV(Select, { value: typeFilter, onValueChange: setTypeFilter, children: [
          _jsxDEV(SelectTrigger, { className: "w-28", children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 260}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 260}, this)
          , _jsxDEV(SelectContent, { children: [_jsxDEV(SelectItem, { value: "all", children: "همه انواع" }, void 0, false, {fileName: _jsxFileName, lineNumber: 261}, this), Object.entries(TX_TYPE_LABELS).map(([k, v]) => _jsxDEV(SelectItem, { value: k, children: v}, k, false, {fileName: _jsxFileName, lineNumber: 261}, this))]}, void 0, true, {fileName: _jsxFileName, lineNumber: 261}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 259}, this)
        , _jsxDEV(Button, { size: "sm", variant: showDeleted ? 'default' : 'outline', onClick: () => setShowDeleted(!showDeleted), children: 
          showDeleted ? 'نمایش همه' : 'حذف‌شده‌ها'
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 263}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 253}, this)

      /* Transaction list with full details */
      , isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 269}, this ) : filtered.length === 0 ? _jsxDEV(EmptyState, { icon: ScrollText, title: "رکوردی نیست" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 269}, this ) : (
        _jsxDEV('div', { className: "space-y-1", children: 
          filtered.slice(0, 100).map(t => {
            const isExpanded = expandedId === t.id;
            return (
              _jsxDEV('div', { className: `rounded-lg border bg-card text-sm overflow-hidden ${t.deleted ? 'opacity-50' : ''}`, children: [
                _jsxDEV('div', {
                  className: "flex items-center justify-between py-2 px-3 cursor-pointer hover:bg-muted/30"      ,
                  onClick: () => setExpandedId(isExpanded ? null : t.id),
 children: [
                  _jsxDEV('div', { className: "min-w-0 flex-1" , children: [
                    _jsxDEV('div', { className: "flex items-center gap-1.5 flex-wrap"   , children: [
                      _jsxDEV('span', { className: "font-medium", children: TX_TYPE_LABELS[t.type] || t.type}, void 0, false, {fileName: _jsxFileName, lineNumber: 281}, this)
                      , t.document_no && _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: ["• " , t.document_no]}, void 0, true, {fileName: _jsxFileName, lineNumber: 282}, this)
                      , _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: formatDate(t.date)}, void 0, false, {fileName: _jsxFileName, lineNumber: 283}, this)
                      , t.edited && _jsxDEV(StatusBadge, { status: "pending", labels: { pending: 'ویرایش‌شده' }, variant: "warning",}, void 0, false, {fileName: _jsxFileName, lineNumber: 284}, this )
                      , t.deleted && _jsxDEV(StatusBadge, { status: "cancelled", labels: { cancelled: 'حذف‌شده' }, variant: "destructive",}, void 0, false, {fileName: _jsxFileName, lineNumber: 285}, this )
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 280}, this)
                    , t.customer_name && (
                      _jsxDEV('p', { className: "text-xs text-muted-foreground mt-0.5"  , children: ["مشتری: " , t.customer_name]}, void 0, true, {fileName: _jsxFileName, lineNumber: 288}, this)
                    )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 279}, this)
                  , _jsxDEV('div', { className: "flex items-center gap-1 shrink-0"   , children: [
                    _jsxDEV('div', { className: "text-left", children: [
                      _jsxDEV('span', { className: "font-mono font-bold" , children: formatNumber(t.amount, 2)}, void 0, false, {fileName: _jsxFileName, lineNumber: 293}, this)
                      , _jsxDEV('span', { className: "text-xs text-muted-foreground mr-1"  , children: t.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 294}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 292}, this)
                    , isExpanded ? _jsxDEV(ChevronUp, { className: "w-4 h-4 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 296}, this ) : _jsxDEV(ChevronDown, { className: "w-4 h-4 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 296}, this )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 291}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 275}, this)
                , isExpanded && (
                  _jsxDEV('div', { className: "px-3 pb-3 pt-1 border-t space-y-1.5 bg-muted/10"     , children: [
                    t.description && (
                      _jsxDEV('div', { children: [
                        _jsxDEV('p', { className: "text-xs font-semibold text-muted-foreground"  , children: "توضیحات:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 303}, this)
                        , _jsxDEV('p', { className: "text-sm whitespace-pre-line" , children: t.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 304}, this)
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 302}, this)
                    )
                    , _jsxDEV('div', { className: "grid grid-cols-2 gap-x-3 gap-y-1 text-xs"    , children: [
                      t.customer_name && _jsxDEV('div', { children: [_jsxDEV('span', { className: "text-muted-foreground", children: "نام مشتری: "  }, void 0, false, {fileName: _jsxFileName, lineNumber: 308}, this), t.customer_name]}, void 0, true, {fileName: _jsxFileName, lineNumber: 308}, this)
                      , t.customer_phone && _jsxDEV('div', { children: [_jsxDEV('span', { className: "text-muted-foreground", children: "موبایل: " }, void 0, false, {fileName: _jsxFileName, lineNumber: 309}, this), t.customer_phone]}, void 0, true, {fileName: _jsxFileName, lineNumber: 309}, this)
                      , t.customer_side && t.customer_side !== 'none' && _jsxDEV('div', { children: [_jsxDEV('span', { className: "text-muted-foreground", children: "سمت مشتری: "  }, void 0, false, {fileName: _jsxFileName, lineNumber: 310}, this), CUSTOMER_SIDE_LABELS[t.customer_side]]}, void 0, true, {fileName: _jsxFileName, lineNumber: 310}, this)
                      , t.counter_type && t.counter_type !== 'none' && _jsxDEV('div', { children: [_jsxDEV('span', { className: "text-muted-foreground", children: "مقابل: " }, void 0, false, {fileName: _jsxFileName, lineNumber: 311}, this), t.counter_type]}, void 0, true, {fileName: _jsxFileName, lineNumber: 311}, this)
                      , t.rate && _jsxDEV('div', { children: [_jsxDEV('span', { className: "text-muted-foreground", children: "نرخ: " }, void 0, false, {fileName: _jsxFileName, lineNumber: 312}, this), formatNumber(t.rate, 2)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 312}, this)
                      , t.fee ? _jsxDEV('div', { children: [_jsxDEV('span', { className: "text-muted-foreground", children: "کارمزد: " }, void 0, false, {fileName: _jsxFileName, lineNumber: 313}, this), formatNumber(t.fee, 2), " " , t.fee_currency || '']}, void 0, true, {fileName: _jsxFileName, lineNumber: 313}, this) : null
                      , t.pair_currency && _jsxDEV('div', { children: [_jsxDEV('span', { className: "text-muted-foreground", children: "ارز جفت: "  }, void 0, false, {fileName: _jsxFileName, lineNumber: 314}, this), t.pair_currency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 314}, this)
                      , t.pair_amount ? _jsxDEV('div', { children: [_jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ جفت: "  }, void 0, false, {fileName: _jsxFileName, lineNumber: 315}, this), formatNumber(t.pair_amount, 2)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 315}, this) : null
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 307}, this)
                    , t.edit_note && (
                      _jsxDEV('div', { className: "text-xs text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 p-2 rounded"      , children: [
                        _jsxDEV('span', { className: "font-semibold", children: "یادداشت ویرایش: "  }, void 0, false, {fileName: _jsxFileName, lineNumber: 319}, this), t.edit_note
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 318}, this)
                    )
                    , t.deleted && t.delete_note && (
                      _jsxDEV('div', { className: "text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 p-2 rounded"      , children: [
                        _jsxDEV('span', { className: "font-semibold", children: "یادداشت حذف: "  }, void 0, false, {fileName: _jsxFileName, lineNumber: 324}, this), t.delete_note
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 323}, this)
                    )
                    , !t.deleted && (
                      _jsxDEV('div', { className: "flex gap-2 pt-1"  , children: [
                        _jsxDEV(Button, { size: "sm", variant: "outline", onClick: (e) => { e.stopPropagation(); openEdit(t); }, children: [
                          _jsxDEV(Pencil, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 330}, this ), " ویرایش"
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 329}, this)
                        , _jsxDEV(Button, { size: "sm", variant: "outline", className: "text-destructive", onClick: (e) => { e.stopPropagation(); setDeleteTx(t); }, children: [
                          _jsxDEV(Trash2, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 333}, this ), " حذف"
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 332}, this)
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 328}, this)
                    )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 300}, this)
                )
              ]}, t.id, true, {fileName: _jsxFileName, lineNumber: 274}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 270}, this)
      )

      /* ── Add Transaction Dialog ── */
      , _jsxDEV(Dialog, { open: addOpen, onOpenChange: setAddOpen, children: 
        _jsxDEV(DialogContent, { className: "max-h-[90vh] overflow-y-auto" , children: [
          _jsxDEV(DialogHeader, { children: 
            _jsxDEV(DialogTitle, { children: "سند جدید" }, void 0, false, {fileName: _jsxFileName, lineNumber: 349}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 348}, this)
          , _jsxDEV('form', { onSubmit: handleAddTx, className: "space-y-3", children: [
            _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "تاریخ"}, void 0, false, {fileName: _jsxFileName, lineNumber: 354}, this)
                , _jsxDEV(Input, { value: addForm.date, onChange: e => setAddForm({ ...addForm, date: e.target.value }), required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 355}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 353}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "نوع سند" }, void 0, false, {fileName: _jsxFileName, lineNumber: 358}, this)
                , _jsxDEV(Select, { value: addForm.type, onValueChange: v => setAddForm({ ...addForm, type: v }), children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 360}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 360}, this)
                  , _jsxDEV(SelectContent, { children: Object.entries(TX_TYPE_LABELS).map(([k, v]) => _jsxDEV(SelectItem, { value: k, children: v}, k, false, {fileName: _jsxFileName, lineNumber: 361}, this))}, void 0, false, {fileName: _jsxFileName, lineNumber: 361}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 359}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 357}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 352}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "ارز"}, void 0, false, {fileName: _jsxFileName, lineNumber: 367}, this)
                , _jsxDEV(Select, { value: addForm.currency, onValueChange: v => setAddForm({ ...addForm, currency: v }), children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 369}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 369}, this)
                  , _jsxDEV(SelectContent, { children: [_jsxDEV(SelectItem, { value: "AFN", children: "AFN"}, void 0, false, {fileName: _jsxFileName, lineNumber: 370}, this), _jsxDEV(SelectItem, { value: "USD", children: "USD"}, void 0, false, {fileName: _jsxFileName, lineNumber: 370}, this), _jsxDEV(SelectItem, { value: "IRT", children: "IRT"}, void 0, false, {fileName: _jsxFileName, lineNumber: 370}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 370}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 368}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 366}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: ["مبلغ " , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 374}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 374}, this)
                , _jsxDEV(AmountInput, { value: addForm.amount, onChange: v => setAddForm({ ...addForm, amount: v }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 375}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 373}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 365}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "سمت مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 379}, this)
              , _jsxDEV(Select, { value: addForm.customer_side, onValueChange: v => setAddForm({ ...addForm, customer_side: v }), children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 381}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 381}, this)
                , _jsxDEV(SelectContent, { children: [
                  _jsxDEV(SelectItem, { value: "none", children: "—"}, void 0, false, {fileName: _jsxFileName, lineNumber: 383}, this)
                  , _jsxDEV(SelectItem, { value: "debit", children: "بدهکار"}, void 0, false, {fileName: _jsxFileName, lineNumber: 384}, this)
                  , _jsxDEV(SelectItem, { value: "credit", children: "بستانکار"}, void 0, false, {fileName: _jsxFileName, lineNumber: 385}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 382}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 380}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 378}, this)

            /* Customer section */
            , _jsxDEV('div', { className: "border rounded-lg p-3 space-y-2"   , children: [
              _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
                _jsxDEV(Label, { className: "text-sm font-semibold" , children: "مشتری"}, void 0, false, {fileName: _jsxFileName, lineNumber: 393}, this)
                , _jsxDEV(Button, { type: "button", size: "sm", variant: "outline", onClick: () => setCustomerDialogOpen(true), children: [
                  _jsxDEV(Plus, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 395}, this ), " افزودن مشتری"
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 394}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 392}, this)
              , customers && customers.length > 0 && (
                _jsxDEV(Select, { value: addForm.customer_id, onValueChange: (v) => {
                  const c = customers.find(c => c.id === v);
                  if (c) selectExistingCustomer(c);
                }, children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, { placeholder: "انتخاب از مشتریان موجود"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 403}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 403}, this)
                  , _jsxDEV(SelectContent, { children: 
                    customers.map(c => _jsxDEV(SelectItem, { value: c.id, children: [c.name, " " , c.phone ? `• ${c.phone}` : '']}, c.id, true, {fileName: _jsxFileName, lineNumber: 405}, this))
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 404}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 399}, this)
              )
              , addForm.customer_name && (
                _jsxDEV('div', { className: "text-xs bg-muted/30 rounded p-2 space-y-0.5"    , children: [
                  _jsxDEV('div', { children: [_jsxDEV('span', { className: "text-muted-foreground", children: "نام: " }, void 0, false, {fileName: _jsxFileName, lineNumber: 411}, this), addForm.customer_name]}, void 0, true, {fileName: _jsxFileName, lineNumber: 411}, this)
                  , addForm.customer_phone && _jsxDEV('div', { children: [_jsxDEV('span', { className: "text-muted-foreground", children: "موبایل: " }, void 0, false, {fileName: _jsxFileName, lineNumber: 412}, this), addForm.customer_phone]}, void 0, true, {fileName: _jsxFileName, lineNumber: 412}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 410}, this)
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 391}, this)

            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "توضیحات (چند خط)"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 418}, this)
              , _jsxDEV(Textarea, {
                value: addForm.description,
                onChange: e => setAddForm({ ...addForm, description: e.target.value }),
                placeholder: "تحویل وجه به ..."   ,
                rows: 3,
                className: "resize-y",}, void 0, false, {fileName: _jsxFileName, lineNumber: 419}, this
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 417}, this)

            , _jsxDEV(DialogFooter, { children: [
              _jsxDEV(Button, { type: "button", variant: "outline", onClick: () => setAddOpen(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 429}, this)
              , _jsxDEV(Button, { type: "submit", disabled: postDocMut.isPending, children: "ثبت سند" }, void 0, false, {fileName: _jsxFileName, lineNumber: 430}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 428}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 351}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 347}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 346}, this)

      /* ── Customer from Contacts Dialog ── */
      , _jsxDEV(Dialog, { open: customerDialogOpen, onOpenChange: setCustomerDialogOpen, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: 
            _jsxDEV(DialogTitle, { children: "افزودن مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 440}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 439}, this)
          , _jsxDEV('form', { onSubmit: handleCreateCustomer, className: "space-y-3", children: [
            _jsxDEV(Button, { type: "button", variant: "outline", className: "w-full", onClick: pickFromContacts, children: [
              _jsxDEV(Contact, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 444}, this ), " انتخاب از مخاطبین"
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 443}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: ["نام " , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 447}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 447}, this)
              , _jsxDEV(Input, { value: customerForm.name, onChange: e => setCustomerForm({ ...customerForm, name: e.target.value }), required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 448}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 446}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "موبایل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 451}, this)
              , _jsxDEV(Input, { value: customerForm.phone, onChange: e => setCustomerForm({ ...customerForm, phone: e.target.value }), inputMode: "numeric",}, void 0, false, {fileName: _jsxFileName, lineNumber: 452}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 450}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "کد"}, void 0, false, {fileName: _jsxFileName, lineNumber: 455}, this)
              , _jsxDEV(Input, { value: customerForm.code, onChange: e => setCustomerForm({ ...customerForm, code: e.target.value }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 456}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 454}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نوع"}, void 0, false, {fileName: _jsxFileName, lineNumber: 459}, this)
              , _jsxDEV(Select, { value: customerForm.customer_type, onValueChange: v => setCustomerForm({ ...customerForm, customer_type: v }), children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 461}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 461}, this)
                , _jsxDEV(SelectContent, { children: [
                  _jsxDEV(SelectItem, { value: "permanent", children: "دائمی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 463}, this)
                  , _jsxDEV(SelectItem, { value: "temporary", children: "موقت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 464}, this)
                  , _jsxDEV(SelectItem, { value: "misc", children: "متفرقه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 465}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 462}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 460}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 458}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "یادداشت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 470}, this)
              , _jsxDEV(Input, { value: customerForm.notes, onChange: e => setCustomerForm({ ...customerForm, notes: e.target.value }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 471}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 469}, this)
            , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "فیلدهای موبایل، کد و یادداشت اختیاری هستند."      }, void 0, false, {fileName: _jsxFileName, lineNumber: 473}, this)
            , _jsxDEV(DialogFooter, { children: [
              _jsxDEV(Button, { type: "button", variant: "outline", onClick: () => setCustomerDialogOpen(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 475}, this)
              , _jsxDEV(Button, { type: "submit", disabled: createCustomerMut.isPending, children: "افزودن"}, void 0, false, {fileName: _jsxFileName, lineNumber: 476}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 474}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 442}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 438}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 437}, this)

      /* ── Edit Dialog ── */
      , _jsxDEV(Dialog, { open: !!editTx, onOpenChange: (v) => !v && setEditTx(null), children: 
        _jsxDEV(DialogContent, { className: "max-h-[90vh] overflow-y-auto" , children: [
          _jsxDEV(DialogHeader, { children: 
            _jsxDEV(DialogTitle, { children: "ویرایش سند" }, void 0, false, {fileName: _jsxFileName, lineNumber: 486}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 485}, this)
          , editTx && (
            _jsxDEV('form', { onSubmit: handleEdit, className: "space-y-3", children: [
              _jsxDEV('div', { className: "flex items-start gap-2 p-2 rounded-lg bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 text-xs"         , children: [
                _jsxDEV(AlertTriangle, { className: "w-4 h-4 shrink-0 mt-0.5"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 491}, this )
                , _jsxDEV('p', { children: "این سند ویرایش خواهد شد، اما نسخه اصلی در دیتابیس حفظ می‌شود. این یک سند رسمی است و در آینده قابل مراجعه خواهد بود."                       }, void 0, false, {fileName: _jsxFileName, lineNumber: 492}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 490}, this)
              , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
                _jsxDEV('div', { children: [
                  _jsxDEV(Label, { children: "تاریخ"}, void 0, false, {fileName: _jsxFileName, lineNumber: 496}, this)
                  , _jsxDEV(Input, { value: editForm.date, onChange: e => setEditForm({ ...editForm, date: e.target.value }), required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 497}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 495}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { children: "نوع"}, void 0, false, {fileName: _jsxFileName, lineNumber: 500}, this)
                  , _jsxDEV(Select, { value: editForm.type, onValueChange: v => setEditForm({ ...editForm, type: v }), children: [
                    _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 502}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 502}, this)
                    , _jsxDEV(SelectContent, { children: Object.entries(TX_TYPE_LABELS).map(([k, v]) => _jsxDEV(SelectItem, { value: k, children: v}, k, false, {fileName: _jsxFileName, lineNumber: 503}, this))}, void 0, false, {fileName: _jsxFileName, lineNumber: 503}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 501}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 499}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 494}, this)
              , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
                _jsxDEV('div', { children: [
                  _jsxDEV(Label, { children: "ارز"}, void 0, false, {fileName: _jsxFileName, lineNumber: 509}, this)
                  , _jsxDEV(Select, { value: editForm.currency, onValueChange: v => setEditForm({ ...editForm, currency: v }), children: [
                    _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 511}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 511}, this)
                    , _jsxDEV(SelectContent, { children: [_jsxDEV(SelectItem, { value: "AFN", children: "AFN"}, void 0, false, {fileName: _jsxFileName, lineNumber: 512}, this), _jsxDEV(SelectItem, { value: "USD", children: "USD"}, void 0, false, {fileName: _jsxFileName, lineNumber: 512}, this), _jsxDEV(SelectItem, { value: "IRT", children: "IRT"}, void 0, false, {fileName: _jsxFileName, lineNumber: 512}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 512}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 510}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 508}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { children: "مبلغ"}, void 0, false, {fileName: _jsxFileName, lineNumber: 516}, this)
                  , _jsxDEV(AmountInput, { value: editForm.amount, onChange: v => setEditForm({ ...editForm, amount: v }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 517}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 515}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 507}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "سمت مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 521}, this)
                , _jsxDEV(Select, { value: editForm.customer_side, onValueChange: v => setEditForm({ ...editForm, customer_side: v }), children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 523}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 523}, this)
                  , _jsxDEV(SelectContent, { children: [
                    _jsxDEV(SelectItem, { value: "none", children: "—"}, void 0, false, {fileName: _jsxFileName, lineNumber: 525}, this)
                    , _jsxDEV(SelectItem, { value: "debit", children: "بدهکار"}, void 0, false, {fileName: _jsxFileName, lineNumber: 526}, this)
                    , _jsxDEV(SelectItem, { value: "credit", children: "بستانکار"}, void 0, false, {fileName: _jsxFileName, lineNumber: 527}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 524}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 522}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 520}, this)
              , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
                _jsxDEV('div', { children: [
                  _jsxDEV(Label, { children: "نام مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 533}, this)
                  , _jsxDEV(Input, { value: editForm.customer_name || '', onChange: e => setEditForm({ ...editForm, customer_name: e.target.value }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 534}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 532}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { children: "موبایل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 537}, this)
                  , _jsxDEV(Input, { value: editForm.customer_phone || '', onChange: e => setEditForm({ ...editForm, customer_phone: e.target.value }), inputMode: "numeric",}, void 0, false, {fileName: _jsxFileName, lineNumber: 538}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 536}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 531}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "توضیحات"}, void 0, false, {fileName: _jsxFileName, lineNumber: 542}, this)
                , _jsxDEV(Textarea, { value: editForm.description, onChange: e => setEditForm({ ...editForm, description: e.target.value }), rows: 3, className: "resize-y",}, void 0, false, {fileName: _jsxFileName, lineNumber: 543}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 541}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "یادداشت ویرایش" }, void 0, false, {fileName: _jsxFileName, lineNumber: 546}, this)
                , _jsxDEV(Input, { value: editNote, onChange: e => setEditNote(e.target.value), placeholder: "دلیل ویرایش..." ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 547}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 545}, this)
              , _jsxDEV(DialogFooter, { children: [
                _jsxDEV(Button, { type: "button", variant: "outline", onClick: () => setEditTx(null), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 550}, this)
                , _jsxDEV(Button, { type: "submit", disabled: editMut.isPending, children: "ذخیره"}, void 0, false, {fileName: _jsxFileName, lineNumber: 551}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 549}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 489}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 484}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 483}, this)

      /* ── Delete (soft-delete) Dialog ── */
      , _jsxDEV(AlertDialog, { open: !!deleteTx, onOpenChange: (v) => !v && setDeleteTx(null), children: 
        _jsxDEV(AlertDialogContent, { children: [
          _jsxDEV(AlertDialogHeader, { children: [
            _jsxDEV(AlertDialogTitle, { className: "flex items-center gap-2"  , children: [
              _jsxDEV(AlertTriangle, { className: "w-5 h-5 text-destructive"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 563}, this ), "حذف سند"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 562}, this)
            , _jsxDEV(AlertDialogDescription, { children: "این سند حذف خواهد شد، اما هرگز از دیتابیس پاک نمی‌شود. این یک سند رسمی ثبت‌شده است و در آینده قابل مراجعه خواهد بود."

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 566}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 561}, this)
          , _jsxDEV('div', { className: "py-2", children: [
            _jsxDEV(Label, { children: "یادداشت حذف" }, void 0, false, {fileName: _jsxFileName, lineNumber: 571}, this)
            , _jsxDEV(Input, { value: deleteNote, onChange: e => setDeleteNote(e.target.value), placeholder: "دلیل حذف..." ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 572}, this )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 570}, this)
          , _jsxDEV(AlertDialogFooter, { children: [
            _jsxDEV(AlertDialogCancel, { children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 575}, this)
            , _jsxDEV(AlertDialogAction, { onClick: handleDelete, disabled: deleteMut.isPending, children: "حذف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 576}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 574}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 560}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 559}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 224}, this)
  );
}