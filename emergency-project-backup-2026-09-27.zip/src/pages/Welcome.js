const _jsxFileName = "src/pages/Welcome.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button.js';
import { Shield, ArrowLeft, Store, UserCircle } from 'lucide-react';
import ContactInfo from '../components/sarraaf/ContactInfo.js';

export default function Welcome() {
  return (
    _jsxDEV('div', { className: "min-h-screen bg-gradient-to-b from-background to-muted/30 flex flex-col items-center justify-between px-5 py-8"         , children: [
      /* Top spacer */
      _jsxDEV('div', { className: "flex-1",}, void 0, false, {fileName: _jsxFileName, lineNumber: 11}, this )

      /* Hero Section */
      , _jsxDEV('div', { className: "w-full max-w-sm text-center"  , children: [
        _jsxDEV('h1', { className: "text-3xl font-extrabold text-foreground tracking-tight mb-2"    , children: "حساب صراف"

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 15}, this)
        , _jsxDEV('p', { className: "text-sm text-muted-foreground leading-relaxed mb-3 max-w-[260px] mx-auto"     , children: "سامانه جامع مدیریت صرافی، تبدیل ارز و حسابداری مالی"

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 18}, this)
        , _jsxDEV('div', { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-success/10 text-success text-xs font-medium mb-8"          , children: [
          _jsxDEV(Shield, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 22}, this ), "محیط امن مالی"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 21}, this)

        /* Action Buttons */
        , _jsxDEV('div', { className: "space-y-2.5", children: [
          _jsxDEV(Link, { to: "/login", className: "block", children: 
            _jsxDEV(Button, { className: "w-full h-12 text-base font-semibold"   , size: "lg", children: [
              _jsxDEV(ArrowLeft, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 30}, this ), "ورود به حساب"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 29}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 28}, this)
          , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV(Link, { to: "/register?type=sarraaf", className: "block", children: 
              _jsxDEV(Button, { variant: "outline", className: "w-full h-11 text-sm font-medium"   , size: "lg", children: [
                _jsxDEV(Store, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this ), "ثبت‌نام صراف"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 36}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 35}, this)
            , _jsxDEV(Link, { to: "/register?type=customer", className: "block", children: 
              _jsxDEV(Button, { variant: "outline", className: "w-full h-11 text-sm font-medium"   , size: "lg", children: [
                _jsxDEV(UserCircle, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this ), "ثبت‌نام مشتری"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 42}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 34}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 27}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 14}, this)

      /* Bottom Section */
      , _jsxDEV('div', { className: "w-full max-w-sm mt-8"  , children: [
        _jsxDEV(ContactInfo, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 53}, this )
        , _jsxDEV('p', { className: "text-[11px] text-muted-foreground/50 text-center mt-6"   , children: "© 2026 حساب صراف — تمامی حقوق محفوظ است"

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 54}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 52}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 9}, this)
  );
}