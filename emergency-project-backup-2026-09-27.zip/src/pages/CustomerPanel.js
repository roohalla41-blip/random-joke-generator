const _jsxFileName = "src/pages/CustomerPanel.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React from 'react';
import { useAuth } from '../lib/AuthContext.js';
import { Card, CardContent } from '../components/ui/card.js';
import { Wallet, ShoppingBag, Send, Users, MessageSquare, Coins } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function CustomerPanel() {
  const { user, logout } = useAuth();

  const MENU = [
    { label: 'کیف پول', icon: Wallet, action: () => {} },
    { label: 'محصولات', icon: ShoppingBag, action: () => {} },
    { label: 'حواله', icon: Send, action: () => {} },
    { label: 'چت و گروه‌ها', icon: MessageSquare, path: '/customer/chat' },
    { label: 'صراف‌های من', icon: Users, action: () => {} },
  ];

  return (
    _jsxDEV('div', { className: "min-h-screen bg-background" , children: [
      _jsxDEV('header', { className: "sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-background border-b"         , children: [
        _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
          _jsxDEV('div', { className: "w-8 h-8 rounded-lg bg-primary flex items-center justify-center"      , children: 
            _jsxDEV(Coins, { className: "w-4 h-4 text-primary-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 23}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 22}, this)
          , _jsxDEV('span', { className: "text-sm font-bold" , children: "حساب مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 25}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 21}, this)
        , _jsxDEV('button', { onClick: () => logout(), className: "text-xs text-muted-foreground" , children: "خروج"}, void 0, false, {fileName: _jsxFileName, lineNumber: 27}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 20}, this)

      , _jsxDEV('main', { className: "max-w-md mx-auto p-4"  , children: [
        _jsxDEV('div', { className: "text-center mb-6" , children: [
          _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "خوش آمدید" }, void 0, false, {fileName: _jsxFileName, lineNumber: 32}, this)
          , _jsxDEV('p', { className: "text-lg font-bold" , children: _optionalChain([user, 'optionalAccess', _ => _.full_name]) || _optionalChain([user, 'optionalAccess', _2 => _2.email])}, void 0, false, {fileName: _jsxFileName, lineNumber: 33}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 31}, this)

        , _jsxDEV('div', { className: "grid grid-cols-2 gap-3 mb-6"   , children: 
          MENU.map((item, i) => {
            const Icon = item.icon;
            if (item.path) {
              return (
                _jsxDEV(Link, { to: item.path, className: "flex flex-col items-center gap-2 p-4 rounded-xl border bg-card hover:bg-muted/30 transition-colors"         , children: [
                  _jsxDEV(Icon, { className: "w-8 h-8 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this )
                  , _jsxDEV('span', { className: "text-sm font-medium" , children: item.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this)
                ]}, i, true, {fileName: _jsxFileName, lineNumber: 41}, this)
              );
            }
            return (
              _jsxDEV('button', { onClick: item.action, className: "flex flex-col items-center gap-2 p-4 rounded-xl border bg-card hover:bg-muted/30 transition-colors"         , children: [
                _jsxDEV(Icon, { className: "w-8 h-8 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this )
                , _jsxDEV('span', { className: "text-sm font-medium" , children: item.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this)
              ]}, i, true, {fileName: _jsxFileName, lineNumber: 48}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this)

        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-4 text-center" , children: 
            _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "پنل مشتری — نسخه اولیه"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 57}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 30}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 19}, this)
  );
}