const _jsxFileName = "src/pages/SarraafMarket.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../lib/AuthContext.js';
import { useSarraafProfile } from '../lib/useSarraaf.js';
import { offlineDB } from '../lib/offlineQueue.js';
import FeatureGate from '../components/FeatureGate.js';
import { PageHeader, LoadingState, EmptyState } from '../components/sarraaf/Pieces.js';
import { Card, CardContent } from '../components/ui/card.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Send, Store, TrendingUp } from 'lucide-react';
import { format } from 'date-fns';

export default function SarraafMarket() {
  const { user } = useAuth();
  const { data: profile } = useSarraafProfile(_optionalChain([user, 'optionalAccess', _ => _.id]));
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  const loadMessages = async () => {
    try {
      const all = await offlineDB.ChatGroup.list();
      let market = all.find(g => g.type === 'sarraaf_market' && g.status === 'active');
      if (!market) {
        market = await offlineDB.ChatGroup.create({
          name: 'بازار نرخ صراف‌ها',
          type: 'sarraaf_market',
          status: 'active',
          description: 'کانال عمومی برای اشتراک نرخ ارز',
          creator_id: _optionalChain([user, 'optionalAccess', _2 => _2.id]),
          creator_name: _optionalChain([profile, 'optionalAccess', _3 => _3.exchange_name]) || _optionalChain([user, 'optionalAccess', _4 => _4.full_name]),
        });
      }
      const msgs = await offlineDB.GroupMessage.filter({ group_id: market.id, status: 'active' }, '-created_date', 100);
      setMessages((msgs || []).reverse());
    } catch (e2) {
      setMessages([]);
    }
    setLoading(false);
  };

  useEffect(() => { loadMessages(); }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!text.trim()) return;
    setSending(true);
    try {
      const all = await offlineDB.ChatGroup.list();
      const market = all.find(g => g.type === 'sarraaf_market');
      if (!market) return;
      await offlineDB.GroupMessage.create({
        group_id: market.id,
        sender_id: _optionalChain([user, 'optionalAccess', _5 => _5.id]),
        sender_name: _optionalChain([profile, 'optionalAccess', _6 => _6.exchange_name]) || _optionalChain([user, 'optionalAccess', _7 => _7.full_name]),
        sender_role: 'sarraaf',
        message: text.trim(),
        sync_status: 'pending',
        status: 'active',
      });
      setText('');
      await loadMessages();
    } catch (e3) {
      // ignore
    }
    setSending(false);
  };

  return (
    _jsxDEV(FeatureGate, { featureKey: "sarraaf_market", children: [
      _jsxDEV(PageHeader, { title: "بازار نرخ صراف‌ها"  , subtitle: "کانال عمومی اشتراک نرخ"   , icon: Store,}, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this )

      , loading ? (
        _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this )
      ) : (
        _jsxDEV(Card, { className: "flex flex-col" , style: { height: 'calc(100vh - 200px)' }, children: [
          _jsxDEV(CardContent, { className: "flex-1 overflow-y-auto p-3 scrollbar-thin"   , ref: scrollRef, children: 
            messages.length === 0 ? (
              _jsxDEV(EmptyState, { icon: TrendingUp, title: "پیامی ثبت نشده"  , description: "اولین نرخ امروز را اشتراک بگذارید"     ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this )
            ) : (
              _jsxDEV('div', { className: "space-y-3", children: 
                messages.map(msg => (
                  _jsxDEV('div', { className: `flex flex-col ${msg.sender_id === _optionalChain([user, 'optionalAccess', _8 => _8.id]) ? 'items-end' : 'items-start'}`, children: 
                    _jsxDEV('div', { className: `max-w-[80%] rounded-2xl px-3 py-2 ${msg.sender_id === _optionalChain([user, 'optionalAccess', _9 => _9.id]) ? 'bg-primary text-primary-foreground' : 'bg-muted'}`, children: [
                      msg.sender_id !== _optionalChain([user, 'optionalAccess', _10 => _10.id]) && (
                        _jsxDEV('p', { className: "text-xs font-bold mb-0.5 opacity-80"   , children: msg.sender_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this)
                      )
                      , _jsxDEV('p', { className: "text-sm whitespace-pre-wrap" , children: msg.message}, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this)
                      , _jsxDEV('p', { className: "text-[10px] opacity-60 mt-1"  , children: 
                        msg.created_date ? format(new Date(msg.created_date), 'HH:mm') : ''
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 91}, this)
                  }, msg.id, false, {fileName: _jsxFileName, lineNumber: 90}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)
            )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this)
          , _jsxDEV('div', { className: "border-t p-2 flex items-center gap-2"    , children: [
            _jsxDEV(Input, {
              value: text,
              onChange: e => setText(e.target.value),
              onKeyDown: e => e.key === 'Enter' && handleSend(),
              placeholder: "نرخ یا پیام خود را بنویسید..."     ,
              disabled: sending,}, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this
            )
            , _jsxDEV(Button, { size: "icon", onClick: handleSend, disabled: sending || !text.trim(), children: 
              _jsxDEV(Send, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 105}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 83}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 77}, this)
  );
}