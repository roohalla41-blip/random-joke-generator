const _jsxFileName = "src/pages/Reconciliation.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState, useMemo } from 'react';
import { useTreasuryBalances, useDocuments } from '../lib/useSarraaf.js';
import { PageHeader, EmptyState, LoadingState } from '../components/sarraaf/Pieces.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { formatNumber } from '../lib/sarraaf.js';
import { documentBaseBalances } from '../lib/ledger.js';
import { Scale, Printer } from 'lucide-react';
import { Card, CardContent } from '../components/ui/card.js';
import { AmountInput } from '../components/sarraaf/Fields.js';

export default function Reconciliation() {
  const { data: treasuryData, isLoading } = useTreasuryBalances();
  const { data: documents } = useDocuments();
  const [physical, setPhysical] = useState({});

  const bookBalances = {};
  for (const b of (treasuryData || [])) {
    bookBalances[b.currency] = b.balance;
  }
  const currencies = Object.keys(bookBalances);

  const diffs = {};
  for (const cur of currencies) {
    const book = bookBalances[cur] || 0;
    const phys = physical[cur] || 0;
    diffs[cur] = phys - book;
  }

  const unbalanced = useMemo(() => {
    if (!documents || documents.length === 0) return [];
    const result = [];
    for (const doc of documents) {
      if (!doc.lines || doc.lines.length < 2) continue;
      const balances = documentBaseBalances(doc.lines);
      const hasImbalance = Object.values(balances).some(b => Math.abs(b.debit - b.credit) > 0.5);
      if (hasImbalance) {
        result.push({ docNo: doc.doc_number, lines: doc.lines, balances });
      }
    }
    return result;
  }, [documents]);

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "مغایرت‌گیری", icon: Scale,
        actions: _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => window.print(), children: [_jsxDEV(Printer, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this ), " چاپ" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 48}, this),}, void 0, false, {fileName: _jsxFileName, lineNumber: 47}, this
      )
      , isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this ) : (
        _jsxDEV(_Fragment, { children: [
          unbalanced.length > 0 && (
            _jsxDEV(Card, { className: "mb-4 border-destructive" , children: 
              _jsxDEV(CardContent, { className: "p-4", children: 
                _jsxDEV('p', { className: "text-sm font-medium text-destructive"  , children: ["⚠ " , unbalanced.length, " سند ناتراز"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 55}, this)
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 54}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 53}, this)
          )
          , _jsxDEV('h3', { className: "text-sm font-semibold mb-2"  , children: "شمارش فیزیکی صندوق"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this)
          , _jsxDEV('div', { className: "space-y-3", children: 
            currencies.length === 0 ? (
              _jsxDEV(EmptyState, { icon: Scale, title: "داده‌ای نیست" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this )
            ) : currencies.map(cur => (
              _jsxDEV('div', { className: "grid grid-cols-3 gap-2 items-center p-3 rounded-xl border"      , children: [
                _jsxDEV('span', { className: "text-sm font-medium" , children: cur}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { className: "text-xs", children: ["دفتری: " , formatNumber(bookBalances[cur] || 0)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 67}, this)
                  , _jsxDEV(AmountInput, { value: physical[cur] || 0, onChange: v => setPhysical({...physical, [cur]: v}), placeholder: "فیزیکی",}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 66}, this)
                , _jsxDEV('div', { className: `text-sm font-bold ${(diffs[cur] || 0) === 0 ? 'text-success' : 'text-destructive'}`, children: ["مغایرت: "
                   , formatNumber(diffs[cur] || 0)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 70}, this)
              ]}, cur, true, {fileName: _jsxFileName, lineNumber: 64}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 51}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 46}, this)
  );
}