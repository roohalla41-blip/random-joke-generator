const _jsxFileName = "src/pages/BalanceSheet.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useMemo } from 'react';
import { useBankAccounts, useAgents, useCustomers, useCurrencies, useRateSettings, useTreasuryBalances, useBankBalances, useAgentBalances, useCustomerBalances } from '../lib/useSarraaf.js';
import { PageHeader, LoadingState } from '../components/sarraaf/Pieces.js';
import { formatNumber } from '../lib/sarraaf.js';
import { Card, CardContent } from '../components/ui/card.js';
import { Button } from '../components/ui/button.js';
import { Scale, Printer, CheckCircle2, AlertCircle, FileSpreadsheet } from 'lucide-react';

// Convert multi-currency balances to AFN using daily rates
function toAfnTotal(balances, rateSettings, currencies) {
  let total = 0;
  for (const [cur, val] of Object.entries(balances)) {
    if (cur === 'AFN') total += val || 0;
    else if (cur === 'USD') total += (val || 0) * parseFloat(_optionalChain([rateSettings, 'optionalAccess', _ => _.usd_afn]) || '0');
    else if (cur === 'IRT') {
      const afnToman = parseFloat(_optionalChain([rateSettings, 'optionalAccess', _2 => _2.afn_toman]) || '0');
      total += afnToman > 0 ? (val || 0) / afnToman : 0;
    } else {
      const c = _optionalChain([currencies, 'optionalAccess', _3 => _3.find, 'call', _4 => _4(x => x.code === cur)]);
      total += (val || 0) * (_optionalChain([c, 'optionalAccess', _5 => _5.daily_rate]) || _optionalChain([c, 'optionalAccess', _6 => _6.sell_rate]) || 0);
    }
  }
  return total;
}

const exportExcel = (label, amounts) => {
  const rows = Object.entries(amounts).map(([cur, val]) => ({ 'ارز': cur, 'مبلغ': val }));
  if (rows.length === 0) return;
  const csv = '\uFEFF' + Object.keys(rows[0]).join(',') + '\n' + rows.map(r => Object.values(r).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = `balance-${label}.csv`; a.click();
  URL.revokeObjectURL(url);
};

export default function BalanceSheet() {
  const { data: treasuryData, isLoading } = useTreasuryBalances();
  const { data: bankBalancesData } = useBankBalances();
  const { data: agentBalancesData } = useAgentBalances();
  const { data: customerBalancesData } = useCustomerBalances();
  const { data: bankAccounts } = useBankAccounts();
  const { data: agents } = useAgents();
  const { data: currencies } = useCurrencies();
  const { data: rateSettings } = useRateSettings();
  const rs = rateSettings || {};
  const curs = currencies || [];

  const cash = {};
  for (const b of (treasuryData || [])) {
    cash[b.currency] = b.balance;
  }
  const totalCash = toAfnTotal(cash, rs, curs);

  const totalBanks = (bankBalancesData || []).reduce((s, b) => {
    const bal = { [b.currency]: b.current_balance || 0 };
    return s + toAfnTotal(bal, rs, curs);
  }, 0);

  const totalAgents = (agentBalancesData || []).reduce((s, a) => {
    const bal = { [a.currency || 'AFN']: a.balance || 0 };
    return s + toAfnTotal(bal, rs, curs);
  }, 0);

  // Liabilities: customer credit balances (money we owe customers)
  const customerLiabilities = useMemo(() => {
    if (!customerBalancesData) return 0;
    let total = 0;
    for (const b of customerBalancesData) {
      if ((b.net_balance || 0) > 0) {
        const creditBal = { [b.balance_currency || 'AFN']: b.net_balance };
        total += toAfnTotal(creditBal, rs, curs);
      }
    }
    return total;
  }, [customerBalancesData, rs, curs]);

  // Customer receivables (money customers owe us)
  const customerReceivables = useMemo(() => {
    if (!customerBalancesData) return 0;
    let total = 0;
    for (const b of customerBalancesData) {
      if ((b.net_balance || 0) < 0) {
        const debitBal = { [b.balance_currency || 'AFN']: Math.abs(b.net_balance) };
        total += toAfnTotal(debitBal, rs, curs);
      }
    }
    return total;
  }, [customerBalancesData, rs, curs]);

  const totalAssets = totalCash + totalBanks + totalAgents + customerReceivables;
  const totalLiabilities = customerLiabilities;
  const equity = totalAssets - totalLiabilities;
  const isBalanced = Math.abs(totalAssets - (totalLiabilities + equity)) < 1;

  const getBankTotal = (bankId) => {
    const b = (bankBalancesData || []).find(x => String(x.bank_id) === String(bankId));
    return b ? { [b.currency]: b.current_balance || 0 } : {};
  };

  const getAgentTotal = (agentId) => {
    const a = (agentBalancesData || []).find(x => String(x.agent_id) === String(agentId));
    return a ? { [a.currency || 'AFN']: a.balance || 0 } : {};
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "ترازنامه", icon: Scale,
        actions: 
          _jsxDEV('div', { className: "flex gap-1" , children: [
            _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => exportExcel('sheet', cash), children: _jsxDEV(FileSpreadsheet, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this)
            , _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => window.print(), children: _jsxDEV(Printer, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 109}, this)
        ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this
      )
      , isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this ) : (
        _jsxDEV('div', { className: "space-y-4", children: [
          _jsxDEV('div', { className: `flex items-center gap-2 p-3 rounded-lg ${isBalanced ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'}`, children: [
            isBalanced ? _jsxDEV(CheckCircle2, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this ) : _jsxDEV(AlertCircle, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this )
            , _jsxDEV('span', { className: "text-sm font-medium" , children: isBalanced ? 'ترازنامه متوازن است' : 'ترازنامه ناتراز است — بررسی کنید'}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 117}, this)

          , _jsxDEV(Card, { children: 
            _jsxDEV(CardContent, { className: "p-4", children: [
              _jsxDEV('h3', { className: "text-sm font-semibold mb-2 text-primary"   , children: "دارایی‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this)
              , _jsxDEV('div', { className: "space-y-1", children: [
                _jsxDEV('div', { className: "flex justify-between text-sm"  , children: [_jsxDEV('span', { children: "صندوق"}, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this), _jsxDEV('span', { className: "font-mono", children: formatNumber(totalCash)}, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 126}, this)
                , (bankAccounts || []).map(b => {
                  const bal = getBankTotal(b.id);
                  const total = Object.values(bal).reduce((s, v) => s + (v || 0), 0);
                  return _jsxDEV('div', { className: "flex justify-between text-sm"  , children: [_jsxDEV('span', { children: b.bank_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this), _jsxDEV('span', { className: "font-mono", children: formatNumber(total)}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)]}, b.id, true, {fileName: _jsxFileName, lineNumber: 130}, this);
                })
                , (agents || []).map(a => {
                  const bal = getAgentTotal(a.id);
                  const total = Object.values(bal).reduce((s, v) => s + (v || 0), 0);
                  return _jsxDEV('div', { className: "flex justify-between text-sm"  , children: [_jsxDEV('span', { children: a.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this), _jsxDEV('span', { className: "font-mono", children: formatNumber(total)}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this)]}, a.id, true, {fileName: _jsxFileName, lineNumber: 135}, this);
                })
                , _jsxDEV('div', { className: "flex justify-between text-sm font-bold border-t pt-1 mt-1"      , children: [_jsxDEV('span', { children: "جمع دارایی‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this), _jsxDEV('span', { className: "font-mono", children: formatNumber(totalAssets)}, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 137}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 125}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 123}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this)

          , _jsxDEV(Card, { children: 
            _jsxDEV(CardContent, { className: "p-4", children: [
              _jsxDEV('h3', { className: "text-sm font-semibold mb-2 text-destructive"   , children: "بدهی‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this)
              , _jsxDEV('div', { className: "space-y-1", children: [
                _jsxDEV('div', { className: "flex justify-between text-sm"  , children: [_jsxDEV('span', { children: "بدهی به مشتریان"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this), _jsxDEV('span', { className: "font-mono", children: formatNumber(customerLiabilities)}, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 146}, this)
                , _jsxDEV('div', { className: "flex justify-between text-sm font-bold border-t pt-1 mt-1"      , children: [_jsxDEV('span', { children: "جمع بدهی‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this), _jsxDEV('span', { className: "font-mono", children: formatNumber(totalLiabilities)}, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 145}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 143}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this)

          , _jsxDEV(Card, { children: 
            _jsxDEV(CardContent, { className: "p-4", children: [
              _jsxDEV('h3', { className: "text-sm font-semibold mb-2 text-success"   , children: "سرمایه و سود/زیان"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 154}, this)
              , _jsxDEV('div', { className: "space-y-1", children: [
                _jsxDEV('div', { className: "flex justify-between text-sm"  , children: [_jsxDEV('span', { children: "طلب از مشتریان"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this), _jsxDEV('span', { className: "font-mono", children: formatNumber(customerReceivables)}, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 156}, this)
                , _jsxDEV('div', { className: "flex justify-between text-sm"  , children: [_jsxDEV('span', { children: "مانده حساب (دارایی - بدهی)"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this), _jsxDEV('span', { className: "font-mono", children: formatNumber(equity)}, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 157}, this)
                , _jsxDEV('div', { className: "flex justify-between text-sm font-bold border-t pt-1 mt-1"      , children: [_jsxDEV('span', { children: "جمع سرمایه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this), _jsxDEV('span', { className: "font-mono", children: formatNumber(customerReceivables + equity)}, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 158}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 155}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 153}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 152}, this)

          , _jsxDEV(Card, { children: 
            _jsxDEV(CardContent, { className: "p-4", children: [
              _jsxDEV('div', { className: "flex justify-between text-sm font-bold"   , children: [
                _jsxDEV('span', { children: "جمع بدهی‌ها + سرمایه"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 166}, this)
                , _jsxDEV('span', { className: "font-mono", children: formatNumber(totalLiabilities + customerReceivables + equity)}, void 0, false, {fileName: _jsxFileName, lineNumber: 167}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 165}, this)
              , _jsxDEV('div', { className: "flex justify-between text-sm font-bold mt-1"    , children: [
                _jsxDEV('span', { children: "جمع دارایی‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 170}, this)
                , _jsxDEV('span', { className: "font-mono", children: formatNumber(totalAssets)}, void 0, false, {fileName: _jsxFileName, lineNumber: 171}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 169}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 164}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 116}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 106}, this)
  );
}