const _jsxFileName = "src/pages/Currencies.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { useCurrencies, useCreateCurrency, useUpdateCurrency } from '../lib/useSarraaf.js';
import { PageHeader, EmptyState, LoadingState } from '../components/sarraaf/Pieces.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Switch } from '../components/ui/switch.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
import { formatNumber } from '../lib/sarraaf.js';
import { recordRateChange } from '../lib/rateHistory.js';
import { useAuth } from '../lib/AuthContext.js';
import { toast } from '../components/ui/use-toast.js';
import { AmountInput } from '../components/sarraaf/Fields.js';
import { Coins, Plus, Pencil, Loader2 } from 'lucide-react';

// Sort: AFN first, USD second, then by sort_order
function sortCurrencies(list) {
  return [...list].sort((a, b) => {
    if (a.code === 'AFN') return -1;
    if (b.code === 'AFN') return 1;
    if (a.code === 'USD') return -1;
    if (b.code === 'USD') return 1;
    return (a.sort_order || 0) - (b.sort_order || 0);
  });
}

export default function Currencies() {
  const { data: currencies, isLoading } = useCurrencies();
  const createMut = useCreateCurrency();
  const updateMut = useUpdateCurrency();
  const { user } = useAuth();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ code: '', name: '', symbol: '', type: 'fiat', buy_rate: 0, sell_rate: 0, daily_rate: 0, decimals: 2, sort_order: 0 });

  const sorted = sortCurrencies(currencies || []);

  const openCreate = () => {
    setEditId(null);
    setForm({ code: '', name: '', symbol: '', type: 'fiat', buy_rate: 0, sell_rate: 0, daily_rate: 0, decimals: 2, sort_order: 0 });
    setDialogOpen(true);
  };

  const openEdit = (c) => {
    setEditId(c.id);
    setForm({ code: c.code || '', name: c.name || '', symbol: c.symbol || '', type: c.type || 'fiat', buy_rate: c.buy_rate || 0, sell_rate: c.sell_rate || 0, daily_rate: c.daily_rate || 0, decimals: c.decimals || 2, sort_order: c.sort_order || 0 });
    setDialogOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editId) {
        // Record rate change for history
        const existing = _optionalChain([currencies, 'optionalAccess', _ => _.find, 'call', _2 => _2(c => c.id === editId)]);
        if (existing) {
          const oldBuy = existing.buy_rate || 0;
          const oldSell = existing.sell_rate || 0;
          if (oldBuy !== form.buy_rate || oldSell !== form.sell_rate) {
            await recordRateChange({
              currency: form.code,
              oldBuyRate: oldBuy,
              oldSellRate: oldSell,
              newBuyRate: form.buy_rate,
              newSellRate: form.sell_rate,
              changedBy: _optionalChain([user, 'optionalAccess', _3 => _3.full_name]) || _optionalChain([user, 'optionalAccess', _4 => _4.email]) || '—',
            });
          }
        }
        await updateMut.mutateAsync({ id: editId, data: form });
      } else {
        await createMut.mutateAsync({ ...form, is_active: true, is_system: false });
      }
      setDialogOpen(false);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleToggleActive = async (c) => {
    if (c.is_system) return; // System currencies can't be disabled
    try {
      await updateMut.mutateAsync({ id: c.id, data: { is_active: !c.is_active } });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "ارز و نرخ"  , subtitle: "مدیریت ارزهای سیستم"  , icon: Coins,
        actions: _jsxDEV(Button, { size: "sm", onClick: openCreate, children: [_jsxDEV(Plus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this ), " افزودن ارز"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 93}, this),}, void 0, false, {fileName: _jsxFileName, lineNumber: 92}, this
      )

      , isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this ) : sorted.length === 0 ? _jsxDEV(EmptyState, { icon: Coins, title: "ارزی تعریف نشده"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          sorted.map(c => (
            _jsxDEV('div', { className: `flex items-center justify-between p-3 rounded-xl border bg-card ${!c.is_active ? 'opacity-50' : ''}`, children: [
              _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                _jsxDEV('div', { className: "w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs"         , children: c.symbol || c.code}, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
                    _jsxDEV('p', { className: "text-sm font-medium" , children: c.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this)
                    , c.is_system && _jsxDEV('span', { className: "text-[10px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300"       , children: "سیستم"}, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this)
                    , _jsxDEV('span', { className: `text-[10px] px-1.5 py-0.5 rounded ${c.type === 'crypto' ? 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300' : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'}`, children: 
                      c.type === 'crypto' ? 'دیجیتال' : 'رایج'
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 103}, this)
                  , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: c.code}, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 102}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 100}, this)
              , _jsxDEV('div', { className: "flex items-center gap-3"  , children: [
                _jsxDEV('div', { className: "text-left", children: [
                  _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: ["خرید: " , formatNumber(c.buy_rate, 2)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 115}, this)
                  , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: ["فروش: " , formatNumber(c.sell_rate, 2)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 116}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 114}, this)
                , _jsxDEV('div', { className: "flex items-center gap-1"  , children: [
                  _jsxDEV(Switch, {
                    checked: c.is_active !== false,
                    onCheckedChange: () => handleToggleActive(c),
                    disabled: c.is_system,}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this
                  )
                  , _jsxDEV(Button, { size: "icon", variant: "ghost", onClick: () => openEdit(c), children: _jsxDEV(Pencil, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 118}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 113}, this)
            ]}, c.id, true, {fileName: _jsxFileName, lineNumber: 99}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)
      )

      , _jsxDEV('p', { className: "text-xs text-muted-foreground mt-3"  , children: "افغانی (AFN) و دلار (USD) ارزهای پایه سیستم هستند و نمی‌توان آن‌ها را غیرفعال کرد. ارزهای غیرفعال در فرم‌های جدید نمایش داده نمی‌شوند ولی معاملات قبلی آن‌ها حفظ می‌شود."

      }, void 0, false, {fileName: _jsxFileName, lineNumber: 132}, this)

      , _jsxDEV(Dialog, { open: dialogOpen, onOpenChange: setDialogOpen, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: editId ? 'ویرایش ارز' : 'افزودن ارز'}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)
          , _jsxDEV('form', { onSubmit: handleSubmit, className: "space-y-3", children: [
            _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [_jsxDEV(Label, { children: "کد"}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this), _jsxDEV(Input, { value: form.code, onChange: e => setForm({...form, code: e.target.value}), placeholder: "USD", required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 141}, this)
              , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "نام"}, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this), _jsxDEV(Input, { value: form.name, onChange: e => setForm({...form, name: e.target.value}), placeholder: "دلر آمریکا" , required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 140}, this)
            , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "نماد"}, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this), _jsxDEV(Input, { value: form.symbol, onChange: e => setForm({...form, symbol: e.target.value}), placeholder: "$",}, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 144}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نوع"}, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this)
              , _jsxDEV(Select, { value: form.type, onValueChange: v => setForm({...form, type: v}), children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this)
                , _jsxDEV(SelectContent, { children: [
                  _jsxDEV(SelectItem, { value: "fiat", children: "ارز رایج" }, void 0, false, {fileName: _jsxFileName, lineNumber: 150}, this)
                  , _jsxDEV(SelectItem, { value: "crypto", children: "دارایی دیجیتال" }, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 149}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 145}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [_jsxDEV(Label, { children: "نرخ خرید" }, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this), _jsxDEV(AmountInput, { value: form.buy_rate, onChange: v => setForm({...form, buy_rate: v}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 156}, this)
              , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "نرخ فروش" }, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this), _jsxDEV(AmountInput, { value: form.sell_rate, onChange: v => setForm({...form, sell_rate: v}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 157}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 155}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [_jsxDEV(Label, { children: "نرخ روز" }, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this), _jsxDEV(AmountInput, { value: form.daily_rate, onChange: v => setForm({...form, daily_rate: v}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 160}, this)
              , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "اعشار"}, void 0, false, {fileName: _jsxFileName, lineNumber: 161}, this), _jsxDEV(Input, { type: "number", value: form.decimals, onChange: e => setForm({...form, decimals: parseInt(e.target.value) || 2}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 161}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 161}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 159}, this)
            , _jsxDEV(DialogFooter, { children: [
              _jsxDEV(Button, { type: "button", variant: "outline", onClick: () => setDialogOpen(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 164}, this)
              , _jsxDEV(Button, { type: "submit", disabled: createMut.isPending || updateMut.isPending, children: (createMut.isPending || updateMut.isPending) ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this ) : 'ذخیره'}, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 163}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 139}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 137}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 91}, this)
  );
}