const _jsxFileName = "src/pages/Debtors.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCustomers, useCustomerBalances } from '../lib/useSarraaf.js';
import { PageHeader, StatCard, EmptyState, LoadingState, StatusBadge } from '../components/sarraaf/Pieces.js';
import { Input } from '../components/ui/input.js';
import { formatNumber, formatAmount } from '../lib/sarraaf.js';
import { Search, Wallet, TrendingDown, TrendingUp, ChevronLeft } from 'lucide-react';
import { cn } from '../lib/utils.js';

const TABS = [
  { key: 'debtors', label: 'بدهکاران' },
  { key: 'creditors', label: 'بستانکاران' },
  { key: 'all', label: 'همه' },
];

export default function Debtors() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState('debtors');

  const { data: customers, isLoading: customersLoading } = useCustomers();
  const { data: customerBalancesData, isLoading: txsLoading } = useCustomerBalances();

  const loading = customersLoading || txsLoading;

  const rows = useMemo(() => {
    if (!customers || !customerBalancesData) return [];
    const list = customers
      .map(c => {
        const balRow = customerBalancesData.find(b => String(b.customer_id) === String(c.id));
        const balances = {};
        if (balRow) {
          balances[balRow.balance_currency || 'AFN'] = balRow.net_balance || 0;
        }
        const net = Object.values(balances).reduce((s, v) => s + (v || 0), 0);
        const hasBalance = Object.values(balances).some(v => Math.abs(v) > 0.0001);
        return { customer: c, balances, net, hasBalance };
      })
      .filter(r => r.hasBalance);

    const filtered = list.filter(r => {
      if (tab === 'debtors' && r.net <= 0) return false;
      if (tab === 'creditors' && r.net >= 0) return false;
      if (search) {
        const s = search.toLowerCase();
        const c = r.customer;
        if (
          !(c.name || '').toLowerCase().includes(s) &&
          !(c.phone || '').includes(s) &&
          !(c.code || '').toLowerCase().includes(s)
        )
          return false;
      }
      return true;
    });

    return filtered.sort((a, b) => Math.abs(b.net) - Math.abs(a.net));
  }, [customers, customerBalancesData, tab, search]);

  const totals = useMemo(() => {
    const debt = rows.filter(r => r.net > 0).reduce((s, r) => s + r.net, 0);
    const credit = rows.filter(r => r.net < 0).reduce((s, r) => s + Math.abs(r.net), 0);
    return { debt, credit, count: rows.length };
  }, [rows]);

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, {
        title: "بدهکاران",
        subtitle: `${formatNumber(totals.count)} نفر`,
        icon: Wallet,}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this
      )

      /* Summary */
      , _jsxDEV('div', { className: "grid grid-cols-3 gap-2 mb-4"   , children: [
        _jsxDEV(StatCard, {
          label: "بدهکار",
          value: formatNumber(totals.debt),
          icon: TrendingUp,
          gradient: "from-success/90 to-success/70" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this
        )
        , _jsxDEV(StatCard, {
          label: "بستانکار",
          value: formatNumber(totals.credit),
          icon: TrendingDown,
          gradient: "from-destructive/90 to-destructive/70" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this
        )
        , _jsxDEV(StatCard, {
          label: "خالص",
          value: formatNumber(totals.debt - totals.credit),
          icon: Wallet,
          gradient: "from-primary/90 to-primary/70" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 75}, this)

      /* Search */
      , _jsxDEV('div', { className: "relative mb-3" , children: [
        _jsxDEV(Search, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this )
        , _jsxDEV(Input, {
          value: search,
          onChange: e => setSearch(e.target.value),
          placeholder: "جستجو نام / موبایل / کد"     ,
          className: "pr-9",}, void 0, false, {fileName: _jsxFileName, lineNumber: 99}, this
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 97}, this)

      /* Tabs */
      , _jsxDEV('div', { className: "flex gap-1 mb-4 p-1 bg-muted rounded-lg"     , children: 
        TABS.map(t => (
          _jsxDEV('button', {

            onClick: () => setTab(t.key),
            className: cn(
              'flex-1 py-1.5 rounded-md text-xs font-medium transition-colors',
              tab === t.key ? 'bg-background shadow-sm text-foreground' : 'text-muted-foreground'
            ),
 children: 
            t.label
          }, t.key, false, {fileName: _jsxFileName, lineNumber: 110}, this)
        ))
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this)

      /* List */
      , loading ? (
        _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this )
      ) : rows.length === 0 ? (
        _jsxDEV(EmptyState, { icon: Wallet, title: "موردی یافت نشد"  , description: "مشتری با مانده غیرصفر وجود ندارد"     ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this )
      ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          rows.map(({ customer, balances, net }) => {
            const isDebtor = net > 0;
            return (
              _jsxDEV('div', {

                className: "flex items-center justify-between gap-2 p-3 rounded-xl border bg-card hover:bg-muted/30 transition-colors cursor-pointer"          ,
                onClick: () => navigate(`/customers/${customer.id}`),
 children: [
                _jsxDEV('div', { className: "flex items-center gap-2 min-w-0"   , children: [
                  _jsxDEV('div', {
                    className: cn(
                      'w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0',
                      isDebtor ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'
                    ),
 children: 
                    (customer.name || '?').charAt(0)
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this)
                  , _jsxDEV('div', { className: "min-w-0", children: [
                    _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
                      _jsxDEV('span', { className: "text-sm font-medium truncate"  , children: customer.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this)
                      , _jsxDEV(StatusBadge, {
                        status: isDebtor ? 'active' : 'inactive',
                        labels: { active: 'بدهکار', inactive: 'بستانکار' },
                        variant: isDebtor ? 'success' : 'destructive',}, void 0, false, {fileName: _jsxFileName, lineNumber: 150}, this
                      )
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 148}, this)
                    , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: [
                      customer.phone || '—', " " , customer.code ? ` • ${customer.code}` : ''
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 156}, this)
                    , _jsxDEV('div', { className: "flex flex-wrap gap-x-2 mt-0.5"   , children: 
                      Object.entries(balances).map(([cur, val]) => (
                        _jsxDEV('span', {

                          className: cn(
                            'text-xs font-semibold',
                            val >= 0 ? 'text-success' : 'text-destructive'
                          ),
 children: 
                          formatAmount(val, cur)
                        }, cur, false, {fileName: _jsxFileName, lineNumber: 161}, this)
                      ))
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 138}, this)
                , _jsxDEV(ChevronLeft, { className: "w-4 h-4 text-muted-foreground shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 174}, this )
              ]}, customer.id, true, {fileName: _jsxFileName, lineNumber: 133}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 67}, this)
  );
}