const _jsxFileName = "src/pages/CustomerDetail.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTransactions, useCustomers, useUpdateCustomer, useCustomerBalances } from '../lib/useSarraaf.js';
import { PageHeader, BalanceCard, EmptyState, LoadingState, TransactionRow, StatusBadge } from '../components/sarraaf/Pieces.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
import { TX_TYPE_LABELS, CUSTOMER_TYPE_LABELS } from '../lib/sarraaf.js';
import { Link } from 'react-router-dom';
import { ArrowLeftRight, TrendingUp, Send, Download, Repeat, Pencil } from 'lucide-react';

const QUICK_ACTIONS = (id) => [
  { label: 'دریافت', path: `/dadogereft?customer=${id}`, icon: ArrowLeftRight },
  { label: 'خرید', path: `/trade?customer=${id}&mode=buy`, icon: TrendingUp },
  { label: 'فروش', path: `/trade?customer=${id}&mode=sell`, icon: TrendingUp },
  { label: 'حواله ارسال', path: `/transfers/send?customer=${id}`, icon: Send },
  { label: 'حواله دریافت', path: `/transfers/receive?customer=${id}`, icon: Download },
  { label: 'تبدیل', path: `/convert?customer=${id}`, icon: Repeat },
];

export default function CustomerDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data: customers } = useCustomers();
  const { data: txs, isLoading } = useTransactions({ customer_id: id });
  const { data: customerBalancesData } = useCustomerBalances();
  const [editOpen, setEditOpen] = useState(false);
  const [form, setForm] = useState({});
  const updateMut = useUpdateCustomer();

  const customer = (customers || []).find(c => c.id === id);
  const custBalanceRow = (customerBalancesData || []).find(b => String(b.customer_id) === String(id));
  const balances = {};
  if (custBalanceRow) {
    balances[custBalanceRow.balance_currency || 'AFN'] = custBalanceRow.net_balance || 0;
  }

  if (!customers) return _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 40}, this );
  if (!customer) return _jsxDEV(EmptyState, { title: "مشتری یافت نشد"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this );

  const openEdit = () => {
    setForm({
      name: customer.name || '', phone: customer.phone || '', code: customer.code || '',
      customer_type: customer.customer_type || 'permanent', status: customer.status || 'active',
      notes: customer.notes || '',
    });
    setEditOpen(true);
  };

  const handleEdit = async (e) => {
    e.preventDefault();
    await updateMut.mutateAsync({ id: customer.id, data: form });
    setEditOpen(false);
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, {
        title: customer.name,
        subtitle: customer.code || '',
        actions: 
          _jsxDEV(Button, { size: "sm", variant: "outline", onClick: openEdit, children: [
            _jsxDEV(Pencil, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this ), " ویرایش"
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 64}, this)
        ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this
      )

      /* Info Chips */
      , _jsxDEV('div', { className: "flex flex-wrap gap-1.5 mb-4"   , children: [
        customer.phone && _jsxDEV('span', { className: "px-2 py-1 rounded-lg bg-muted text-xs"    , children: customer.phone}, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this)
        , customer.customer_type && _jsxDEV('span', { className: "px-2 py-1 rounded-lg bg-muted text-xs"    , children: CUSTOMER_TYPE_LABELS[customer.customer_type]}, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)
        , _jsxDEV(StatusBadge, { status: customer.status, labels: { active: 'فعال', inactive: 'غیرفعال' },}, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 71}, this)

      /* Balances */
      , _jsxDEV('div', { className: "grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4"    , children: 
        Object.keys(balances).length === 0 ? (
          _jsxDEV(BalanceCard, { label: "موجودی", amounts: { AFN: 0 },}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this )
        ) : (
          Object.entries(balances).map(([cur, val]) => (
            _jsxDEV(BalanceCard, { label: `موجودی ${cur}`, amounts: { [cur]: val }, accent: val >= 0 ? 'text-success' : 'text-destructive',}, cur, false, {fileName: _jsxFileName, lineNumber: 83}, this )
          ))
        )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this)

      /* Quick Actions */
      , _jsxDEV('div', { className: "grid grid-cols-3 sm:grid-cols-6 gap-2 mb-6"    , children: 
        QUICK_ACTIONS(id).map(a => {
          const Icon = a.icon;
          return (
            _jsxDEV(Link, { to: a.path, className: "flex flex-col items-center gap-1 p-2 rounded-lg bg-muted/50 hover:bg-muted"       , children: [
              _jsxDEV(Icon, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this )
              , _jsxDEV('span', { className: "text-[10px] font-medium" , children: a.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this)
            ]}, a.label, true, {fileName: _jsxFileName, lineNumber: 93}, this)
          );
        })
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this)

      /* Transactions */
      , _jsxDEV('h3', { className: "text-sm font-semibold mb-2"  , children: "گردش حساب" }, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this)
      , isLoading ? (
        _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this )
      ) : (txs || []).length === 0 ? (
        _jsxDEV(EmptyState, { title: "تراکنشی وجود ندارد"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this )
      ) : (
        _jsxDEV('div', { className: "space-y-1", children: 
          (txs || []).map(tx => (
            _jsxDEV(TransactionRow, { tx: tx, labels: TX_TYPE_LABELS, onClick: () => navigate(`/receipt?type=tx&id=${tx.id}`),}, tx.id, false, {fileName: _jsxFileName, lineNumber: 110}, this )
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this)
      )

      /* Edit Dialog */
      , _jsxDEV(Dialog, { open: editOpen, onOpenChange: setEditOpen, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "ویرایش مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this)
          , _jsxDEV('form', { onSubmit: handleEdit, className: "space-y-3", children: [
            _jsxDEV('div', { children: [_jsxDEV(Label, { children: "نام"}, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this), _jsxDEV(Input, { value: form.name || '', onChange: e => setForm({...form, name: e.target.value}), required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 120}, this)
            , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "موبایل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this), _jsxDEV(Input, { value: form.phone || '', onChange: e => setForm({...form, phone: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 121}, this)
            , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "کد"}, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this), _jsxDEV(Input, { value: form.code || '', onChange: e => setForm({...form, code: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 122}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "نوع"}, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this)
                , _jsxDEV(Select, { value: form.customer_type, onValueChange: v => setForm({...form, customer_type: v}), children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this)
                  , _jsxDEV(SelectContent, { children: [
                    _jsxDEV(SelectItem, { value: "permanent", children: "دائمی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this)
                    , _jsxDEV(SelectItem, { value: "temporary", children: "موقت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)
                    , _jsxDEV(SelectItem, { value: "misc", children: "متفرقه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 128}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 126}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 124}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "وضعیت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this)
                , _jsxDEV(Select, { value: form.status, onValueChange: v => setForm({...form, status: v}), children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)
                  , _jsxDEV(SelectContent, { children: [
                    _jsxDEV(SelectItem, { value: "active", children: "فعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 140}, this)
                    , _jsxDEV(SelectItem, { value: "inactive", children: "غیرفعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 139}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 137}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 135}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 123}, this)
            , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "یادداشت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this), _jsxDEV(Input, { value: form.notes || '', onChange: e => setForm({...form, notes: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 146}, this)
            , _jsxDEV(DialogFooter, { children: [
              _jsxDEV(Button, { type: "button", variant: "outline", onClick: () => setEditOpen(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this)
              , _jsxDEV(Button, { type: "submit", disabled: updateMut.isPending, children: "ذخیره"}, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 119}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 117}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 59}, this)
  );
}