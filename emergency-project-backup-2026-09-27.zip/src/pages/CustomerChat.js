const _jsxFileName = "src/pages/CustomerChat.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  useChatGroups, useGroupMessages, useIsGroupMember,
  useJoinGroup, useSendMessage, useMessageCooldown,
} from '../lib/useChat.js';
import { useAuth } from '../lib/AuthContext.js';
import { formatCooldown } from '../lib/chat.js';
import { PageHeader, EmptyState, LoadingState } from '../components/sarraaf/Pieces.js';
import GroupCard from '../components/chat/GroupCard.js';
import MessageBubble from '../components/chat/MessageBubble.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { toast } from '../components/ui/use-toast.js';
import { useRateSettings } from '../lib/useSarraaf.js';
import { offlineDB } from '../lib/offlineQueue.js';
import { Send, Users, Globe, ArrowRight } from 'lucide-react';

function useLastMessages(groups) {
  const [result, setResult] = useState({});
  useEffect(() => {
    if (!groups || groups.length === 0) { setResult({}); return; }
    let cancelled = false;
    (async () => {
      const map = {};
      for (const g of groups) {
        const list = await offlineDB.GroupMessage.filter({ group_id: g.id });
        if (!cancelled && list && list.length > 0) {
          const active = list.filter(m => m.status !== 'deleted');
          active.sort((a, b) => new Date(b.created_date || 0) - new Date(a.created_date || 0));
          if (active[0]) map[g.id] = active[0];
        }
      }
      if (!cancelled) setResult(map);
    })();
    return () => { cancelled = true; };
  }, [JSON.stringify(_optionalChain([groups, 'optionalAccess', _ => _.map, 'call', _2 => _2(g => g.id)]))]);
  return result;
}

export default function CustomerChat() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: groups, isLoading } = useChatGroups('public');
  const { data: rateSettings } = useRateSettings();
  const lastMessages = useLastMessages(groups || []);

  // If a groupId is in URL, show chat room
  const urlParams = new URLSearchParams(window.location.search);
  const activeGroupId = urlParams.get('group');

  if (activeGroupId) {
    return _jsxDEV(CustomerChatRoom, { groupId: activeGroupId,}, void 0, false, {fileName: _jsxFileName, lineNumber: 53}, this );
  }

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "چت و گروه‌ها"  , icon: Users, actions: _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => navigate('/customer'), children: [_jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this ), " بازگشت" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 58}, this),}, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this )

      , _jsxDEV('div', { className: "mb-4 p-3 rounded-xl bg-green-50 border border-green-200 text-green-800 text-xs"       , children: "شما به‌عنوان مشتری می‌توانید در گروه‌های عمومی شرکت کنید. گروه‌های خصوصی صرافان برای مشتریان قابل مشاهده نیست."

      }, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)

      , isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this ) : !groups || groups.length === 0 ? (
        _jsxDEV(EmptyState, { icon: Globe, title: "گروه عمومی وجود ندارد"   , description: "گروه‌های عمومی به‌زودی فعال می‌شوند"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this )
      ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          groups.map(g => (
            _jsxDEV(GroupCard, {

              group: g,
              lastMessage: lastMessages[g.id],
              to: `/customer/chat?group=${g.id}`,}, g.id, false, {fileName: _jsxFileName, lineNumber: 69}, this
            )
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 57}, this)
  );
}

function CustomerChatRoom({ groupId }) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: messages, isLoading: msgLoading } = useGroupMessages(groupId);
  const { data: isMember } = useIsGroupMember(groupId, _optionalChain([user, 'optionalAccess', _3 => _3.id]));
  const joinMut = useJoinGroup();
  const sendMut = useSendMessage();
  const { data: rateSettings } = useRateSettings();
  const [message, setMessage] = useState('');
  const messagesEndRef = React.useRef(null);

  const ttlKey = _optionalChain([rateSettings, 'optionalAccess', _4 => _4.chat_message_ttl]) || 'never';

  // Rate limiting — customers: 5 minutes between messages
  const cooldownRemaining = useMessageCooldown(groupId, _optionalChain([user, 'optionalAccess', _5 => _5.id]), 'customer', null);
  const isRateLimited = cooldownRemaining > 0;

  React.useEffect(() => {
    _optionalChain([messagesEndRef, 'access', _6 => _6.current, 'optionalAccess', _7 => _7.scrollIntoView, 'call', _8 => _8({ behavior: 'smooth' })]);
  }, [messages]);

  const handleJoin = async () => {
    const group = { id: groupId, name: '', type: 'public' };
    try {
      await joinMut.mutateAsync({ group, user, userRole: 'customer', profile: null });
      toast({ title: 'پیوستید', description: 'به گروه عمومی پیوستید' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleSend = async () => {
    if (!message.trim()) return;
    if (!isMember) {
      toast({ title: 'خطا', description: 'ابتدا به گروه بپیوندید', variant: 'destructive' });
      return;
    }
    try {
      await sendMut.mutateAsync({
        group: { id: groupId, name: '', type: 'public' },
        user,
        userRole: 'customer',
        profile: null,
        message: message.trim(),
        ttlKey,
      });
      setMessage('');
    } catch (err) {
      if (_optionalChain([err, 'access', _9 => _9.message, 'optionalAccess', _10 => _10.startsWith, 'call', _11 => _11('rate_limited:')])) {
        const seconds = parseInt(err.message.split(':')[1]) || 0;
        toast({ title: 'محدودیت ارسال', description: `لطفاً ${formatCooldown(seconds)} صبر کنید`, variant: 'destructive' });
      } else {
        toast({ title: 'خطا', description: err.message, variant: 'destructive' });
      }
    }
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "گروه عمومی" , icon: Globe, actions: _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => navigate('/customer/chat'), children: [_jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this ), " بازگشت" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 141}, this),}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this )

      , !isMember && (
        _jsxDEV('div', { className: "mb-4", children: 
          _jsxDEV(Button, { className: "w-full", onClick: handleJoin, disabled: joinMut.isPending, children: "پیوستن به گروه"

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 145}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this)
      )

      , _jsxDEV('div', { className: "space-y-2 mb-20" , children: [
        msgLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 152}, this ) : !messages || messages.length === 0 ? (
          _jsxDEV(EmptyState, { icon: Send, title: "پیامی نیست" , description: "اولین پیام را ارسال کنید"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 153}, this )
        ) : (
          messages.map(msg => (
            _jsxDEV(MessageBubble, { message: msg, showActions: isMember,}, msg.id, false, {fileName: _jsxFileName, lineNumber: 156}, this )
          ))
        )
        , _jsxDEV('div', { ref: messagesEndRef,}, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 151}, this)

      , isMember && (
        _jsxDEV('div', { className: "fixed bottom-0 left-0 right-0 z-40 bg-background border-t p-3"       , children: [
          isRateLimited && (
            _jsxDEV('div', { className: "max-w-5xl mx-auto mb-2 text-center text-xs text-amber-600 bg-amber-50 rounded-lg py-1"        , children: ["⏳ لطفاً "
                , formatCooldown(cooldownRemaining), " برای ارسال پیام بعدی صبر کنید"
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 165}, this)
          )
          , _jsxDEV('div', { className: "max-w-5xl mx-auto flex items-center gap-2"    , children: [
            _jsxDEV(Input, {
              value: message,
              onChange: e => setMessage(e.target.value),
              onKeyDown: e => { if (e.key === 'Enter') { e.preventDefault(); handleSend(); } },
              placeholder: isRateLimited ? 'در حال انتظار...' : 'پیام خود را بنویسید...',
              className: "flex-1",
              disabled: isRateLimited,}, void 0, false, {fileName: _jsxFileName, lineNumber: 170}, this
            )
            , _jsxDEV(Button, { size: "icon", onClick: handleSend, disabled: sendMut.isPending || !message.trim() || isRateLimited, children: 
              _jsxDEV(Send, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 169}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 163}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 140}, this)
  );
}