const _jsxFileName = "src/pages/Bank.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState } from 'react';
import { useBankAccounts, useCreateBankAccount, useCurrencies, useBankBalances, useTransactions } from '../lib/useSarraaf.js';
import { PageHeader, BalanceCard, TransactionRow, LoadingState } from '../components/sarraaf/Pieces.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog.js';
import { CurrencySelect } from '../components/sarraaf/Fields.js';
import { TX_TYPE_LABELS } from '../lib/sarraaf.js';
import { Landmark, Plus, Loader2 } from 'lucide-react';

export default function Bank() {
  const { data: txs, isLoading } = useTransactions();
  const { data: bankAccounts } = useBankAccounts();
  const { data: currencies } = useCurrencies();
  const { data: bankBalancesData } = useBankBalances();
  const createMut = useCreateBankAccount();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ bank_name: '', holder: '', card_number: '', account_number: '', currency: 'AFN', branch: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await createMut.mutateAsync(form);
    setDialogOpen(false);
    setForm({ bank_name: '', holder: '', card_number: '', account_number: '', currency: 'AFN', branch: '' });
  };

  const getBankBalance = (bankId) => {
    const b = (bankBalancesData || []).find(x => String(x.bank_id) === String(bankId));
    return b ? { [b.currency]: b.current_balance || 0 } : {};
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "بانک", icon: Landmark,
        actions: _jsxDEV(Button, { size: "sm", onClick: () => setDialogOpen(true), children: [_jsxDEV(Plus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this ), " حساب جدید"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 36}, this),}, void 0, false, {fileName: _jsxFileName, lineNumber: 35}, this
      )
      , _jsxDEV('div', { className: "grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4"    , children: 
        (bankAccounts || []).length === 0 ? (
          _jsxDEV(BalanceCard, { label: "حساب بانکی" , amounts: { AFN: 0 },}, void 0, false, {fileName: _jsxFileName, lineNumber: 40}, this )
        ) : (
          (bankAccounts || []).map(b => {
            const bal = getBankBalance(b.id);
            return _jsxDEV(BalanceCard, { label: `${b.bank_name} - ${b.currency}`, amounts: bal,}, b.id, false, {fileName: _jsxFileName, lineNumber: 44}, this );
          })
        )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this)
      , isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this ) : (
        (txs || []).filter(t => t.counter_type === 'bank').slice(0, 20).map(tx => (
          _jsxDEV(TransactionRow, { tx: tx, labels: TX_TYPE_LABELS,}, tx.id, false, {fileName: _jsxFileName, lineNumber: 50}, this )
        ))
      )

      , _jsxDEV(Dialog, { open: dialogOpen, onOpenChange: setDialogOpen, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "حساب بانکی جدید"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
          , _jsxDEV('form', { onSubmit: handleSubmit, className: "space-y-3", children: [
            _jsxDEV('div', { children: [_jsxDEV(Label, { children: "نام بانک" }, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this), _jsxDEV(Input, { value: form.bank_name, onChange: e => setForm({...form, bank_name: e.target.value}), required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 58}, this)
            , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "دارنده"}, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this), _jsxDEV(Input, { value: form.holder, onChange: e => setForm({...form, holder: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 59}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [_jsxDEV(Label, { children: "شماره کارت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this), _jsxDEV(Input, { value: form.card_number, onChange: e => setForm({...form, card_number: e.target.value}), inputMode: "numeric",}, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 61}, this)
              , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "شماره حساب" }, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this), _jsxDEV(Input, { value: form.account_number, onChange: e => setForm({...form, account_number: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 62}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 60}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "ارز"}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
                , _jsxDEV(CurrencySelect, { value: form.currency, onChange: v => setForm({...form, currency: v}), currencies: currencies,}, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)
              , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "شعبه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this), _jsxDEV(Input, { value: form.branch, onChange: e => setForm({...form, branch: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 69}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 64}, this)
            , _jsxDEV(DialogFooter, { children: [
              _jsxDEV(Button, { type: "button", variant: "outline", onClick: () => setDialogOpen(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this)
              , _jsxDEV(Button, { type: "submit", disabled: createMut.isPending, children: createMut.isPending ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this ) : 'افزودن'}, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 71}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 57}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 55}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 54}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 34}, this)
  );
}