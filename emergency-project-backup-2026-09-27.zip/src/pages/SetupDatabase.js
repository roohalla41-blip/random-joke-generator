const _jsxFileName = "src/pages/SetupDatabase.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState } from 'react';
import { Button } from '../components/ui/button.js';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card.js';
import { Loader2, CheckCircle2, XCircle, Database, UserPlus, AlertCircle, ExternalLink } from 'lucide-react';
import { callSupabase } from '../lib/supabaseApi.js';

const IDLE = 'idle';
const LOADING = 'loading';
const SUCCESS = 'success';
const ERROR = 'error';

export default function SetupDatabase() {
  const [connStatus, setConnStatus] = useState(IDLE);
  const [connMsg, setConnMsg] = useState('');
  const [adminStatus, setAdminStatus] = useState(IDLE);
  const [adminMsg, setAdminMsg] = useState('');

  const testConnection = async () => {
    setConnStatus(LOADING);
    setConnMsg('');
    try {
      const res = await callSupabase('test');
      if (res.connected) {
        setConnStatus(SUCCESS);
        setConnMsg('اتصال موفق — جداول ساخته شده‌اند');
      } else {
        setConnStatus(ERROR);
        setConnMsg(res.error || 'اتصال ناموفق');
      }
    } catch (e) {
      setConnStatus(ERROR);
      setConnMsg(e.message || 'خطای ناشناخته');
    }
  };

  const bootstrapAdmin = async () => {
    setAdminStatus(LOADING);
    setAdminMsg('');
    try {
      const res = await callSupabase('bootstrapAdmin');
      if (res.success) {
        setAdminStatus(SUCCESS);
        setAdminMsg(res.message || 'حساب سازنده ایجاد شد');
      } else {
        setAdminStatus(ERROR);
        setAdminMsg(res.error || 'ایجاد ناموفق');
      }
    } catch (e) {
      setAdminStatus(ERROR);
      setAdminMsg(e.message || 'خطای ناشناخته');
    }
  };

  const StatusIcon = ({ status }) => {
    if (status === LOADING) return _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this );
    if (status === SUCCESS) return _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-success"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this );
    if (status === ERROR) return _jsxDEV(XCircle, { className: "w-4 h-4 text-destructive"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 57}, this );
    return null;
  };

  return (
    _jsxDEV('div', { className: "min-h-screen bg-background p-4"  , dir: "rtl", children: 
      _jsxDEV('div', { className: "max-w-2xl mx-auto space-y-4"  , children: [
        _jsxDEV(Card, { children: 
          _jsxDEV(CardHeader, { children: 
            _jsxDEV('div', { className: "flex items-center gap-3"  , children: [
              _jsxDEV('div', { className: "rounded-lg bg-primary/10 p-2"  , children: 
                _jsxDEV(Database, { className: "h-6 w-6 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(CardTitle, { className: "text-lg", children: "راه‌اندازی دیتابیس" }, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this)
                , _jsxDEV('p', { className: "text-sm text-muted-foreground mt-1"  , children: "مراحل زیر را به ترتیب انجام دهید"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 70}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 66}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)

        /* Step 1: SQL Schema */
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
            _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
              _jsxDEV('span', { className: "flex items-center justify-center w-7 h-7 rounded-full bg-primary text-primary-foreground text-sm font-bold"         , children: "۱"}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this)
              , _jsxDEV('h3', { className: "font-semibold", children: "اجرای اسکریپت SQL در Supabase"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 81}, this)
            , _jsxDEV('div', { className: "space-y-2 rounded-lg bg-muted p-3 text-sm"    , children: [
              _jsxDEV('p', { className: "font-medium", children: "مراحل:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this)
              , _jsxDEV('ol', { className: "list-decimal list-inside space-y-1 text-muted-foreground"   , children: [
                _jsxDEV('li', { children: ["وارد " , _jsxDEV('a', { href: "https://supabase.com/dashboard", target: "_blank", rel: "noopener noreferrer" , className: "text-primary underline inline-flex items-center gap-0.5"    , children: ["Supabase Dashboard "  , _jsxDEV(ExternalLink, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 88}, this), " شوید" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 88}, this)
                , _jsxDEV('li', { children: ["به بخش "  , _jsxDEV('strong', { children: "SQL Editor → New Query"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this), " بروید" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 89}, this)
                , _jsxDEV('li', { children: ["محتوای فایل "  , _jsxDEV('code', { className: "bg-background px-1 rounded"  , children: "base44/shared/supabase_schema.sql"}, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this), " را کپی کنید"   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 90}, this)
                , _jsxDEV('li', { children: ["دکمه " , _jsxDEV('strong', { children: "Run"}, void 0, false, {fileName: _jsxFileName, lineNumber: 91}, this), " را بزنید"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 91}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 87}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 85}, this)
            , _jsxDEV('div', { className: "flex items-start gap-2 rounded-lg bg-info/10 p-3 text-xs text-info"       , children: [
              _jsxDEV(AlertCircle, { className: "w-4 h-4 shrink-0 mt-0.5"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this )
              , _jsxDEV('p', { children: "این اسکریپت غیرمخرب است (CREATE TABLE IF NOT EXISTS) و می‌توانید چند بار اجرا کنید. هیچ داده‌ای حذف نمی‌شود."                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 94}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 80}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this)

        /* Step 2: Test Connection */
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
            _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
              _jsxDEV('span', { className: "flex items-center justify-center w-7 h-7 rounded-full bg-primary text-primary-foreground text-sm font-bold"         , children: "۲"}, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this)
              , _jsxDEV('h3', { className: "font-semibold", children: "تست اتصال به دیتابیس"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 104}, this)
            , _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "بررسی می‌کند که جداول ساخته شده‌اند و Supabase در دسترس است."          }, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this)
            , _jsxDEV(Button, {
              onClick: testConnection,
              disabled: connStatus === LOADING,
              className: "w-full",
              variant: connStatus === SUCCESS ? 'outline' : 'default',
 children: [
              connStatus === LOADING ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this ) :
               connStatus === SUCCESS ? _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-success"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this ) :
               connStatus === ERROR ? _jsxDEV(XCircle, { className: "w-4 h-4 text-destructive"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 117}, this ) :
               _jsxDEV(Database, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this ), "تست اتصال"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 109}, this)
            , connMsg && (
              _jsxDEV('p', { className: `text-sm ${connStatus === SUCCESS ? 'text-success' : 'text-destructive'}`, children: connMsg}, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 103}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this)

        /* Step 3: Bootstrap Admin */
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
            _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
              _jsxDEV('span', { className: "flex items-center justify-center w-7 h-7 rounded-full bg-primary text-primary-foreground text-sm font-bold"         , children: "۳"}, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this)
              , _jsxDEV('h3', { className: "font-semibold", children: "ایجاد حساب سازنده"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 132}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 130}, this)
            , _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "حساب سازنده با ایمیل و رمز عبور تنظیم‌شده در Secrets ایجاد می‌شود."           }, void 0, false, {fileName: _jsxFileName, lineNumber: 134}, this)
            , _jsxDEV(Button, {
              onClick: bootstrapAdmin,
              disabled: adminStatus === LOADING || connStatus !== SUCCESS,
              className: "w-full",
              variant: adminStatus === SUCCESS ? 'outline' : 'default',
 children: [
              adminStatus === LOADING ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this ) :
               adminStatus === SUCCESS ? _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-success"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this ) :
               adminStatus === ERROR ? _jsxDEV(XCircle, { className: "w-4 h-4 text-destructive"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this ) :
               _jsxDEV(UserPlus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this ), "ایجاد حساب سازنده"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 135}, this)
            , adminMsg && (
              _jsxDEV('p', { className: `text-sm ${adminStatus === SUCCESS ? 'text-success' : 'text-destructive'}`, children: adminMsg}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this)
            )
            , connStatus !== SUCCESS && (
              _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "ابتدا تست اتصال را با موفقیت انجام دهید."       }, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 129}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 128}, this)

        /* Summary */
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-4", children: 
            _jsxDEV('div', { className: "flex items-center gap-2 text-sm"   , children: 
              connStatus === SUCCESS && adminStatus === SUCCESS ? (
                _jsxDEV(_Fragment, { children: [
                  _jsxDEV(CheckCircle2, { className: "w-5 h-5 text-success"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 162}, this )
                  , _jsxDEV('span', { className: "text-success font-medium" , children: "راه‌اندازی کامل شد! می‌توانید وارد شوید."     }, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 161}, this)
              ) : (
                _jsxDEV(_Fragment, { children: [
                  _jsxDEV(AlertCircle, { className: "w-5 h-5 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 167}, this )
                  , _jsxDEV('span', { className: "text-muted-foreground", children: "مراحل بالا را به ترتیب تکمیل کنید."      }, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 166}, this)
              )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 63}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this)
  );
}