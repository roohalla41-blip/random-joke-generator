const _jsxFileName = "src/pages/OnlineProducts.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext.js';
import { PageHeader } from '../components/sarraaf/Pieces.js';
import { Card, CardContent } from '../components/ui/card.js';
import { offlineDB } from '../lib/offlineQueue.js';
import {
  Wallet, Smartphone, Gamepad2, ShoppingBag, Package,
} from 'lucide-react';

const PRODUCT_SECTIONS = [
  { path: '/online-products/wallet', label: 'کیف پول', desc: 'ایجاد و مدیریت کیف پول', icon: Wallet, color: 'bg-blue-500' },
  { path: '/online-products/recharge', label: 'شارژ و اینترنت', desc: 'شارژ سیم‌کارت و بسته اینترنت', icon: Smartphone, color: 'bg-green-500' },
  { path: '/online-products/games', label: 'بازی‌ها', desc: 'UC پابجی، جم کلش و...', icon: Gamepad2, color: 'bg-purple-500' },
];

export default function OnlineProducts() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [wallets, setWallets] = useState([]);
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const load = async () => {
      try {
        const w = await offlineDB.Wallet.list();
        setWallets(w || []);
        const o = await offlineDB.OnlineOrder.list();
        setOrders(o || []);
      } catch (e) {
        // ignore
      }
    };
    load();
  }, []);

  const totalBalance = wallets.reduce((s, w) => s + (w.balance || 0), 0);
  const pendingOrders = orders.filter(o => o.status === 'pending' || o.status === 'processing' || o.status === 'new').length;

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "محصولات آنلاین" , subtitle: "خدمات دیجیتال و مالی"   , icon: ShoppingBag,}, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this )

      /* Summary Cards */
      , _jsxDEV('div', { className: "grid grid-cols-2 gap-3 mb-4"   , children: [
        _jsxDEV(Card, { className: "shadow-sm", children: 
          _jsxDEV(CardContent, { className: "p-4", children: 
            _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
              _jsxDEV('div', { className: "w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center shrink-0"        , children: 
                _jsxDEV(Wallet, { className: "w-4 h-4 text-blue-500"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this)
              , _jsxDEV('div', { className: "min-w-0", children: [
                _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "موجودی کیف پول‌ها"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 53}, this)
                , _jsxDEV('p', { className: "text-sm font-bold truncate"  , children: [totalBalance.toLocaleString(), " " , _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: "مجموع"}, void 0, false, {fileName: _jsxFileName, lineNumber: 54}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 54}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 52}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 48}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 47}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this)
        , _jsxDEV(Card, { className: "shadow-sm", children: 
          _jsxDEV(CardContent, { className: "p-4", children: 
            _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
              _jsxDEV('div', { className: "w-8 h-8 rounded-lg bg-rose-100 dark:bg-rose-900/30 flex items-center justify-center shrink-0"        , children: 
                _jsxDEV(Package, { className: "w-4 h-4 text-rose-500"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this)
              , _jsxDEV('div', { className: "min-w-0", children: [
                _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "سفارش‌های فعال" }, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
                , _jsxDEV('p', { className: "text-sm font-bold truncate"  , children: [pendingOrders, " " , _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: "در حال انجام"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 67}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 61}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 45}, this)

      /* Product Grid */
      , _jsxDEV('div', { children: [
        _jsxDEV('h2', { className: "text-sm font-bold text-foreground mb-3"   , children: "امکانات"}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)
        , _jsxDEV('div', { className: "grid grid-cols-3 gap-3"  , children: 
          PRODUCT_SECTIONS.map((section) => {
            const Icon = section.icon;
            return (
              _jsxDEV('button', {

                onClick: () => navigate(section.path),
                className: "flex flex-col items-center gap-2 p-3 rounded-xl border border-border bg-card hover:border-primary/40 hover:shadow-md transition-all text-center"            ,
 children: [
                _jsxDEV('div', { className: `w-12 h-12 rounded-2xl ${section.color} flex items-center justify-center shadow-sm`, children: 
                  _jsxDEV(Icon, { className: "w-6 h-6 text-white"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this)
                , _jsxDEV('span', { className: "text-[11px] font-bold text-foreground leading-tight"   , children: section.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this)
              ]}, section.path, true, {fileName: _jsxFileName, lineNumber: 81}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 75}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 41}, this)
  );
}