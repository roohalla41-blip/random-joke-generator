const _jsxFileName = "src/pages/AgencyChooser.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React from 'react';
import { Link } from 'react-router-dom';
import { PageHeader } from '../components/sarraaf/Pieces.js';
import { Network, Share2, Users } from 'lucide-react';
import { Card, CardContent } from '../components/ui/card.js';

export default function AgencyChooser() {
  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "نمایندگی‌ها", icon: Network,}, void 0, false, {fileName: _jsxFileName, lineNumber: 10}, this )
      , _jsxDEV('div', { className: "grid grid-cols-1 sm:grid-cols-2 gap-3"   , children: [
        _jsxDEV(Link, { to: "/agents", children: 
          _jsxDEV(Card, { className: "hover:bg-muted/30 transition-colors" , children: 
            _jsxDEV(CardContent, { className: "p-6 flex flex-col items-center gap-2"    , children: [
              _jsxDEV(Users, { className: "w-10 h-10 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 15}, this )
              , _jsxDEV('span', { className: "text-sm font-medium" , children: "نمایندگی خودم" }, void 0, false, {fileName: _jsxFileName, lineNumber: 16}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 14}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 13}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 12}, this)
        , _jsxDEV(Link, { to: "/agency-network", children: 
          _jsxDEV(Card, { className: "hover:bg-muted/30 transition-colors" , children: 
            _jsxDEV(CardContent, { className: "p-6 flex flex-col items-center gap-2"    , children: [
              _jsxDEV(Share2, { className: "w-10 h-10 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 23}, this )
              , _jsxDEV('span', { className: "text-sm font-medium" , children: "نمایندگی خارجی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 24}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 22}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 21}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 20}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 11}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 9}, this)
  );
}