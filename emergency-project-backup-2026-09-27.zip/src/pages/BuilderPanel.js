const _jsxFileName = "src/pages/BuilderPanel.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useEffect, useState, useMemo } from 'react';
import { useAuth } from '../lib/AuthContext.js';
import { useFeatures, useToggleFeature } from '../lib/useSarraaf.js';
import { FEATURE_CATALOG, CRITICAL_FEATURES } from '../lib/features.js';
import { PageHeader } from '../components/sarraaf/Pieces.js';
import { Card, CardContent } from '../components/ui/card.js';
import { Switch } from '../components/ui/switch.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
import {
  Shield, Users, CreditCard, Lock, Bell, MessageSquare,
  Server, Wallet, Crown, Upload, LogOut, Download, AlertTriangle, UserCog, Clock
} from 'lucide-react';
import { Button } from '../components/ui/button.js';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs.js';
import ChatManagement from '../components/sarraaf/ChatManagement.js';
import UserManagement from '../components/sarraaf/UserManagement.js';
import NotificationManager from '../components/sarraaf/NotificationManager.js';
import PlanFeatureManager from '../components/sarraaf/PlanFeatureManager.js';
import PlanPricingManager from '../components/sarraaf/PlanPricingManager.js';
import PermissionManager from '../components/sarraaf/PermissionManager.js';
import PaymentMethodsManager from '../components/sarraaf/PaymentMethodsManager.js';
import SystemOverview from '../components/sarraaf/SystemOverview.js';
import VersionManager from '../components/sarraaf/VersionManager.js';
import ContactSettingsManager from '../components/sarraaf/ContactSettingsManager.js';
import EmergencyBackup from '../components/sarraaf/EmergencyBackup.js';
import EmergencyBackupV2 from '../components/sarraaf/EmergencyBackupV2.js';
import TripleBackup from '../components/sarraaf/TripleBackup.js';
import WithdrawalManagement from '../components/sarraaf/WithdrawalManagement.js';
import CoCreatorManager from '../components/sarraaf/CoCreatorManager.js';
import { checkBuilderAccess, startBuilderSession } from '../lib/builderAccess.js';

const STATUS_LABELS = {
  active: 'فعال',
  updating: 'در حال به‌روزرسانی',
  disabled: 'غیرفعال',
};

const STATUS_COLORS = {
  active: 'bg-green-100 text-green-700',
  updating: 'bg-amber-100 text-amber-700',
  disabled: 'bg-red-100 text-red-700',
};

// گروه‌بندی تب‌ها بر اساس نقش
const TAB_GROUPS = [
  {
    label: 'سیستم',
    icon: Server,
    value: 'system',
    description: 'نمای کلی، اتصال و آمار',
  },
  {
    label: 'بخش‌ها',
    icon: Shield,
    value: 'features',
    description: 'مدیریت فعال‌سازی بخش‌ها',
  },
  {
    label: 'کاربران',
    icon: Users,
    value: 'users',
    description: 'مدیریت کاربران و دسترسی‌ها',
  },
  {
    label: 'مجوزها',
    icon: Lock,
    value: 'perms',
    description: 'مجوزهای نقش‌ها',
  },
  {
    label: 'پلن‌ها',
    icon: Crown,
    value: 'plans',
    description: 'سهمیه و امکانات پلن',
  },
  {
    label: 'قیمت‌گذاری',
    icon: CreditCard,
    value: 'pricing',
    description: 'قیمت پلن‌ها',
  },
  {
    label: 'اعلان‌ها',
    icon: Bell,
    value: 'notif',
    description: 'مدیریت اعلان‌ها',
  },
  {
    label: 'چت',
    icon: MessageSquare,
    value: 'chat',
    description: 'مدیریت چت و گروه‌ها',
  },
  {
    label: 'پرداخت',
    icon: Wallet,
    value: 'payments',
    description: 'روش‌های پرداخت',
  },
  {
    label: 'برداشت‌ها',
    icon: CreditCard,
    value: 'withdrawals',
    description: 'تأیید/رد برداشت کیف پول',
  },
  {
    label: 'نسخه',
    icon: Upload,
    value: 'version',
    description: 'مدیریت نسخه برنامه',
  },
  {
    label: 'پشتیبان',
    icon: Download,
    value: 'backup',
    description: 'پشتیبان اضطراری پروژه',
  },
  {
    label: 'پشتیبان v2',
    icon: AlertTriangle,
    value: 'backup_v2',
    description: 'نسخه اضطراری کامل (۲۸ بخش)',
  },
  {
    label: 'سه گانه',
    icon: Download,
    value: 'triple_backup',
    description: 'PDF + ZIP + Supabase',
  },
  {
    label: 'کمک‌سازنده',
    icon: UserCog,
    value: 'co_creators',
    description: 'مدیریت دسترسی کمک‌سازنده‌ها',
  },
];

export default function BuilderPanel() {
  const { user, logout } = useAuth();
  const { data: features, refetch } = useFeatures();
  const toggleMut = useToggleFeature();
  const [autoLogoutWarning, setAutoLogoutWarning] = useState(false);

  // ── Determine builder access level ──
  const accessInfo = useMemo(() => checkBuilderAccess(user), [user]);
  const isFullCreator = _optionalChain([user, 'optionalAccess', _ => _.role]) === 'creator' || _optionalChain([user, 'optionalAccess', _2 => _2.role]) === 'admin';
  const allowedTabs = _optionalChain([accessInfo, 'optionalAccess', _3 => _3.allowed_tabs]) === 'all' ? null : (_optionalChain([accessInfo, 'optionalAccess', _4 => _4.allowed_tabs]) || []);

  // ── Auto-logout after 30 min inactivity ──
  useEffect(() => {
    const cleanup = startBuilderSession(() => {
      setAutoLogoutWarning(true);
      setTimeout(() => logout(true), 2000);
    });
    return cleanup;
  }, [logout]);

  const handleToggle = async (f) => {
    if (CRITICAL_FEATURES.includes(f.feature_key)) return;
    const current = _optionalChain([features, 'optionalAccess', _5 => _5.find, 'call', _6 => _6(fx => fx.feature_key === f.feature_key)]);
    if (!current) {
      // Record doesn't exist yet — create it
      try {
        const { createSupabaseEntity } = await import('../lib/supabaseApi.js');
        const sbFeatures = createSupabaseEntity('FeatureSetting');
        await sbFeatures.create({
          feature_key: f.feature_key,
          name: f.name,
          icon: f.icon,
          location: f.location,
          display_order: f.display_order,
          enabled: true,
          status: f.default_status || 'active',
          free_enabled: true,
          paid_enabled: true,
        });
        if (refetch) refetch();
      } catch (e) {
        // ignore
      }
      return;
    }
    toggleMut.mutate({ id: current.id, enabled: !current.enabled });
  };

  const handleStatusChange = async (featureKey, newStatus) => {
    const current = _optionalChain([features, 'optionalAccess', _7 => _7.find, 'call', _8 => _8(fx => fx.feature_key === featureKey)]);
    if (CRITICAL_FEATURES.includes(featureKey)) return;
    try {
      const { createSupabaseEntity } = await import('../lib/supabaseApi.js');
      const sbFeatures = createSupabaseEntity('FeatureSetting');
      if (!current) {
        // Record doesn't exist yet — create it with the new status
        const f = FEATURE_CATALOG.find(fx => fx.feature_key === featureKey);
        await sbFeatures.create({
          feature_key: featureKey,
          name: _optionalChain([f, 'optionalAccess', _9 => _9.name]) || featureKey,
          icon: _optionalChain([f, 'optionalAccess', _10 => _10.icon]),
          location: _optionalChain([f, 'optionalAccess', _11 => _11.location]),
          display_order: _optionalChain([f, 'optionalAccess', _12 => _12.display_order]),
          enabled: newStatus !== 'disabled',
          status: newStatus,
          free_enabled: true,
          paid_enabled: true,
        });
      } else {
        await sbFeatures.update(current.id, {
          status: newStatus,
          enabled: newStatus !== 'disabled',
        });
      }
      if (refetch) refetch();
    } catch (e2) {
      // ignore
    }
  };

  if (autoLogoutWarning) {
    return (
      _jsxDEV('div', { className: "fixed inset-0 z-50 flex flex-col items-center justify-center bg-background gap-3 p-6"         , children: [
        _jsxDEV(Clock, { className: "w-12 h-12 text-amber-500 animate-pulse"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 221}, this )
        , _jsxDEV('h2', { className: "text-lg font-bold" , children: "خروج خودکار" }, void 0, false, {fileName: _jsxFileName, lineNumber: 222}, this)
        , _jsxDEV('p', { className: "text-sm text-muted-foreground text-center"  , children: "به دلیل ۳۰ دقیقه بی‌فعالیتی در پنل سازنده، نشست شما به‌صورت خودکار پایان می‌یابد."

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 220}, this)
    );
  }

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, {
        title: "پنل سازنده حساب صراف"   ,
        subtitle: isFullCreator ? _optionalChain([user, 'optionalAccess', _13 => _13.full_name]) : `کمک‌سازنده: ${_optionalChain([accessInfo, 'optionalAccess', _14 => _14.name]) || _optionalChain([user, 'optionalAccess', _15 => _15.full_name]) || ''}`,
        icon: Shield,
        actions: 
          _jsxDEV(Button, {
            variant: "destructive",
            size: "sm",
            onClick: () => logout(true),
            className: "gap-1.5",
 children: [
            _jsxDEV(LogOut, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 243}, this ), "خروج از پنل"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 237}, this)
        ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 232}, this
      )

      , _jsxDEV(Tabs, { defaultValue: "system", children: [
        _jsxDEV(TabsList, { className: "flex overflow-x-auto scrollbar-thin w-full gap-0.5 justify-start sm:justify-around"      , children: 
          TAB_GROUPS.filter(group => {
            if (isFullCreator) return true;
            if (group.value === 'co_creators') return false; // co-creators can't manage other co-creators
            if (!allowedTabs) return true;
            return allowedTabs.includes(group.value);
          }).map(group => {
            const Icon = group.icon;
            return (
              _jsxDEV(TabsTrigger, { value: group.value, className: "flex flex-col items-center gap-0.5 py-2 shrink-0 min-w-[64px]"      , children: [
                _jsxDEV(Icon, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 260}, this )
                , _jsxDEV('span', { className: "text-[9px]", children: group.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 261}, this)
              ]}, group.value, true, {fileName: _jsxFileName, lineNumber: 259}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 250}, this)

        /* سیستم — نمای کلی، اتصال، آمار */
        , _jsxDEV(TabsContent, { value: "system", children: 
          _jsxDEV(SystemOverview, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 269}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 268}, this)

        /* بخش‌ها */
        , _jsxDEV(TabsContent, { value: "features", children: 
          _jsxDEV(Card, { children: _jsxDEV(CardContent, { className: "p-4", children: [
            _jsxDEV('h3', { className: "text-sm font-semibold mb-1"  , children: "مدیریت بخش‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 275}, this)
            , _jsxDEV('p', { className: "text-xs text-muted-foreground mb-4"  , children: "هر بخش را می‌توانید فعال، در حال به‌روزرسانی یا غیرفعال کنید."          }, void 0, false, {fileName: _jsxFileName, lineNumber: 276}, this)
            , _jsxDEV('div', { className: "space-y-2", children: 
              FEATURE_CATALOG.map(f => {
                const dbFeature = _optionalChain([features, 'optionalAccess', _16 => _16.find, 'call', _17 => _17(fx => fx.feature_key === f.feature_key)]);
                const enabled = dbFeature ? dbFeature.enabled !== false : true;
                const status = _optionalChain([dbFeature, 'optionalAccess', _18 => _18.status]) || (f.default_status || 'active');
                const isCritical = CRITICAL_FEATURES.includes(f.feature_key);
                return (
                  _jsxDEV('div', { className: "flex items-center justify-between p-2.5 rounded-lg border"     , children: [
                    _jsxDEV('div', { className: "flex-1", children: [
                      _jsxDEV('span', { className: "text-sm font-medium" , children: f.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 286}, this)
                      , _jsxDEV('span', { className: `text-[10px] font-bold px-1.5 py-0.5 rounded-full mr-2 ${STATUS_COLORS[status]}`, children: 
                        STATUS_LABELS[status]
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 287}, this)
                      , isCritical && _jsxDEV('span', { className: "text-[10px] text-muted-foreground mr-2"  , children: "(حیاتی)"}, void 0, false, {fileName: _jsxFileName, lineNumber: 290}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 285}, this)
                    , _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                      !isCritical && (
                        _jsxDEV(Select, { value: status, onValueChange: (v) => handleStatusChange(f.feature_key, v), children: [
                          _jsxDEV(SelectTrigger, { className: "text-xs h-7 w-28"  , children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 295}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 295}, this)
                          , _jsxDEV(SelectContent, { children: [
                            _jsxDEV(SelectItem, { value: "active", children: "فعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 297}, this)
                            , _jsxDEV(SelectItem, { value: "updating", children: "به‌روزرسانی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 298}, this)
                            , _jsxDEV(SelectItem, { value: "disabled", children: "غیرفعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 299}, this)
                          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 296}, this)
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 294}, this)
                      )
                      , _jsxDEV(Switch, {
                        checked: enabled,
                        disabled: isCritical,
                        onCheckedChange: () => handleToggle(f),}, void 0, false, {fileName: _jsxFileName, lineNumber: 303}, this
                      )
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 292}, this)
                  ]}, f.feature_key, true, {fileName: _jsxFileName, lineNumber: 284}, this)
                );
              })
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 277}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 274}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 274}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 273}, this)

        /* کاربران */
        , _jsxDEV(TabsContent, { value: "users", children: _jsxDEV(UserManagement, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 317}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 317}, this)

        /* مجوزها */
        , _jsxDEV(TabsContent, { value: "perms", children: _jsxDEV(PermissionManager, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 320}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 320}, this)

        /* پلن‌ها */
        , _jsxDEV(TabsContent, { value: "plans", children: _jsxDEV(PlanFeatureManager, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 323}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 323}, this)

        /* قیمت‌گذاری */
        , _jsxDEV(TabsContent, { value: "pricing", children: _jsxDEV(PlanPricingManager, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 326}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 326}, this)

        /* اعلان‌ها */
        , _jsxDEV(TabsContent, { value: "notif", children: _jsxDEV(NotificationManager, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 329}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 329}, this)

        /* چت */
        , _jsxDEV(TabsContent, { value: "chat", children: _jsxDEV(ChatManagement, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 332}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 332}, this)

        /* پرداخت */
        , _jsxDEV(TabsContent, { value: "payments", children: _jsxDEV(PaymentMethodsManager, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 335}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 335}, this)

        /* برداشت‌ها */
        , _jsxDEV(TabsContent, { value: "withdrawals", children: _jsxDEV(WithdrawalManagement, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 338}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 338}, this)

        /* نسخه */
        , _jsxDEV(TabsContent, { value: "version", children: 
          _jsxDEV('div', { className: "space-y-4", children: [
            _jsxDEV(VersionManager, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 343}, this )
            , _jsxDEV(ContactSettingsManager, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 344}, this )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 342}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 341}, this)

        /* پشتیبان اضطراری */
        , _jsxDEV(TabsContent, { value: "backup", children: 
          _jsxDEV(EmergencyBackup, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 350}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 349}, this)

        /* پشتیبان اضطراری v2 — Snapshot کامل وضعیت پروژه */
        , _jsxDEV(TabsContent, { value: "backup_v2", children: 
          _jsxDEV(EmergencyBackupV2, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 355}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 354}, this)

        /* پشتیبان سه‌گانه — PDF + ZIP + Supabase */
        , _jsxDEV(TabsContent, { value: "triple_backup", children: 
          _jsxDEV(TripleBackup, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 360}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 359}, this)

        /* کمک‌سازنده‌ها — فقط سازنده اصلی */
        , isFullCreator && (
          _jsxDEV(TabsContent, { value: "co_creators", children: 
            _jsxDEV(CoCreatorManager, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 366}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 365}, this)
        )

      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 249}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 231}, this)
  );
}