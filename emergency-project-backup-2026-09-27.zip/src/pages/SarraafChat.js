const _jsxFileName = "src/pages/SarraafChat.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../lib/AuthContext.js';
import { useSarraafProfile } from '../lib/useSarraaf.js';
import { offlineDB } from '../lib/offlineQueue.js';
import FeatureGate from '../components/FeatureGate.js';
import { PageHeader, LoadingState, EmptyState } from '../components/sarraaf/Pieces.js';
import { Card, CardContent } from '../components/ui/card.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Send, MessageSquareMore, Search, ArrowLeft } from 'lucide-react';
import { format } from 'date-fns';

export default function SarraafChat() {
  const { user } = useAuth();
  const { data: profile } = useSarraafProfile(_optionalChain([user, 'optionalAccess', _ => _.id]));
  const [chats, setChats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeChat, setActiveChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [search, setSearch] = useState('');
  const scrollRef = useRef(null);

  const loadChats = async () => {
    try {
      const all = await offlineDB.ChatGroup.filter({ type: 'sarraaf_direct' }, '-updated_date', 50);
      const mine = (all || []).filter(g => g.creator_id === _optionalChain([user, 'optionalAccess', _2 => _2.id]) || g.exchange_code === _optionalChain([profile, 'optionalAccess', _3 => _3.code]));
      setChats(mine);
    } catch (e2) {
      setChats([]);
    }
    setLoading(false);
  };

  useEffect(() => { loadChats(); }, []);

  const openChat = async (chat) => {
    setActiveChat(chat);
    const msgs = await offlineDB.GroupMessage.filter({ group_id: chat.id, status: 'active' }, '-created_date', 100);
    setMessages((msgs || []).reverse());
  };

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = async () => {
    if (!text.trim() || !activeChat) return;
    setSending(true);
    try {
      await offlineDB.GroupMessage.create({
        group_id: activeChat.id,
        sender_id: _optionalChain([user, 'optionalAccess', _4 => _4.id]),
        sender_name: _optionalChain([profile, 'optionalAccess', _5 => _5.exchange_name]) || _optionalChain([user, 'optionalAccess', _6 => _6.full_name]),
        sender_role: 'sarraaf',
        message: text.trim(),
        sync_status: 'pending',
        status: 'active',
      });
      setText('');
      const msgs = await offlineDB.GroupMessage.filter({ group_id: activeChat.id, status: 'active' }, '-created_date', 100);
      setMessages((msgs || []).reverse());
    } catch (e3) {
      // ignore
    }
    setSending(false);
  };

  const filteredChats = chats.filter(c => 
    !search || _optionalChain([c, 'access', _7 => _7.name, 'optionalAccess', _8 => _8.toLowerCase, 'call', _9 => _9(), 'access', _10 => _10.includes, 'call', _11 => _11(search.toLowerCase())])
  );

  return (
    _jsxDEV(FeatureGate, { featureKey: "sarraaf_chat", children: [
      _jsxDEV(PageHeader, { title: "چت صراف‌ها" , subtitle: "پیام خصوصی با سایر صراف‌ها"    , icon: MessageSquareMore,}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this )

      , activeChat ? (
        _jsxDEV(Card, { className: "flex flex-col" , style: { height: 'calc(100vh - 200px)' }, children: [
          _jsxDEV('div', { className: "flex items-center gap-2 p-3 border-b"    , children: [
            _jsxDEV(Button, { variant: "ghost", size: "icon", onClick: () => setActiveChat(null), children: 
              _jsxDEV(ArrowLeft, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
            , _jsxDEV('div', { className: "flex-1", children: [
              _jsxDEV('p', { className: "text-sm font-bold" , children: activeChat.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this)
              , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: activeChat.description || 'چت خصوصی'}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 84}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 80}, this)
          , _jsxDEV(CardContent, { className: "flex-1 overflow-y-auto p-3 scrollbar-thin"   , ref: scrollRef, children: 
            messages.length === 0 ? (
              _jsxDEV(EmptyState, { icon: MessageSquareMore, title: "پیامی نیست" , description: "شروع گفتگو" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 91}, this )
            ) : (
              _jsxDEV('div', { className: "space-y-3", children: 
                messages.map(msg => (
                  _jsxDEV('div', { className: `flex flex-col ${msg.sender_id === _optionalChain([user, 'optionalAccess', _12 => _12.id]) ? 'items-end' : 'items-start'}`, children: 
                    _jsxDEV('div', { className: `max-w-[80%] rounded-2xl px-3 py-2 ${msg.sender_id === _optionalChain([user, 'optionalAccess', _13 => _13.id]) ? 'bg-primary text-primary-foreground' : 'bg-muted'}`, children: [
                      _jsxDEV('p', { className: "text-sm whitespace-pre-wrap" , children: msg.message}, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)
                      , _jsxDEV('p', { className: "text-[10px] opacity-60 mt-1"  , children: 
                        msg.created_date ? format(new Date(msg.created_date), 'HH:mm') : ''
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 96}, this)
                  }, msg.id, false, {fileName: _jsxFileName, lineNumber: 95}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this)
            )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this)
          , _jsxDEV('div', { className: "border-t p-2 flex items-center gap-2"    , children: [
            _jsxDEV(Input, {
              value: text,
              onChange: e => setText(e.target.value),
              onKeyDown: e => e.key === 'Enter' && handleSend(),
              placeholder: "پیام خود را بنویسید..."   ,
              disabled: sending,}, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this
            )
            , _jsxDEV(Button, { size: "icon", onClick: handleSend, disabled: sending || !text.trim(), children: 
              _jsxDEV(Send, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 107}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 79}, this)
      ) : (
        _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-3", children: [
            _jsxDEV('div', { className: "relative mb-3" , children: [
              _jsxDEV(Search, { className: "absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this )
              , _jsxDEV(Input, {
                value: search,
                onChange: e => setSearch(e.target.value),
                placeholder: "جستجوی چت..." ,
                className: "pr-8",}, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 123}, this)
            , loading ? (
              _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 133}, this )
            ) : filteredChats.length === 0 ? (
              _jsxDEV(EmptyState, { icon: MessageSquareMore, title: "چتی وجود ندارد"  , description: "از شبکه نمایندگی چت خصوصی شروع کنید"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this )
            ) : (
              _jsxDEV('div', { className: "space-y-1", children: 
                filteredChats.map(chat => (
                  _jsxDEV('button', {

                    onClick: () => openChat(chat),
                    className: "w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-muted transition-colors text-right"        ,
 children: [
                    _jsxDEV('div', { className: "w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center"      , children: 
                      _jsxDEV(MessageSquareMore, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 145}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this)
                    , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
                      _jsxDEV('p', { className: "text-sm font-medium truncate"  , children: chat.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this)
                      , _jsxDEV('p', { className: "text-xs text-muted-foreground truncate"  , children: chat.description || 'چت خصوصی'}, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
                  ]}, chat.id, true, {fileName: _jsxFileName, lineNumber: 139}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 122}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 75}, this)
  );
}