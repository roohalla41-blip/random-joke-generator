const _jsxFileName = "src/pages/customer/CustomerWallet.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext.js';
import { loadWallets, loadTransactions, loadRates } from '../../lib/walletMockData.js';
import { Button } from '../../components/ui/button.js';
import { Skeleton } from '../../components/ui/skeleton.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { ArrowRight, Landmark, Wifi, WifiOff, RefreshCw, Plus, ArrowDownToLine } from 'lucide-react';
import WalletCards from '../../components/customer/wallet/WalletCards.js';
import WalletDetailSheet from '../../components/customer/wallet/WalletDetailSheet.js';
import TransactionHistory from '../../components/customer/wallet/TransactionHistory.js';
import AddFundsSheet from '../../components/customer/wallet/AddFundsSheet.js';

export default function CustomerWallet() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [wallets, setWallets] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [rates, setRates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState(null);
  const [addFundsOpen, setAddFundsOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  const loadData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError(false);
    try {
      const [w, t, r] = await Promise.all([
        loadWallets(user.id),
        loadTransactions(user.id),
        loadRates(),
      ]);
      setWallets(w);
      setTransactions(t);
      setRates(r);
    } catch (e) {
      setError(true);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);



  useEffect(() => {
    const updateOnline = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', updateOnline);
    window.addEventListener('offline', updateOnline);
    return () => {
      window.removeEventListener('online', updateOnline);
      window.removeEventListener('offline', updateOnline);
    };
  }, []);

  if (loading) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
          _jsxDEV('div', { className: "space-y-2", children: [
            _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this )
            , _jsxDEV(Skeleton, { className: "h-3 w-24" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 67}, this)
          , _jsxDEV(Skeleton, { className: "h-9 w-9 rounded-lg"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 66}, this)
        , _jsxDEV(Skeleton, { className: "h-20 w-full rounded-xl"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this )
        , _jsxDEV('div', { className: "grid grid-cols-2 md:grid-cols-4 gap-3"   , children: 
          [1, 2, 3, 4].map((i) => (
            _jsxDEV(Skeleton, { className: "h-28 rounded-xl" ,}, i, false, {fileName: _jsxFileName, lineNumber: 76}, this )
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this)
        , _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this )
        , _jsxDEV('div', { className: "space-y-2", children: 
          [1, 2, 3].map((i) => (
            _jsxDEV(Skeleton, { className: "h-16 rounded-xl" ,}, i, false, {fileName: _jsxFileName, lineNumber: 82}, this )
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)
    );
  }

  if (error) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV('div', { children: [
          _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "کیف پول من"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "موجودی و گردش کیف پول"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 92}, this)
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-8 text-center space-y-4"  , children: [
            _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "دریافت اطلاعات کیف پول با مشکل مواجه شد."

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)
            , _jsxDEV(Button, { onClick: loadData, variant: "outline", size: "sm", children: [
              _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this ), "تلاش مجدد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 101}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 97}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 91}, this)
    );
  }

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      /* Header */
      _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
        _jsxDEV('div', { className: "min-w-0", children: [
          _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "کیف پول من"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground truncate"  , children: 
            _optionalChain([user, 'optionalAccess', _ => _.full_name]) || 'مشتری'
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 117}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 115}, this)
        , _jsxDEV('div', { className: "flex items-center gap-1.5 shrink-0"   , children: [
          _jsxDEV('span', {
            className: `inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[9px] font-medium ${
              isOnline ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'
            }`,
 children: [
            isOnline ? _jsxDEV(Wifi, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this ) : _jsxDEV(WifiOff, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this )
            , isOnline ? 'آنلاین' : 'آفلاین'
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 122}, this)
          , _jsxDEV(Button, {
            variant: "ghost",
            size: "icon",
            className: "h-8 w-8" ,
            onClick: () => navigate('/customer'),
 children: 
            _jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 121}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 114}, this)

      /* Add Funds / Withdraw Buttons */
      , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
        _jsxDEV(Button, { onClick: () => setAddFundsOpen(true), children: [
          _jsxDEV(Plus, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this ), "افزودن موجودی"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 143}, this)
        , _jsxDEV(Button, {
          variant: "outline",
          onClick: () => navigate('/customer/withdraw'),
 children: [
          _jsxDEV(ArrowDownToLine, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this ), "برداشت"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)

      /* Wallet Cards */
      , _jsxDEV(WalletCards, {
        wallets: wallets,
        transactions: transactions,
        rates: rates,
        onWalletClick: setSelectedCurrency,}, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this
      )

      /* Wallet Detail Sheet */
      , _jsxDEV(WalletDetailSheet, {
        open: !!selectedCurrency,
        onOpenChange: (open) => !open && setSelectedCurrency(null),
        currency: selectedCurrency,
        wallets: wallets,
        transactions: transactions,}, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this
      )

      /* Transaction History */
      , _jsxDEV(TransactionHistory, { transactions: transactions,}, void 0, false, {fileName: _jsxFileName, lineNumber: 174}, this )

      /* Link to Account */
      , _jsxDEV(Button, {
        variant: "outline",
        className: "w-full",
        onClick: () => navigate('/customer/account'),
 children: [
        _jsxDEV(Landmark, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this ), "مشاهده حساب من با صراف"

      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 177}, this)

      /* Add Funds Sheet */
      , _jsxDEV(AddFundsSheet, {
        open: addFundsOpen,
        onOpenChange: setAddFundsOpen,
        user: user,}, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 112}, this)
  );
}