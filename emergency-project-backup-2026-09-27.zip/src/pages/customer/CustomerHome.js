const _jsxFileName = "src/pages/customer/CustomerHome.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext.js';
import { offlineDB as db } from '../../lib/offlineQueue.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { Wallet, Smartphone, Gamepad2, Send, Landmark, Package, MessageSquare, ArrowLeft } from 'lucide-react';

const SECTIONS = [
  { path: '/customer/wallet', label: 'کیف پول من', desc: 'موجودی و تاریخچه تراکنش‌ها', icon: Wallet, color: 'from-blue-500 to-blue-600' },
  { path: '/customer/recharge', label: 'شارژ و اینترنت', desc: 'شارژ سیم‌کارت و بسته اینترنت', icon: Smartphone, color: 'from-green-500 to-green-600' },
  { path: '/customer/games', label: 'بازی‌ها', desc: 'UC پابجی، جم کلش و...', icon: Gamepad2, color: 'from-violet-500 to-violet-600' },
  { path: '/customer/transfer', label: 'ارسال پول / حواله', desc: 'ثبت درخواست ارسال پول', icon: Send, color: 'from-orange-500 to-orange-600' },
  { path: '/customer/account', label: 'حساب من با صراف', desc: 'طلب، بدهی و مانده حساب', icon: Landmark, color: 'from-cyan-500 to-cyan-600' },
  { path: '/customer/orders', label: 'سفارش‌ها و درخواست‌ها', desc: 'پیگیری سفارش‌ها', icon: Package, color: 'from-rose-500 to-rose-600' },
  { path: '/customer/messages', label: 'ارتباط و پیام‌ها', desc: 'چت با صراف و پیام‌ها', icon: MessageSquare, color: 'from-indigo-500 to-indigo-600' },
];

export default function CustomerHome() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [wallets, setWallets] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      if (!user) return;
      try {
        const w = await db.Wallet.list();
        setWallets(w.filter(x => x.user_id === user.id));
        const go = await db.OnlineOrder.list();
        setOrders(go.filter(x => x.created_by_id === user.id));
      } catch (e) {
        // ignore
      }
      setLoading(false);
    };
    loadData();
  }, [user]);

  const totalBalance = wallets.reduce((sum, w) => sum + (w.balance || 0), 0);
  const pendingOrders = orders.filter(o => o.status === 'pending' || o.status === 'processing').length;

  return (
    _jsxDEV('div', { className: "space-y-5", children: [
      /* Welcome */
      _jsxDEV('div', { className: "rounded-2xl bg-gradient-to-br from-primary to-primary/80 p-5 text-primary-foreground shadow-card"      , children: [
        _jsxDEV('h1', { className: "text-xl font-bold" , children: ["سلام " , _optionalChain([user, 'optionalAccess', _ => _.full_name, 'optionalAccess', _2 => _2.split, 'call', _3 => _3(' '), 'access', _4 => _4[0]]) || 'کاربر', " 👋" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 48}, this)
        , _jsxDEV('p', { className: "text-sm text-primary-foreground/80 mt-1"  , children: "به پنل مشتری حساب صراف خوش آمدید"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 47}, this)

      /* Summary Cards */
      , _jsxDEV('div', { className: "grid grid-cols-2 gap-2.5"  , children: [
        _jsxDEV(Card, { className: "shadow-card border-0" , children: 
          _jsxDEV(CardContent, { className: "p-4 bg-gradient-to-br from-blue-500 to-blue-600 text-white"    , children: [
            _jsxDEV('div', { className: "flex items-center justify-between mb-2"   , children: [
              _jsxDEV('span', { className: "text-xs font-medium opacity-90"  , children: "موجودی کیف پول"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 57}, this)
              , _jsxDEV(Wallet, { className: "w-4 h-4 opacity-80"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 56}, this)
            , _jsxDEV('p', { className: "text-lg font-bold tabular-nums"  , children: totalBalance.toLocaleString()}, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this)
            , _jsxDEV('p', { className: "text-[10px] opacity-75 mt-0.5"  , children: "مجموع"}, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 55}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 54}, this)
        , _jsxDEV(Card, { className: "shadow-card border-0" , children: 
          _jsxDEV(CardContent, { className: "p-4 bg-gradient-to-br from-rose-500 to-rose-600 text-white"    , children: [
            _jsxDEV('div', { className: "flex items-center justify-between mb-2"   , children: [
              _jsxDEV('span', { className: "text-xs font-medium opacity-90"  , children: "سفارش‌های فعال" }, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this)
              , _jsxDEV(Package, { className: "w-4 h-4 opacity-80"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 66}, this)
            , _jsxDEV('p', { className: "text-lg font-bold tabular-nums"  , children: pendingOrders}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)
            , _jsxDEV('p', { className: "text-[10px] opacity-75 mt-0.5"  , children: "در حال انجام"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 53}, this)

      /* Main Sections */
      , _jsxDEV('div', { children: [
        _jsxDEV('h2', { className: "text-sm font-bold text-foreground mb-3"   , children: "امکانات"}, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this)
        , _jsxDEV('div', { className: "grid grid-cols-3 gap-2.5"  , children: 
          SECTIONS.map((section) => {
            const Icon = section.icon;
            return (
              _jsxDEV('button', {

                onClick: () => navigate(section.path),
                className: "flex flex-col items-center gap-2 p-3 rounded-xl border border-border bg-card hover:border-primary/30 hover:shadow-card-hover transition-all text-center group"             ,
 children: [
                _jsxDEV('div', { className: `w-12 h-12 rounded-2xl bg-gradient-to-br ${section.color} flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform`, children: 
                  _jsxDEV(Icon, { className: "w-6 h-6 text-white"  , strokeWidth: 2.2,}, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)
                , _jsxDEV('span', { className: "text-[11px] font-bold text-foreground leading-tight"   , children: section.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 91}, this)
              ]}, section.path, true, {fileName: _jsxFileName, lineNumber: 83}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 77}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 45}, this)
  );
}