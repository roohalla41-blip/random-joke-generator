const _jsxFileName = "src/pages/customer/CustomerProfile.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext.js';
import { handleGoogleCallback } from '../../lib/googleAuth.js';
import { loadProfile, saveProfile, saveNotificationSettings } from '../../lib/profileMockData.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { Button } from '../../components/ui/button.js';
import { Input } from '../../components/ui/input.js';
import { Label } from '../../components/ui/label.js';
import { Switch } from '../../components/ui/switch.js';
import { Skeleton } from '../../components/ui/skeleton.js';
import {
  User, BadgeCheck, Building2, Shield, Lock, LogOut,
  Bell, Wallet, Landmark, Package, MessageSquare, ArrowRight,
  RefreshCw, Check, AlertCircle, CheckCircle2, Settings as SettingsIcon,
} from 'lucide-react';
import { initiateGoogleLink } from '../../lib/googleAuth.js';
import GoogleIcon from '../../components/GoogleIcon.js';
import { changePassword as localChangePassword } from '../../lib/localAuth.js';
import { callSupabase } from '../../lib/supabaseApi.js';

const STATUS_LABELS = {
  active: { label: 'فعال', color: 'bg-success/15 text-success' },
  suspended: { label: 'معلق', color: 'bg-destructive/15 text-destructive' },
  inactive: { label: 'غیرفعال', color: 'bg-muted text-muted-foreground' },
};

export default function CustomerProfile() {
  const navigate = useNavigate();
  const { user, logout, checkAppState } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [activeSection, setActiveSection] = useState('info');

  // Edit form
  const [editForm, setEditForm] = useState({});
  const [editErrors, setEditErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Password form
  const [pwForm, setPwForm] = useState({ current: '', newPass: '', confirm: '' });
  const [pwErrors, setPwErrors] = useState({});
  const [pwSaving, setPwSaving] = useState(false);
  const [pwSuccess, setPwSuccess] = useState(false);

  // Notification settings
  const [notifSettings, setNotifSettings] = useState({});
  const [notifSaving, setNotifSaving] = useState(false);
  const [notifSuccess, setNotifSuccess] = useState(false);

  // Logout confirm
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const p = await loadProfile(user);
      // Merge with real user data from auth
      const merged = {
        ...p,
        customer_name: _optionalChain([user, 'optionalAccess', _ => _.full_name]) || _optionalChain([p, 'optionalAccess', _2 => _2.customer_name]) || '',
        username: _optionalChain([user, 'optionalAccess', _3 => _3.email, 'optionalAccess', _4 => _4.split, 'call', _5 => _5('@'), 'access', _6 => _6[0]]) || '',
        phone: _optionalChain([user, 'optionalAccess', _7 => _7.phone]) || '',
        email: _optionalChain([user, 'optionalAccess', _8 => _8.email]) || '',
        display_name: _optionalChain([user, 'optionalAccess', _9 => _9.full_name]) || '',
        account_status: 'active',
      };
      setProfile(merged);
      setEditForm({
        customer_name: merged.customer_name || '',
        phone: merged.phone || '',
        email: merged.email || '',
        display_name: merged.display_name || '',
      });
      // Load notification settings from localStorage
      try {
        const key = `notif_settings_${_optionalChain([user, 'optionalAccess', _10 => _10.id])}`;
        const saved = JSON.parse(localStorage.getItem(key) || '{}');
        setNotifSettings({ in_app: true, orders: true, messages: true, general: false, ...saved });
      } catch (e2) {
        setNotifSettings({ in_app: true, orders: true, messages: true, general: false });
      }
    } catch (e) {
      setError(true);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // ── Google link callback handler ──
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('google_link') !== '1') return;
    handleGoogleCallback().then((result) => {
      if (_optionalChain([result, 'optionalAccess', _11 => _11.linked])) {
        window.history.replaceState({}, '', '/customer/profile');
        // Refresh user data
        checkAppState();
      }
    });
  }, []);

  const validateEditForm = () => {
    const errs = {};
    if (!editForm.customer_name || editForm.customer_name.trim().length < 3) {
      errs.customer_name = 'نام باید حداقل ۳ کاراکتر باشد.';
    }
    if (editForm.phone && !/^[\d\s+\-()]{7,15}$/.test(editForm.phone.trim())) {
      errs.phone = 'فرمت شماره موبایل نامعتبر است.';
    }
    if (editForm.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(editForm.email.trim())) {
      errs.email = 'فرمت ایمیل نامعتبر است.';
    }
    setEditErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSaveProfile = async () => {
    if (!validateEditForm()) return;
    setSaving(true);
    setSaveSuccess(false);
    await saveProfile(_optionalChain([user, 'optionalAccess', _12 => _12.id]), editForm);
    setProfile((prev) => ({ ...prev, ...editForm }));
    setSaving(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const validatePwForm = () => {
    const errs = {};
    if (!pwForm.current) errs.current = 'رمز فعلی الزامی است.';
    if (!pwForm.newPass) errs.newPass = 'رمز جدید الزامی است.';
    if (pwForm.newPass && pwForm.newPass.length < 6) errs.newPass = 'رمز جدید باید حداقل ۶ کاراکتر باشد.';
    if (pwForm.newPass !== pwForm.confirm) errs.confirm = 'رمز جدید و تکرار آن یکسان نیستند.';
    setPwErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleChangePassword = async () => {
    if (!validatePwForm()) return;
    setPwSaving(true);
    setPwSuccess(false);
    setPwErrors({});
    try {
      const isLocalUser = _optionalChain([user, 'optionalAccess', _13 => _13.isLocal]) || !!localStorage.getItem('local_users_db');
      if (isLocalUser) {
        const res = localChangePassword(pwForm.current, pwForm.newPass);
        if (!res.success) {
          const msg = res.error === 'wrong_password' ? 'رمز فعلی اشتباه است' : 'خطا در تغییر رمز عبور';
          setPwErrors({ current: msg });
          setPwSaving(false);
          return;
        }
      } else {
        const res = await callSupabase('changePassword', {
          old_password: pwForm.current,
          new_password: pwForm.newPass,
        });
        if (!_optionalChain([res, 'optionalAccess', _14 => _14.success])) {
          const err = _optionalChain([res, 'optionalAccess', _15 => _15.error]);
          const msg = err === 'wrong_password' ? 'رمز فعلی اشتباه است' : 'خطا در تغییر رمز عبور';
          setPwErrors({ current: msg });
          setPwSaving(false);
          return;
        }
      }
      setPwForm({ current: '', newPass: '', confirm: '' });
      setPwSuccess(true);
      setTimeout(() => setPwSuccess(false), 3000);
    } catch (err) {
      setPwErrors({ current: 'خطا در ارتباط با سرور. مجدداً تلاش کنید.' });
    }
    setPwSaving(false);
  };

  const handleNotifToggle = async (key, value) => {
    const updated = { ...notifSettings, [key]: value };
    setNotifSettings(updated);
    setNotifSaving(true);
    setNotifSuccess(false);
    await saveNotificationSettings(_optionalChain([user, 'optionalAccess', _16 => _16.id]), { [key]: value });
    setNotifSaving(false);
    setNotifSuccess(true);
    setTimeout(() => setNotifSuccess(false), 2000);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (loading) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 201}, this )
        , _jsxDEV(Skeleton, { className: "h-24 w-full rounded-xl"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 202}, this )
        , _jsxDEV(Skeleton, { className: "h-48 w-full rounded-xl"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 203}, this )
        , _jsxDEV(Skeleton, { className: "h-32 w-full rounded-xl"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 204}, this )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 200}, this)
    );
  }

  if (error) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "پروفایل و تنظیمات"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 212}, this)
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-8 text-center space-y-4"  , children: [
            _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "دریافت اطلاعات با مشکل مواجه شد."     }, void 0, false, {fileName: _jsxFileName, lineNumber: 215}, this)
            , _jsxDEV(Button, { onClick: loadData, variant: "outline", size: "sm", children: [
              _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 217}, this ), "تلاش مجدد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 216}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 214}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 213}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 211}, this)
    );
  }

  const status = STATUS_LABELS[profile.account_status] || STATUS_LABELS.inactive;

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      /* Header */
      _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
        _jsxDEV('div', { className: "flex items-center gap-2 min-w-0"   , children: [
          _jsxDEV('div', { className: "w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"       , children: 
            _jsxDEV(User, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 234}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 233}, this)
          , _jsxDEV('div', { className: "min-w-0", children: [
            _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "پروفایل و تنظیمات"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 237}, this)
            , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "اطلاعات شخصی و تنظیمات حساب"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 238}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 236}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 232}, this)
        , _jsxDEV('div', { className: "flex items-center gap-1.5 shrink-0"   , children: 
          _jsxDEV(Button, { variant: "ghost", size: "icon", className: "h-8 w-8" , onClick: () => navigate('/customer'), children: 
            _jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 243}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 242}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 241}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 231}, this)

      /* Profile Card */
      , _jsxDEV(Card, { className: "shadow-sm", children: 
        _jsxDEV(CardContent, { className: "p-4", children: 
          _jsxDEV('div', { className: "flex items-center gap-3"  , children: [
            _jsxDEV('div', { className: "w-14 h-14 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shrink-0"         , children: 
              _jsxDEV(User, { className: "w-7 h-7 text-primary-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 253}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 252}, this)
            , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
              _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                _jsxDEV('p', { className: "text-sm font-bold text-foreground truncate"   , children: profile.customer_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 257}, this)
                , _jsxDEV('span', { className: `text-[8px] px-1.5 py-0.5 rounded ${status.color}`, children: status.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 258}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 256}, this)
              , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: ["@", profile.username]}, void 0, true, {fileName: _jsxFileName, lineNumber: 260}, this)
              , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: ["کد مشتری: "  , profile.customer_code]}, void 0, true, {fileName: _jsxFileName, lineNumber: 261}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 255}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 251}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 250}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 249}, this)

      /* Section Tabs */
      , _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
        [
          { key: 'info', label: 'اطلاعات شخصی', icon: User },
          { key: 'security', label: 'امنیت حساب', icon: Shield },
          { key: 'notifications', label: 'اعلان‌ها', icon: Bell },
          { key: 'exchange', label: 'حساب با صرافی', icon: Building2 },
        ].map((tab) => {
          const TabIcon = tab.icon;
          return (
            _jsxDEV('button', {

              onClick: () => setActiveSection(tab.key),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all flex items-center gap-1.5 ${
                activeSection === tab.key ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: [
              _jsxDEV(TabIcon, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 284}, this )
              , tab.label
            ]}, tab.key, true, {fileName: _jsxFileName, lineNumber: 277}, this)
          );
        })
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 268}, this)

      /* Section: Personal Info */
      , activeSection === 'info' && (
        _jsxDEV('div', { className: "space-y-3", children: [
          _jsxDEV(Card, { className: "shadow-sm", children: 
            _jsxDEV(CardContent, { className: "p-3 space-y-3" , children: 
              _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: [
                _jsxDEV('div', { children: [
                  _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "کد مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 298}, this)
                  , _jsxDEV('p', { className: "text-xs font-mono text-foreground"  , children: profile.customer_code}, void 0, false, {fileName: _jsxFileName, lineNumber: 299}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 297}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "تاریخ عضویت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 302}, this)
                  , _jsxDEV('p', { className: "text-xs text-foreground" , children: new Date(profile.joined_date).toLocaleDateString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 303}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 301}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "نام صرافی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 306}, this)
                  , _jsxDEV('p', { className: "text-xs text-foreground" , children: profile.exchange_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 307}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 305}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "کد صرافی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 310}, this)
                  , _jsxDEV('p', { className: "text-xs font-mono text-foreground"  , children: profile.exchange_code}, void 0, false, {fileName: _jsxFileName, lineNumber: 311}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 309}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 296}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 295}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 294}, this)

          , _jsxDEV(Card, { className: "shadow-sm", children: 
            _jsxDEV(CardContent, { className: "p-3 space-y-3" , children: [
              _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                _jsxDEV(SettingsIcon, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 320}, this )
                , _jsxDEV('p', { className: "text-xs font-bold text-foreground"  , children: "ویرایش اطلاعات مجاز"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 321}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 319}, this)

              , _jsxDEV('div', { className: "space-y-2", children: [
                _jsxDEV('div', { children: [
                  _jsxDEV(Label, { className: "text-[10px] text-muted-foreground" , children: "نام کامل" }, void 0, false, {fileName: _jsxFileName, lineNumber: 326}, this)
                  , _jsxDEV(Input, {
                    value: editForm.customer_name || '',
                    onChange: (e) => setEditForm({ ...editForm, customer_name: e.target.value }),
                    className: "text-xs h-9 mt-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 327}, this
                  )
                  , editErrors.customer_name && _jsxDEV('p', { className: "text-[9px] text-destructive mt-0.5"  , children: editErrors.customer_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 332}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 325}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { className: "text-[10px] text-muted-foreground" , children: "نام نمایشی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 335}, this)
                  , _jsxDEV(Input, {
                    value: editForm.display_name || '',
                    onChange: (e) => setEditForm({ ...editForm, display_name: e.target.value }),
                    className: "text-xs h-9 mt-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 336}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 334}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { className: "text-[10px] text-muted-foreground" , children: "شماره موبایل" }, void 0, false, {fileName: _jsxFileName, lineNumber: 343}, this)
                  , _jsxDEV(Input, {
                    value: editForm.phone || '',
                    onChange: (e) => setEditForm({ ...editForm, phone: e.target.value }),
                    className: "text-xs h-9 mt-1"  ,
                    dir: "ltr",}, void 0, false, {fileName: _jsxFileName, lineNumber: 344}, this
                  )
                  , editErrors.phone && _jsxDEV('p', { className: "text-[9px] text-destructive mt-0.5"  , children: editErrors.phone}, void 0, false, {fileName: _jsxFileName, lineNumber: 350}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 342}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { className: "text-[10px] text-muted-foreground" , children: "ایمیل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 353}, this)
                  , _jsxDEV(Input, {
                    type: "email",
                    value: editForm.email || '',
                    onChange: (e) => setEditForm({ ...editForm, email: e.target.value }),
                    className: "text-xs h-9 mt-1"  ,
                    dir: "ltr",}, void 0, false, {fileName: _jsxFileName, lineNumber: 354}, this
                  )
                  , editErrors.email && _jsxDEV('p', { className: "text-[9px] text-destructive mt-0.5"  , children: editErrors.email}, void 0, false, {fileName: _jsxFileName, lineNumber: 361}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 352}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 324}, this)

              , saveSuccess && (
                _jsxDEV('div', { className: "flex items-center gap-1.5 text-[10px] text-success bg-success/10 rounded-lg p-2"       , children: [
                  _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 367}, this ), "اطلاعات با موفقیت در حالت آزمایشی ذخیره شد."

                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 366}, this)
              )

              , _jsxDEV(Button, { onClick: handleSaveProfile, disabled: saving, className: "w-full text-xs h-9"  , children: [
                saving ? _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-1 animate-spin"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 373}, this ) : _jsxDEV(Check, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 373}, this ), "ذخیره تغییرات"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 372}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 318}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 317}, this)

          /* Read-only Financial Summary */
          , _jsxDEV(Card, { className: "shadow-sm", children: 
            _jsxDEV(CardContent, { className: "p-3", children: [
              _jsxDEV('div', { className: "flex items-center gap-2 mb-2"   , children: [
                _jsxDEV(Wallet, { className: "w-4 h-4 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 383}, this )
                , _jsxDEV('p', { className: "text-xs font-bold text-foreground"  , children: "خلاصه مالی (فقط نمایش)"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 384}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 382}, this)
              , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: 
                profile.balances.map((b) => (
                  _jsxDEV('div', { className: "flex items-center justify-between rounded-lg bg-muted/50 px-2 py-1.5"      , children: [
                    _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: b.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 389}, this)
                    , _jsxDEV('div', { className: "text-left", children: [
                      _jsxDEV('p', { className: "text-xs font-bold text-foreground"  , children: b.amount.toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 391}, this)
                      , _jsxDEV('p', { className: "text-[8px] text-muted-foreground" , children: b.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 392}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 390}, this)
                  ]}, b.currency, true, {fileName: _jsxFileName, lineNumber: 388}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 386}, this)
              , _jsxDEV('p', { className: "text-[9px] text-muted-foreground mt-2 flex items-center gap-1"     , children: [
                _jsxDEV(AlertCircle, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 398}, this ), "موجودی‌ها فقط قابل مشاهده هستند. شارژ کیف پول توسط صرافی انجام می‌شود."

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 397}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 381}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 380}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 293}, this)
      )

      /* Section: Security */
      , activeSection === 'security' && (
        _jsxDEV('div', { className: "space-y-3", children: [
          _jsxDEV(Card, { className: "shadow-sm", children: 
            _jsxDEV(CardContent, { className: "p-3 space-y-3" , children: [
              _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                _jsxDEV(Lock, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 412}, this )
                , _jsxDEV('p', { className: "text-xs font-bold text-foreground"  , children: "تغییر رمز عبور"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 413}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 411}, this)
              , _jsxDEV('div', { className: "space-y-2", children: [
                _jsxDEV('div', { children: [
                  _jsxDEV(Label, { className: "text-[10px] text-muted-foreground" , children: "رمز فعلی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 417}, this)
                  , _jsxDEV(Input, {
                    type: "password",
                    value: pwForm.current,
                    onChange: (e) => setPwForm({ ...pwForm, current: e.target.value }),
                    className: "text-xs h-9 mt-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 418}, this
                  )
                  , pwErrors.current && _jsxDEV('p', { className: "text-[9px] text-destructive mt-0.5"  , children: pwErrors.current}, void 0, false, {fileName: _jsxFileName, lineNumber: 424}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 416}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { className: "text-[10px] text-muted-foreground" , children: "رمز جدید" }, void 0, false, {fileName: _jsxFileName, lineNumber: 427}, this)
                  , _jsxDEV(Input, {
                    type: "password",
                    value: pwForm.newPass,
                    onChange: (e) => setPwForm({ ...pwForm, newPass: e.target.value }),
                    className: "text-xs h-9 mt-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 428}, this
                  )
                  , pwErrors.newPass && _jsxDEV('p', { className: "text-[9px] text-destructive mt-0.5"  , children: pwErrors.newPass}, void 0, false, {fileName: _jsxFileName, lineNumber: 434}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 426}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { className: "text-[10px] text-muted-foreground" , children: "تکرار رمز جدید"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 437}, this)
                  , _jsxDEV(Input, {
                    type: "password",
                    value: pwForm.confirm,
                    onChange: (e) => setPwForm({ ...pwForm, confirm: e.target.value }),
                    className: "text-xs h-9 mt-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 438}, this
                  )
                  , pwErrors.confirm && _jsxDEV('p', { className: "text-[9px] text-destructive mt-0.5"  , children: pwErrors.confirm}, void 0, false, {fileName: _jsxFileName, lineNumber: 444}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 436}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 415}, this)
              , pwSuccess && (
                _jsxDEV('div', { className: "flex items-center gap-1.5 text-[10px] text-success bg-success/10 rounded-lg p-2"       , children: [
                  _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 449}, this ), "رمز عبور در حالت آزمایشی تغییر یافت."

                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 448}, this)
              )
              , _jsxDEV(Button, { onClick: handleChangePassword, disabled: pwSaving, className: "w-full text-xs h-9"  , children: [
                pwSaving ? _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-1 animate-spin"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 454}, this ) : _jsxDEV(Lock, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 454}, this ), "تغییر رمز عبور"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 453}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 410}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 409}, this)

          , _jsxDEV(Card, { className: "shadow-sm", children: 
            _jsxDEV(CardContent, { className: "p-3 space-y-2" , children: [
              _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                _jsxDEV(Shield, { className: "w-4 h-4 text-success"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 463}, this )
                , _jsxDEV('p', { className: "text-xs font-bold text-foreground"  , children: "وضعیت امنیت حساب"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 464}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 462}, this)
              , _jsxDEV('div', { className: "space-y-1.5", children: [
                _jsxDEV('div', { className: "flex items-center justify-between text-xs"   , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "رمز عبور" }, void 0, false, {fileName: _jsxFileName, lineNumber: 468}, this)
                  , _jsxDEV('span', { className: "text-success flex items-center gap-0.5"   , children: [_jsxDEV(BadgeCheck, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 469}, this ), " تنظیم شده"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 469}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 467}, this)
                , _jsxDEV('div', { className: "flex items-center justify-between text-xs"   , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "تأیید موبایل" }, void 0, false, {fileName: _jsxFileName, lineNumber: 472}, this)
                  , _jsxDEV('span', { className: "text-success flex items-center gap-0.5"   , children: [_jsxDEV(BadgeCheck, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 473}, this ), " تأیید شده"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 473}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 471}, this)
                , _jsxDEV('div', { className: "flex items-center justify-between text-xs"   , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "تأیید ایمیل" }, void 0, false, {fileName: _jsxFileName, lineNumber: 476}, this)
                  , _jsxDEV('span', { className: "text-muted-foreground", children: "—"}, void 0, false, {fileName: _jsxFileName, lineNumber: 477}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 475}, this)

                /* Google Account Link */
                , _jsxDEV('div', { className: "pt-2 border-t" , children: [
                  _jsxDEV('p', { className: "text-xs text-muted-foreground mb-2"  , children: "حساب گوگل" }, void 0, false, {fileName: _jsxFileName, lineNumber: 482}, this)
                  , _optionalChain([user, 'optionalAccess', _17 => _17.email]) ? (
                    _jsxDEV('div', { className: "flex items-center gap-2 text-xs"   , children: [
                      _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 text-success shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 485}, this )
                      , _jsxDEV('span', { className: "text-foreground truncate" , dir: "ltr", children: user.email}, void 0, false, {fileName: _jsxFileName, lineNumber: 486}, this)
                      , _jsxDEV('span', { className: "text-success text-[10px]" , children: "متصل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 487}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 484}, this)
                  ) : (
                    _jsxDEV(Button, {
                      variant: "outline",
                      className: "w-full h-9 text-xs"  ,
                      onClick: () => initiateGoogleLink(_optionalChain([user, 'optionalAccess', _18 => _18.mobile]) || '', '/customer/profile?google_link=1'),
 children: [
                      _jsxDEV(GoogleIcon, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 495}, this ), "اتصال حساب گوگل"

                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 490}, this)
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 481}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 466}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 461}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 460}, this)

          /* Logout */
          , !showLogoutConfirm ? (
            _jsxDEV(Button, { variant: "destructive", className: "w-full text-xs h-9"  , onClick: () => setShowLogoutConfirm(true), children: [
              _jsxDEV(LogOut, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 507}, this ), "خروج از حساب"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 506}, this)
          ) : (
            _jsxDEV(Card, { className: "shadow-sm border-destructive/30" , children: 
              _jsxDEV(CardContent, { className: "p-3 space-y-3" , children: [
                _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                  _jsxDEV(AlertCircle, { className: "w-4 h-4 text-destructive"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 514}, this )
                  , _jsxDEV('p', { className: "text-xs font-bold text-foreground"  , children: "خروج از حساب"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 515}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 513}, this)
                , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "آیا مطمئن هستید که می‌خواهید از حساب خارج شوید؟"        }, void 0, false, {fileName: _jsxFileName, lineNumber: 517}, this)
                , _jsxDEV('div', { className: "flex gap-2" , children: [
                  _jsxDEV(Button, { variant: "outline", className: "flex-1 text-xs h-9"  , onClick: () => setShowLogoutConfirm(false), children: "انصراف"

                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 519}, this)
                  , _jsxDEV(Button, { variant: "destructive", className: "flex-1 text-xs h-9"  , onClick: handleLogout, children: [
                    _jsxDEV(LogOut, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 523}, this ), "خروج"

                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 522}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 518}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 512}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 511}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 408}, this)
      )

      /* Section: Notification Settings */
      , activeSection === 'notifications' && (
        _jsxDEV(Card, { className: "shadow-sm", children: 
          _jsxDEV(CardContent, { className: "p-3 space-y-3" , children: [
            _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
              _jsxDEV(Bell, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 538}, this )
              , _jsxDEV('p', { className: "text-xs font-bold text-foreground"  , children: "تنظیمات اعلان‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 539}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 537}, this)
            , _jsxDEV('div', { className: "space-y-3", children: 
              [
                { key: 'in_app', label: 'اعلان‌های داخل برنامه' },
                { key: 'orders', label: 'اعلان سفارش‌ها' },
                { key: 'messages', label: 'اعلان پیام‌ها' },
                { key: 'general', label: 'اعلان‌های عمومی' },
              ].map((item) => (
                _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
                  _jsxDEV('span', { className: "text-xs text-foreground" , children: item.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 549}, this)
                  , _jsxDEV(Switch, {
                    checked: !!notifSettings[item.key],
                    onCheckedChange: (val) => handleNotifToggle(item.key, val),}, void 0, false, {fileName: _jsxFileName, lineNumber: 550}, this
                  )
                ]}, item.key, true, {fileName: _jsxFileName, lineNumber: 548}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 541}, this)
            , notifSaving && (
              _jsxDEV('p', { className: "text-[9px] text-muted-foreground flex items-center gap-1"    , children: [
                _jsxDEV(RefreshCw, { className: "w-3 h-3 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 559}, this ), "در حال ذخیره..."

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 558}, this)
            )
            , notifSuccess && (
              _jsxDEV('div', { className: "flex items-center gap-1.5 text-[10px] text-success bg-success/10 rounded-lg p-2"       , children: [
                _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 565}, this ), "تنظیمات ذخیره شد."

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 564}, this)
            )
            , _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: "اعلان‌ها فقط در برنامه نمایش داده می‌شوند. Push و SMS فعال نیستند."           }, void 0, false, {fileName: _jsxFileName, lineNumber: 569}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 536}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 535}, this)
      )

      /* Section: Exchange Link */
      , activeSection === 'exchange' && (
        _jsxDEV(Card, { className: "shadow-sm", children: 
          _jsxDEV(CardContent, { className: "p-3 space-y-3" , children: [
            _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
              _jsxDEV(Building2, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 579}, this )
              , _jsxDEV('p', { className: "text-xs font-bold text-foreground"  , children: "ارتباط با صرافی"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 580}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 578}, this)
            , _jsxDEV('div', { className: "space-y-2", children: [
              _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "نام صرافی:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 584}, this)
                , _jsxDEV('span', { className: "text-foreground", children: profile.exchange_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 585}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 583}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "کد صرافی:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 588}, this)
                , _jsxDEV('span', { className: "font-mono text-foreground" , children: profile.exchange_code}, void 0, false, {fileName: _jsxFileName, lineNumber: 589}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 587}, this)
              , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "وضعیت ارتباط:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 592}, this)
                , _jsxDEV('span', { className: "text-success flex items-center gap-0.5"   , children: [_jsxDEV(BadgeCheck, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 593}, this ), " فعال" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 593}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 591}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 582}, this)
            , _jsxDEV(Button, { variant: "outline", className: "w-full text-xs h-9"  , onClick: () => navigate('/customer/account'), children: ["مشاهده جزئیات حساب"

              , _jsxDEV(ArrowRight, { className: "w-4 h-4 mr-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 598}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 596}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 577}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 576}, this)
      )

      /* Quick Links */
      , _jsxDEV('div', { className: "grid grid-cols-3 gap-2"  , children: [
        _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/wallet'), children: [
          _jsxDEV(Wallet, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 607}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "کیف پول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 608}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 606}, this)
        , _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/account'), children: [
          _jsxDEV(Landmark, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 611}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "حساب من" }, void 0, false, {fileName: _jsxFileName, lineNumber: 612}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 610}, this)
        , _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/orders'), children: [
          _jsxDEV(Package, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 615}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "سفارش‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 616}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 614}, this)
        , _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/messages'), children: [
          _jsxDEV(MessageSquare, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 619}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "پیام‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 620}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 618}, this)
        , _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/notifications'), children: [
          _jsxDEV(Bell, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 623}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "اعلان‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 624}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 622}, this)
        , _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer'), children: [
          _jsxDEV(User, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 627}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "خانه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 628}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 626}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 605}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 229}, this)
  );
}