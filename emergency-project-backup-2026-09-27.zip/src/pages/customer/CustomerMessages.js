const _jsxFileName = "src/pages/customer/CustomerMessages.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext.js';
import {
  loadMessagesProfile, loadConversations, sendMessage, markConversationRead,
} from '../../lib/messagesMockData.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { Button } from '../../components/ui/button.js';
import { Input } from '../../components/ui/input.js';
import { Skeleton } from '../../components/ui/skeleton.js';
import {
  MessageSquare, Send, Search, ArrowRight, RefreshCw,
  Check, CheckCheck, AlertCircle, ChevronLeft, Wallet, Package, Landmark,
} from 'lucide-react';

const STATUS_ICONS = {
  sending: { icon: RefreshCw, color: 'text-muted-foreground', spin: true },
  sent: { icon: Check, color: 'text-muted-foreground', spin: false },
  delivered: { icon: CheckCheck, color: 'text-muted-foreground', spin: false },
  read: { icon: CheckCheck, color: 'text-primary', spin: false },
  error: { icon: AlertCircle, color: 'text-destructive', spin: false },
};

const MAX_MESSAGE_LENGTH = 500;

export default function CustomerMessages() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [activeConvId, setActiveConvId] = useState(null);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [search, setSearch] = useState('');
  const messagesEndRef = useRef(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const [prof, convs] = await Promise.all([
        loadMessagesProfile(user), loadConversations(_optionalChain([user, 'optionalAccess', _ => _.id])),
      ]);
      setProfile(prof);
      setConversations(convs);
    } catch (e) {
      setError(true);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const activeConv = conversations.find((c) => c.id === activeConvId);

  useEffect(() => {
    if (activeConvId) {
      markConversationRead(activeConvId, _optionalChain([user, 'optionalAccess', _2 => _2.id])).then(() => {
        setConversations((prev) => prev.map((c) =>
          c.id === activeConvId ? { ...c, unread_count: 0, messages: c.messages.map((m) => m.sender === 'exchange' ? { ...m, status: 'read' } : m) } : c
        ));
      });
    }
  }, [activeConvId]);

  useEffect(() => {
    _optionalChain([messagesEndRef, 'access', _3 => _3.current, 'optionalAccess', _4 => _4.scrollIntoView, 'call', _5 => _5({ behavior: 'smooth' })]);
  }, [_optionalChain([activeConv, 'optionalAccess', _6 => _6.messages])]);

  const filteredConversations = conversations.filter((c) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return c.name.toLowerCase().includes(q) || (c.last_message || '').toLowerCase().includes(q);
  });

  const totalUnread = conversations.reduce((sum, c) => sum + (c.unread_count || 0), 0);

  const handleSend = async () => {
    if (!input.trim() || !activeConvId || sending) return;
    if (input.length > MAX_MESSAGE_LENGTH) return;
    setSending(true);
    try {
      await sendMessage(activeConvId, input.trim(), _optionalChain([user, 'optionalAccess', _7 => _7.full_name]) || _optionalChain([profile, 'optionalAccess', _8 => _8.customer_name]) || 'مشتری', _optionalChain([user, 'optionalAccess', _9 => _9.id]));
      const updated = await loadConversations(_optionalChain([user, 'optionalAccess', _10 => _10.id]));
      setConversations(updated);
      setInput('');
    } catch (e) {
      // error handled visually
    }
    setSending(false);
  };

  if (loading) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 100}, this )
        , _jsxDEV(Skeleton, { className: "h-20 w-full rounded-xl"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this )
        , _jsxDEV(Skeleton, { className: "h-8 w-full rounded-lg"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this )
        , _jsxDEV('div', { className: "space-y-2", children: 
          [1, 2, 3].map((i) => _jsxDEV(Skeleton, { className: "h-16 rounded-xl" ,}, i, false, {fileName: _jsxFileName, lineNumber: 104}, this ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 99}, this)
    );
  }

  if (error) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "پیام‌ها و پیام‌رسانی"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this)
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-8 text-center space-y-4"  , children: [
            _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "دریافت اطلاعات با مشکل مواجه شد."     }, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this)
            , _jsxDEV(Button, { onClick: loadData, variant: "outline", size: "sm", children: [
              _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this ), "تلاش مجدد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 117}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 115}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 112}, this)
    );
  }

  // Chat View
  if (activeConv) {
    return (
      _jsxDEV('div', { className: "space-y-3", children: [
        /* Chat Header */
        _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
          _jsxDEV(Button, { variant: "ghost", size: "icon", className: "h-8 w-8 shrink-0"  , onClick: () => setActiveConvId(null), children: 
            _jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 134}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 133}, this)
          , _jsxDEV('div', { className: "flex items-center gap-2 flex-1 min-w-0"    , children: [
            _jsxDEV('div', { className: "w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0"       , children: 
              _jsxDEV(MessageSquare, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this)
            , _jsxDEV('div', { className: "min-w-0", children: [
              _jsxDEV('p', { className: "text-sm font-bold text-foreground truncate"   , children: activeConv.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this)
              , _jsxDEV('p', { className: "text-[10px] text-success flex items-center gap-1"    , children: [
                _jsxDEV('span', { className: "w-1.5 h-1.5 rounded-full bg-success"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this ), "آنلاین"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 140}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 136}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 132}, this)

        /* Messages */
        , _jsxDEV(Card, { className: "shadow-sm flex flex-col"  , style: { minHeight: 'calc(100vh - 220px)' }, children: 
          _jsxDEV(CardContent, { className: "p-3 flex-1 flex flex-col"   , children: [
            _jsxDEV('div', { className: "flex-1 space-y-2 overflow-y-auto scrollbar-thin"   , style: { maxHeight: 'calc(100vh - 280px)' }, children: [
              activeConv.messages.length === 0 ? (
                _jsxDEV('div', { className: "text-center py-8" , children: [
                  _jsxDEV(MessageSquare, { className: "w-8 h-8 text-muted-foreground/30 mx-auto mb-2"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this )
                  , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "گفتگو بدون پیام — اولین پیام را ارسال کنید."        }, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 155}, this)
              ) : (
                activeConv.messages.map((msg) => {
                  const isMine = msg.sender === 'customer';
                  const st = STATUS_ICONS[msg.status] || STATUS_ICONS.sent;
                  const StIcon = st.icon;
                  return (
                    _jsxDEV('div', { className: `flex ${isMine ? 'justify-end' : 'justify-start'}`, children: 
                      _jsxDEV('div', { className: `max-w-[80%] rounded-xl px-3 py-2 ${isMine ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground'}`, children: [
                        _jsxDEV('p', { className: "text-xs whitespace-pre-wrap break-words"  , children: msg.content}, void 0, false, {fileName: _jsxFileName, lineNumber: 167}, this)
                        , _jsxDEV('div', { className: `flex items-center gap-1 mt-0.5 ${isMine ? 'justify-end' : 'justify-start'}`, children: [
                          _jsxDEV('p', { className: `text-[8px] ${isMine ? 'text-primary-foreground/70' : 'text-muted-foreground'}`, children: 
                            new Date(msg.timestamp).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
                          }, void 0, false, {fileName: _jsxFileName, lineNumber: 169}, this)
                          , isMine && _jsxDEV(StIcon, { className: `w-2.5 h-2.5 ${st.color} ${st.spin ? 'animate-spin' : ''}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 172}, this )
                        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 168}, this)
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 166}, this)
                    }, msg.id, false, {fileName: _jsxFileName, lineNumber: 165}, this)
                  );
                })
              )
              , _jsxDEV('div', { ref: messagesEndRef,}, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 153}, this)

            /* Input */
            , _jsxDEV('div', { className: "flex gap-1 mt-2 pt-2 border-t border-border"     , children: [
              _jsxDEV(Input, {
                value: input,
                onChange: (e) => setInput(e.target.value),
                onKeyDown: (e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend()),
                placeholder: "پیام خود را بنویسید..."   ,
                className: "text-xs h-9" ,
                maxLength: MAX_MESSAGE_LENGTH,
                disabled: sending,}, void 0, false, {fileName: _jsxFileName, lineNumber: 184}, this
              )
              , _jsxDEV(Button, { size: "icon", className: "h-9 w-9 shrink-0"  , onClick: handleSend, disabled: !input.trim() || sending, children: 
                sending ? _jsxDEV(RefreshCw, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 194}, this ) : _jsxDEV(Send, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 194}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 193}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 183}, this)
            , input.length > MAX_MESSAGE_LENGTH * 0.8 && (
              _jsxDEV('p', { className: "text-[9px] text-muted-foreground text-left mt-1"   , children: [
                input.length, " / "  , MAX_MESSAGE_LENGTH
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 198}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 152}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 130}, this)
    );
  }

  // Conversation List View
  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      /* Header */
      _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
        _jsxDEV('div', { className: "flex items-center gap-2 min-w-0"   , children: [
          _jsxDEV('div', { className: "w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"       , children: 
            _jsxDEV(MessageSquare, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 215}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 214}, this)
          , _jsxDEV('div', { className: "min-w-0", children: [
            _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "پیام‌ها و پیام‌رسانی"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 218}, this)
            , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "ارتباط با صرافی شما"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 219}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 217}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 213}, this)
        , _jsxDEV('div', { className: "flex items-center gap-1.5 shrink-0"   , children: 
          _jsxDEV(Button, { variant: "ghost", size: "icon", className: "h-8 w-8" , onClick: () => navigate('/customer'), children: 
            _jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 224}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 222}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 212}, this)

      /* Customer Info */
      , _jsxDEV(Card, { className: "shadow-sm", children: 
        _jsxDEV(CardContent, { className: "p-3", children: 
          _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "نام مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 234}, this)
              , _jsxDEV('p', { className: "text-xs font-medium text-foreground"  , children: _optionalChain([profile, 'optionalAccess', _11 => _11.customer_name]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 235}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 233}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "کد مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 238}, this)
              , _jsxDEV('p', { className: "text-xs font-mono text-foreground"  , children: _optionalChain([profile, 'optionalAccess', _12 => _12.customer_code]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 239}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 237}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "نام صرافی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 242}, this)
              , _jsxDEV('p', { className: "text-xs font-medium text-foreground"  , children: _optionalChain([profile, 'optionalAccess', _13 => _13.exchange_name]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 243}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 241}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "پیام‌های خوانده‌نشده" }, void 0, false, {fileName: _jsxFileName, lineNumber: 246}, this)
              , _jsxDEV('p', { className: `text-xs font-bold ${totalUnread > 0 ? 'text-primary' : 'text-muted-foreground'}`, children: totalUnread}, void 0, false, {fileName: _jsxFileName, lineNumber: 247}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 245}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 232}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 231}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 230}, this)

      /* Search */
      , _jsxDEV('div', { className: "relative", children: [
        _jsxDEV(Search, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 255}, this )
        , _jsxDEV(Input, {
          placeholder: "جستجو در گفتگوها..."  ,
          value: search,
          onChange: (e) => setSearch(e.target.value),
          className: "text-xs pr-9" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 256}, this
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 254}, this)

      /* Conversations List */
      , filteredConversations.length === 0 ? (
        _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-6 text-center text-sm text-muted-foreground"   , children: 
            conversations.length === 0
              ? 'هنوز گفتگویی برای شما ایجاد نشده است.'
              : 'گفتگویی با این عبارت یافت نشد'
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 267}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 266}, this)
      ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          filteredConversations.map((conv) => {
            const time = new Date(conv.last_message_time);
            return (
              _jsxDEV(Card, { className: "shadow-sm cursor-pointer hover:shadow-md transition-shadow"   , onClick: () => setActiveConvId(conv.id), children: 
                _jsxDEV(CardContent, { className: "p-3 flex items-center gap-3"   , children: [
                  _jsxDEV('div', { className: "w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0"       , children: 
                    _jsxDEV(MessageSquare, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 281}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 280}, this)
                  , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
                    _jsxDEV('div', { className: "flex items-center justify-between gap-2"   , children: [
                      _jsxDEV('p', { className: "text-xs font-bold text-foreground truncate"   , children: conv.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 285}, this)
                      , _jsxDEV('span', { className: "text-[9px] text-muted-foreground shrink-0"  , children: [
                        time.toLocaleDateString('fa-IR'), " " , time.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 286}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 284}, this)
                    , _jsxDEV('div', { className: "flex items-center justify-between gap-2"   , children: [
                      _jsxDEV('p', { className: `text-[10px] truncate ${conv.unread_count > 0 ? 'text-foreground font-medium' : 'text-muted-foreground'}`, children: 
                        conv.last_message
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 291}, this)
                      , conv.unread_count > 0 && (
                        _jsxDEV('span', { className: "inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full bg-primary text-primary-foreground text-[9px] font-bold shrink-0"           , children: 
                          conv.unread_count
                        }, void 0, false, {fileName: _jsxFileName, lineNumber: 295}, this)
                      )
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 290}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 283}, this)
                  , _jsxDEV(ChevronLeft, { className: "w-4 h-4 text-muted-foreground shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 301}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 279}, this)
              }, conv.id, false, {fileName: _jsxFileName, lineNumber: 278}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 274}, this)
      )

      /* Quick Links */
      , _jsxDEV('div', { className: "grid grid-cols-3 gap-2"  , children: [
        _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/wallet'), children: [
          _jsxDEV(Wallet, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 312}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "کیف پول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 313}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 311}, this)
        , _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/account'), children: [
          _jsxDEV(Landmark, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 316}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "حساب من" }, void 0, false, {fileName: _jsxFileName, lineNumber: 317}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 315}, this)
        , _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/orders'), children: [
          _jsxDEV(Package, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 320}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "سفارش‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 321}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 319}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 310}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 210}, this)
  );
}