const _jsxFileName = "src/pages/customer/CustomerAccount.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext.js';
import {
  loadAccountProfile, loadAccountBalances, loadTransactions,
} from '../../lib/accountMockData.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { Button } from '../../components/ui/button.js';
import { Skeleton } from '../../components/ui/skeleton.js';
import {
  Landmark, Wallet, Package, MessageSquare, ArrowRight,
  RefreshCw, ShieldCheck,
} from 'lucide-react';
import AccountSummary from '../../components/customer/account/AccountSummary.js';
import TransactionHistory from '../../components/customer/account/TransactionHistory.js';

const STATUS_LABELS = {
  active: { label: 'فعال', color: 'bg-success/10 text-success' },
  suspended: { label: 'معلق', color: 'bg-destructive/10 text-destructive' },
  inactive: { label: 'غیرفعال', color: 'bg-muted text-muted-foreground' },
};

export default function CustomerAccount() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [balances, setBalances] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const [prof, bals, txns] = await Promise.all([
        loadAccountProfile(user), loadAccountBalances(_optionalChain([user, 'optionalAccess', _ => _.id])), loadTransactions(_optionalChain([user, 'optionalAccess', _2 => _2.id])),
      ]);
      setProfile(prof);
      setBalances(bals);
      setTransactions(txns);
    } catch (e) {
      setError(true);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  if (loading) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this )
        , _jsxDEV(Skeleton, { className: "h-24 w-full rounded-xl"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this )
        , _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 57}, this )
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: 
          [1, 2, 3, 4].map((i) => _jsxDEV(Skeleton, { className: "h-32 rounded-xl" ,}, i, false, {fileName: _jsxFileName, lineNumber: 59}, this ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this)
        , _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this )
        , _jsxDEV('div', { className: "space-y-2", children: 
          [1, 2, 3].map((i) => _jsxDEV(Skeleton, { className: "h-16 rounded-xl" ,}, i, false, {fileName: _jsxFileName, lineNumber: 63}, this ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 54}, this)
    );
  }

  if (error) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "حساب من با صراف"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this)
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-8 text-center space-y-4"  , children: [
            _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "دریافت اطلاعات با مشکل مواجه شد."     }, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
            , _jsxDEV(Button, { onClick: loadData, variant: "outline", size: "sm", children: [
              _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this ), "تلاش مجدد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 76}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 74}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 71}, this)
    );
  }

  const st = STATUS_LABELS[_optionalChain([profile, 'optionalAccess', _3 => _3.account_status])] || STATUS_LABELS.active;

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      /* Header */
      _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
        _jsxDEV('div', { className: "flex items-center gap-2 min-w-0"   , children: [
          _jsxDEV('div', { className: "w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"       , children: 
            _jsxDEV(Landmark, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this)
          , _jsxDEV('div', { className: "min-w-0", children: [
            _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "حساب من با صراف"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)
            , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "وضعیت مالی شما با صرافی"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 96}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 92}, this)
        , _jsxDEV('div', { className: "flex items-center gap-1.5 shrink-0"   , children: 
          _jsxDEV(Button, { variant: "ghost", size: "icon", className: "h-8 w-8" , onClick: () => navigate('/customer'), children: 
            _jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 91}, this)

      /* Customer & Exchange Info */
      , _jsxDEV(Card, { className: "shadow-sm", children: 
        _jsxDEV(CardContent, { className: "p-3 space-y-2" , children: [
          _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "نام مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this)
              , _jsxDEV('p', { className: "text-xs font-medium text-foreground"  , children: _optionalChain([profile, 'optionalAccess', _4 => _4.customer_name]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 112}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "کد مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 117}, this)
              , _jsxDEV('p', { className: "text-xs font-mono text-foreground"  , children: _optionalChain([profile, 'optionalAccess', _5 => _5.customer_code]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 116}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "نام صرافی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this)
              , _jsxDEV('p', { className: "text-xs font-medium text-foreground"  , children: _optionalChain([profile, 'optionalAccess', _6 => _6.exchange_name]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 120}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "کد صرافی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this)
              , _jsxDEV('p', { className: "text-xs font-mono text-foreground"  , children: _optionalChain([profile, 'optionalAccess', _7 => _7.exchange_code]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 124}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 111}, this)
          , _jsxDEV('div', { className: "flex items-center justify-between pt-2 border-t border-border"     , children: [
            _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: "وضعیت حساب:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)
            , _jsxDEV('span', { className: `inline-flex items-center gap-1 px-2 py-0.5 rounded text-[9px] font-medium ${st.color}`, children: [
              _jsxDEV(ShieldCheck, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 132}, this )
              , st.label
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 131}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 129}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 110}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this)

      /* Account Summary */
      , _jsxDEV(AccountSummary, { balances: balances, lastUpdated: _optionalChain([profile, 'optionalAccess', _8 => _8.last_updated]),}, void 0, false, {fileName: _jsxFileName, lineNumber: 140}, this )

      /* Transaction History */
      , _jsxDEV(TransactionHistory, { transactions: transactions,}, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this )

      /* Quick Links */
      , _jsxDEV('div', { className: "grid grid-cols-3 gap-2"  , children: [
        _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/wallet'), children: [
          _jsxDEV(Wallet, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "کیف پول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
        , _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/orders'), children: [
          _jsxDEV(Package, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 152}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "سفارش‌های من" }, void 0, false, {fileName: _jsxFileName, lineNumber: 153}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 151}, this)
        , _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/messages'), children: [
          _jsxDEV(MessageSquare, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "پیام‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 155}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 146}, this)

      /* Info Note */
      , _jsxDEV('div', { className: "rounded-xl bg-muted/50 p-3 text-center"   , children: 
        _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "این اطلاعات توسط صراف شما ثبت و به‌روزرسانی می‌شود. شما فقط اطلاعات حساب خودتان را مشاهده می‌کنید."

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 162}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 89}, this)
  );
}