const _jsxFileName = "src/pages/customer/CustomerNotifications.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext.js';
import {
  loadNotifications, markNotificationRead, markAllNotificationsRead,
} from '../../lib/notificationsMockData.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { Button } from '../../components/ui/button.js';
import { Input } from '../../components/ui/input.js';
import { Skeleton } from '../../components/ui/skeleton.js';
import {
  Bell, Package, Landmark, Wallet, ArrowRightLeft, MessageSquare,
  Megaphone, ShieldCheck, Info, ArrowRight, RefreshCw, Search, X, CheckCheck,
} from 'lucide-react';

const TYPE_META = {
  order: { label: 'سفارش', icon: Package, color: 'bg-blue-100 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400' },
  account: { label: 'حساب', icon: Landmark, color: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/30 dark:text-cyan-400' },
  wallet: { label: 'کیف پول', icon: Wallet, color: 'bg-success/15 text-success' },
  transaction: { label: 'تراکنش', icon: ArrowRightLeft, color: 'bg-purple-100 text-purple-700 dark:bg-purple-950/30 dark:text-purple-400' },
  message: { label: 'پیام', icon: MessageSquare, color: 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400' },
  announcement: { label: 'اطلاعیه', icon: Megaphone, color: 'bg-pink-100 text-pink-700 dark:bg-pink-950/30 dark:text-pink-400' },
  security: { label: 'امنیت', icon: ShieldCheck, color: 'bg-destructive/15 text-destructive' },
  general: { label: 'عمومی', icon: Info, color: 'bg-muted text-muted-foreground' },
};

const READ_FILTERS = [
  { value: 'all', label: 'همه' },
  { value: 'unread', label: 'خوانده‌نشده' },
  { value: 'read', label: 'خوانده‌شده' },
];

const TYPE_FILTERS = [
  { value: 'all', label: 'همه نوع‌ها' },
  { value: 'order', label: 'سفارش' },
  { value: 'account', label: 'حساب' },
  { value: 'wallet', label: 'کیف پول' },
  { value: 'transaction', label: 'تراکنش' },
  { value: 'message', label: 'پیام' },
  { value: 'security', label: 'امنیت' },
  { value: 'announcement', label: 'اطلاعیه' },
];

export default function CustomerNotifications() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const userId = _optionalChain([user, 'optionalAccess', _ => _.id]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [search, setSearch] = useState('');
  const [readFilter, setReadFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [markingAll, setMarkingAll] = useState(false);

  const loadData = useCallback(async () => {
    if (!userId) return;
    setLoading(true);
    setError(false);
    try {
      const list = await loadNotifications(userId);
      setNotifications(list);
    } catch (e) {
      setError(true);
    }
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const unreadCount = useMemo(() => notifications.filter((n) => !n.read).length, [notifications]);

  const filtered = useMemo(() => {
    return notifications.filter((n) => {
      if (readFilter === 'unread' && n.read) return false;
      if (readFilter === 'read' && !n.read) return false;
      if (typeFilter !== 'all' && n.type !== typeFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        const meta = TYPE_META[n.type] || TYPE_META.general;
        const haystack = `${n.title || ''} ${n.body || ''} ${meta.label}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [notifications, readFilter, typeFilter, search]);

  const hasActiveFilters = search || readFilter !== 'all' || typeFilter !== 'all';

  const clearAllFilters = () => {
    setSearch('');
    setReadFilter('all');
    setTypeFilter('all');
  };

  const handleOpenNotification = async (notif) => {
    if (!notif.read) {
      await markNotificationRead(notif.id);
      setNotifications((prev) => prev.map((n) => n.id === notif.id ? { ...n, read: true } : n));
    }
    if (notif.link) {
      navigate(notif.link);
    }
  };

  const handleMarkAllRead = async () => {
    setMarkingAll(true);
    await markAllNotificationsRead(userId);
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    setMarkingAll(false);
  };

  if (loading) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this )
        , _jsxDEV(Skeleton, { className: "h-20 w-full rounded-xl"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this )
        , _jsxDEV(Skeleton, { className: "h-8 w-full rounded-lg"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this )
        , _jsxDEV('div', { className: "space-y-2", children: 
          [1, 2, 3, 4].map((i) => _jsxDEV(Skeleton, { className: "h-16 rounded-xl" ,}, i, false, {fileName: _jsxFileName, lineNumber: 122}, this ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 117}, this)
    );
  }

  if (error) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "اعلان‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this)
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-8 text-center space-y-!4"  , children: [
            _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "دریافت اطلاعات با مشکل مواجه شد."     }, void 0, false, {fileName: _jsxFileName, lineNumber: 134}, this)
            , _jsxDEV(Button, { onClick: loadData, variant: "outline", size: "sm", children: [
              _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this ), "تلاش مجدد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 135}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 133}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 132}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 130}, this)
    );
  }

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      /* Header */
      _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
        _jsxDEV('div', { className: "flex items-center gap-2 min-w-0"   , children: [
          _jsxDEV('div', { className: "w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 relative"        , children: [
            _jsxDEV(Bell, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this )
            , unreadCount > 0 && (
              _jsxDEV('span', { className: "absolute -top-1 -right-1 inline-flex items-center justify-center min-w-[16px] h-4 px-1 rounded-full bg-destructive text-destructive-foreground text-[8px] font-bold"             , children: 
                unreadCount
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 153}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 150}, this)
          , _jsxDEV('div', { className: "min-w-0", children: [
            _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "اعلان‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this)
            , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "اطلاعیه‌ها و اعلان‌های حساب شما"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 158}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 149}, this)
        , _jsxDEV(Button, { variant: "ghost", size: "icon", className: "h-8 w-8 shrink-0"  , onClick: () => navigate('/customer'), children: 
          _jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 164}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 148}, this)

      /* Summary & Mark All Read */
      , _jsxDEV(Card, { className: "shadow-sm", children: 
        _jsxDEV(CardContent, { className: "p-3 flex items-center justify-between"   , children: [
          _jsxDEV('div', { children: [
            _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "اعلان‌های خوانده‌نشده" }, void 0, false, {fileName: _jsxFileName, lineNumber: 172}, this)
            , _jsxDEV('p', { className: `text-sm font-bold ${unreadCount > 0 ? 'text-primary' : 'text-muted-foreground'}`, children: unreadCount}, void 0, false, {fileName: _jsxFileName, lineNumber: 173}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 171}, this)
          , _jsxDEV(Button, {
            variant: "outline",
            size: "sm",
            onClick: handleMarkAllRead,
            disabled: unreadCount === 0 || markingAll,
            className: "text-xs",
 children: [
            markingAll ? _jsxDEV(RefreshCw, { className: "w-3.5 h-3.5 ml-1.5 animate-spin"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this ) : _jsxDEV(CheckCheck, { className: "w-3.5 h-3.5 ml-1.5"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this ), "همه را خوانده‌شده کن"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 175}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 170}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 169}, this)

      /* Search */
      , _jsxDEV('div', { className: "relative", children: [
        _jsxDEV(Search, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 190}, this )
        , _jsxDEV(Input, {
          placeholder: "جستجو در اعلان‌ها..."  ,
          value: search,
          onChange: (e) => setSearch(e.target.value),
          className: "text-xs pr-9" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 191}, this
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 189}, this)

      /* Filters */
      , _jsxDEV('div', { className: "space-y-2", children: [
        _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          READ_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setReadFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                readFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 203}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 201}, this)
        , _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          TYPE_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setTypeFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                typeFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 216}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 214}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 200}, this)

      /* Clear Filters */
      , hasActiveFilters && (
        _jsxDEV('button', { onClick: clearAllFilters, className: "text-[10px] text-destructive flex items-center gap-1"    , children: [
          _jsxDEV(X, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 232}, this ), "پاک کردن فیلترها"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 231}, this)
      )

      /* Notifications List */
      , filtered.length === 0 ? (
        _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-6 text-center text-sm text-muted-foreground"   , children: 
            notifications.length === 0
              ? 'در حال حاضر اعلان جدیدی برای شما وجود ندارد.'
              : 'اعلانی با این فیلترها یافت نشد'
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 240}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 239}, this)
      ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          filtered.map((notif) => {
            const meta = TYPE_META[notif.type] || TYPE_META.general;
            const TypeIcon = meta.icon;
            const date = new Date(notif.timestamp);
            return (
              _jsxDEV(Card, {

                className: `shadow-sm cursor-pointer hover:shadow-md transition-shadow ${!notif.read ? 'border-primary/30 bg-primary/5' : ''}`,
                onClick: () => handleOpenNotification(notif),
 children: 
                _jsxDEV(CardContent, { className: "p-3 flex items-start gap-3"   , children: [
                  _jsxDEV('div', { className: `w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${meta.color}`, children: 
                    _jsxDEV(TypeIcon, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 260}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 259}, this)
                  , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
                    _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                      _jsxDEV('p', { className: `text-xs truncate ${!notif.read ? 'font-bold text-foreground' : 'font-medium text-foreground'}`, children: 
                        notif.title
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 264}, this)
                      , !notif.read && _jsxDEV('span', { className: "w-2 h-2 rounded-full bg-primary shrink-0"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 267}, this )
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 263}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground line-clamp-2 mt-0.5"   , children: notif.body}, void 0, false, {fileName: _jsxFileName, lineNumber: 269}, this)
                    , _jsxDEV('div', { className: "flex items-center justify-between gap-2 mt-1"    , children: [
                      _jsxDEV('span', { className: `text-[8px] px-1.5 py-0.5 rounded ${meta.color}`, children: meta.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 271}, this)
                      , _jsxDEV('span', { className: "text-[9px] text-muted-foreground" , children: [
                        date.toLocaleDateString('fa-IR'), " " , date.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 272}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 270}, this)
                    , notif.link && (
                      _jsxDEV('p', { className: "text-[9px] text-primary mt-1 flex items-center gap-0.5"     , children: ["مشاهده جزئیات"

                        , _jsxDEV(ArrowRight, { className: "w-2.5 h-2.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 279}, this )
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 277}, this)
                    )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 262}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 258}, this)
              }, notif.id, false, {fileName: _jsxFileName, lineNumber: 253}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 247}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 146}, this)
  );
}