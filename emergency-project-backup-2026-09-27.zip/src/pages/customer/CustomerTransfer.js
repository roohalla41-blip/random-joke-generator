const _jsxFileName = "src/pages/customer/CustomerTransfer.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext.js';
import {
  loadWallets, loadDestinations, loadCountries, loadTransferMethods,
  loadMyRequests, calcFee, submitRequest, loadDraft, saveDraft, clearDraft,
} from '../../lib/transferMockData.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { Button } from '../../components/ui/button.js';
import { Input } from '../../components/ui/input.js';
import { Label } from '../../components/ui/label.js';
import { Skeleton } from '../../components/ui/skeleton.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select.js';
import {
  Send, Wallet, Package, AlertTriangle, RefreshCw,
  ArrowRight, Hash, Loader2, CheckCircle, XCircle,
} from 'lucide-react';
import { offlineDB } from '../../lib/offlineQueue.js';
import ConfirmDialog from '../../components/customer/transfer/ConfirmDialog.js';
import { AmountInput } from '../../components/sarraaf/Fields.js';
import SuccessSheet from '../../components/customer/transfer/SuccessSheet.js';
import TransferHistory from '../../components/customer/transfer/TransferHistory.js';

const WALLET_LABELS = {
  AFN: 'افغانی (AFN)',
  USD: 'دلار (USD)',
  IRT: 'تومان (IRT)',
  USDT: 'تتر (USDT)',
};

export default function CustomerTransfer() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [wallets, setWallets] = useState([]);
  const [destinations, setDestinations] = useState([]);
  const [countries, setCountries] = useState([]);
  const [methods, setMethods] = useState([]);
  const [transfers, setTransfers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  // Form state
  const [walletCurrency, setWalletCurrency] = useState('AFN');
  const [amount, setAmount] = useState(0);
  const [receiverName, setReceiverName] = useState('');
  const [receiverPhone, setReceiverPhone] = useState('');
  const [receiverCode, setReceiverCode] = useState('');
  const [destinationType, setDestinationType] = useState('');
  const [destinationCountry, setDestinationCountry] = useState('');
  const [transferMethod, setTransferMethod] = useState('');
  const [description, setDescription] = useState('');
  const [sarraafCode, setSarraafCode] = useState('');
  const [sarraafValid, setSarraafValid] = useState(null);
  const [sarraafChecking, setSarraafChecking] = useState(false);
  const [errors, setErrors] = useState({});
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [successRequest, setSuccessRequest] = useState(null);
  const [successOpen, setSuccessOpen] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const [wals, dests, ctries, meths] = await Promise.all([
        loadWallets(_optionalChain([user, 'optionalAccess', _ => _.id])), loadDestinations(), loadCountries(), loadTransferMethods(),
      ]);
      setWallets(wals);
      setDestinations(dests);
      setCountries(ctries);
      setMethods(meths);
      const draft = loadDraft();
      if (draft) {
        if (draft.walletCurrency) setWalletCurrency(draft.walletCurrency);
        if (draft.amount) setAmount(draft.amount);
        if (draft.receiverName) setReceiverName(draft.receiverName);
        if (draft.receiverPhone) setReceiverPhone(draft.receiverPhone);
        if (draft.receiverCode) setReceiverCode(draft.receiverCode);
        if (draft.destinationType) setDestinationType(draft.destinationType);
        if (draft.destinationCountry) setDestinationCountry(draft.destinationCountry);
        if (draft.transferMethod) setTransferMethod(draft.transferMethod);
        if (draft.description) setDescription(draft.description);
      }
      // Load existing transfers
      const reqs = await loadMyRequests(_optionalChain([user, 'optionalAccess', _2 => _2.id]) || 'demo-customer');
      setTransfers(reqs);
    } catch (e) {
      setError(true);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Save draft
  useEffect(() => {
    saveDraft({
      walletCurrency, amount, receiverName, receiverPhone, receiverCode,
      destinationType, destinationCountry, transferMethod, description, sarraafCode,
    });
  }, [walletCurrency, amount, receiverName, receiverPhone, receiverCode, destinationType, destinationCountry, transferMethod, description, sarraafCode]);

  // Validate sarraaf code
  useEffect(() => {
    if (!sarraafCode || sarraafCode.trim().length < 3) {
      setSarraafValid(null);
      return;
    }
    const timer = setTimeout(async () => {
      setSarraafChecking(true);
      try {
        const profiles = await offlineDB.SarraafProfile.filter({ code: sarraafCode.trim() });
        setSarraafValid(profiles && profiles.length > 0);
      } catch (e2) {
        setSarraafValid(false);
      }
      setSarraafChecking(false);
    }, 500);
    return () => clearTimeout(timer);
  }, [sarraafCode]);

  const selectedWallet = wallets.find((w) => w.currency === walletCurrency);
  const numAmount = parseFloat(amount) || 0;
  const fee = numAmount > 0 ? calcFee(numAmount, walletCurrency) : 0;
  const totalAmount = numAmount + fee;
  const balanceAfter = (_optionalChain([selectedWallet, 'optionalAccess', _3 => _3.balance]) || 0) - totalAmount;
  const insufficientBalance = selectedWallet && numAmount > 0 && (selectedWallet.balance || 0) < totalAmount;

  const validate = () => {
    const errs = {};
    if (!walletCurrency) errs.walletCurrency = 'کیف پول پرداخت را انتخاب کنید.';
    if (!amount || numAmount <= 0) errs.amount = 'مبلغ انتقال معتبر وارد کنید.';
    if (!_optionalChain([receiverName, 'optionalAccess', _4 => _4.trim, 'call', _5 => _5()])) errs.receiverName = 'نام گیرنده را وارد کنید.';
    if (receiverPhone && !/^[0-9+\-\s]{7,15}$/.test(receiverPhone.replace(/\s/g, ''))) {
      errs.receiverPhone = 'فرمت شماره موبایل معتبر نیست.';
    }
    if (!destinationType) errs.destinationType = 'مقصد را انتخاب کنید.';
    if (!_optionalChain([sarraafCode, 'optionalAccess', _6 => _6.trim, 'call', _7 => _7()])) errs.sarraafCode = 'کد صراف اجباری است.';
    else if (sarraafValid === false) errs.sarraafCode = 'کد صراف معتبر نیست.';
    if (insufficientBalance) errs.balance = 'موجودی کیف پول برای انجام این انتقال کافی نیست.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleOpenConfirm = () => {
    if (!validate()) return;
    setConfirmOpen(true);
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const dest = destinations.find((d) => d.code === destinationType);
      const result = await submitRequest({
        user_id: _optionalChain([user, 'optionalAccess', _8 => _8.id]) || 'demo-customer',
        user_name: _optionalChain([user, 'optionalAccess', _9 => _9.full_name]) || 'مشتری',
        sarraaf_code: sarraafCode,
        receiver_name: receiverName,
        receiver_phone: receiverPhone,
        receiver_code: receiverCode,
        destination_type: destinationType,
        destination_type_name: _optionalChain([dest, 'optionalAccess', _10 => _10.name]) || '',
        destination_country: destinationCountry,
        transfer_method: transferMethod,
        currency: walletCurrency,
        wallet_currency: walletCurrency,
        amount: numAmount,
        wallet_balance: _optionalChain([selectedWallet, 'optionalAccess', _11 => _11.balance]) || 0,
        description,
      });
      setSuccessRequest(result);
      setSuccessOpen(true);
      setConfirmOpen(false);
      clearDraft();
      // Reset form
      setAmount(0);
      setReceiverName('');
      setReceiverPhone('');
      setReceiverCode('');
      setSarraafCode('');
      setDestinationType('');
      setDestinationCountry('');
      setTransferMethod('');
      setDescription('');
      // Reload transfers
      const reqs = await loadMyRequests(_optionalChain([user, 'optionalAccess', _12 => _12.id]) || 'demo-customer');
      setTransfers(reqs);
    } catch (e) {
      const msg = _optionalChain([e, 'optionalAccess', _13 => _13.message]) === 'insufficient_balance' ? 'موجودی کافی نیست'
        : _optionalChain([e, 'optionalAccess', _14 => _14.message]) === 'wallet_not_found' ? 'کیف پول یافت نشد'
        : 'خطا در ثبت انتقال';
      setErrors({ submit: msg });
    }
    setSubmitting(false);
  };

  if (loading) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 202}, this )
        , _jsxDEV(Skeleton, { className: "h-48 w-full rounded-xl"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 203}, this )
        , _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 204}, this )
        , _jsxDEV('div', { className: "space-y-2", children: 
          [1, 2, 3].map((i) => _jsxDEV(Skeleton, { className: "h-16 rounded-xl" ,}, i, false, {fileName: _jsxFileName, lineNumber: 206}, this ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 205}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 201}, this)
    );
  }

  if (error) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "انتقال وجه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 215}, this)
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-8 text-center space-y-4"  , children: [
            _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "دریافت اطلاعات با مشکل مواجه شد."     }, void 0, false, {fileName: _jsxFileName, lineNumber: 218}, this)
            , _jsxDEV(Button, { onClick: loadData, variant: "outline", size: "sm", children: [
              _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 220}, this ), "تلاش مجدد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 219}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 217}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 216}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 214}, this)
    );
  }

  const confirmData = {
    sender_name: _optionalChain([user, 'optionalAccess', _15 => _15.full_name]) || 'مشتری',
    receiver_name: receiverName,
    receiver_phone: receiverPhone,
    currency: walletCurrency,
    wallet_currency: walletCurrency,
    amount: numAmount,
    fee,
    total_amount: totalAmount,
    wallet_balance: _optionalChain([selectedWallet, 'optionalAccess', _16 => _16.balance]) || 0,
    balance_after: balanceAfter,
    destination_type_name: _optionalChain([destinations, 'access', _17 => _17.find, 'call', _18 => _18((d) => d.code === destinationType), 'optionalAccess', _19 => _19.name]) || '',
    destination_country: destinationCountry,
    transfer_method: transferMethod,
    description,
  };

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      /* Header */
      _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
        _jsxDEV('div', { className: "min-w-0", children: [
          _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "انتقال وجه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 251}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "ثبت درخواست انتقال وجه و پیگیری"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 252}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 250}, this)
        , _jsxDEV(Button, { variant: "ghost", size: "icon", className: "h-8 w-8 shrink-0"  , onClick: () => navigate('/customer'), children: 
          _jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 255}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 254}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 249}, this)

      /* Transfer Form */
      , _jsxDEV(Card, { className: "shadow-sm", children: 
        _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
          /* Wallet Selection */
          _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "کیف پول پرداخت"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 264}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 md:grid-cols-4 gap-2 mt-1"    , children: 
              wallets.map((w) => (
                _jsxDEV('button', {

                  onClick: () => { setWalletCurrency(w.currency); setErrors({}); },
                  className: `p-2.5 rounded-lg border text-center transition-all ${walletCurrency === w.currency ? 'border-primary bg-primary/5' : 'border-border'}`,
 children: [
                  _jsxDEV(Wallet, { className: "w-4 h-4 mx-auto mb-1 text-muted-foreground"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 272}, this )
                  , _jsxDEV('p', { className: "text-[10px] font-bold text-foreground"  , children: w.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 273}, this)
                  , _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: (w.balance || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 274}, this)
                ]}, w.currency, true, {fileName: _jsxFileName, lineNumber: 267}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 265}, this)
            , errors.walletCurrency && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.walletCurrency}, void 0, false, {fileName: _jsxFileName, lineNumber: 278}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 263}, this)

          /* Amount */
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "مبلغ انتقال" }, void 0, false, {fileName: _jsxFileName, lineNumber: 283}, this)
            , _jsxDEV(AmountInput, { value: amount, onChange: (v) => { setAmount(v); setErrors({}); }, placeholder: "0",}, void 0, false, {fileName: _jsxFileName, lineNumber: 284}, this )
            , errors.amount && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.amount}, void 0, false, {fileName: _jsxFileName, lineNumber: 285}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 282}, this)

          /* Calculation Summary */
          , numAmount > 0 && (
            _jsxDEV(Card, { className: "bg-muted/30 border-border" , children: 
              _jsxDEV(CardContent, { className: "p-3 space-y-1.5" , children: [
                _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ انتقال:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 293}, this)
                  , _jsxDEV('span', { className: "text-foreground", children: [numAmount.toLocaleString('fa-IR'), " " , walletCurrency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 294}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 292}, this)
                , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "کارمزد:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 297}, this)
                  , _jsxDEV('span', { className: "text-foreground", children: [fee.toLocaleString('fa-IR'), " " , walletCurrency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 298}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 296}, this)
                , _jsxDEV('div', { className: "flex justify-between text-xs pt-1.5 border-t border-border"     , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ نهایی:" }, void 0, false, {fileName: _jsxFileName, lineNumber: 301}, this)
                  , _jsxDEV('span', { className: "font-bold text-primary" , children: [totalAmount.toLocaleString('fa-IR'), " " , walletCurrency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 302}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 300}, this)
                , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "موجودی کیف پول:"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 305}, this)
                  , _jsxDEV('span', { className: "text-foreground", children: (_optionalChain([selectedWallet, 'optionalAccess', _20 => _20.balance]) || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 306}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 304}, this)
                , _jsxDEV('div', { className: "flex justify-between text-xs"  , children: [
                  _jsxDEV('span', { className: "text-muted-foreground", children: "موجودی بعد از انتقال:"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 309}, this)
                  , _jsxDEV('span', { className: `font-medium ${balanceAfter < 0 ? 'text-destructive' : 'text-foreground'}`, children: balanceAfter.toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 310}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 308}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 291}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 290}, this)
          )

          /* Sarraaf Code */
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "کد صراف (اجباری)"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 318}, this)
            , _jsxDEV('div', { className: "relative mt-1" , children: [
              _jsxDEV(Hash, { className: "absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 320}, this )
              , _jsxDEV(Input, {
                placeholder: "کد صراف مقصد را وارد کنید"     ,
                value: sarraafCode,
                onChange: (e) => { setSarraafCode(e.target.value); setErrors({}); },
                dir: "ltr",
                className: "text-sm pr-8" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 321}, this
              )
              , sarraafChecking && _jsxDEV(Loader2, { className: "absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground animate-spin"       ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 328}, this )
              , !sarraafChecking && sarraafValid === true && _jsxDEV(CheckCircle, { className: "absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-success"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 329}, this )
              , !sarraafChecking && sarraafValid === false && _jsxDEV(XCircle, { className: "absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-destructive"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 330}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 319}, this)
            , errors.sarraafCode && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.sarraafCode}, void 0, false, {fileName: _jsxFileName, lineNumber: 332}, this)
            , sarraafValid === true && _jsxDEV('p', { className: "text-[10px] text-success mt-1"  , children: "کد صراف تأیید شد"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 333}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 317}, this)

          /* Destination Type */
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "مقصد"}, void 0, false, {fileName: _jsxFileName, lineNumber: 338}, this)
            , _jsxDEV('div', { className: "flex flex-wrap gap-2 mt-1"   , children: 
              destinations.map((d) => (
                _jsxDEV('button', {

                  onClick: () => { setDestinationType(d.code); setErrors({}); },
                  className: `px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${destinationType === d.code ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'}`,
 children: 
                  d.name
                }, d.code, false, {fileName: _jsxFileName, lineNumber: 341}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 339}, this)
            , errors.destinationType && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.destinationType}, void 0, false, {fileName: _jsxFileName, lineNumber: 350}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 337}, this)

          /* Receiver Info */
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "نام گیرنده" }, void 0, false, {fileName: _jsxFileName, lineNumber: 355}, this)
            , _jsxDEV(Input, {
              placeholder: "نام کامل گیرنده"  ,
              value: receiverName,
              onChange: (e) => { setReceiverName(e.target.value); setErrors({}); },
              className: "text-sm mt-1" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 356}, this
            )
            , errors.receiverName && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.receiverName}, void 0, false, {fileName: _jsxFileName, lineNumber: 362}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 354}, this)

          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "شماره موبایل گیرنده"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 366}, this)
            , _jsxDEV(Input, {
              placeholder: "07XXXXXXXXX",
              value: receiverPhone,
              onChange: (e) => { setReceiverPhone(e.target.value); setErrors({}); },
              dir: "ltr",
              className: "text-sm mt-1" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 367}, this
            )
            , errors.receiverPhone && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.receiverPhone}, void 0, false, {fileName: _jsxFileName, lineNumber: 374}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 365}, this)

          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "کد مشتری / شناسه گیرنده (اختیاری)"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 378}, this)
            , _jsxDEV(Input, {
              placeholder: "کد یا شناسه"  ,
              value: receiverCode,
              onChange: (e) => setReceiverCode(e.target.value),
              dir: "ltr",
              className: "text-sm mt-1" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 379}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 377}, this)

          /* Country */
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "کشور / مقصد (اختیاری)"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 390}, this)
            , _jsxDEV(Select, { value: destinationCountry || 'none', onValueChange: (v) => setDestinationCountry(v === 'none' ? '' : v), children: [
              _jsxDEV(SelectTrigger, { className: "mt-1", children: _jsxDEV(SelectValue, { placeholder: "انتخاب کنید..." ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 392}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 392}, this)
              , _jsxDEV(SelectContent, { children: [
                _jsxDEV(SelectItem, { value: "none", children: "انتخاب کنید..." }, void 0, false, {fileName: _jsxFileName, lineNumber: 394}, this)
                , countries.map((c) => _jsxDEV(SelectItem, { value: c, children: c}, c, false, {fileName: _jsxFileName, lineNumber: 395}, this))
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 393}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 391}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 389}, this)

          /* Transfer Method */
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "روش انتقال (اختیاری)"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 402}, this)
            , _jsxDEV(Select, { value: transferMethod || 'none', onValueChange: (v) => setTransferMethod(v === 'none' ? '' : v), children: [
              _jsxDEV(SelectTrigger, { className: "mt-1", children: _jsxDEV(SelectValue, { placeholder: "انتخاب کنید..." ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 404}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 404}, this)
              , _jsxDEV(SelectContent, { children: [
                _jsxDEV(SelectItem, { value: "none", children: "انتخاب کنید..." }, void 0, false, {fileName: _jsxFileName, lineNumber: 406}, this)
                , methods.map((m) => _jsxDEV(SelectItem, { value: m, children: m}, m, false, {fileName: _jsxFileName, lineNumber: 407}, this))
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 405}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 403}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 401}, this)

          /* Description */
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "توضیحات (اختیاری)" }, void 0, false, {fileName: _jsxFileName, lineNumber: 414}, this)
            , _jsxDEV(Input, {
              placeholder: "توضیحات...",
              value: description,
              onChange: (e) => setDescription(e.target.value),
              className: "text-sm mt-1" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 415}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 413}, this)

          /* Insufficient Balance */
          , insufficientBalance && (
            _jsxDEV(Card, { className: "border-destructive/30 bg-destructive/5" , children: 
              _jsxDEV(CardContent, { className: "p-3 flex items-center gap-2"   , children: [
                _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-destructive shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 427}, this )
                , _jsxDEV('p', { className: "text-xs text-destructive font-medium"  , children: "موجودی کیف پول برای انجام این انتقال کافی نیست."

                }, void 0, false, {fileName: _jsxFileName, lineNumber: 428}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 426}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 425}, this)
          )

          /* Submit */
          , _jsxDEV(Button, { onClick: handleOpenConfirm, className: "w-full", disabled: insufficientBalance || numAmount <= 0, children: [
            _jsxDEV(Send, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 437}, this ), "ادامه و تأیید"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 436}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 261}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 260}, this)

      /* Link to Wallet */
      , _jsxDEV(Button, { variant: "outline", className: "w-full", onClick: () => navigate('/customer/wallet'), children: [
        _jsxDEV(Wallet, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 445}, this ), "کیف پول من"

      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 444}, this)

      /* Transfer History */
      , _jsxDEV(TransferHistory, { transfers: transfers,}, void 0, false, {fileName: _jsxFileName, lineNumber: 450}, this )

      /* Link to Orders */
      , _jsxDEV(Button, { variant: "outline", className: "w-full", onClick: () => navigate('/customer/orders'), children: [
        _jsxDEV(Package, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 454}, this ), "سفارش‌های من"

      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 453}, this)

      /* Confirm Dialog */
      , _jsxDEV(ConfirmDialog, {
        open: confirmOpen,
        onOpenChange: setConfirmOpen,
        data: confirmData,
        onConfirm: handleSubmit,
        submitting: submitting,}, void 0, false, {fileName: _jsxFileName, lineNumber: 459}, this
      )

      /* Success Sheet */
      , _jsxDEV(SuccessSheet, {
        open: successOpen,
        onOpenChange: setSuccessOpen,
        request: successRequest,
        onGoToOrders: () => { setSuccessOpen(false); navigate('/customer/orders'); },}, void 0, false, {fileName: _jsxFileName, lineNumber: 468}, this
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 247}, this)
  );
}