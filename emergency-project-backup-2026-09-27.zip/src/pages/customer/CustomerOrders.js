const _jsxFileName = "src/pages/customer/CustomerOrders.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext.js';
import { loadOrdersProfile, loadOrders } from '../../lib/ordersMockData.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { Button } from '../../components/ui/button.js';
import { Input } from '../../components/ui/input.js';
import { Skeleton } from '../../components/ui/skeleton.js';
import {
  Package, Wallet, Landmark, MessageSquare, ArrowRight,
  RefreshCw, Search, X, Calendar, ChevronLeft,
} from 'lucide-react';
import OrderDetail from '../../components/customer/orders/OrderDetail.js';

const STATUS_LABELS = {
  new: { label: 'جدید', color: 'bg-blue-100 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400' },
  review: { label: 'در حال بررسی', color: 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400' },
  approved: { label: 'تأیید شده', color: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/30 dark:text-cyan-400' },
  processing: { label: 'در حال انجام', color: 'bg-purple-100 text-purple-700 dark:bg-purple-950/30 dark:text-purple-400' },
  completed: { label: 'تکمیل شده', color: 'bg-success/15 text-success' },
  rejected: { label: 'رد شده', color: 'bg-destructive/15 text-destructive' },
  cancelled: { label: 'لغو شده', color: 'bg-muted text-muted-foreground' },
};

const STATUS_FILTERS = [
  { value: 'all', label: 'همه وضعیت‌ها' },
  { value: 'new', label: 'جدید' },
  { value: 'review', label: 'در حال بررسی' },
  { value: 'approved', label: 'تأیید شده' },
  { value: 'processing', label: 'در حال انجام' },
  { value: 'completed', label: 'تکمیل شده' },
  { value: 'rejected', label: 'رد شده' },
  { value: 'cancelled', label: 'لغو شده' },
];

const TYPE_FILTERS = [
  { value: 'all', label: 'همه نوع‌ها' },
  { value: 'mobile_recharge', label: 'شارژ موبایل' },
  { value: 'internet_package', label: 'بسته اینترنت' },
  { value: 'game_service', label: 'خدمات بازی' },
  { value: 'transfer', label: 'انتقال وجه' },
  { value: 'currency_buy', label: 'خرید ارز' },
  { value: 'currency_convert', label: 'تبدیل ارز' },
];

const CURRENCY_FILTERS = [
  { value: 'all', label: 'همه ارزها' },
  { value: 'AFN', label: 'AFN' },
  { value: 'USD', label: 'USD' },
  { value: 'IRT', label: 'تومان' },
  { value: 'USDT', label: 'USDT' },
];

export default function CustomerOrders() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [currencyFilter, setCurrencyFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [showDateFilter, setShowDateFilter] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const [prof, ords] = await Promise.all([loadOrdersProfile(user), loadOrders(_optionalChain([user, 'optionalAccess', _ => _.id]))]);
      setProfile(prof);
      setOrders(ords);
    } catch (e) {
      setError(true);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const filtered = useMemo(() => {
    return orders.filter((o) => {
      if (statusFilter !== 'all' && o.status !== statusFilter) return false;
      if (typeFilter !== 'all' && o.service_type !== typeFilter) return false;
      if (currencyFilter !== 'all' && o.currency !== currencyFilter) return false;
      if (dateFrom) {
        const d = new Date(o.created_date);
        const from = new Date(dateFrom);
        from.setHours(0, 0, 0, 0);
        if (d < from) return false;
      }
      if (dateTo) {
        const d = new Date(o.created_date);
        const to = new Date(dateTo);
        to.setHours(23, 59, 59, 999);
        if (d > to) return false;
      }
      if (search.trim()) {
        const q = search.toLowerCase();
        const haystack = `${o.id || ''} ${o.tracking_number || ''} ${o.title || ''} ${o.service_type_label || ''} ${o.description || ''}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [orders, statusFilter, typeFilter, currencyFilter, search, dateFrom, dateTo]);

  const hasActiveFilters = search || statusFilter !== 'all' || typeFilter !== 'all' || currencyFilter !== 'all' || dateFrom || dateTo;

  const clearAllFilters = () => {
    setSearch('');
    setStatusFilter('all');
    setTypeFilter('all');
    setCurrencyFilter('all');
    setDateFrom('');
    setDateTo('');
    setShowDateFilter(false);
  };

  if (loading) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 128}, this )
        , _jsxDEV(Skeleton, { className: "h-20 w-full rounded-xl"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this )
        , _jsxDEV(Skeleton, { className: "h-8 w-full rounded-lg"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this )
        , _jsxDEV('div', { className: "space-y-2", children: 
          [1, 2, 3, 4].map((i) => _jsxDEV(Skeleton, { className: "h-16 rounded-xl" ,}, i, false, {fileName: _jsxFileName, lineNumber: 132}, this ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 127}, this)
    );
  }

  if (error) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "سفارش‌های من" }, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this)
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-8 text-center space-y-4"  , children: [
            _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "دریافت اطلاعات با مشکل مواجه شد."     }, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this)
            , _jsxDEV(Button, { onClick: loadData, variant: "outline", size: "sm", children: [
              _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this ), "تلاش مجدد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 145}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 143}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 140}, this)
    );
  }

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      /* Header */
      _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
        _jsxDEV('div', { className: "flex items-center gap-2 min-w-0"   , children: [
          _jsxDEV('div', { className: "w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"       , children: 
            _jsxDEV(Package, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 161}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this)
          , _jsxDEV('div', { className: "min-w-0", children: [
            _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "سفارش‌های من" }, void 0, false, {fileName: _jsxFileName, lineNumber: 164}, this)
            , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "پیگیری سفارش‌های ثبت‌شده برای شما"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 163}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 159}, this)
        , _jsxDEV(Button, { variant: "ghost", size: "icon", className: "h-8 w-8 shrink-0"  , onClick: () => navigate('/customer'), children: 
          _jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 169}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 158}, this)

      /* Customer Info */
      , _jsxDEV(Card, { className: "shadow-sm", children: 
        _jsxDEV(CardContent, { className: "p-3", children: 
          _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
            _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "نام مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this)
              , _jsxDEV('p', { className: "text-xs font-medium text-foreground"  , children: _optionalChain([profile, 'optionalAccess', _2 => _2.customer_name]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 177}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "کد مشتری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this)
              , _jsxDEV('p', { className: "text-xs font-mono text-foreground"  , children: _optionalChain([profile, 'optionalAccess', _3 => _3.customer_code]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 183}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 181}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "نام صرافی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 186}, this)
              , _jsxDEV('p', { className: "text-xs font-medium text-foreground"  , children: _optionalChain([profile, 'optionalAccess', _4 => _4.exchange_name]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 185}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "تعداد سفارش‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 190}, this)
              , _jsxDEV('p', { className: "text-xs font-bold text-primary"  , children: orders.length}, void 0, false, {fileName: _jsxFileName, lineNumber: 191}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 189}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 176}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 175}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 174}, this)

      /* Search */
      , _jsxDEV('div', { className: "relative", children: [
        _jsxDEV(Search, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 199}, this )
        , _jsxDEV(Input, {
          placeholder: "جستجو: شماره سفارش، پیگیری، عنوان..."    ,
          value: search,
          onChange: (e) => setSearch(e.target.value),
          className: "text-xs pr-9" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 200}, this
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 198}, this)

      /* Date Filter Toggle */
      , _jsxDEV('button', {
        onClick: () => setShowDateFilter(!showDateFilter),
        className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
          showDateFilter || dateFrom || dateTo ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
        }`,
 children: [
        _jsxDEV(Calendar, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 215}, this ), "بازه زمانی"

      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 209}, this)
      , showDateFilter && (
        _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
          _jsxDEV(Input, { type: "date", value: dateFrom, onChange: (e) => setDateFrom(e.target.value), className: "text-xs",}, void 0, false, {fileName: _jsxFileName, lineNumber: 220}, this )
          , _jsxDEV('span', { className: "text-[10px] text-muted-foreground" , children: "تا"}, void 0, false, {fileName: _jsxFileName, lineNumber: 221}, this)
          , _jsxDEV(Input, { type: "date", value: dateTo, onChange: (e) => setDateTo(e.target.value), className: "text-xs",}, void 0, false, {fileName: _jsxFileName, lineNumber: 222}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 219}, this)
      )

      /* Filter Chips */
      , _jsxDEV('div', { className: "space-y-2", children: [
        _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          STATUS_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setStatusFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                statusFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 230}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 228}, this)
        , _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          TYPE_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setTypeFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                typeFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 243}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 241}, this)
        , _jsxDEV('div', { className: "flex gap-1.5 overflow-x-auto scrollbar-thin pb-1"    , children: 
          CURRENCY_FILTERS.map((f) => (
            _jsxDEV('button', {

              onClick: () => setCurrencyFilter(f.value),
              className: `px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap border transition-all ${
                currencyFilter === f.value ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'
              }`,
 children: 
              f.label
            }, f.value, false, {fileName: _jsxFileName, lineNumber: 256}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 254}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 227}, this)

      /* Clear Filters */
      , hasActiveFilters && (
        _jsxDEV('button', { onClick: clearAllFilters, className: "text-[10px] text-destructive flex items-center gap-1"    , children: [
          _jsxDEV(X, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 272}, this ), "پاک کردن فیلترها"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 271}, this)
      )

      /* Orders List */
      , filtered.length === 0 ? (
        _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-6 text-center text-sm text-muted-foreground"   , children: 
            orders.length === 0
              ? 'هنوز سفارشی برای شما ثبت نشده است.'
              : 'سفارشی با این فیلترها یافت نشد'
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 280}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 279}, this)
      ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          filtered.map((order) => {
            const st = STATUS_LABELS[order.status] || STATUS_LABELS.new;
            const date = new Date(order.created_date);
            return (
              _jsxDEV(Card, { className: "shadow-sm cursor-pointer hover:shadow-md transition-shadow"   , onClick: () => setSelectedOrder(order), children: 
                _jsxDEV(CardContent, { className: "p-3 flex items-center gap-3"   , children: [
                  _jsxDEV('div', { className: "w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"       , children: 
                    _jsxDEV(Package, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 295}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 294}, this)
                  , _jsxDEV('div', { className: "flex-1 min-w-0" , children: [
                    _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                      _jsxDEV('p', { className: "text-xs font-medium text-foreground truncate"   , children: order.title}, void 0, false, {fileName: _jsxFileName, lineNumber: 299}, this)
                      , _jsxDEV('span', { className: `text-[8px] px-1.5 py-0.5 rounded ${st.color}`, children: st.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 300}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 298}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground truncate"  , children: [
                      order.id, " • "  , order.service_type_label, " • "  , date.toLocaleDateString('fa-IR')
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 302}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 297}, this)
                  , _jsxDEV('div', { className: "text-left shrink-0" , children: [
                    _jsxDEV('p', { className: "text-sm font-bold text-foreground"  , children: (order.amount || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 307}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: order.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 308}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 306}, this)
                  , _jsxDEV(ChevronLeft, { className: "w-4 h-4 text-muted-foreground shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 310}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 293}, this)
              }, order.id, false, {fileName: _jsxFileName, lineNumber: 292}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 287}, this)
      )

      /* Quick Links */
      , _jsxDEV('div', { className: "grid grid-cols-3 gap-2"  , children: [
        _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/wallet'), children: [
          _jsxDEV(Wallet, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 321}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "کیف پول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 322}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 320}, this)
        , _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/account'), children: [
          _jsxDEV(Landmark, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 325}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "حساب من" }, void 0, false, {fileName: _jsxFileName, lineNumber: 326}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 324}, this)
        , _jsxDEV(Button, { variant: "outline", className: "flex-col h-auto py-3 gap-1"   , onClick: () => navigate('/customer/messages'), children: [
          _jsxDEV(MessageSquare, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 329}, this )
          , _jsxDEV('span', { className: "text-[10px]", children: "پیام‌ها"}, void 0, false, {fileName: _jsxFileName, lineNumber: 330}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 328}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 319}, this)

      /* Order Detail Sheet */
      , _jsxDEV(OrderDetail, {
        open: !!selectedOrder,
        onOpenChange: (open) => !open && setSelectedOrder(null),
        order: selectedOrder,}, void 0, false, {fileName: _jsxFileName, lineNumber: 335}, this
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 156}, this)
  );
}