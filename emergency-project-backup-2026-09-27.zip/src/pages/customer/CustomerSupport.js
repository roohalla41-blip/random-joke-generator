const _jsxFileName = "src/pages/customer/CustomerSupport.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React from 'react';
import SupportPanel from '../../components/sarraaf/SupportPanel.js';
import ContactInfo from '../../components/sarraaf/ContactInfo.js';
import FeedbackButton from '../../components/sarraaf/FeedbackButton.js';
import ReferralCard from '../../components/sarraaf/ReferralCard.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { LifeBuoy, UserPlus } from 'lucide-react';
import { useSarraafProfile, useToggleReferral } from '../../lib/useSarraaf.js';
import { useAuth } from '../../lib/AuthContext.js';

export default function CustomerSupport() {
  const { user } = useAuth();
  const { data: profile } = useSarraafProfile(_optionalChain([user, 'optionalAccess', _ => _.id]));
  const toggleMut = useToggleReferral();

  const handleToggle = (enabled) => {
    if (!profile) return;
    toggleMut.mutate({ profileId: profile.id, enabled });
  };

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
        _jsxDEV(LifeBuoy, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 24}, this )
        , _jsxDEV('h1', { className: "text-lg font-bold" , children: "پشتیبانی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 25}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 23}, this)

      , _jsxDEV(ContactInfo, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 28}, this )

      , _jsxDEV(SupportPanel, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 30}, this )

      /* Referral — share invite link */
      , _jsxDEV('div', { className: "flex items-center gap-2 pt-2"   , children: [
        _jsxDEV(UserPlus, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 34}, this )
        , _jsxDEV('h2', { className: "text-sm font-semibold" , children: "دعوت دوستان" }, void 0, false, {fileName: _jsxFileName, lineNumber: 35}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 33}, this)
      , _jsxDEV(ReferralCard, {
        profile: profile,
        onToggle: handleToggle,
        loading: toggleMut.isPending,}, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this
      )

      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4", children: [
          _jsxDEV('p', { className: "text-xs text-muted-foreground mb-3"  , children: "آیا بازخورد یا پیشنهادی دارید؟"

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 45}, this)
          , _jsxDEV(FeedbackButton, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 44}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 22}, this)
  );
}