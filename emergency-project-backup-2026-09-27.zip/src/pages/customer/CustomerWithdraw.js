const _jsxFileName = "src/pages/customer/CustomerWithdraw.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../lib/AuthContext.js';
import { useWallets } from '../../lib/useCustomer.js';
import { createWithdrawalRequest as serverCreateWithdrawal } from '../../lib/customerApi.js';
import { WITHDRAWAL_METHODS } from '../../lib/walletWithdrawal.js';
import { Button } from '../../components/ui/button.js';
import { Input } from '../../components/ui/input.js';
import { Label } from '../../components/ui/label.js';
import { Textarea } from '../../components/ui/textarea.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { ArrowRight, ArrowDownToLine, Loader2 } from 'lucide-react';
import { useToast } from '../../components/ui/use-toast.js';
import { AmountInput } from '../../components/sarraaf/Fields.js';

export default function CustomerWithdraw() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: wallets = [], isLoading } = useWallets();
  const [amount, setAmount] = useState(0);
  const [walletId, setWalletId] = useState('');
  const [method, setMethod] = useState('bank_transfer');
  const [destination, setDestination] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (wallets.length > 0 && !walletId) {
      setWalletId(wallets[0].id);
    }
  }, [wallets, walletId]);

  async function handleSubmit() {
    const amt = parseFloat(amount) || 0;
    if (!amt || amt <= 0) {
      toast({ title: 'خطا', description: 'مبلغ معتبر وارد کنید', variant: 'destructive' });
      return;
    }
    if (!walletId) {
      toast({ title: 'خطا', description: 'کیف پول انتخاب کنید', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    try {
      await serverCreateWithdrawal({
        walletId,
        amount: amt,
        method,
        destination,
        description,
      });
      toast({ title: 'موفق', description: 'درخواست برداشت ثبت شد و در انتظار تأیید است' });
      navigate('/customer/wallet');
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
    setSubmitting(false);
  }

  if (isLoading) {
    return (
      _jsxDEV('div', { className: "flex items-center justify-center py-12"   , children: 
        _jsxDEV(Loader2, { className: "w-6 h-6 animate-spin text-primary"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
    );
  }

  const selectedWallet = wallets.find(w => w.id === walletId);

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      /* Header */
      _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
        _jsxDEV(Button, { variant: "ghost", size: "icon", onClick: () => navigate('/customer/wallet'), children: 
          _jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)
        , _jsxDEV('h1', { className: "text-lg font-bold" , children: "برداشت از کیف پول"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 75}, this)

      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
          _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "کیف پول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this)
            , _jsxDEV(Select, { value: walletId, onValueChange: setWalletId, children: [
              _jsxDEV(SelectTrigger, { className: "mt-1", children: _jsxDEV(SelectValue, { placeholder: "انتخاب کیف پول"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this)
              , _jsxDEV(SelectContent, { children: 
                wallets.map(w => (
                  _jsxDEV(SelectItem, { value: w.id, children: [
                    w.currency, " — موجودی: "   , w.balance || 0
                  ]}, w.id, true, {fileName: _jsxFileName, lineNumber: 90}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 86}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 84}, this)

          , selectedWallet && (
            _jsxDEV('div', { className: "p-2 rounded-lg bg-muted/50 text-xs text-muted-foreground"    , children: ["موجودی قابل برداشت: "
                 , selectedWallet.balance || 0, " " , selectedWallet.currency
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 99}, this)
          )

          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "مبلغ برداشت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this)
            , _jsxDEV(AmountInput, { value: amount, onChange: setAmount, placeholder: "0",}, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 104}, this)

          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "روش برداشت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this)
            , _jsxDEV(Select, { value: method, onValueChange: setMethod, children: [
              _jsxDEV(SelectTrigger, { className: "mt-1", children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this)
              , _jsxDEV(SelectContent, { children: 
                WITHDRAWAL_METHODS.map(m => (
                  _jsxDEV(SelectItem, { value: m.value, children: m.label}, m.value, false, {fileName: _jsxFileName, lineNumber: 115}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 111}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 109}, this)

          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "مقصد (شماره حساب / نام نمایندگی)"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this)
            , _jsxDEV(Input, {
              value: destination,
              onChange: (e) => setDestination(e.target.value),
              placeholder: "مثلاً: حساب بانکی یا کد نمایندگی"     ,
              className: "mt-1",}, void 0, false, {fileName: _jsxFileName, lineNumber: 123}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 121}, this)

          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "توضیحات (اختیاری)" }, void 0, false, {fileName: _jsxFileName, lineNumber: 132}, this)
            , _jsxDEV(Textarea, {
              value: description,
              onChange: (e) => setDescription(e.target.value),
              className: "mt-1 min-h-[60px]" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 133}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 131}, this)

          , _jsxDEV(Button, { onClick: handleSubmit, disabled: submitting, className: "w-full", children: [
            submitting ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this ) : _jsxDEV(ArrowDownToLine, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this ), "ثبت درخواست برداشت"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 140}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 83}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 73}, this)
  );
}