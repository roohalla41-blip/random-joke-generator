const _jsxFileName = "src/pages/ForgotPassword.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Phone, ArrowRight, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { initiateGoogleLink, handleGoogleCallback } from '../lib/googleAuth.js';
import GoogleIcon from '../components/GoogleIcon.js';
import BrandMark from '../components/BrandMark.js';

export default function ForgotPassword() {
  const [mobile, setMobile] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [linked, setLinked] = useState(false);
  const [error, setError] = useState('');

  // ── Google link callback handler ──
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('google_link') !== '1') return;
    setGoogleLoading(true);
    handleGoogleCallback().then((result) => {
      setGoogleLoading(false);
      if (!result) return;
      if (result.error) {
        setError(
          result.error === 'user_not_found'
            ? 'کاربری با این شماره موبایل یافت نشد'
            : result.error === 'email_exists'
            ? 'این حساب گوگل قبلاً به کاربر دیگری متصل شده است'
            : 'خطا در اتصال حساب گوگل'
        );
        window.history.replaceState({}, '', '/forgot-password');
        return;
      }
      if (result.linked) {
        setLinked(true);
        window.history.replaceState({}, '', '/forgot-password');
      }
    });
  }, []);

  const handleGoogleLink = (e) => {
    e.preventDefault();
    setError('');
    if (!mobile || mobile.length < 10) {
      setError('شماره موبایل معتبر وارد کنید');
      return;
    }
    initiateGoogleLink(mobile, '/forgot-password?google_link=1');
  };

  if (googleLoading) {
    return (
      _jsxDEV('div', { className: "min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4"       , children: 
        _jsxDEV('div', { className: "w-full max-w-md text-center space-y-4"   , children: [
          _jsxDEV(Loader2, { className: "w-12 h-12 animate-spin text-primary mx-auto"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this )
          , _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "در حال اتصال به گوگل..."    }, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 57}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
    );
  }

  if (linked) {
    return (
      _jsxDEV('div', { className: "min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4"       , children: 
        _jsxDEV('div', { className: "w-full max-w-md" , children: 
          _jsxDEV('div', { className: "text-center space-y-4" , children: [
            _jsxDEV('div', { className: "w-16 h-16 rounded-2xl bg-success/10 flex items-center justify-center mx-auto"       , children: 
              _jsxDEV(CheckCircle2, { className: "w-8 h-8 text-success"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)
            , _jsxDEV('h1', { className: "text-lg font-bold" , children: "حساب گوگل متصل شد"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)
            , _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "اکنون می‌توانید با دکمه «ورود با گوگل» وارد حساب خود شوید. دیگر نیازی به رمز عبور ندارید."


            }, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this)
            , _jsxDEV(Link, { to: "/login", children: 
              _jsxDEV(Button, { className: "w-full h-11" , children: [
                _jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this ), "بازگشت به ورود"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 79}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 69}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this)
    );
  }

  return (
    _jsxDEV('div', { className: "min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4"       , children: 
      _jsxDEV('div', { className: "w-full max-w-md" , children: [
        _jsxDEV('div', { className: "text-center mb-6" , children: [
          _jsxDEV('div', { className: "flex justify-center mb-3"  , children: 
            _jsxDEV(BrandMark, { size: "md",}, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this)
          , _jsxDEV('h1', { className: "text-xl font-bold text-foreground"  , children: "فراموشی رمز عبور"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground mt-1"  , children: "حساب صراف — سامانه تخصصی مدیریت صرافی"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)
          , _jsxDEV('p', { className: "text-sm text-muted-foreground mt-1"  , children: "حساب گوگل خود را متصل کنید تا بدون رمز عبور وارد شوید"

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 99}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 93}, this)

        , _jsxDEV('div', { className: "bg-card rounded-xl border shadow-sm p-6 space-y-4"     , children: [
          _jsxDEV('form', { onSubmit: handleGoogleLink, className: "space-y-3", children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "شماره موبایل ثبت‌شده"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this)
              , _jsxDEV('div', { className: "relative", children: [
                _jsxDEV(Phone, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this )
                , _jsxDEV(Input, {
                  value: mobile,
                  onChange: (e) => setMobile(e.target.value),
                  placeholder: "07XXXXXXXX",
                  className: "pr-9",
                  inputMode: "numeric",
                  dir: "ltr",
                  required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this
                )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 108}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 106}, this)

            , error && (
              _jsxDEV('div', { className: "flex items-center gap-2 text-sm text-destructive bg-destructive/10 rounded-lg p-2"       , children: [
                _jsxDEV(AlertCircle, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this )
                , error
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 123}, this)
            )

            , _jsxDEV(Button, { type: "submit", className: "w-full h-11" , disabled: loading, children: [
              _jsxDEV(GoogleIcon, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this ), "اتصال حساب گوگل"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 129}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 105}, this)

          , _jsxDEV('div', { className: "relative", children: [
            _jsxDEV('div', { className: "absolute inset-0 flex items-center"   , children: 
              _jsxDEV('span', { className: "w-full border-t" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this)
            , _jsxDEV('div', { className: "relative flex justify-center text-xs"   , children: 
              _jsxDEV('span', { className: "bg-card px-2 text-muted-foreground"  , children: "راهنما"}, void 0, false, {fileName: _jsxFileName, lineNumber: 140}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 135}, this)

          , _jsxDEV('div', { className: "space-y-2 text-xs text-muted-foreground"  , children: [
            _jsxDEV('p', { children: "۱. شماره موبایلی که با آن ثبت‌نام کرده‌اید را وارد کنید."          }, void 0, false, {fileName: _jsxFileName, lineNumber: 145}, this)
            , _jsxDEV('p', { children: "۲. روی «اتصال حساب گوگل» بزنید و با حساب گوگل خود وارد شوید."            }, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this)
            , _jsxDEV('p', { children: "۳. پس از اتصال، می‌توانید با گوگل وارد حساب خود شوید."          }, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 144}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 104}, this)

        , _jsxDEV('div', { className: "mt-6 text-center" , children: 
          _jsxDEV(Link, { to: "/login", className: "text-xs text-muted-foreground hover:text-foreground"  , children: "بازگشت به ورود"

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 152}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 92}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 91}, this)
  );
}