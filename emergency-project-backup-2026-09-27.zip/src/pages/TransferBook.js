const _jsxFileName = "src/pages/TransferBook.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useTransfers, useExecuteTransfer } from '../lib/useSarraaf.js';
import { PageHeader, EmptyState, LoadingState, StatusBadge } from '../components/sarraaf/Pieces.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog.js';
import { buildTransferExecute } from '../lib/ledger.js';
import { formatDate, formatNumber, TRANSFER_STATUS_LABELS } from '../lib/sarraaf.js';
import { toast } from '../components/ui/use-toast.js';
import { AmountInput } from '../components/sarraaf/Fields.js';
import { BookOpen, Search, CheckCircle, FileSpreadsheet } from 'lucide-react';

const exportExcel = (transfers) => {
  if (!transfers || transfers.length === 0) return;
  const rows = transfers.map(t => ({
    'شماره حواله': t.transfer_no || '', 'نوع': t.direction === 'send' ? 'ارسال' : 'دریافت',
    'فرستنده': t.sender_name || '', 'گیرنده': t.receiver_name || '', 'موبایل گیرنده': t.receiver_phone || '',
    'مقصد': t.destination || '', 'ارز': t.currency, 'مبلغ': t.amount, 'کارمزد': t.fee || 0,
    'وضعیت': TRANSFER_STATUS_LABELS[t.status] || t.status, 'تاریخ': formatDate(t.created_date),
  }));
  const csv = '\uFEFF' + Object.keys(rows[0]).join(',') + '\n' + rows.map(r => Object.values(r).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'transfer-book.csv'; a.click();
  URL.revokeObjectURL(url);
};

export default function TransferBook() {
  const { data: transfers, isLoading } = useTransfers();
  const execMut = useExecuteTransfer();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [execDialog, setExecDialog] = useState(null);
  const [payCurrency, setPayCurrency] = useState('AFN');
  const [payAmount, setPayAmount] = useState(0);
  const [payCounter, setPayCounter] = useState('cash');

  const filtered = (transfers || []).filter(t => {
    if (statusFilter !== 'all' && t.status !== statusFilter) return false;
    if (search) {
      const s = search.toLowerCase();
      return (t.transfer_no || '').toLowerCase().includes(s) ||
        (t.sender_name || '').toLowerCase().includes(s) ||
        (t.receiver_name || '').toLowerCase().includes(s);
    }
    return true;
  });

  const handleExecute = async () => {
    if (!execDialog) return;
    const lines = await buildTransferExecute(execDialog, payCurrency, payAmount, payCounter);
    try {
      await execMut.mutateAsync({ transfer: execDialog, lines, payCurrency, payAmount, payCounter });
      toast({ title: 'اجرای حواله', description: 'حواله با موفقیت اجرا شد' });
      setExecDialog(null);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "دفتر حواله" , icon: BookOpen,
        actions: _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => exportExcel(filtered), children: _jsxDEV(FileSpreadsheet, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this),}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this
      )
      , _jsxDEV('div', { className: "flex gap-2 mb-3"  , children: [
        _jsxDEV('div', { className: "relative flex-1" , children: [
          _jsxDEV(Search, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this )
          , _jsxDEV(Input, { value: search, onChange: e => setSearch(e.target.value), placeholder: "جستجو...", className: "pr-9",}, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 69}, this)
        , _jsxDEV(Select, { value: statusFilter, onValueChange: setStatusFilter, children: [
          _jsxDEV(SelectTrigger, { className: "w-32", children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this)
          , _jsxDEV(SelectContent, { children: [
            _jsxDEV(SelectItem, { value: "all", children: "همه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)
            , _jsxDEV(SelectItem, { value: "registered", children: "ثبت‌شده"}, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)
            , _jsxDEV(SelectItem, { value: "pending", children: "در انتظار" }, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this)
            , _jsxDEV(SelectItem, { value: "paid", children: "پرداخت‌شده"}, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this)
            , _jsxDEV(SelectItem, { value: "cancelled", children: "لغو‌شده"}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 75}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 73}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 68}, this)
      , isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this ) : filtered.length === 0 ? _jsxDEV(EmptyState, { icon: BookOpen, title: "حواله‌ای نیست" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          filtered.map(t => (
            _jsxDEV('div', { className: "p-3 rounded-xl border bg-card"   , children: [
              _jsxDEV('div', { className: "flex items-center justify-between mb-1"   , children: [
                _jsxDEV('span', { className: "text-sm font-bold" , children: t.transfer_no}, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this)
                , _jsxDEV(StatusBadge, { status: t.status, labels: TRANSFER_STATUS_LABELS,}, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 88}, this)
              , _jsxDEV('div', { className: "text-xs text-muted-foreground space-y-0.5"  , children: [
                _jsxDEV('p', { children: ["گیرنده: " , t.receiver_name, " — "  , t.receiver_phone]}, void 0, true, {fileName: _jsxFileName, lineNumber: 93}, this)
                , _jsxDEV('p', { children: ["مبلغ: " , formatNumber(t.amount), " " , t.currency, " — "  , t.direction === 'send' ? 'ارسال' : 'دریافت']}, void 0, true, {fileName: _jsxFileName, lineNumber: 94}, this)
                , _jsxDEV('p', { children: ["تاریخ: " , formatDate(t.created_date)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 92}, this)
              , _jsxDEV('div', { className: "flex gap-1 mt-2"  , children: [
                t.status !== 'paid' && t.status !== 'cancelled' && (
                  _jsxDEV(Button, { size: "sm", onClick: () => { setExecDialog(t); setPayAmount(t.amount); setPayCurrency(t.currency); }, children: [
                    _jsxDEV(CheckCircle, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 100}, this ), " اجرای حواله"
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 99}, this)
                )
                , _jsxDEV(Link, { to: `/receipt?type=transfer&id=${t.id}`, children: 
                  _jsxDEV(Button, { size: "sm", variant: "outline", children: "رسید"}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this)
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 97}, this)
            ]}, t.id, true, {fileName: _jsxFileName, lineNumber: 87}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this)
      )

      , _jsxDEV(Dialog, { open: !!execDialog, onOpenChange: () => setExecDialog(null), children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: ["اجرای حواله "  , _optionalChain([execDialog, 'optionalAccess', _ => _.transfer_no])]}, void 0, true, {fileName: _jsxFileName, lineNumber: 114}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
          , _jsxDEV('div', { className: "space-y-3", children: [
            _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV('label', { className: "text-xs", children: "ارز پرداخت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this)
                , _jsxDEV(Select, { value: payCurrency, onValueChange: setPayCurrency, children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 120}, this)
                  , _jsxDEV(SelectContent, { children: [_jsxDEV(SelectItem, { value: "AFN", children: "AFN"}, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this), _jsxDEV(SelectItem, { value: "USD", children: "USD"}, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this), _jsxDEV(SelectItem, { value: "IRT", children: "IRT"}, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 121}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 119}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 117}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV('label', { className: "text-xs", children: "مبلغ پرداخت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this)
                , _jsxDEV(AmountInput, { value: payAmount, onChange: setPayAmount,}, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 124}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 116}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('label', { className: "text-xs", children: "حساب پرداخت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)
              , _jsxDEV(Select, { value: payCounter, onValueChange: setPayCounter, children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 132}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 132}, this)
                , _jsxDEV(SelectContent, { children: [_jsxDEV(SelectItem, { value: "cash", children: "صندوق"}, void 0, false, {fileName: _jsxFileName, lineNumber: 133}, this), _jsxDEV(SelectItem, { value: "bank", children: "بانک"}, void 0, false, {fileName: _jsxFileName, lineNumber: 133}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 133}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 131}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 129}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 115}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setExecDialog(null), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)
            , _jsxDEV(Button, { onClick: handleExecute, disabled: execMut.isPending, children: "اجرا"}, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 137}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 113}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 64}, this)
  );
}