const _jsxFileName = "src/pages/Journal.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React from 'react';
import { useTransactions, useCurrencies, useRateSettings } from '../lib/useSarraaf.js';
import { PageHeader, LoadingState, EmptyState } from '../components/sarraaf/Pieces.js';
import { groupByDocument, documentBaseBalances } from '../lib/ledger.js';
import { formatDate, formatNumber, TX_TYPE_LABELS } from '../lib/sarraaf.js';
import { Card, CardContent } from '../components/ui/card.js';
import { BookCopy, Printer } from 'lucide-react';
import { Button } from '../components/ui/button.js';

export default function Journal() {
  const { data: txs, isLoading } = useTransactions();
  const { data: currencies } = useCurrencies();
  const { data: rateSettings } = useRateSettings();

  const groups = txs ? groupByDocument(txs) : {};
  const groupEntries = Object.entries(groups).sort((a, b) => {
    const da = _optionalChain([a, 'access', _ => _[1], 'access', _2 => _2[0], 'optionalAccess', _3 => _3.date]) || '';
    const db = _optionalChain([b, 'access', _4 => _4[1], 'access', _5 => _5[0], 'optionalAccess', _6 => _6.date]) || '';
    return db.localeCompare(da);
  });

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "دفتر روزنامه" , icon: BookCopy,
        actions: _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => window.print(), children: [_jsxDEV(Printer, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 25}, this ), " چاپ" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 25}, this),}, void 0, false, {fileName: _jsxFileName, lineNumber: 24}, this
      )
      , isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 27}, this ) : groupEntries.length === 0 ? _jsxDEV(EmptyState, { icon: BookCopy, title: "سندی وجود ندارد"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 27}, this ) : (
        _jsxDEV('div', { className: "space-y-3", children: 
          groupEntries.map(([docNo, lines]) => {
            const bal = documentBaseBalances(lines);
            const isBalanced = Object.values(bal).every(b => Math.abs(b.debit - b.credit) < 1);
            return (
              _jsxDEV(Card, { children: 
                _jsxDEV(CardContent, { className: "p-3", children: [
                  _jsxDEV('div', { className: "flex items-center justify-between mb-2"   , children: [
                    _jsxDEV('span', { className: "text-sm font-bold" , children: docNo}, void 0, false, {fileName: _jsxFileName, lineNumber: 36}, this)
                    , _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: formatDate(_optionalChain([lines, 'access', _7 => _7[0], 'optionalAccess', _8 => _8.date]))}, void 0, false, {fileName: _jsxFileName, lineNumber: 37}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 35}, this)
                  , _jsxDEV('div', { className: "space-y-1", children: 
                    lines.map((l, i) => (
                      _jsxDEV('div', { className: "flex items-center justify-between text-xs py-1 border-b last:border-0"      , children: [
                        _jsxDEV('span', { className: "truncate flex-1" , children: l.description || TX_TYPE_LABELS[l.type] || l.type}, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this)
                        , _jsxDEV('span', { className: "font-mono text-left" , children: [formatNumber(l.amount, 2), " " , l.currency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 43}, this)
                      ]}, i, true, {fileName: _jsxFileName, lineNumber: 41}, this)
                    ))
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 39}, this)
                  , _jsxDEV('div', { className: `text-xs mt-2 font-medium ${isBalanced ? 'text-success' : 'text-destructive'}`, children: 
                    isBalanced ? '✓ تراز' : '✗ ناتراز'
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 47}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 34}, this)
              }, docNo, false, {fileName: _jsxFileName, lineNumber: 33}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 28}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 23}, this)
  );
}