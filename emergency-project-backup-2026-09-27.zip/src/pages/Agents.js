const _jsxFileName = "src/pages/Agents.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState } from 'react';
import { useAgents, useAgentBalances, useCreateAgent, useUpdateAgent } from '../lib/useSarraaf.js';
import { PageHeader, EmptyState, LoadingState } from '../components/sarraaf/Pieces.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog.js';
import { formatNumber } from '../lib/sarraaf.js';
import { Network, Plus, Pencil, Send, Download } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Agents() {
  const { data: agents, isLoading } = useAgents();
  const { data: agentBalancesData } = useAgentBalances();
  const createMut = useCreateAgent();
  const updateMut = useUpdateAgent();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ name: '', phone: '', city: '', code: '', status: 'active', notes: '' });

  const openCreate = () => { setEditId(null); setForm({ name: '', phone: '', city: '', code: '', status: 'active', notes: '' }); setDialogOpen(true); };
  const openEdit = (a) => { setEditId(a.id); setForm({ name: a.name, phone: a.phone, city: a.city, code: a.code, status: a.status, notes: a.notes }); setDialogOpen(true); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editId) await updateMut.mutateAsync({ id: editId, data: form });
    else await createMut.mutateAsync(form);
    setDialogOpen(false);
  };

  const getAgentBal = (agentId) => {
    const b = (agentBalancesData || []).find(x => String(x.agent_id) === String(agentId));
    return b ? { [b.currency || 'AFN']: b.balance || 0 } : {};
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "نمایندگی‌ها", icon: Network,
        actions: _jsxDEV(Button, { size: "sm", onClick: openCreate, children: [_jsxDEV(Plus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 39}, this ), " افزودن" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 39}, this),}, void 0, false, {fileName: _jsxFileName, lineNumber: 38}, this
      )
      , isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this ) : (agents || []).length === 0 ? _jsxDEV(EmptyState, { icon: Network, title: "نماینده‌ای نیست" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          (agents || []).map(a => {
            const bal = getAgentBal(a.id);
            return (
              _jsxDEV('div', { className: "p-3 rounded-xl border bg-card"   , children: [
                _jsxDEV('div', { className: "flex items-center justify-between mb-2"   , children: [
                  _jsxDEV('div', { children: [
                    _jsxDEV('span', { className: "text-sm font-bold" , children: a.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this)
                    , a.code && _jsxDEV('span', { className: "text-xs text-muted-foreground mr-2"  , children: a.code}, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 48}, this)
                  , _jsxDEV(Button, { size: "icon", variant: "ghost", onClick: () => openEdit(a), children: _jsxDEV(Pencil, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 52}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 52}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 47}, this)
                , _jsxDEV('div', { className: "text-xs text-muted-foreground mb-2"  , children: [
                  a.phone && _jsxDEV('p', { children: ["موبایل: " , a.phone]}, void 0, true, {fileName: _jsxFileName, lineNumber: 55}, this)
                  , a.city && _jsxDEV('p', { children: ["شهر: " , a.city]}, void 0, true, {fileName: _jsxFileName, lineNumber: 56}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 54}, this)
                , Object.keys(bal).length > 0 && (
                  _jsxDEV('div', { className: "flex gap-2 flex-wrap"  , children: 
                    Object.entries(bal).map(([cur, val]) => (
                      _jsxDEV('span', { className: "text-xs px-2 py-1 rounded-lg bg-muted"    , children: [formatNumber(val), " " , cur]}, cur, true, {fileName: _jsxFileName, lineNumber: 61}, this)
                    ))
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this)
                )
                , _jsxDEV('div', { className: "flex gap-1 mt-2"  , children: [
                  _jsxDEV(Link, { to: `/transfers/send?agent=${a.id}`, children: _jsxDEV(Button, { size: "sm", variant: "outline", children: [_jsxDEV(Send, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this ), " ارسال" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 66}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
                  , _jsxDEV(Link, { to: `/transfers/receive?agent=${a.id}`, children: _jsxDEV(Button, { size: "sm", variant: "outline", children: [_jsxDEV(Download, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this ), " دریافت" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 67}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)
              ]}, a.id, true, {fileName: _jsxFileName, lineNumber: 46}, this)
            );
          })
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 42}, this)
      )

      , _jsxDEV(Dialog, { open: dialogOpen, onOpenChange: setDialogOpen, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: editId ? 'ویرایش نماینده' : 'افزودن نماینده'}, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)
          , _jsxDEV('form', { onSubmit: handleSubmit, className: "space-y-3", children: [
            _jsxDEV('div', { children: [_jsxDEV(Label, { children: "نام"}, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this), _jsxDEV(Input, { value: form.name, onChange: e => setForm({...form, name: e.target.value}), required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 79}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [_jsxDEV(Label, { children: "موبایل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this), _jsxDEV(Input, { value: form.phone, onChange: e => setForm({...form, phone: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 81}, this)
              , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "کد"}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this), _jsxDEV(Input, { value: form.code, onChange: e => setForm({...form, code: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 82}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 80}, this)
            , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "شهر"}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this), _jsxDEV(Input, { value: form.city, onChange: e => setForm({...form, city: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 84}, this)
            , _jsxDEV(DialogFooter, { children: [
              _jsxDEV(Button, { type: "button", variant: "outline", onClick: () => setDialogOpen(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this)
              , _jsxDEV(Button, { type: "submit", disabled: createMut.isPending || updateMut.isPending, children: "ذخیره"}, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 85}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 78}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 76}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 37}, this)
  );
}