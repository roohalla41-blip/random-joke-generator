const _jsxFileName = "src/pages/PaymentGateway.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { useFeatures } from '../lib/useSarraaf.js';
import { isFeatureUpdating } from '../lib/features.js';
import { PageHeader } from '../components/sarraaf/Pieces.js';
import { Card, CardContent } from '../components/ui/card.js';
import { Button } from '../components/ui/button.js';
import { Badge } from '../components/ui/badge.js';
import { CreditCard, AlertCircle, Settings as SettingsIcon, Lock } from 'lucide-react';
import BankGatewayManager from '../components/sarraaf/BankGatewayManager.js';

export default function PaymentGateway() {
  const { data: features } = useFeatures();
  const isUpdating = isFeatureUpdating(features, 'payment_gateway');
  const [showManager, setShowManager] = useState(false);

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "درگاه پرداخت بانکی"  , icon: CreditCard,}, void 0, false, {fileName: _jsxFileName, lineNumber: 18}, this )

      /* Status banner */
      , _jsxDEV(Card, { className: "mb-4 border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/10"    , children: 
        _jsxDEV(CardContent, { className: "p-4 flex items-start gap-3"   , children: [
          _jsxDEV(AlertCircle, { className: "w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5"     ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 23}, this )
          , _jsxDEV('div', { className: "flex-1", children: [
            _jsxDEV('h3', { className: "text-sm font-semibold text-amber-800 dark:text-amber-300 mb-1"    , children: "درگاه بانکی در حال راه‌اندازی"

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 25}, this)
            , _jsxDEV('p', { className: "text-xs text-amber-700 dark:text-amber-400 leading-relaxed"   , children: "این بخش در حال توسعه است. اتصال به درگاه بانکی واقعی به‌زودی فعال خواهد شد. در حال حاضر امکان پرداخت آنلاین از طریق درگاه بانکی در دسترس نیست."


            }, void 0, false, {fileName: _jsxFileName, lineNumber: 28}, this)
            , _jsxDEV(Badge, { variant: "outline", className: "mt-2 text-amber-700 dark:text-amber-400 border-amber-300 dark:border-amber-700"    , children: "وضعیت: در حال به‌روزرسانی"

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 32}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 24}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 22}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 21}, this)

      /* Feature info cards */
      , _jsxDEV('div', { className: "grid grid-cols-2 gap-3 mb-4"   , children: [
        _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-4 text-center" , children: [
            _jsxDEV(Lock, { className: "w-6 h-6 mx-auto text-muted-foreground mb-2"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this )
            , _jsxDEV('p', { className: "text-xs font-medium" , children: "امنیت بانکی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 44}, this)
            , _jsxDEV('p', { className: "text-[10px] text-muted-foreground mt-1"  , children: "رمزنگاری SSL و احراز هویت دو مرحله‌ای"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 45}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 42}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 41}, this)
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-4 text-center" , children: [
            _jsxDEV(CreditCard, { className: "w-6 h-6 mx-auto text-muted-foreground mb-2"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 50}, this )
            , _jsxDEV('p', { className: "text-xs font-medium" , children: "پرداخت آنلاین" }, void 0, false, {fileName: _jsxFileName, lineNumber: 51}, this)
            , _jsxDEV('p', { className: "text-[10px] text-muted-foreground mt-1"  , children: "شارژ کیف پول و پرداخت سفارشات"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 52}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 49}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 40}, this)

      /* Admin gateway management (admin/creator only) */
      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4", children: [
          _jsxDEV('div', { className: "flex items-center justify-between mb-3"   , children: [
            _jsxDEV('div', { children: [
              _jsxDEV('h3', { className: "text-sm font-semibold" , children: "پیکربندی درگاه‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this)
              , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "مدیریت تنظیمات درگاه‌های پرداخت (برای فعال‌سازی آینده)"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 61}, this)
            , _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => setShowManager(!showManager), children: [
              _jsxDEV(SettingsIcon, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this )
              , _jsxDEV('span', { className: "text-xs mr-1" , children: showManager ? 'بستن' : 'مدیریت'}, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 60}, this)
          , showManager && _jsxDEV(BankGatewayManager, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 59}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 58}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 17}, this)
  );
}