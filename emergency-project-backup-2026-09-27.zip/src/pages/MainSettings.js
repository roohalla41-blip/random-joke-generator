const _jsxFileName = "src/pages/MainSettings.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { useRateSettings, useCreateRateSetting, useSarraafProfile } from '../lib/useSarraaf.js';
import { useAuth } from '../lib/AuthContext.js';
import { PageHeader } from '../components/sarraaf/Pieces.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Card, CardContent } from '../components/ui/card.js';
import { Shield, User, Store, Copy, Loader2, Save } from 'lucide-react';
import { toast } from '../components/ui/use-toast.js';
import { offlineDB } from '../lib/offlineQueue.js';

const RATE_KEYS = [
  { key: 'usd_afn', label: 'نرخ دلار به افغانی' },
  { key: 'afn_toman', label: 'نرخ افغانی به تومان' },
  { key: 'large_transfer_threshold', label: 'حد نصاب حواله بزرگ' },
];

export default function MainSettings() {
  const { user } = useAuth();
  const { data: settings } = useRateSettings();
  const { data: profile } = useSarraafProfile(_optionalChain([user, 'optionalAccess', _ => _.id]));
  const createMut = useCreateRateSetting();
  const [values, setValues] = useState({});
  const [profileForm, setProfileForm] = useState({});
  const [savingProfile, setSavingProfile] = useState(false);

  useEffect(() => {
    if (settings) {
      const v = {};
      for (const rk of RATE_KEYS) v[rk.key] = settings[rk.key] || '';
      setValues(v);
    }
  }, [settings]);

  useEffect(() => {
    if (profile) {
      setProfileForm({
        exchange_name: profile.exchange_name || '',
        name: profile.name || '',
        phone: profile.phone || '',
        email: profile.email || '',
        code: profile.code || '',
      });
    }
  }, [profile]);

  const handleSave = async (key) => {
    try {
      await createMut.mutateAsync({ key, value: values[key], updated_by_name: _optionalChain([user, 'optionalAccess', _2 => _2.full_name]) || 'admin' });
      toast({ title: 'ذخیره شد' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleSaveProfile = async () => {
    if (!profile) return;
    setSavingProfile(true);
    try {
      await offlineDB.SarraafProfile.update(profile.id, {
        exchange_name: profileForm.exchange_name,
        name: profileForm.name,
        phone: profileForm.phone,
        email: profileForm.email,
      });
      toast({ title: 'اطلاعات صرافی ذخیره شد' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    } finally {
      setSavingProfile(false);
    }
  };

  const copyCode = () => {
    if (profileForm.code) {
      _optionalChain([navigator, 'access', _3 => _3.clipboard, 'optionalAccess', _4 => _4.writeText, 'call', _5 => _5(profileForm.code)]);
      toast({ title: 'کُد صرافی کپی شد' });
    }
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "تنظیمات اصلی" , subtitle: "اطلاعات صرافی و نرخ‌ها"   , icon: Shield,}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this )

      /* Sarraaf Profile Info */
      , _jsxDEV(Card, { className: "mb-4", children: 
        _jsxDEV(CardContent, { className: "p-4 space-y-4" , children: [
          _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            _jsxDEV(Store, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this )
            , _jsxDEV('h3', { className: "text-sm font-semibold" , children: "اطلاعات صرافی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 91}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 89}, this)

          , profile ? (
            _jsxDEV(_Fragment, { children: [
              _jsxDEV('div', { className: "flex items-center gap-2 p-3 rounded-lg bg-muted"     , children: [
                _jsxDEV('div', { className: "flex-1", children: [
                  _jsxDEV(Label, { className: "text-xs text-muted-foreground" , children: "کُد صرافی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)
                  , _jsxDEV('p', { className: "text-lg font-bold tracking-wider"  , dir: "ltr", children: profileForm.code || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 99}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 97}, this)
                , _jsxDEV(Button, { size: "icon", variant: "ghost", onClick: copyCode, disabled: !profileForm.code, children: 
                  _jsxDEV(Copy, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 96}, this)

              , _jsxDEV('div', { className: "space-y-3", children: [
                _jsxDEV('div', { children: [
                  _jsxDEV(Label, { children: "نام صرافی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this)
                  , _jsxDEV(Input, { value: profileForm.exchange_name || '', onChange: e => setProfileForm({...profileForm, exchange_name: e.target.value}), placeholder: "صرافی احمدی" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 107}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { children: "نام مسئول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this)
                  , _jsxDEV(Input, { value: profileForm.name || '', onChange: e => setProfileForm({...profileForm, name: e.target.value}), placeholder: "نام و نام خانوادگی"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 111}, this)
                , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
                  _jsxDEV('div', { children: [
                    _jsxDEV(Label, { children: "تلفن"}, void 0, false, {fileName: _jsxFileName, lineNumber: 117}, this)
                    , _jsxDEV(Input, { value: profileForm.phone || '', onChange: e => setProfileForm({...profileForm, phone: e.target.value}), placeholder: "07XXXXXXXX", inputMode: "numeric",}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 116}, this)
                  , _jsxDEV('div', { children: [
                    _jsxDEV(Label, { children: "ایمیل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this)
                    , _jsxDEV(Input, { value: profileForm.email || '', onChange: e => setProfileForm({...profileForm, email: e.target.value}), placeholder: "email@example.com", dir: "ltr",}, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 120}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 115}, this)
                , _jsxDEV(Button, { onClick: handleSaveProfile, disabled: savingProfile, className: "w-full", children: [
                  savingProfile ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this ) : _jsxDEV(Save, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this ), "ذخیره اطلاعات صرافی"

                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 125}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 106}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)
          ) : (
            _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "اطلاعات صرافی یافت نشد."   }, void 0, false, {fileName: _jsxFileName, lineNumber: 132}, this)
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 88}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this)

      /* User Account Info */
      , _jsxDEV(Card, { className: "mb-4", children: 
        _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
          _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
            _jsxDEV(User, { className: "w-5 h-5 text-emerald-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this )
            , _jsxDEV('h3', { className: "text-sm font-semibold" , children: "حساب کاربری" }, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 140}, this)
          , _jsxDEV('div', { className: "grid grid-cols-2 gap-2 text-sm"   , children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs text-muted-foreground" , children: "نام"}, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this)
              , _jsxDEV('p', { className: "font-medium", children: _optionalChain([user, 'optionalAccess', _6 => _6.full_name]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 145}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs text-muted-foreground" , children: "ایمیل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 150}, this)
              , _jsxDEV('p', { className: "font-medium truncate" , dir: "ltr", children: _optionalChain([user, 'optionalAccess', _7 => _7.email]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 149}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs text-muted-foreground" , children: "نقش"}, void 0, false, {fileName: _jsxFileName, lineNumber: 154}, this)
              , _jsxDEV('p', { className: "font-medium", children: _optionalChain([user, 'optionalAccess', _8 => _8.role]) === 'admin' ? 'مدیر' : _optionalChain([user, 'optionalAccess', _9 => _9.role]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 155}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 153}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { className: "text-xs text-muted-foreground" , children: "موبایل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this)
              , _jsxDEV('p', { className: "font-medium", dir: "ltr", children: _optionalChain([user, 'optionalAccess', _10 => _10.mobile]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 157}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 144}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 139}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)

      /* Base Rate Settings */
      , _jsxDEV(Card, { children: 
        _jsxDEV(CardContent, { className: "p-4 space-y-4" , children: [
          _jsxDEV('h3', { className: "text-sm font-semibold" , children: "نرخ پایه ارز"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this)
          , RATE_KEYS.map(rk => (
            _jsxDEV('div', { className: "flex items-end gap-2"  , children: [
              _jsxDEV('div', { className: "flex-1", children: [
                _jsxDEV(Label, { children: rk.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 172}, this)
                , _jsxDEV(Input, {
                  type: "number",
                  value: values[rk.key] || '',
                  onChange: e => setValues({...values, [rk.key]: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 173}, this
                )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 171}, this)
              , _jsxDEV(Button, { onClick: () => handleSave(rk.key), disabled: createMut.isPending, children: 
                createMut.isPending ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 180}, this ) : 'ذخیره'
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this)
            ]}, rk.key, true, {fileName: _jsxFileName, lineNumber: 170}, this)
          ))
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 167}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 166}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 83}, this)
  );
}