const _jsxFileName = "src/pages/Reports.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React from 'react';
import { Link } from 'react-router-dom';
import { PageHeader } from '../components/sarraaf/Pieces.js';
import { Card, CardContent } from '../components/ui/card.js';
import { FileText, Banknote, Send, Network, TrendingUp, BookCopy, ScrollText, Scale } from 'lucide-react';

const REPORT_CARDS = [
  { label: 'تراکنش‌ها', path: '/general-ledger', icon: FileText, gradient: 'from-blue-500 to-blue-600' },
  { label: 'موجودی ارز', path: '/balance-sheet', icon: Banknote, gradient: 'from-green-500 to-green-600' },
  { label: 'حواله‌ها', path: '/transfer-book', icon: Send, gradient: 'from-orange-500 to-orange-600' },
  { label: 'نمایندگی‌ها', path: '/agents', icon: Network, gradient: 'from-cyan-500 to-cyan-600' },
  { label: 'سود و زیان', path: '/profit-loss', icon: TrendingUp, gradient: 'from-purple-500 to-purple-600' },
  { label: 'دفتر روزنامه', path: '/journal', icon: BookCopy, gradient: 'from-violet-500 to-violet-600' },
  { label: 'مغایرت‌گیری', path: '/reconciliation', icon: Scale, gradient: 'from-rose-500 to-rose-600' },
];

export default function Reports() {
  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "گزارش‌ها", icon: FileText,}, void 0, false, {fileName: _jsxFileName, lineNumber: 20}, this )
      , _jsxDEV('div', { className: "grid grid-cols-2 sm:grid-cols-4 gap-3"   , children: 
        REPORT_CARDS.map(r => {
          const Icon = r.icon;
          return (
            _jsxDEV(Link, { to: r.path, children: 
              _jsxDEV(Card, { className: "overflow-hidden hover:bg-muted/30 transition-colors"  , children: 
                _jsxDEV(CardContent, { className: "p-4 flex flex-col items-center gap-2"    , children: [
                  _jsxDEV('div', { className: `w-12 h-12 rounded-xl bg-gradient-to-br ${r.gradient} flex items-center justify-center`, children: 
                    _jsxDEV(Icon, { className: "w-6 h-6 text-white"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 29}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 28}, this)
                  , _jsxDEV('span', { className: "text-sm font-medium text-center"  , children: r.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 31}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 27}, this)
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 26}, this)
            }, r.label, false, {fileName: _jsxFileName, lineNumber: 25}, this)
          );
        })
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 21}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 19}, this)
  );
}