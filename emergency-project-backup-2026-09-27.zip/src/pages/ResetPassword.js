const _jsxFileName = "src/pages/ResetPassword.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { callSupabase } from "../lib/supabaseApi.js";
import { Button } from "../components/ui/button.js";
import { Input } from "../components/ui/input.js";
import { Label } from "../components/ui/label.js";
import { Lock, Loader2, AlertTriangle } from "lucide-react";
import AuthLayout from "../components/AuthLayout.js";

export default function ResetPassword() {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [hasSession, setHasSession] = useState(false);
  const [accessToken, setAccessToken] = useState("");
  const [checkingSession, setCheckingSession] = useState(true);

  // Check for Supabase Auth recovery code in URL hash or query
  useEffect(() => {
    const checkRecovery = async () => {
      try {
        const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ""));
        const queryParams = new URLSearchParams(window.location.search);
        const code = hashParams.get("code") || queryParams.get("code") || "";
        const type = hashParams.get("type") || queryParams.get("type") || "";

        if (code && type === "recovery") {
          const res = await callSupabase("auth_recover", { code });
          if (_optionalChain([res, 'optionalAccess', _ => _.success]) && _optionalChain([res, 'optionalAccess', _2 => _2.session, 'optionalAccess', _3 => _3.access_token])) {
            setAccessToken(res.session.access_token);
            setHasSession(true);
          }
        }
      } catch (e2) {
        // ignore — no valid recovery session
      }
      setCheckingSession(false);
    };
    checkRecovery();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (newPassword !== confirmPassword) {
      setError("رمز عبور و تکرار آن یکسان نیستند");
      return;
    }
    if (newPassword.length < 8) {
      setError("رمز عبور باید حداقل ۸ کاراکتر باشد");
      return;
    }
    setLoading(true);
    try {
      const res = await callSupabase("auth_updateUser", {
        access_token: accessToken,
        new_password: newPassword,
      });
      if (!_optionalChain([res, 'optionalAccess', _4 => _4.success])) throw new Error(_optionalChain([res, 'optionalAccess', _5 => _5.error]) || "Failed to reset password");
      await callSupabase("auth_signOut", { access_token: accessToken });
      window.location.href = "/login";
    } catch (err) {
      setError(err.message || "Failed to reset password");
    } finally {
      setLoading(false);
    }
  };

  if (checkingSession) {
    return (
      _jsxDEV('div', { className: "min-h-screen flex items-center justify-center"   , children: 
        _jsxDEV(Loader2, { className: "w-8 h-8 animate-spin text-primary"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this)
    );
  }

  if (!hasSession) {
    return (
      _jsxDEV(AuthLayout, {
        icon: AlertTriangle,
        title: "لینک نامعتبر" ,
        subtitle: "لینک بازنشانی رمز عبور نامعتبر یا منقضی است"       ,
        footer: 
          _jsxDEV(Link, { to: "/forgot-password", className: "text-primary font-medium hover:underline"  , children: "درخواست لینک جدید"

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this)
        ,
 children: 
        _jsxDEV('p', { className: "text-sm text-foreground text-center"  , children: "لینکی که استفاده کردید نامعتبر است یا منقضی شده است. لطفاً از طریق فراموشی رمز عبور، لینک جدیدی دریافت کنید."

        }, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this)
    );
  }

  return (
    _jsxDEV(AuthLayout, {
      icon: Lock,
      title: "رمز عبور جدید"  ,
      subtitle: "رمز عبور جدید خود را وارد کنید"      ,
 children: [
      error && (
        _jsxDEV('div', { className: "mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm"     , children: 
          error
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this)
      )
      , _jsxDEV('form', { onSubmit: handleSubmit, className: "space-y-4", children: [
        _jsxDEV('div', { className: "space-y-2", children: [
          _jsxDEV(Label, { htmlFor: "password", children: "رمز عبور جدید"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this)
          , _jsxDEV('div', { className: "relative", children: [
            _jsxDEV(Lock, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      , 'aria-hidden': "true",}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this )
            , _jsxDEV(Input, {
              id: "password",
              type: "password",
              autoComplete: "new-password",
              autoFocus: true,
              placeholder: "••••••••",
              value: newPassword,
              onChange: (e) => setNewPassword(e.target.value),
              className: "pr-10 h-12" ,
              required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 113}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 111}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 109}, this)
        , _jsxDEV('div', { className: "space-y-2", children: [
          _jsxDEV(Label, { htmlFor: "confirm", children: "تکرار رمز عبور"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this)
          , _jsxDEV('div', { className: "relative", children: [
            _jsxDEV(Lock, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      , 'aria-hidden': "true",}, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this )
            , _jsxDEV(Input, {
              id: "confirm",
              type: "password",
              autoComplete: "new-password",
              placeholder: "••••••••",
              value: confirmPassword,
              onChange: (e) => setConfirmPassword(e.target.value),
              className: "pr-10 h-12" ,
              required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 128}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 126}, this)
        , _jsxDEV(Button, { type: "submit", className: "w-full h-12 font-medium"  , disabled: loading, children: 
          loading ? (
            _jsxDEV(_Fragment, { children: [
              _jsxDEV(Loader2, { className: "w-4 h-4 ml-2 animate-spin"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 145}, this ), "در حال بازنشانی..."

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 144}, this)
          ) : (
            "بازنشانی رمز عبور"
          )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 108}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 98}, this)
  );
}