const _jsxFileName = "src/pages/Cash.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _nullishCoalesce(lhs, rhsFn) { if (lhs != null) { return lhs; } else { return rhsFn(); } } function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { useTransactions, useBankAccounts, useSafes, useCreateSafe, useUpdateSafe, useCurrencies, usePostDocument } from '../lib/useSarraaf.js';
import { PageHeader, BalanceCard, TransactionRow, EmptyState, LoadingState } from '../components/sarraaf/Pieces.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
import { CurrencySelect, AmountInput } from '../components/sarraaf/Fields.js';
import { TX_TYPE_LABELS } from '../lib/sarraaf.js';
import { buildTransferLines, buildOpeningBalanceLines } from '../lib/ledgerApi.js';
import { useTreasuryBalances } from '../lib/useSarraaf.js';
import { toast } from '../components/ui/use-toast.js';
import { Banknote, ArrowRightLeft, Plus, Pencil, Loader2 } from 'lucide-react';

export default function Cash() {
  const { data: txs, isLoading } = useTransactions();
  const { data: bankAccounts } = useBankAccounts();
  const { data: safes } = useSafes();
  const { data: currencies } = useCurrencies();
  const postMut = usePostDocument();
  const createSafeMut = useCreateSafe();
  const updateSafeMut = useUpdateSafe();

  const [transferOpen, setTransferOpen] = useState(false);
  const [fromType, setFromType] = useState('cash');
  const [toType, setToType] = useState('bank');
  const [bankId, setBankId] = useState('');
  const [currency, setCurrency] = useState('AFN');
  const [amount, setAmount] = useState(0);
  const [description, setDescription] = useState('');

  const [safeDialogOpen, setSafeDialogOpen] = useState(false);
  const [editingSafe, setEditingSafe] = useState(null);
  const [safeForm, setSafeForm] = useState({ name: '', currency: 'AFN', opening_balance: 0 });

  const { data: treasuryBalances } = useTreasuryBalances();
  const balances = {};
  for (const b of (treasuryBalances || [])) {
    balances[b.currency] = b.balance;
  }
  const cashTxs = (txs || []).filter(t => t.counter_type === 'cash').slice(0, 20);
  const safeList = safes || [];

  const openSafeDialog = (safe = null) => {
    if (safe) {
      setEditingSafe(safe);
      setSafeForm({ name: safe.name, currency: safe.currency, opening_balance: safe.opening_balance || 0 });
    } else {
      setEditingSafe(null);
      setSafeForm({ name: '', currency: 'AFN', opening_balance: 0 });
    }
    setSafeDialogOpen(true);
  };

  const handleSaveSafe = async (e) => {
    e.preventDefault();
    if (!safeForm.name || !safeForm.currency) return;

    // بررسی محدودیت ۴ صندوق (فقط هنگام ایجاد جدید)
    if (!editingSafe && safeList.length >= 4) {
      toast({
        title: 'هشدار',
        description: 'هر صراف نهایتاً می‌تواند ۴ صندوق ایجاد کند.',
        variant: 'destructive',
      });
      return;
    }

    // بررسی ارز تکراری
    const duplicate = safeList.find(s => s.currency === safeForm.currency && s.id !== _optionalChain([editingSafe, 'optionalAccess', _ => _.id]));
    if (duplicate) {
      toast({
        title: 'هشدار',
        description: `صندوقی با ارز ${safeForm.currency} قبلاً ثبت شده است. هر صندوق باید ارز منحصراً فرد داشته باشد.`,
        variant: 'destructive',
      });
      return;
    }

    try {
      if (editingSafe) {
        await updateSafeMut.mutateAsync({ id: editingSafe.id, data: safeForm });
        toast({ title: 'صندوق ویرایش شد' });
      } else {
        const order = safeList.length;
        const created = await createSafeMut.mutateAsync({ ...safeForm, display_order: order, active: true });

        // ثبت سند افتتاح حساب برای موجودی اولیه
        if (safeForm.opening_balance && safeForm.opening_balance > 0) {
          const lines = buildOpeningBalanceLines({
            customer_id: created.id,
            customer_name: safeForm.name,
            currency: safeForm.currency,
            amount: safeForm.opening_balance,
          });
          await postMut.mutateAsync({
            doc_type: 'open_balance',
            currency: safeForm.currency,
            amount: safeForm.opening_balance,
            related_type: 'safe',
            related_id: created.id,
            related_name: safeForm.name,
            description: `افتتاح صندوق ${safeForm.name}`,
            lines,
          });
        }
        toast({ title: 'صندوق ایجاد شد' });
      }
      setSafeDialogOpen(false);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleTransfer = async (e) => {
    e.preventDefault();
    if (!amount || amount <= 0) return;
    const lines = buildTransferLines({
      from_type: fromType, from_id: fromType === 'bank' ? bankId : currency,
      to_type: toType, to_id: toType === 'bank' ? bankId : currency,
      currency, amount,
    });
    try {
      await postMut.mutateAsync({
        doc_type: 'internal_transfer',
        currency,
        amount,
        description: description || 'انتقال داخلی',
        lines,
      });
      toast({ title: 'ثبت شد' });
      setTransferOpen(false);
      setAmount(0);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "صندوق", icon: Banknote,
        actions: 
          _jsxDEV(_Fragment, { children: [
            _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => openSafeDialog(null), children: [_jsxDEV(Plus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 145}, this ), " صندوق جدید"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 145}, this)
            , _jsxDEV(Button, { size: "sm", onClick: () => setTransferOpen(true), children: [_jsxDEV(ArrowRightLeft, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this ), " ثبت جدید"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 146}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 144}, this)
        ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this
      )

      /* کارت‌های صندوق */
      , _jsxDEV('div', { className: "grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4"    , children: 
        safeList.length === 0 ? (
          Object.keys(balances).length === 0 ? (
            _jsxDEV(BalanceCard, { label: "صندوق", amounts: { AFN: 0 },}, void 0, false, {fileName: _jsxFileName, lineNumber: 155}, this )
          ) : (
            Object.entries(balances).map(([cur, val]) => (
              _jsxDEV(BalanceCard, { label: `صندوق ${cur}`, amounts: { [cur]: val },}, cur, false, {fileName: _jsxFileName, lineNumber: 158}, this )
            ))
          )
        ) : (
          safeList.map(safe => {
            const bal = _nullishCoalesce(_nullishCoalesce(balances[safe.currency], () => ( safe.opening_balance)), () => ( 0));
            return (
              _jsxDEV('div', { className: "relative group" , children: [
                _jsxDEV(BalanceCard, { label: safe.name, amounts: { [safe.currency]: bal },}, void 0, false, {fileName: _jsxFileName, lineNumber: 166}, this )
                , _jsxDEV('button', {
                  onClick: () => openSafeDialog(safe),
                  className: "absolute top-2 left-2 p-1 rounded-md bg-muted/50 hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"         ,
 children: 
                  _jsxDEV(Pencil, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 171}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 167}, this)
              ]}, safe.id, true, {fileName: _jsxFileName, lineNumber: 165}, this)
            );
          })
        )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 152}, this)

      , _jsxDEV('h3', { className: "text-sm font-semibold mb-2"  , children: "گردش صندوق" }, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this)
      , isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 180}, this ) : cashTxs.length === 0 ? _jsxDEV(EmptyState, { title: "تراکنشی نیست" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 180}, this ) : (
        _jsxDEV('div', { className: "space-y-1", children: 
          cashTxs.map(tx => _jsxDEV(TransactionRow, { tx: tx, labels: TX_TYPE_LABELS,}, tx.id, false, {fileName: _jsxFileName, lineNumber: 182}, this ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 181}, this)
      )

      /* دیالوگ انتقال داخلی */
      , _jsxDEV(Dialog, { open: transferOpen, onOpenChange: setTransferOpen, children: 
        _jsxDEV(DialogContent, { className: "max-h-[90vh] overflow-y-auto" , children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "انتقال داخلی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 189}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 189}, this)
          , _jsxDEV('form', { onSubmit: handleTransfer, className: "space-y-3", children: [
            _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "مبدأ"}, void 0, false, {fileName: _jsxFileName, lineNumber: 193}, this)
                , _jsxDEV(Select, { value: fromType, onValueChange: setFromType, children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 195}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 195}, this)
                  , _jsxDEV(SelectContent, { children: [_jsxDEV(SelectItem, { value: "cash", children: "صندوق"}, void 0, false, {fileName: _jsxFileName, lineNumber: 196}, this), _jsxDEV(SelectItem, { value: "bank", children: "بانک"}, void 0, false, {fileName: _jsxFileName, lineNumber: 196}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 196}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 194}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 192}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "مقصد"}, void 0, false, {fileName: _jsxFileName, lineNumber: 200}, this)
                , _jsxDEV(Select, { value: toType, onValueChange: setToType, children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 202}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 202}, this)
                  , _jsxDEV(SelectContent, { children: [_jsxDEV(SelectItem, { value: "cash", children: "صندوق"}, void 0, false, {fileName: _jsxFileName, lineNumber: 203}, this), _jsxDEV(SelectItem, { value: "bank", children: "بانک"}, void 0, false, {fileName: _jsxFileName, lineNumber: 203}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 203}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 201}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 199}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 191}, this)
            , (fromType === 'bank' || toType === 'bank') && (
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "حساب بانکی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 209}, this)
                , _jsxDEV(Select, { value: bankId, onValueChange: setBankId, children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, { placeholder: "حساب",}, void 0, false, {fileName: _jsxFileName, lineNumber: 211}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 211}, this)
                  , _jsxDEV(SelectContent, { children: 
                    (bankAccounts || []).map(b => _jsxDEV(SelectItem, { value: b.id, children: b.bank_name}, b.id, false, {fileName: _jsxFileName, lineNumber: 213}, this))
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 212}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 210}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 208}, this)
            )
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "ارز"}, void 0, false, {fileName: _jsxFileName, lineNumber: 220}, this)
                , _jsxDEV(CurrencySelect, { value: currency, onChange: setCurrency, currencies: currencies,}, void 0, false, {fileName: _jsxFileName, lineNumber: 221}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 219}, this)
              , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "مبلغ"}, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this), _jsxDEV(AmountInput, { value: amount, onChange: setAmount,}, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 223}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 218}, this)
            , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "توضیحات"}, void 0, false, {fileName: _jsxFileName, lineNumber: 225}, this), _jsxDEV(Input, { value: description, onChange: e => setDescription(e.target.value),}, void 0, false, {fileName: _jsxFileName, lineNumber: 225}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 225}, this)
            , _jsxDEV(DialogFooter, { children: [
              _jsxDEV(Button, { type: "button", variant: "outline", onClick: () => setTransferOpen(false), children: "پایان"}, void 0, false, {fileName: _jsxFileName, lineNumber: 227}, this)
              , _jsxDEV(Button, { type: "submit", disabled: postMut.isPending, children: postMut.isPending ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 228}, this ) : 'ثبت'}, void 0, false, {fileName: _jsxFileName, lineNumber: 228}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 226}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 190}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 188}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this)

      /* دیالوگ افزودن/ویرایش صندوق */
      , _jsxDEV(Dialog, { open: safeDialogOpen, onOpenChange: setSafeDialogOpen, children: 
        _jsxDEV(DialogContent, { className: "max-h-[90vh] overflow-y-auto" , children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: editingSafe ? 'ویرایش صندوق' : 'صندوق جدید'}, void 0, false, {fileName: _jsxFileName, lineNumber: 237}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 237}, this)
          , _jsxDEV('form', { onSubmit: handleSaveSafe, className: "space-y-3", children: [
            _jsxDEV('div', { children: [_jsxDEV(Label, { children: "نام صندوق" }, void 0, false, {fileName: _jsxFileName, lineNumber: 239}, this), _jsxDEV(Input, { value: safeForm.name, onChange: e => setSafeForm({ ...safeForm, name: e.target.value }), placeholder: "صندوق اصلی" , required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 239}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 239}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "ارز"}, void 0, false, {fileName: _jsxFileName, lineNumber: 241}, this)
              , _jsxDEV(CurrencySelect, {
                value: safeForm.currency,
                onChange: v => setSafeForm({ ...safeForm, currency: v }),
                currencies: currencies,
                disabled: !!editingSafe,}, void 0, false, {fileName: _jsxFileName, lineNumber: 242}, this
              )
              , editingSafe && _jsxDEV('p', { className: "text-xs text-muted-foreground mt-1"  , children: "ارز صندوق پس از ایجاد قابل تغییر نیست"       }, void 0, false, {fileName: _jsxFileName, lineNumber: 248}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 240}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "مبلغ افتتاح صندوق"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 251}, this)
              , _jsxDEV(AmountInput, { value: safeForm.opening_balance, onChange: v => setSafeForm({ ...safeForm, opening_balance: v }), disabled: !!editingSafe,}, void 0, false, {fileName: _jsxFileName, lineNumber: 252}, this )
              , editingSafe && _jsxDEV('p', { className: "text-xs text-muted-foreground mt-1"  , children: "مبلغ افتتاح ثابت است و قابل تغییر نیست"       }, void 0, false, {fileName: _jsxFileName, lineNumber: 253}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 250}, this)
            , _jsxDEV(DialogFooter, { children: [
              _jsxDEV(Button, { type: "button", variant: "outline", onClick: () => setSafeDialogOpen(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 256}, this)
              , _jsxDEV(Button, { type: "submit", disabled: createSafeMut.isPending || updateSafeMut.isPending, children: 
                (createSafeMut.isPending || updateSafeMut.isPending) ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 258}, this ) : 'ذخیره'
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 257}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 255}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 238}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 236}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 235}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 141}, this)
  );
}