const _jsxFileName = "src/pages/Transfer.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { useCustomers, useAgents, useCreateTransfer, useCurrencies } from '../lib/useSarraaf.js';
import { PageHeader } from '../components/sarraaf/Pieces.js';
import { Field, AmountInput, CurrencySelect } from '../components/sarraaf/Fields.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Textarea } from '../components/ui/textarea.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
// Transfer now uses postTransfer directly via useCreateTransfer mutation
import { toast } from '../components/ui/use-toast.js';
import { Send, Loader2 } from 'lucide-react';

export default function Transfer() {
  const { direction } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const customerId = params.get('customer') || '';
  const agentId = params.get('agent') || '';
  const isSend = direction === 'send';

  const { data: customers } = useCustomers();
  const { data: agents } = useAgents();
  const { data: currencies } = useCurrencies();
  const createMut = useCreateTransfer();

  const [customer, setCustomer] = useState(customerId);
  const [senderName, setSenderName] = useState('');
  const [senderPhone, setSenderPhone] = useState('');
  const [receiverName, setReceiverName] = useState('');
  const [receiverPhone, setReceiverPhone] = useState('');
  const [destination, setDestination] = useState('');
  const [currency, setCurrency] = useState('AFN');
  const [amount, setAmount] = useState(0);
  const [rate, setRate] = useState(0);
  const [fee, setFee] = useState(0);
  const [agent, setAgent] = useState(agentId);
  const [description, setDescription] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!customer || !amount) { toast({ title: 'خطا', description: 'مشتری و مبلغ الزامی است', variant: 'destructive' }); return; }
    try {
      const result = await createMut.mutateAsync({
        direction: isSend ? 'send' : 'receive',
        sender_name: senderName, sender_phone: senderPhone,
        receiver_name: receiverName, receiver_phone: receiverPhone,
        destination, amount, currency, rate, fee, description,
      });
      toast({ title: 'ثبت شد', description: `حواله ${result.transfer_number || ''} ثبت شد` });
      navigate('/transfer-book');
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: isSend ? 'حواله ارسال' : 'حواله دریافت', icon: Send,}, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this )
      , _jsxDEV('form', { onSubmit: handleSubmit, className: "space-y-4 max-w-md" , children: [
        _jsxDEV(Field, { label: "مشتری", required: true, children: 
          _jsxDEV(Select, { value: customer, onValueChange: setCustomer, children: [
            _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, { placeholder: "انتخاب مشتری" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this)
            , _jsxDEV(SelectContent, { children: 
              (customers || []).map(c => _jsxDEV(SelectItem, { value: c.id, children: c.name}, c.id, false, {fileName: _jsxFileName, lineNumber: 65}, this))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 62}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this)
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: [
          _jsxDEV(Field, { label: "نام فرستنده" , children: _jsxDEV(Input, { value: senderName, onChange: e => setSenderName(e.target.value),}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)
          , _jsxDEV(Field, { label: "موبایل فرستنده" , children: _jsxDEV(Input, { value: senderPhone, onChange: e => setSenderPhone(e.target.value), inputMode: "numeric",}, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 69}, this)
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: [
          _jsxDEV(Field, { label: "نام گیرنده" , required: true, children: _jsxDEV(Input, { value: receiverName, onChange: e => setReceiverName(e.target.value), required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this)
          , _jsxDEV(Field, { label: "موبایل گیرنده" , children: _jsxDEV(Input, { value: receiverPhone, onChange: e => setReceiverPhone(e.target.value), inputMode: "numeric",}, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 73}, this)
        , _jsxDEV(Field, { label: "مقصد", children: _jsxDEV(Input, { value: destination, onChange: e => setDestination(e.target.value),}, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)
        , _jsxDEV('div', { className: "grid grid-cols-3 gap-2"  , children: [
          _jsxDEV(Field, { label: "ارز", required: true, children: 
            _jsxDEV(CurrencySelect, { value: currency, onChange: setCurrency, currencies: currencies,}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this)
          , _jsxDEV(Field, { label: "مبلغ", required: true, children: _jsxDEV(AmountInput, { value: amount, onChange: setAmount,}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this)
          , _jsxDEV(Field, { label: "نرخ", children: _jsxDEV(AmountInput, { value: rate, onChange: setRate, placeholder: "نرخ",}, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 78}, this)
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: [
          _jsxDEV(Field, { label: "کارمزد", children: _jsxDEV(AmountInput, { value: fee, onChange: setFee,}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this)
          , _jsxDEV(Field, { label: "نماینده", children: 
            _jsxDEV(Select, { value: agent, onValueChange: setAgent, children: [
              _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, { placeholder: "نماینده",}, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this)
              , _jsxDEV(SelectContent, { children: 
                (agents || []).map(a => _jsxDEV(SelectItem, { value: a.id, children: a.name}, a.id, false, {fileName: _jsxFileName, lineNumber: 91}, this))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 88}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 85}, this)
        , _jsxDEV(Field, { label: "توضیحات", children: _jsxDEV(Textarea, { value: description, onChange: e => setDescription(e.target.value), rows: 2,}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this)
        , _jsxDEV(Button, { type: "submit", className: "w-full", disabled: createMut.isPending, children: [
          createMut.isPending ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this ) : _jsxDEV(Send, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this ), "ثبت حواله"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 97}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 60}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 58}, this)
  );
}