const _jsxFileName = "src/pages/ChatGroups.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { useChatGroups, useCreateGroup, useDeleteGroup, useUpdateGroup, useMessageReports } from '../lib/useChat.js';
import { useSarraafProfile } from '../lib/useSarraaf.js';
import { useAuth } from '../lib/AuthContext.js';
import { useNavigate } from 'react-router-dom';
import { canCreatePrivateGroup, canAccessPrivateGroups, getSarraafTier, canCreateGroup, getMaxGroups, getMaxMembers } from '../lib/chat.js';
import { PageHeader, EmptyState, LoadingState } from '../components/sarraaf/Pieces.js';
import GroupCard from '../components/chat/GroupCard.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Textarea } from '../components/ui/textarea.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs.js';
import { toast } from '../components/ui/use-toast.js';
import { Users, Plus, Lock, Globe, ShieldAlert, Crown, Shield, Trash2, Edit2 } from 'lucide-react';

export default function ChatGroups() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { data: profile } = useSarraafProfile(_optionalChain([user, 'optionalAccess', _ => _.id]));
  const { data: groups, isLoading } = useChatGroups();
  const { data: reports } = useMessageReports();
  const createMut = useCreateGroup();
  const deleteMut = useDeleteGroup();
  const updateMut = useUpdateGroup();
  const [showCreate, setShowCreate] = useState(false);
  const [editGroup, setEditGroup] = useState(null);
  const [deleteGroup, setDeleteGroup] = useState(null);
  const [form, setForm] = useState({ name: '', description: '', type: 'public', rules: '' });

  const isSystemAdmin = _optionalChain([user, 'optionalAccess', _2 => _2.role]) === 'creator' || _optionalChain([user, 'optionalAccess', _3 => _3.role]) === 'admin';
  const tier = isSystemAdmin ? 'paid' : getSarraafTier(profile);
  const canPrivate = canCreatePrivateGroup(profile, _optionalChain([user, 'optionalAccess', _4 => _4.role]));
  const canAccessPrivate = canAccessPrivateGroups(profile, _optionalChain([user, 'optionalAccess', _5 => _5.role]));
  const canCreate = canCreateGroup(profile, _optionalChain([user, 'optionalAccess', _6 => _6.role]));
  const maxGroups = getMaxGroups(profile, _optionalChain([user, 'optionalAccess', _7 => _7.role]));
  const maxMembers = getMaxMembers(profile, _optionalChain([user, 'optionalAccess', _8 => _8.role]));

  const allGroups = groups || [];
  const publicGroups = allGroups.filter(g => g.type === 'public' && !g.creator_managed);
  const privateGroups = allGroups.filter(g => g.type === 'private' && !g.creator_managed);
  const systemGroups = allGroups.filter(g => g.creator_managed === true);
  const myGroups = allGroups.filter(g => g.creator_id === _optionalChain([user, 'optionalAccess', _9 => _9.id]));

  // Check group creation limit
  const myGroupCount = myGroups.length;
  const reachedLimit = !isSystemAdmin && myGroupCount >= maxGroups;

  const handleCreate = async () => {
    if (!form.name.trim()) {
      toast({ title: 'خطا', description: 'نام گروه الزامی است', variant: 'destructive' });
      return;
    }
    if (!canCreate) {
      toast({ title: 'دسترسی محدود', description: 'ایجاد گروه فقط برای پلن‌های پولی (پایه و بالاتر) مجاز است. لطفاً اشتراک خود را ارتقا دهید.', variant: 'destructive' });
      return;
    }
    if (reachedLimit) {
      toast({ title: 'سقف گروه‌ها', description: `شما در پلن فعلی نهایتاً ${maxGroups} گروه می‌توانید ایجاد کنید. برای گروه بیشتر، به نسخه بالاتر ارتقا دهید.`, variant: 'destructive' });
      return;
    }
    if (form.type === 'private' && !canPrivate) {
      toast({ title: 'دسترسی محدود', description: 'ایجاد گروه خصوصی فقط برای صرافان نسخه پولی مجاز است', variant: 'destructive' });
      return;
    }
    try {
      await createMut.mutateAsync({
        name: form.name.trim(),
        description: form.description.trim(),
        type: form.type,
        rules: form.rules.trim(),
        creator_id: user.id,
        creator_name: user.full_name || user.email,
        exchange_code: _optionalChain([profile, 'optionalAccess', _10 => _10.code]) || '',
        creator_managed: isSystemAdmin,
        status: 'active',
        member_count: 1,
      });
      toast({ title: 'گروه ایجاد شد', description: 'گروه جدید با موفقیت ایجاد شد' });
      setShowCreate(false);
      setForm({ name: '', description: '', type: 'public', rules: '' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleEdit = (g) => {
    setEditGroup(g);
    setForm({ name: g.name, description: g.description || '', type: g.type, rules: g.rules || '' });
  };

  const handleSaveEdit = async () => {
    if (!editGroup || !form.name.trim()) return;
    try {
      await updateMut.mutateAsync({ id: editGroup.id, data: { name: form.name.trim(), description: form.description.trim(), rules: form.rules.trim() } });
      toast({ title: 'ویرایش شد', description: 'گروه با موفقیت ویرایش شد' });
      setEditGroup(null);
      setForm({ name: '', description: '', type: 'public', rules: '' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleDelete = async () => {
    if (!deleteGroup) return;
    try {
      await deleteMut.mutateAsync(deleteGroup.id);
      toast({ title: 'حذف شد', description: 'گروه و تمام اعضا و پیام‌های آن حذف شد' });
      setDeleteGroup(null);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const canManageGroup = (g) => g.creator_id === _optionalChain([user, 'optionalAccess', _11 => _11.id]) || isSystemAdmin;

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "چت و گروه‌ها"  , icon: Users,}, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this )

      /* Subscription Status Banner */
      , tier === 'trial' && (
        _jsxDEV('div', { className: "mb-4 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-center gap-2"          , children: [
          _jsxDEV(ShieldAlert, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this ), "نسخه رایگان — برای ساخت گروه، نسخه پولی (پایه و بالاتر) را تهیه کنید."

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 125}, this)
      )
      , tier === 'expired' && (
        _jsxDEV('div', { className: "mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs flex items-center gap-2"          , children: [
          _jsxDEV(ShieldAlert, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 132}, this ), "اشتراک منقضی شده — برای استفاده از امکانات صرافی، اشتراک خود را تمدید کنید."

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 131}, this)
      )
      , tier === 'paid' && (
        _jsxDEV('div', { className: "mb-4 p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-800 text-xs flex items-center gap-2"          , children: [
          _jsxDEV(Crown, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this ), "صراف تأییدشده — سقف "
              , maxGroups, " گروه و "   , maxMembers.toLocaleString('fa-IR'), " عضو در هر گروه."
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 137}, this)
      )
      , tier === 'basic' && (
        _jsxDEV('div', { className: "mb-4 p-3 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-800 text-xs flex items-center gap-2"          , children: [
          _jsxDEV(Crown, { className: "w-4 h-4 shrink-0"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this ), "پلن پایه — سقف "
              , maxGroups, " گروه و "   , maxMembers.toLocaleString('fa-IR'), " عضو در هر گروه."
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 143}, this)
      )

      /* Group count indicator for sarraaf */
      , canCreate && !isSystemAdmin && (
        _jsxDEV('div', { className: "mb-3 text-xs text-muted-foreground text-center"   , children: ["گروه‌های شما: "
            , myGroupCount, " از "  , maxGroups
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 151}, this)
      )

      /* Action Bar */
      , _jsxDEV('div', { className: "flex items-center justify-between mb-4"   , children: [
        _jsxDEV('span', { className: "text-sm text-muted-foreground" , children: 
          _optionalChain([reports, 'optionalAccess', _12 => _12.length]) > 0 ? `گزارش‌های در انتظار: ${reports.length}` : ''
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this)
        , canCreate ? (
          _jsxDEV(Button, { size: "sm", onClick: () => setShowCreate(true), disabled: reachedLimit, children: [
            _jsxDEV(Plus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 163}, this ), "ایجاد گروه"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 162}, this)
        ) : (
          _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => navigate('/settings'), children: [
            _jsxDEV(Crown, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this ), "ارتقا به پولی"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 167}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 157}, this)

      , _jsxDEV(Tabs, { defaultValue: "all", className: "w-full", children: [
        _jsxDEV(TabsList, { className: "grid w-full grid-cols-4 mb-4"   , children: [
          _jsxDEV(TabsTrigger, { value: "all", children: "همه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 176}, this)
          , _jsxDEV(TabsTrigger, { value: "public", children: "عمومی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 177}, this)
          , _jsxDEV(TabsTrigger, { value: "private", children: "خصوصی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this)
          , _jsxDEV(TabsTrigger, { value: "my", children: "گروه‌های من" }, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 175}, this)

        , _jsxDEV(TabsContent, { value: "all", className: "space-y-2", children: 
          isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 183}, this ) : allGroups.length === 0 ? (
            _jsxDEV(EmptyState, { icon: Users, title: "گروهی وجود ندارد"  , description: "اولین گروه را ایجاد کنید"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 184}, this )
          ) : (
            allGroups.map(g => (
              _jsxDEV('div', { className: "relative group" , children: [
                _jsxDEV(GroupCard, { group: g, to: `/chat/group/${g.id}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 188}, this )
                , canManageGroup(g) && (
                  _jsxDEV('div', { className: "absolute top-2 left-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity"       , children: [
                    _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-7 w-7 bg-background/80"  , onClick: (e) => { e.preventDefault(); handleEdit(g); }, children: 
                      _jsxDEV(Edit2, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 192}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 191}, this)
                    , _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-7 w-7 bg-background/80 text-destructive"   , onClick: (e) => { e.preventDefault(); setDeleteGroup(g); }, children: 
                      _jsxDEV(Trash2, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 195}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 194}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 190}, this)
                )
              ]}, g.id, true, {fileName: _jsxFileName, lineNumber: 187}, this)
            ))
          )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this)

        , _jsxDEV(TabsContent, { value: "public", className: "space-y-2", children: 
          isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 205}, this ) : publicGroups.length === 0 ? (
            _jsxDEV(EmptyState, { icon: Globe, title: "گروه عمومی وجود ندارد"   , description: "اولین گروه عمومی را ایجاد کنید"     ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 206}, this )
          ) : (
            publicGroups.map(g => (
              _jsxDEV('div', { className: "relative group" , children: [
                _jsxDEV(GroupCard, { group: g, to: `/chat/group/${g.id}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 210}, this )
                , canManageGroup(g) && (
                  _jsxDEV('div', { className: "absolute top-2 left-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity"       , children: [
                    _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-7 w-7 bg-background/80"  , onClick: (e) => { e.preventDefault(); handleEdit(g); }, children: 
                      _jsxDEV(Edit2, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 214}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 213}, this)
                    , _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-7 w-7 bg-background/80 text-destructive"   , onClick: (e) => { e.preventDefault(); setDeleteGroup(g); }, children: 
                      _jsxDEV(Trash2, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 217}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 216}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 212}, this)
                )
              ]}, g.id, true, {fileName: _jsxFileName, lineNumber: 209}, this)
            ))
          )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 204}, this)

        , _jsxDEV(TabsContent, { value: "private", className: "space-y-2", children: 
          !canAccessPrivate ? (
            _jsxDEV(EmptyState, { icon: Lock, title: "دسترسی محدود" , description: "گروه‌های خصوصی فقط برای صرافان نسخه پولی و اشتراک فعال قابل مشاهده است"            ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 228}, this )
          ) : isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 229}, this ) : privateGroups.length === 0 ? (
            _jsxDEV(EmptyState, { icon: Lock, title: "گروه خصوصی وجود ندارد"   , description: "گروه خصوصی صرافان ایجاد کنید"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 230}, this )
          ) : (
            privateGroups.map(g => (
              _jsxDEV('div', { className: "relative group" , children: [
                _jsxDEV(GroupCard, { group: g, to: `/chat/group/${g.id}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 234}, this )
                , canManageGroup(g) && (
                  _jsxDEV('div', { className: "absolute top-2 left-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity"       , children: [
                    _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-7 w-7 bg-background/80"  , onClick: (e) => { e.preventDefault(); handleEdit(g); }, children: 
                      _jsxDEV(Edit2, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 238}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 237}, this)
                    , _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-7 w-7 bg-background/80 text-destructive"   , onClick: (e) => { e.preventDefault(); setDeleteGroup(g); }, children: 
                      _jsxDEV(Trash2, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 241}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 240}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 236}, this)
                )
              ]}, g.id, true, {fileName: _jsxFileName, lineNumber: 233}, this)
            ))
          )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 226}, this)

        , _jsxDEV(TabsContent, { value: "my", className: "space-y-2", children: 
          isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 251}, this ) : myGroups.length === 0 ? (
            _jsxDEV(EmptyState, { icon: Users, title: "گروهی نساخته‌اید" , description: "گروه جدید ایجاد کنید"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 252}, this )
          ) : (
            myGroups.map(g => (
              _jsxDEV('div', { className: "relative group" , children: [
                _jsxDEV(GroupCard, { group: g, to: `/chat/group/${g.id}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 256}, this )
                , _jsxDEV('div', { className: "absolute top-2 left-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity"       , children: [
                  _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-7 w-7 bg-background/80"  , onClick: (e) => { e.preventDefault(); handleEdit(g); }, children: 
                    _jsxDEV(Edit2, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 259}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 258}, this)
                  , _jsxDEV(Button, { size: "icon", variant: "ghost", className: "h-7 w-7 bg-background/80 text-destructive"   , onClick: (e) => { e.preventDefault(); setDeleteGroup(g); }, children: 
                    _jsxDEV(Trash2, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 262}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 261}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 257}, this)
              ]}, g.id, true, {fileName: _jsxFileName, lineNumber: 255}, this)
            ))
          )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 250}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 174}, this)

      /* Create Group Dialog */
      , _jsxDEV(Dialog, { open: showCreate, onOpenChange: setShowCreate, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "ایجاد گروه جدید"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 274}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 274}, this)
          , _jsxDEV('div', { className: "space-y-3", children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نام گروه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 277}, this)
              , _jsxDEV(Input, { value: form.name, onChange: e => setForm({ ...form, name: e.target.value }), placeholder: "نام گروه" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 278}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 276}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "توضیحات"}, void 0, false, {fileName: _jsxFileName, lineNumber: 281}, this)
              , _jsxDEV(Textarea, { value: form.description, onChange: e => setForm({ ...form, description: e.target.value }), placeholder: "توضیحات گروه (اختیاری)"  , rows: 2,}, void 0, false, {fileName: _jsxFileName, lineNumber: 282}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 280}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نوع گروه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 285}, this)
              , _jsxDEV(Select, {
                value: form.type,
                onValueChange: (v) => {
                  if (v === 'private' && !canPrivate) {
                    toast({ title: 'دسترسی محدود', description: 'ایجاد گروه خصوصی فقط برای صرافان نسخه پولی مجاز است', variant: 'destructive' });
                    return;
                  }
                  setForm({ ...form, type: v });
                },
 children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 296}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 296}, this)
                , _jsxDEV(SelectContent, { children: [
                  _jsxDEV(SelectItem, { value: "public", children: "عمومی — مشتریان و صرافان"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 298}, this)
                  , _jsxDEV(SelectItem, { value: "private", disabled: !canPrivate, children: "خصوصی — فقط صرافان"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 299}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 297}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 286}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 284}, this)
            , form.type === 'private' && (
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "قوانین گروه (اختیاری)"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 305}, this)
                , _jsxDEV(Textarea, { value: form.rules, onChange: e => setForm({ ...form, rules: e.target.value }), placeholder: "قوانین گروه" , rows: 3,}, void 0, false, {fileName: _jsxFileName, lineNumber: 306}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 304}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 275}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setShowCreate(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 311}, this)
            , _jsxDEV(Button, { onClick: handleCreate, disabled: createMut.isPending, children: 
              createMut.isPending ? 'در حال ایجاد...' : 'ایجاد گروه'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 312}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 310}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 273}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 272}, this)

      /* Edit Group Dialog */
      , _jsxDEV(Dialog, { open: !!editGroup, onOpenChange: () => setEditGroup(null), children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "ویرایش گروه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 322}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 322}, this)
          , _jsxDEV('div', { className: "space-y-3", children: [
            _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "نام گروه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 325}, this)
              , _jsxDEV(Input, { value: form.name, onChange: e => setForm({ ...form, name: e.target.value }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 326}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 324}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "توضیحات"}, void 0, false, {fileName: _jsxFileName, lineNumber: 329}, this)
              , _jsxDEV(Textarea, { value: form.description, onChange: e => setForm({ ...form, description: e.target.value }), rows: 2,}, void 0, false, {fileName: _jsxFileName, lineNumber: 330}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 328}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "قوانین گروه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 333}, this)
              , _jsxDEV(Textarea, { value: form.rules, onChange: e => setForm({ ...form, rules: e.target.value }), rows: 3,}, void 0, false, {fileName: _jsxFileName, lineNumber: 334}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 332}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 323}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setEditGroup(null), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 338}, this)
            , _jsxDEV(Button, { onClick: handleSaveEdit, disabled: updateMut.isPending, children: 
              updateMut.isPending ? 'در حال ذخیره...' : 'ذخیره تغییرات'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 339}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 337}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 321}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 320}, this)

      /* Delete Group Confirmation */
      , _jsxDEV(Dialog, { open: !!deleteGroup, onOpenChange: () => setDeleteGroup(null), children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "حذف گروه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 349}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 349}, this)
          , _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: ["آیا از حذف گروه «"
                , _optionalChain([deleteGroup, 'optionalAccess', _13 => _13.name]), "» مطمئن هستید؟ تمام اعضا و پیام‌های این گروه حذف خواهند شد."
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 350}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setDeleteGroup(null), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 354}, this)
            , _jsxDEV(Button, { variant: "destructive", onClick: handleDelete, disabled: deleteMut.isPending, children: 
              deleteMut.isPending ? 'در حال حذف...' : 'حذف گروه'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 355}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 353}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 348}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 347}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 120}, this)
  );
}