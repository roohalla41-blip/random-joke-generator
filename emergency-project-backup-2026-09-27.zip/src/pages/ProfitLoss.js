const _jsxFileName = "src/pages/ProfitLoss.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _nullishCoalesce(lhs, rhsFn) { if (lhs != null) { return lhs; } else { return rhsFn(); } }import React, { useMemo } from 'react';
import { useTransactions, useCurrencies, useRateSettings } from '../lib/useSarraaf.js';
import { PageHeader, StatCard, LoadingState, EmptyState } from '../components/sarraaf/Pieces.js';
import { computeProfitDetailed } from '../lib/ledger.js';
import { formatNumber, formatDate, toPersianDigits } from '../lib/sarraaf.js';
import { Card, CardContent } from '../components/ui/card.js';
import { Button } from '../components/ui/button.js';
import { TrendingUp, Printer, FileSpreadsheet, Coins, Percent } from 'lucide-react';

const PRINT_STYLES = `
@media print {
  body * { visibility: hidden; }
  .profit-loss-report, .profit-loss-report * { visibility: visible; }
  .profit-loss-report { position: absolute; left: 0; top: 0; width: 100%; padding: 20px; }
  .no-print { display: none !important; }
  table { width: 100% !important; border-collapse: collapse; }
  tr { page-break-inside: avoid; }
  thead { display: table-header-group; }
}
`;

const TYPE_LABELS = {
  buy: 'خرید ارز',
  sell: 'فروش ارز',
  transfer_send: 'حواله ارسال',
  transfer_receive: 'حواله دریافت',
  convert: 'تبدیل ارز',
  dadogereft: 'دریافت/پرداخت',
  internal_transfer: 'انتقال داخلی',
  manual: 'سند دستی',
  open_balance: 'افتتاح حساب',
};

function exportProfitExcel(data) {
  const { lineItems, byType, byCurrency, totalFee, totalRateDiff, total } = data;
  const rows = [];

  // Section 1: Summary
  rows.push(['گزارش سود و زیان', '']);
  rows.push(['تاریخ تولید', new Date().toLocaleDateString('fa-IR')]);
  rows.push(['', '']);
  rows.push(['خلاصه', 'مبلغ (افغانی)']);
  rows.push(['سود کارمزدها', Math.round(totalFee)]);
  rows.push(['سود اختلاف نرخ', Math.round(totalRateDiff)]);
  rows.push(['سود کل', Math.round(total)]);
  rows.push(['', '']);

  // Section 2: By type
  rows.push(['تفکیک بر اساس نوع تراکنش', '', '']);
  rows.push(['نوع', 'کارمزد', 'اختلاف نرخ', 'تعداد']);
  for (const [type, val] of Object.entries(byType)) {
    rows.push([TYPE_LABELS[type] || type, Math.round(val.fee), Math.round(val.rateDiff), val.count]);
  }
  rows.push(['', '']);

  // Section 3: By currency
  rows.push(['تفکیک بر اساس ارز', '', '']);
  rows.push(['ارز', 'کارمزد', 'اختلاف نرخ', 'تعداد']);
  for (const [cur, val] of Object.entries(byCurrency)) {
    rows.push([cur, Math.round(val.fee), Math.round(val.rateDiff), val.count]);
  }
  rows.push(['', '']);

  // Section 4: Line items
  rows.push(['تراکنش‌های دارای سود', '', '', '', '', '', '', '']);
  rows.push(['تاریخ', 'سند', 'نوع', 'مشتری', 'ارز', 'مبلغ', 'کارمزد (AFN)', 'سود کل (AFN)']);
  for (const item of lineItems) {
    rows.push([
      formatDate(item.date),
      item.document_no,
      TYPE_LABELS[item.type] || item.type,
      item.customer_name,
      item.currency,
      Math.round(item.amount),
      Math.round(item.feeAfn),
      Math.round(item.profit),
    ]);
  }

  const csv = '\uFEFF' + rows.map(r => r.map(c => `"${_nullishCoalesce(c, () => ( ''))}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `profit-loss-${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function ProfitLoss() {
  const { data: txs, isLoading } = useTransactions();
  const { data: currencies } = useCurrencies();
  const { data: rateSettings } = useRateSettings();

  const report = useMemo(() => {
    if (!txs) return null;
    return computeProfitDetailed(txs, rateSettings || {}, currencies || []);
  }, [txs, rateSettings, currencies]);

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV('style', { children: PRINT_STYLES}, void 0, false, {fileName: _jsxFileName, lineNumber: 102}, this)
      , _jsxDEV(PageHeader, { title: "سود و زیان"  , icon: TrendingUp,
        actions: 
          report && (
            _jsxDEV('div', { className: "flex gap-1 no-print"  , children: [
              _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => exportProfitExcel(report), children: 
                _jsxDEV(FileSpreadsheet, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this)
              , _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => window.print(), children: 
                _jsxDEV(Printer, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 106}, this)
          )
        ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this
      )
      , isLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 117}, this ) : !report ? (
        _jsxDEV(EmptyState, { icon: TrendingUp, title: "داده‌ای موجود نیست"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this )
      ) : (
        _jsxDEV('div', { className: "space-y-4 profit-loss-report" , children: [
          /* Summary cards */
          _jsxDEV('div', { className: "grid grid-cols-1 sm:grid-cols-3 gap-3"   , children: [
            _jsxDEV(StatCard, { label: "سود کل" , value: formatNumber(report.total), sub: "AFN", icon: TrendingUp, gradient: "from-success to-success/80" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 123}, this )
            , _jsxDEV(StatCard, { label: "سود اختلاف نرخ"  , value: formatNumber(report.totalRateDiff), sub: "AFN", icon: Percent, gradient: "from-primary to-primary/80" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this )
            , _jsxDEV(StatCard, { label: "کارمزدها", value: formatNumber(report.totalFee), sub: "AFN", icon: Coins, gradient: "from-chart-2 to-chart-2/80" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 122}, this)

          /* By type */
          , _jsxDEV(Card, { children: 
            _jsxDEV(CardContent, { className: "p-4", children: [
              _jsxDEV('h3', { className: "text-sm font-semibold mb-3 text-primary"   , children: "تفکیک بر اساس نوع تراکنش"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 131}, this)
              , _jsxDEV('div', { className: "space-y-1", children: [
                Object.entries(report.byType).map(([type, val]) => (
                  _jsxDEV('div', { className: "flex items-center justify-between text-sm border-b border-border/50 pb-1"      , children: [
                    _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                      _jsxDEV('span', { className: "font-medium", children: TYPE_LABELS[type] || type}, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this)
                      , _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: ["(", toPersianDigits(val.count), " تراکنش)" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 137}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 135}, this)
                    , _jsxDEV('div', { className: "flex items-center gap-3"  , children: [
                      _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: ["کارمزد: " , formatNumber(val.fee)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 140}, this)
                      , _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: ["اختلاف: " , formatNumber(val.rateDiff)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 141}, this)
                      , _jsxDEV('span', { className: "font-bold text-success" , children: formatNumber(val.fee + val.rateDiff)}, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 139}, this)
                  ]}, type, true, {fileName: _jsxFileName, lineNumber: 134}, this)
                ))
                , Object.keys(report.byType).length === 0 && (
                  _jsxDEV('p', { className: "text-sm text-muted-foreground text-center py-4"   , children: "تراکنش سودآوری یافت نشد"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this)
                )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 132}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 130}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this)

          /* By currency */
          , _jsxDEV(Card, { children: 
            _jsxDEV(CardContent, { className: "p-4", children: [
              _jsxDEV('h3', { className: "text-sm font-semibold mb-3 text-primary"   , children: "تفکیک بر اساس ارز"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this)
              , _jsxDEV('div', { className: "space-y-1", children: 
                Object.entries(report.byCurrency).map(([cur, val]) => (
                  _jsxDEV('div', { className: "flex items-center justify-between text-sm border-b border-border/50 pb-1"      , children: [
                    _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                      _jsxDEV('span', { className: "font-medium", children: cur}, void 0, false, {fileName: _jsxFileName, lineNumber: 161}, this)
                      , _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: ["(", toPersianDigits(val.count), " تراکنش)" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 162}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 160}, this)
                    , _jsxDEV('div', { className: "flex items-center gap-3"  , children: [
                      _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: ["کارمزد: " , formatNumber(val.fee)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 165}, this)
                      , _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: ["اختلاف: " , formatNumber(val.rateDiff)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 166}, this)
                      , _jsxDEV('span', { className: "font-bold text-success" , children: formatNumber(val.fee + val.rateDiff)}, void 0, false, {fileName: _jsxFileName, lineNumber: 167}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 164}, this)
                  ]}, cur, true, {fileName: _jsxFileName, lineNumber: 159}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 157}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 155}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 154}, this)

          /* Top profit transactions */
          , _jsxDEV(Card, { children: 
            _jsxDEV(CardContent, { className: "p-4", children: [
              _jsxDEV('h3', { className: "text-sm font-semibold mb-3 text-primary"   , children: "تراکنش‌های پرسود" }, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this)
              , _jsxDEV('div', { className: "space-y-1", children: [
                report.lineItems.slice(0, 20).map((item) => (
                  _jsxDEV('div', { className: "flex items-center justify-between text-sm border-b border-border/50 pb-1"      , children: [
                    _jsxDEV('div', { className: "flex items-center gap-2 min-w-0"   , children: [
                      _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: formatDate(item.date)}, void 0, false, {fileName: _jsxFileName, lineNumber: 183}, this)
                      , _jsxDEV('span', { className: "font-medium truncate" , children: TYPE_LABELS[item.type] || item.type}, void 0, false, {fileName: _jsxFileName, lineNumber: 184}, this)
                      , item.customer_name && _jsxDEV('span', { className: "text-xs text-muted-foreground truncate"  , children: ["— " , item.customer_name]}, void 0, true, {fileName: _jsxFileName, lineNumber: 185}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 182}, this)
                    , _jsxDEV('div', { className: "flex items-center gap-2 shrink-0"   , children: [
                      _jsxDEV('span', { className: "text-xs text-muted-foreground" , children: [item.currency, " " , formatNumber(item.amount)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 188}, this)
                      , _jsxDEV('span', { className: "font-bold text-success" , children: [formatNumber(item.profit), " AFN" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 189}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 187}, this)
                  ]}, item.id, true, {fileName: _jsxFileName, lineNumber: 181}, this)
                ))
                , report.lineItems.length === 0 && (
                  _jsxDEV('p', { className: "text-sm text-muted-foreground text-center py-4"   , children: "تراکنش سودآوری یافت نشد"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 194}, this)
                )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 179}, this)
              , report.lineItems.length > 20 && (
                _jsxDEV('p', { className: "text-xs text-muted-foreground text-center mt-2"   , children: ["نمایش ۲۰ تراکنش اول از "
                       , toPersianDigits(report.lineItems.length), " تراکنش — برای لیست کامل خروجی Excel بگیرید"
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 198}, this)
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 177}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 176}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 120}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 101}, this)
  );
}