const _jsxFileName = "src/pages/ChatGroupDetail.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  useChatGroup, useGroupMembers, useGroupMessages, useIsGroupMember,
  useJoinGroup, useSendMessage, useDeleteMessage, useReportMessage,
  usePendingMembers, useUpdateMemberStatus, useRemoveMember,
  useDeleteGroup, useUpdateGroup, useMessageCooldown,
} from '../lib/useChat.js';
import { useSarraafProfile } from '../lib/useSarraaf.js';
import { useAuth } from '../lib/AuthContext.js';
import { canAccessPrivateGroups, getGroupTypeDisplay, getMemberRole, formatCooldown } from '../lib/chat.js';
import { PageHeader, EmptyState, LoadingState } from '../components/sarraaf/Pieces.js';
import MessageBubble from '../components/chat/MessageBubble.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Textarea } from '../components/ui/textarea.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog.js';
import { toast } from '../components/ui/use-toast.js';
import { useRateSettings } from '../lib/useSarraaf.js';
import { Send, ArrowRight, Users, UserCheck, UserX, Trash2, Flag, Lock, Edit2, Crown } from 'lucide-react';

export default function ChatGroupDetail() {
  const { id: groupId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = useSarraafProfile(_optionalChain([user, 'optionalAccess', _ => _.id]));
  const { data: group } = useChatGroup(groupId);
  const { data: messages, isLoading: msgLoading } = useGroupMessages(groupId);
  const { data: members } = useGroupMembers(groupId);
  const { data: pendingMembers } = usePendingMembers(groupId);
  const { data: isMember } = useIsGroupMember(groupId, _optionalChain([user, 'optionalAccess', _2 => _2.id]));
  const { data: rateSettings } = useRateSettings();

  const joinMut = useJoinGroup();
  const sendMut = useSendMessage();
  const deleteMut = useDeleteMessage();
  const reportMut = useReportMessage();
  const approveMut = useUpdateMemberStatus();
  const removeMut = useRemoveMember();
  const deleteGroupMut = useDeleteGroup();
  const updateGroupMut = useUpdateGroup();

  const [message, setMessage] = useState('');
  const [showMembers, setShowMembers] = useState(false);
  const [reportDialog, setReportDialog] = useState(null);
  const [reportReason, setReportReason] = useState('');
  const [editDialog, setEditDialog] = useState(false);
  const [deleteDialog, setDeleteDialog] = useState(false);
  const [editForm, setEditForm] = useState({ name: '', description: '', rules: '' });
  const messagesEndRef = useRef(null);

  const cooldownRemaining = useMessageCooldown(groupId, _optionalChain([user, 'optionalAccess', _3 => _3.id]), _optionalChain([user, 'optionalAccess', _4 => _4.role]), profile);
  const isRateLimited = cooldownRemaining > 0;

  const ttlKey = _optionalChain([rateSettings, 'optionalAccess', _5 => _5.chat_message_ttl]) || 'never';
  const typeDisplay = group ? getGroupTypeDisplay(group.type) : null;
  const isCreator = _optionalChain([group, 'optionalAccess', _6 => _6.creator_id]) === _optionalChain([user, 'optionalAccess', _7 => _7.id]);
  const isSystemAdmin = _optionalChain([user, 'optionalAccess', _8 => _8.role]) === 'creator' || _optionalChain([user, 'optionalAccess', _9 => _9.role]) === 'admin';
  const canManage = isCreator || isSystemAdmin;
  const canAccessPrivate = canAccessPrivateGroups(profile, _optionalChain([user, 'optionalAccess', _10 => _10.role]));
  const blockedByPrivate = _optionalChain([group, 'optionalAccess', _11 => _11.type]) === 'private' && !canAccessPrivate;

  useEffect(() => {
    _optionalChain([messagesEndRef, 'access', _12 => _12.current, 'optionalAccess', _13 => _13.scrollIntoView, 'call', _14 => _14({ behavior: 'smooth' })]);
  }, [messages]);

  const handleJoin = async () => {
    if (!group) return;
    try {
      await joinMut.mutateAsync({ group, user, userRole: user.role, profile });
      toast({ title: 'عضویت', description: group.type === 'private' ? 'درخواست عضویت ارسال شد' : 'به گروه پیوستید' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleSend = async () => {
    if (!message.trim() || !group) return;
    if (!isMember) {
      toast({ title: 'خطا', description: 'ابتدا به گروه بپیوندید', variant: 'destructive' });
      return;
    }
    try {
      await sendMut.mutateAsync({ group, user, userRole: user.role, profile, message: message.trim(), ttlKey });
      setMessage('');
    } catch (err) {
      if (_optionalChain([err, 'access', _15 => _15.message, 'optionalAccess', _16 => _16.startsWith, 'call', _17 => _17('rate_limited:')])) {
        const seconds = parseInt(err.message.split(':')[1]) || 0;
        toast({ title: 'محدودیت ارسال', description: `لطفاً ${formatCooldown(seconds)} صبر کنید`, variant: 'destructive' });
      } else {
        toast({ title: 'خطا', description: err.message, variant: 'destructive' });
      }
    }
  };

  const handleDelete = async (msg) => {
    try {
      await deleteMut.mutateAsync(msg.id);
      toast({ title: 'حذف شد', description: 'پیام حذف شد' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleReport = async () => {
    if (!reportDialog || !reportReason.trim()) return;
    try {
      await reportMut.mutateAsync({ message: reportDialog, reporter: user, reason: reportReason.trim() });
      toast({ title: 'گزارش ارسال شد', description: 'پیام به مدیران گزارش شد' });
      setReportDialog(null);
      setReportReason('');
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleApproveMember = async (memberId, status) => {
    try {
      await approveMut.mutateAsync({ id: memberId, status, groupId, currentCount: _optionalChain([group, 'optionalAccess', _18 => _18.member_count]) || 0 });
      toast({ title: status === 'active' ? 'تأیید شد' : 'رد شد' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleRemoveMember = async (memberId) => {
    try {
      await removeMut.mutateAsync({ id: memberId, groupId, currentCount: _optionalChain([group, 'optionalAccess', _19 => _19.member_count]) || 0 });
      toast({ title: 'حذف شد', description: 'عضو از گروه حذف شد' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleEditGroup = async () => {
    if (!editForm.name.trim()) return;
    try {
      await updateGroupMut.mutateAsync({ id: groupId, data: { name: editForm.name.trim(), description: editForm.description.trim(), rules: editForm.rules.trim() } });
      toast({ title: 'ویرایش شد', description: 'گروه با موفقیت ویرایش شد' });
      setEditDialog(false);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleDeleteGroup = async () => {
    try {
      await deleteGroupMut.mutateAsync(groupId);
      toast({ title: 'حذف شد', description: 'گروه حذف شد' });
      navigate('/chat');
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  if (!group) return _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this );

  if (blockedByPrivate) {
    return (
      _jsxDEV(_Fragment, { children: [
        _jsxDEV(PageHeader, { title: group.name, icon: Lock, actions: _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => navigate('/chat'), children: [_jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 161}, this ), " بازگشت" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 161}, this),}, void 0, false, {fileName: _jsxFileName, lineNumber: 161}, this )
        , _jsxDEV(EmptyState, {
          icon: Lock,
          title: "دسترسی محدود" ,
          description: "این گروه خصوصی فقط برای صرافان نسخه پولی و اشتراک فعال قابل مشاهده است"             ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 162}, this
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 160}, this)
    );
  }

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, {
        title: group.name,
        subtitle: _optionalChain([typeDisplay, 'optionalAccess', _20 => _20.label]),
        icon: group.type === 'private' ? Lock : Users,
        actions: 
          _jsxDEV('div', { className: "flex items-center gap-1"  , children: [
            canManage && (
              _jsxDEV(_Fragment, { children: [
                _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => { setEditForm({ name: group.name, description: group.description || '', rules: group.rules || '' }); setEditDialog(true); }, children: 
                  _jsxDEV(Edit2, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 181}, this)
                , _jsxDEV(Button, { size: "sm", variant: "ghost", className: "text-destructive", onClick: () => setDeleteDialog(true), children: 
                  _jsxDEV(Trash2, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 185}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 184}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 180}, this)
            )
            , _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => navigate('/chat'), children: [_jsxDEV(ArrowRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 189}, this ), " بازگشت" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 189}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 178}, this)
        ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 173}, this
      )

      /* Group Info */
      , group.description && (
        _jsxDEV('p', { className: "text-xs text-muted-foreground mb-3 px-1"   , children: group.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 196}, this)
      )

      /* Creator badge */
      , group.creator_managed && (
        _jsxDEV('div', { className: "mb-3 flex items-center gap-1.5 px-2 py-1 rounded-lg bg-primary/5 text-primary text-[10px] font-medium"          , children: [
          _jsxDEV(Crown, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 202}, this ), "گروه سیستمی — مدیریت توسط سازنده"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 201}, this)
      )
      , !group.creator_managed && group.creator_name && (
        _jsxDEV('div', { className: "mb-3 text-[10px] text-muted-foreground px-1"   , children: ["ایجاد شده توسط: "
             , group.creator_name
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 207}, this)
      )

      /* Join Button */
      , !isMember && (
        _jsxDEV('div', { className: "mb-4", children: 
          _jsxDEV(Button, { className: "w-full", onClick: handleJoin, disabled: joinMut.isPending, children: [
            _jsxDEV(UserCheck, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 216}, this )
            , group.type === 'private' ? 'درخواست عضویت' : 'پیوستن به گروه'
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 215}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 214}, this)
      )

      /* Pending Members (creator only) */
      , canManage && pendingMembers && pendingMembers.length > 0 && (
        _jsxDEV('div', { className: "mb-4 p-3 rounded-xl border bg-amber-50"    , children: [
          _jsxDEV('p', { className: "text-xs font-bold text-amber-800 mb-2"   , children: ["درخواست‌های عضویت ("  , pendingMembers.length, ")"]}, void 0, true, {fileName: _jsxFileName, lineNumber: 225}, this)
          , pendingMembers.map(m => (
            _jsxDEV('div', { className: "flex items-center justify-between py-1"   , children: [
              _jsxDEV('span', { className: "text-xs", children: m.user_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 228}, this)
              , _jsxDEV('div', { className: "flex gap-1" , children: [
                _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => handleApproveMember(m.id, 'active'), children: [
                  _jsxDEV(UserCheck, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 231}, this ), " تأیید"
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 230}, this)
                , _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => handleApproveMember(m.id, 'rejected'), children: [
                  _jsxDEV(UserX, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 234}, this ), " رد"
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 233}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 229}, this)
            ]}, m.id, true, {fileName: _jsxFileName, lineNumber: 227}, this)
          ))
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 224}, this)
      )

      /* Messages */
      , _jsxDEV('div', { className: "space-y-2 mb-4 min-h-[200px]"  , children: [
        msgLoading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 244}, this ) : !messages || messages.length === 0 ? (
          _jsxDEV(EmptyState, { icon: Send, title: "پیامی نیست" , description: "اولین پیام را ارسال کنید"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 245}, this )
        ) : (
          messages.map(msg => (
            _jsxDEV(MessageBubble, {

              message: msg,
              onDelete: canManage ? handleDelete : undefined,
              onReport: handleReport ? () => setReportDialog(msg) : undefined,
              showActions: isMember,}, msg.id, false, {fileName: _jsxFileName, lineNumber: 248}, this
            )
          ))
        )
        , _jsxDEV('div', { ref: messagesEndRef,}, void 0, false, {fileName: _jsxFileName, lineNumber: 257}, this )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 243}, this)

      /* Message Input */
      , isMember && (
        _jsxDEV('div', { className: "fixed bottom-[52px] lg:bottom-0 left-0 right-0 z-40 bg-background border-t p-3"        , children: [
          isRateLimited && (
            _jsxDEV('div', { className: "max-w-5xl mx-auto mb-2 text-center text-xs text-amber-600 bg-amber-50 rounded-lg py-1"        , children: ["⏳ لطفاً "
                , formatCooldown(cooldownRemaining), " برای ارسال پیام بعدی صبر کنید"
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 264}, this)
          )
          , _jsxDEV('div', { className: "max-w-5xl mx-auto flex items-center gap-2"    , children: [
            _jsxDEV(Input, {
              value: message,
              onChange: e => setMessage(e.target.value),
              onKeyDown: e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } },
              placeholder: isRateLimited ? 'در حال انتظار...' : 'پیام خود را بنویسید...',
              className: "flex-1",
              disabled: isRateLimited,}, void 0, false, {fileName: _jsxFileName, lineNumber: 269}, this
            )
            , _jsxDEV(Button, { size: "icon", onClick: handleSend, disabled: sendMut.isPending || !message.trim() || isRateLimited, children: 
              _jsxDEV(Send, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 278}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 277}, this)
            , _jsxDEV(Button, { size: "icon", variant: "outline", onClick: () => setShowMembers(!showMembers), children: 
              _jsxDEV(Users, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 281}, this )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 280}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 268}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 262}, this)
      )

      /* Members Panel — visible to all members */
      , showMembers && (
        _jsxDEV('div', { className: "fixed inset-0 z-50 bg-black/50 flex items-end"     , onClick: () => setShowMembers(false), children: 
          _jsxDEV('div', { className: "bg-background w-full rounded-t-2xl p-4 max-h-[60vh] overflow-y-auto"     , onClick: e => e.stopPropagation(), children: [
            _jsxDEV('div', { className: "flex items-center justify-between mb-3"   , children: [
              _jsxDEV('h3', { className: "font-bold text-sm" , children: ["اعضای گروه ("  , _optionalChain([members, 'optionalAccess', _21 => _21.length]) || 0, ")"]}, void 0, true, {fileName: _jsxFileName, lineNumber: 292}, this)
              , _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => setShowMembers(false), children: "بستن"}, void 0, false, {fileName: _jsxFileName, lineNumber: 293}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 291}, this)
            , _optionalChain([members, 'optionalAccess', _22 => _22.map, 'call', _23 => _23(m => (
              _jsxDEV('div', { className: "flex items-center justify-between py-2 border-b"    , children: [
                _jsxDEV('div', { className: "min-w-0", children: [
                  _jsxDEV('p', { className: "text-sm font-medium truncate"  , children: m.user_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 298}, this)
                  , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: [
                    m.role === 'admin' ? 'مدیر گروه' : 'عضو', " — "  , m.user_role === 'sarraaf_verified' ? 'صراف' : m.user_role === 'customer' ? 'مشتری' : m.user_role === 'admin' ? 'مدیر سیستم' : 'صراف'
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 299}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 297}, this)
                , canManage && (
                  _jsxDEV(Button, { size: "sm", variant: "ghost", className: "text-destructive", onClick: () => handleRemoveMember(m.id), children: 
                    _jsxDEV(Trash2, { className: "w-3 h-3" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 305}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 304}, this)
                )
              ]}, m.id, true, {fileName: _jsxFileName, lineNumber: 296}, this)
            ))])
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 290}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 289}, this)
      )

      /* Edit Group Dialog */
      , _jsxDEV(Dialog, { open: editDialog, onOpenChange: setEditDialog, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "ویرایش گروه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 317}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 317}, this)
          , _jsxDEV('div', { className: "space-y-3", children: [
            _jsxDEV('div', { children: [
              _jsxDEV('label', { className: "text-xs", children: "نام گروه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 320}, this)
              , _jsxDEV(Input, { value: editForm.name, onChange: e => setEditForm({ ...editForm, name: e.target.value }),}, void 0, false, {fileName: _jsxFileName, lineNumber: 321}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 319}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('label', { className: "text-xs", children: "توضیحات"}, void 0, false, {fileName: _jsxFileName, lineNumber: 324}, this)
              , _jsxDEV(Textarea, { value: editForm.description, onChange: e => setEditForm({ ...editForm, description: e.target.value }), rows: 2,}, void 0, false, {fileName: _jsxFileName, lineNumber: 325}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 323}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV('label', { className: "text-xs", children: "قوانین گروه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 328}, this)
              , _jsxDEV(Textarea, { value: editForm.rules, onChange: e => setEditForm({ ...editForm, rules: e.target.value }), rows: 3,}, void 0, false, {fileName: _jsxFileName, lineNumber: 329}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 327}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 318}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setEditDialog(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 333}, this)
            , _jsxDEV(Button, { onClick: handleEditGroup, disabled: updateGroupMut.isPending, children: 
              updateGroupMut.isPending ? 'در حال ذخیره...' : 'ذخیره'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 334}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 332}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 316}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 315}, this)

      /* Delete Group Dialog */
      , _jsxDEV(Dialog, { open: deleteDialog, onOpenChange: setDeleteDialog, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "حذف گروه" }, void 0, false, {fileName: _jsxFileName, lineNumber: 344}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 344}, this)
          , _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: ["آیا از حذف گروه «"
                , group.name, "» مطمئن هستید؟ تمام اعضا و پیام‌ها حذف خواهند شد."
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 345}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setDeleteDialog(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 349}, this)
            , _jsxDEV(Button, { variant: "destructive", onClick: handleDeleteGroup, disabled: deleteGroupMut.isPending, children: 
              deleteGroupMut.isPending ? 'در حال حذف...' : 'حذف گروه'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 350}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 348}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 343}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 342}, this)

      /* Report Dialog */
      , _jsxDEV(Dialog, { open: !!reportDialog, onOpenChange: () => setReportDialog(null), children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "گزارش پیام نامناسب"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 360}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 360}, this)
          , _jsxDEV('div', { className: "space-y-3", children: [
            reportDialog && (
              _jsxDEV('div', { className: "p-2 rounded-lg bg-muted text-xs"   , children: [
                _jsxDEV('p', { className: "font-medium", children: [reportDialog.sender_name, ":"]}, void 0, true, {fileName: _jsxFileName, lineNumber: 364}, this)
                , _jsxDEV('p', { className: "text-muted-foreground", children: reportDialog.message}, void 0, false, {fileName: _jsxFileName, lineNumber: 365}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 363}, this)
            )
            , _jsxDEV('div', { children: [
              _jsxDEV('label', { className: "text-xs", children: "دلیل گزارش" }, void 0, false, {fileName: _jsxFileName, lineNumber: 369}, this)
              , _jsxDEV(Textarea, {
                value: reportReason,
                onChange: e => setReportReason(e.target.value),
                placeholder: "دلیل گزارش را شرح دهید"    ,
                rows: 3,}, void 0, false, {fileName: _jsxFileName, lineNumber: 370}, this
              )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 368}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 361}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setReportDialog(null), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 379}, this)
            , _jsxDEV(Button, { variant: "destructive", onClick: handleReport, disabled: !reportReason.trim() || reportMut.isPending, children: [
              _jsxDEV(Flag, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 381}, this ), "ارسال گزارش"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 380}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 378}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 359}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 358}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 172}, this)
  );
}