const _jsxFileName = "src/pages/Receipt.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useTransactions, useTransfers } from '../lib/useSarraaf.js';
import { PageHeader, LoadingState } from '../components/sarraaf/Pieces.js';
import { Button } from '../components/ui/button.js';
import { formatDate, formatNumber, TX_TYPE_LABELS, TRANSFER_STATUS_LABELS } from '../lib/sarraaf.js';
import { Receipt as ReceiptIcon, Printer, Coins } from 'lucide-react';

export default function Receipt() {
  const [params] = useSearchParams();
  const type = params.get('type');
  const id = params.get('id');
  const { data: txs, isLoading: txLoading } = useTransactions();
  const { data: transfers, isLoading: transferLoading } = useTransfers();
  const [data, setData] = useState(null);
  const [checked, setChecked] = useState(false);

  const isTxLoading = type === 'tx' ? txLoading : transferLoading;

  useEffect(() => {
    if (type === 'tx' && txs) {
      setData(txs.find(t => t.id === id) || null);
      setChecked(true);
    } else if (type === 'transfer' && transfers) {
      setData(transfers.find(t => t.id === id) || null);
      setChecked(true);
    } else if (type && id && !isTxLoading && txs === undefined && transfers === undefined) {
      setChecked(true);
    }
  }, [type, id, txs, transfers, isTxLoading]);

  const loading = isTxLoading || (!checked && !!id);
  const notFound = checked && !data;

  if (loading) return _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 35}, this );
  if (notFound) {
    return (
      _jsxDEV(_Fragment, { children: [
        _jsxDEV(PageHeader, { title: "رسید", icon: ReceiptIcon,
          actions: _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => window.history.back(), children: "بازگشت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 40}, this),}, void 0, false, {fileName: _jsxFileName, lineNumber: 39}, this
        )
        , _jsxDEV('div', { className: "max-w-md mx-auto p-8 text-center border rounded-xl bg-card"      , children: [
          _jsxDEV(ReceiptIcon, { className: "w-12 h-12 mx-auto text-muted-foreground/40 mb-3"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 43}, this )
          , _jsxDEV('p', { className: "text-sm font-medium text-muted-foreground"  , children: "رسید یافت نشد"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 44}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground/70 mt-1"  , children: "رسید مورد نظر وجود ندارد یا حذف شده است."        }, void 0, false, {fileName: _jsxFileName, lineNumber: 45}, this)
          , _jsxDEV(Button, { size: "sm", variant: "outline", className: "mt-4", onClick: () => window.history.back(), children: "بازگشت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 46}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 42}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 38}, this)
    );
  }

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "رسید", icon: ReceiptIcon,
        actions: _jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => window.print(), children: [_jsxDEV(Printer, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this ), " چاپ" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 55}, this),}, void 0, false, {fileName: _jsxFileName, lineNumber: 54}, this
      )
      , _jsxDEV('div', { className: "max-w-md mx-auto p-4 border rounded-xl bg-card space-y-3"      , children: 
        type === 'tx' ? (
          _jsxDEV(_Fragment, { children: [
            _jsxDEV('div', { className: "text-center pb-3 border-b"  , children: [
              _jsxDEV('div', { className: "inline-flex w-12 h-12 rounded-xl bg-primary items-center justify-center mb-2"       , children: 
                _jsxDEV(Coins, { className: "w-6 h-6 text-primary-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this)
              , _jsxDEV('h3', { className: "text-sm font-bold" , children: "رسید تراکنش" }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 60}, this)
            , _jsxDEV(Row, { label: "نوع", value: TX_TYPE_LABELS[data.type] || data.type,}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this )
            , _jsxDEV(Row, { label: "تاریخ", value: formatDate(data.date),}, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this )
            , _jsxDEV(Row, { label: "شماره سند" , value: data.document_no || '—',}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this )
            , _jsxDEV(Row, { label: "مبلغ", value: `${formatNumber(data.amount, 2)} ${data.currency}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this )
            , data.description && _jsxDEV(Row, { label: "توضیحات", value: data.description,}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 59}, this)
        ) : (
          _jsxDEV(_Fragment, { children: [
            _jsxDEV('div', { className: "text-center pb-3 border-b"  , children: [
              _jsxDEV('div', { className: "inline-flex w-12 h-12 rounded-xl bg-primary items-center justify-center mb-2"       , children: 
                _jsxDEV(Coins, { className: "w-6 h-6 text-primary-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
              , _jsxDEV('h3', { className: "text-sm font-bold" , children: "رسید حواله" }, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 74}, this)
            , _jsxDEV(Row, { label: "شماره حواله" , value: data.transfer_no || '—',}, void 0, false, {fileName: _jsxFileName, lineNumber: 80}, this )
            , _jsxDEV(Row, { label: "نوع", value: data.direction === 'send' ? 'ارسال' : 'دریافت',}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this )
            , _jsxDEV(Row, { label: "گیرنده", value: data.receiver_name || '—',}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this )
            , _jsxDEV(Row, { label: "موبایل گیرنده" , value: data.receiver_phone || '—',}, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this )
            , _jsxDEV(Row, { label: "مبلغ", value: `${formatNumber(data.amount)} ${data.currency}`,}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this )
            , _jsxDEV(Row, { label: "وضعیت", value: TRANSFER_STATUS_LABELS[data.status] || data.status,}, void 0, false, {fileName: _jsxFileName, lineNumber: 85}, this )
            , _jsxDEV(Row, { label: "تاریخ", value: formatDate(data.created_date),}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 73}, this)
        )
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 57}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 53}, this)
  );
}

function Row({ label, value }) {
  return (
    _jsxDEV('div', { className: "flex items-center justify-between text-sm"   , children: [
      _jsxDEV('span', { className: "text-muted-foreground", children: label}, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)
      , _jsxDEV('span', { className: "font-medium", children: value}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 96}, this)
  );
}