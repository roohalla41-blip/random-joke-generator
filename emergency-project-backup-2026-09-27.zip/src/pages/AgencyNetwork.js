const _jsxFileName = "src/pages/AgencyNetwork.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { useAuth } from '../lib/AuthContext.js';
import { useSarraafProfile } from '../lib/useSarraaf.js';
import { offlineDB } from '../lib/offlineQueue.js';
import { PageHeader, EmptyState, LoadingState, StatusBadge } from '../components/sarraaf/Pieces.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog.js';
import { toast } from '../components/ui/use-toast.js';
import { Share2, Plus, Copy } from 'lucide-react';

export default function AgencyNetwork() {
  const { user } = useAuth();
  const { data: profile, isLoading } = useSarraafProfile(_optionalChain([user, 'optionalAccess', _ => _.id]));
  const [dialogOpen, setDialogOpen] = useState(false);
  const [links, setLinks] = useState([]);
  const [form, setForm] = useState({ target_code: '', city: '', request_note: '' });

  React.useEffect(() => {
    if (user) loadLinks();
  }, [user]);

  const loadLinks = async () => {
    try {
      const all = await offlineDB.AgencyLink.list('-created_date', 500);
      setLinks(all.filter(l => l.requester_user_id === user.id || l.target_user_id === user.id));
    } catch (e2) {}
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!profile || !form.target_code) return;
    try {
      await offlineDB.AgencyLink.create({
        requester_profile_id: profile.id,
        requester_user_id: user.id,
        requester_code: profile.code,
        requester_name: profile.name,
        requester_exchange_name: profile.exchange_name,
        requester_phone: profile.phone,
        target_code: form.target_code,
        status: 'pending',
        city: form.city,
        request_note: form.request_note,
      });
      toast({ title: 'درخواست ارسال شد' });
      setDialogOpen(false);
      loadLinks();
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const copyCode = () => {
    navigator.clipboard.writeText(_optionalChain([profile, 'optionalAccess', _2 => _2.code]) || '');
    toast({ title: 'کپی شد' });
  };

  if (isLoading) return _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 60}, this );

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "شبکه نمایندگی" , icon: Share2,
        actions: _jsxDEV(Button, { size: "sm", onClick: () => setDialogOpen(true), children: [_jsxDEV(Plus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 65}, this ), " افزودن" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this),}, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this
      )
      , _jsxDEV('div', { className: "p-3 rounded-xl border bg-card mb-4 flex items-center justify-between"       , children: [
        _jsxDEV('div', { children: [
          _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "کد نمایندگی شما"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this)
          , _jsxDEV('p', { className: "text-lg font-bold" , children: _optionalChain([profile, 'optionalAccess', _3 => _3.code]) || '—'}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 68}, this)
        , _jsxDEV(Button, { size: "icon", variant: "outline", onClick: copyCode, children: _jsxDEV(Copy, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 72}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 67}, this)

      , _jsxDEV('h3', { className: "text-sm font-semibold mb-2"  , children: "درخواست‌ها و اتصالات"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
      , links.length === 0 ? _jsxDEV(EmptyState, { icon: Share2, title: "اتصالی نیست" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          links.map(l => (
            _jsxDEV('div', { className: "p-3 rounded-xl border bg-card"   , children: [
              _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
                _jsxDEV('span', { className: "text-sm font-medium" , children: l.requester_code === _optionalChain([profile, 'optionalAccess', _4 => _4.code]) ? l.target_name : l.requester_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
                , _jsxDEV(StatusBadge, { status: l.status, labels: { pending: 'در انتظار', active: 'فعال', rejected: 'رد شده' },}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 80}, this)
              , l.city && _jsxDEV('p', { className: "text-xs text-muted-foreground mt-1"  , children: ["شهر: " , l.city]}, void 0, true, {fileName: _jsxFileName, lineNumber: 84}, this)
            ]}, l.id, true, {fileName: _jsxFileName, lineNumber: 79}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 77}, this)
      )

      , _jsxDEV(Dialog, { open: dialogOpen, onOpenChange: setDialogOpen, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: _jsxDEV(DialogTitle, { children: "افزودن نمایندگی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 92}, this)}, void 0, false, {fileName: _jsxFileName, lineNumber: 92}, this)
          , _jsxDEV('form', { onSubmit: handleAdd, className: "space-y-3", children: [
            _jsxDEV('div', { children: [_jsxDEV(Label, { children: "کد صرافی مقصد"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this), _jsxDEV(Input, { value: form.target_code, onChange: e => setForm({...form, target_code: e.target.value}), required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 94}, this)
            , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "شهر"}, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this), _jsxDEV(Input, { value: form.city, onChange: e => setForm({...form, city: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)
            , _jsxDEV('div', { children: [_jsxDEV(Label, { children: "پیام"}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this), _jsxDEV(Input, { value: form.request_note, onChange: e => setForm({...form, request_note: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this )]}, void 0, true, {fileName: _jsxFileName, lineNumber: 96}, this)
            , _jsxDEV(DialogFooter, { children: [
              _jsxDEV(Button, { type: "button", variant: "outline", onClick: () => setDialogOpen(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)
              , _jsxDEV(Button, { type: "submit", children: "ارسال درخواست" }, void 0, false, {fileName: _jsxFileName, lineNumber: 99}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 97}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 93}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 91}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 63}, this)
  );
}