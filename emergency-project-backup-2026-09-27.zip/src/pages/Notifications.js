const _jsxFileName = "src/pages/Notifications.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { useAuth } from '../lib/AuthContext.js';
import { offlineDB } from '../lib/offlineQueue.js';
import { PageHeader, EmptyState, LoadingState } from '../components/sarraaf/Pieces.js';
import { Bell, CheckCheck, Download, ExternalLink } from 'lucide-react';
import { Button } from '../components/ui/button.js';
import { toast } from '../components/ui/use-toast.js';

export default function Notifications() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const list = await offlineDB.UserNotification.list('-created_date', 100);
        const mine = list.filter(n =>
          n.target_user_id === _optionalChain([user, 'optionalAccess', _ => _.id]) ||
          n.target_role === 'all' ||
          n.target_role === _optionalChain([user, 'optionalAccess', _2 => _2.role])
        );
        if (!cancelled) setNotifications(mine);
      } catch (e) {
        // ignore
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [_optionalChain([user, 'optionalAccess', _3 => _3.id])]);

  const markRead = async (id) => {
    try {
      await offlineDB.UserNotification.update(id, { read: true });
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    } catch (e2) {
      // ignore
    }
  };

  const markAllRead = async () => {
    const unread = notifications.filter(n => !n.read);
    for (const n of unread) {
      await offlineDB.UserNotification.update(n.id, { read: true });
    }
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    toast({ title: 'همه خوانده شد' });
  };

  const kindLabel = (kind) => {
    const map = {
      paid_purchase: 'خرید نسخه پولی',
      paid_activated: 'فعال شدن نسخه پولی',
      paid_expired: 'پایان اعتبار',
      general: 'اطلاعیه',
      account_limitation: 'محدودیت حساب',
      feature_toggle: 'تغییر قابلیت',
      app_update: 'آپدیت برنامه',
      custom: 'پیام',
    };
    return map[kind] || 'پیام';
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, {
        title: "اعلان‌ها",
        icon: Bell,
        actions: 
          notifications.some(n => !n.read) ? (
            _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: markAllRead, children: [
              _jsxDEV(CheckCheck, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 74}, this ), "خواندن همه"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 73}, this)
          ) : undefined
        ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this
      )

      , loading ? _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this ) : notifications.length === 0 ? (
        _jsxDEV(EmptyState, { icon: Bell, title: "اعلانی نیست" , description: "پیام جدیدی وجود ندارد"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this )
      ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          notifications.map(n => (
            _jsxDEV('div', {

              className: `p-3 rounded-xl border ${n.read ? 'bg-background' : 'bg-primary/5 border-primary/20'}`,
 children: 
              _jsxDEV('div', { className: "flex items-start justify-between gap-2"   , children: [
                _jsxDEV('div', { className: "min-w-0 flex-1" , children: [
                  _jsxDEV('div', { className: "flex items-center gap-2 mb-1"   , children: [
                    _jsxDEV('span', { className: "text-[10px] px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground"     , children: 
                      kindLabel(n.kind)
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this)
                    , !n.read && _jsxDEV('span', { className: "w-2 h-2 rounded-full bg-primary"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 92}, this)
                  , _jsxDEV('p', { className: "text-sm font-medium" , children: n.title}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)
                  , _jsxDEV('p', { className: "text-xs text-muted-foreground mt-1"  , children: n.message}, void 0, false, {fileName: _jsxFileName, lineNumber: 99}, this)
                  , n.sent_by_name && (
                    _jsxDEV('p', { className: "text-[10px] text-muted-foreground mt-1"  , children: ["از: " , n.sent_by_name]}, void 0, true, {fileName: _jsxFileName, lineNumber: 101}, this)
                  )
                  , n.action_url && (
                    _jsxDEV('a', {
                      href: n.action_url,
                      target: "_blank",
                      rel: "noreferrer",
                      className: "inline-flex items-center gap-1.5 mt-2 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-medium hover:bg-primary/90 transition-colors"            ,
 children: [
                      _jsxDEV(Download, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this )
                      , n.action_label || 'مشاهده لینک'
                      , _jsxDEV(ExternalLink, { className: "w-3 h-3 opacity-70"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this )
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 104}, this)
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 91}, this)
                , !n.read && (
                  _jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => markRead(n.id), children: 
                    _jsxDEV(CheckCheck, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this )
                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 117}, this)
                )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 90}, this)
            }, n.id, false, {fileName: _jsxFileName, lineNumber: 86}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this)
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 67}, this)
  );
}