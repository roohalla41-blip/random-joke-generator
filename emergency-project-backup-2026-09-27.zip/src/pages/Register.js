const _jsxFileName = "src/pages/Register.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { callSupabase } from '../lib/supabaseApi.js';
import { useAuth } from '../lib/AuthContext.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs.js';
import { cacheCredentialsForOffline } from '../lib/credentialCache.js';
import { initiateGoogleLogin } from '../lib/googleAuth.js';
import { processReferral } from '../lib/referralSystem.js';
import GoogleIcon from '../components/GoogleIcon.js';
import BrandMark from '../components/BrandMark.js';
import { ArrowLeft, User, Lock, Mail, Store, Phone, MapPin, UserCircle, ShieldCheck, Send, Loader2, WifiOff, Gift } from 'lucide-react';

const ERRORS = {
  missing_fields: 'لطفاً تمام فیلدهای ضروری را پر کنید',
  mobile_exists: 'این شماره موبایل قبلاً ثبت‌نام شده است. لطفاً با نام کاربری و رمز عبور خود وارد شوید.',
  username_exists: 'این نام کاربری قبلاً استفاده شده است. لطفاً نام کاربری دیگری انتخاب کنید.',
  server_error: 'خطای سرور. لطفاً بعداً تلاش کنید.',
  no_internet: 'برای ثبت‌نام اولیه، اینترنت لازم است. لطفاً اینترنت خود را وصل کنید و دوباره تلاش کنید.',
};

export default function Register() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const [searchParams] = useSearchParams();
  const initialTab = searchParams.get('type') === 'customer' ? 'customer' : 'sarraaf';
  const [tab, setTab] = useState(initialTab);

  // Redirect already-authenticated users away from register
  useEffect(() => {
    if (isAuthenticated && user) {
      const role = user.role;
      if (role === 'creator' || role === 'admin') window.location.href = '/builder';
      else if (role === 'customer') window.location.href = '/customer';
      else window.location.href = '/dashboard';
    }
  }, [isAuthenticated, user]);

  // Common state
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showEmail, setShowEmail] = useState(false);
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sarraaf fields
  const [exExchangeName, setExExchangeName] = useState('');
  const [exFullName, setExFullName] = useState('');
  const [exMobile, setExMobile] = useState('');
  const [exUsername, setExUsername] = useState('');
  const [exEmail, setExEmail] = useState('');
  const [exPassword, setExPassword] = useState('');
  const [exConfirmPassword, setExConfirmPassword] = useState('');
  const [exCountry, setExCountry] = useState('');
  const [exCity, setExCity] = useState('');
  const [exReferralCode, setExReferralCode] = useState('');
  const [exEmailCode, setExEmailCode] = useState('');
  const [exEmailVerified, setExEmailVerified] = useState(false);
  const [exCodeSent, setExCodeSent] = useState(false);
  const [exCodeSending, setExCodeSending] = useState(false);
  const [exCodeError, setExCodeError] = useState('');
  const [exCodeVerifying, setExCodeVerifying] = useState(false);

  // Customer fields
  const [cuFullName, setCuFullName] = useState('');
  const [cuMobile, setCuMobile] = useState('');
  const [cuUsername, setCuUsername] = useState('');
  const [cuEmail, setCUEmail] = useState('');
  const [cuPassword, setCuPassword] = useState('');
  const [cuConfirmPassword, setCuConfirmPassword] = useState('');
  const [cuReferralCode, setCuReferralCode] = useState('');

  const handleSendExCode = async () => {
    setExCodeError('');
    const email = (exEmail || '').trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setExCodeError('ابتدا یک ایمیل معتبر وارد کنید');
      return;
    }
    if (!exPassword || exPassword.length < 8) {
      setExCodeError('ابتدا رمز عبور را وارد کنید (حداقل ۸ کاراکتر)');
      return;
    }
    setExCodeSending(true);
    try {
      if (exCodeSent) {
        const res = await callSupabase('auth_resend', { email });
        if (!_optionalChain([res, 'optionalAccess', _ => _.success])) throw new Error(_optionalChain([res, 'optionalAccess', _2 => _2.error]) || '');
      } else {
        const res = await callSupabase('auth_signup', { email, password: exPassword });
        if (!_optionalChain([res, 'optionalAccess', _3 => _3.success])) throw new Error(_optionalChain([res, 'optionalAccess', _4 => _4.error]) || '');
        setExCodeSent(true);
        setExEmailVerified(false);
      }
    } catch (err) {
      const msg = (_optionalChain([err, 'optionalAccess', _5 => _5.message]) || '').toLowerCase();
      if (msg.includes('email_exists')) {
        setExCodeError('این ایمیل قبلاً ثبت شده است. لطفاً وارد شوید یا ایمیل دیگری استفاده کنید.');
      } else if (msg.includes('rate_limit')) {
        setExCodeError(_optionalChain([err, 'optionalAccess', _6 => _6.message, 'optionalAccess', _7 => _7.includes, 'call', _8 => _8('۴ ساعت')]) ? 'برای ارسال مجدد کد، ۴ ساعت صبر کنید.' : 'لطفاً کمی صبر کنید و دوباره تلاش کنید.');
      } else {
        const detail = _optionalChain([err, 'optionalAccess', _9 => _9.message]) || _optionalChain([err, 'optionalAccess', _10 => _10.data, 'optionalAccess', _11 => _11.detail]) || _optionalChain([err, 'optionalAccess', _12 => _12.data, 'optionalAccess', _13 => _13.message]) || '';
        setExCodeError(`ارسال کد ناموفق بود${detail ? ': ' + detail : ''}. لطفاً دوباره تلاش کنید.`);
      }
    } finally {
      setExCodeSending(false);
    }
  };

  const handleVerifyExCode = async () => {
    setExCodeError('');
    const code = (exEmailCode || '').trim();
    const email = (exEmail || '').trim();
    if (!code || code.length !== 6) {
      setExCodeError('کد تأیید ۶ رقمی را وارد کنید');
      return;
    }
    setExCodeVerifying(true);
    try {
      const res = await callSupabase('auth_verifyOtp', { email, token: code });
      if (!_optionalChain([res, 'optionalAccess', _14 => _14.success])) throw new Error(_optionalChain([res, 'optionalAccess', _15 => _15.error]) || '');
      // Mark as verified — email confirmed via Supabase Auth
      setExEmailVerified(true);
      setExCodeError('');
    } catch (err) {
      const msg = (_optionalChain([err, 'optionalAccess', _16 => _16.message]) || '').toLowerCase();
      if (msg.includes('no_code_sent')) {
        setExCodeError('ابتدا کد را ارسال کنید');
      } else if (msg.includes('code_expired')) {
        setExCodeError('کد منقضی شده است. دوباره ارسال کنید.');
      } else if (msg.includes('too_many_attempts')) {
        setExCodeError('تلاش‌های زیادی انجام شد. دوباره کد ارسال کنید.');
      } else {
        const detail = _optionalChain([err, 'optionalAccess', _17 => _17.message]) || '';
        setExCodeError(`کد تأیید اشتباه است${detail ? ': ' + detail : ''}`);
      }
    } finally {
      setExCodeVerifying(false);
    }
  };

  const handleSarraafRegister = async (e) => {
    e.preventDefault();
    setError('');
    if (!exExchangeName || !exFullName || !exMobile || !exUsername || !exPassword || !exEmail) {
      setError('لطفاً تمام فیلدهای ضروری را پر کنید');
      return;
    }
    if (exPassword.length < 8) { setError('رمز عبور باید حداقل ۸ کاراکتر باشد'); return; }
    if (exPassword !== exConfirmPassword) { setError('تکرار رمز مطابقت ندارد'); return; }
    if (exMobile.length < 10) { setError('شماره موبایل معتبر وارد کنید'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(exEmail)) { setError('ایمیل معتبر وارد کنید'); return; }
    if (!exEmailVerified) { setError('لطفاً ایمیل خود را با کد تأیید کنید'); return; }

    // ── الزامی بودن اینترنت برای ثبت‌نام اولیه ──
    if (typeof navigator === 'undefined' || !navigator.onLine) {
      setError(ERRORS.no_internet);
      return;
    }

    setLoading(true);
    try {
      const res = await callSupabase('registerExchange', {
        exchange_name: exExchangeName,
        full_name: exFullName,
        mobile: exMobile,
        username: exUsername,
        password: exPassword,
        email: exEmail,
        country: exCountry,
        city: exCity,
      });
      if (!_optionalChain([res, 'optionalAccess', _18 => _18.success])) {
        throw new Error(ERRORS[_optionalChain([res, 'optionalAccess', _19 => _19.error])] || _optionalChain([res, 'optionalAccess', _20 => _20.error]) || 'خطا در ثبت‌نام');
      }
      // ── ثبت موفق در Supabase ──
      // اطلاعات کاربر و صرافی برگشتی از سرور
      const serverUser = res.user;
      const serverExchange = res.exchange;
      const mappedUser = {
        id: String(serverUser.id || ''),
        full_name: serverUser.full_name || '',
        name: serverUser.full_name || '',
        mobile: serverUser.mobile || '',
        username: serverUser.username || '',
        email: serverUser.email || '',
        role: serverUser.role || 'exchange',
        account_type: serverUser.role === 'creator' ? 'admin' : serverUser.role,
        status: serverUser.status || 'active',
        exchange_code: _optionalChain([serverExchange, 'optionalAccess', _21 => _21.exchange_code]) || '',
        exchange_name: _optionalChain([serverExchange, 'optionalAccess', _22 => _22.exchange_name]) || '',
      };
      // ── کش اعتبارنامه برای ورود آفلاین (فقط بعد از ثبت موفق در سرور) ──
      await cacheCredentialsForOffline(exMobile, exPassword, mappedUser);
      // ذخیره نشست برای AuthContext
      localStorage.setItem('auth_user', JSON.stringify(mappedUser));
      localStorage.setItem('auth_token', res.token);
      // ── پردازش کد دعوت (در صورت وجود) ──
      if (exReferralCode) {
        try {
          await processReferral(exReferralCode, String(serverUser.id || ''), exFullName, 'sarraaf');
        } catch (e2) {
          // ignore — referral processing is non-blocking
        }
      }
      // ── ایجاد پروفایل صراف در دیتابیس Base44 (برای نمایش در پنل سازنده) ──
      try {
        const { offlineDB } = await import('../lib/offlineQueue.js');
        const profileCode = _optionalChain([serverExchange, 'optionalAccess', _23 => _23.exchange_code]) || `EX-${Date.now()}`;
        await offlineDB.SarraafProfile.create({
          code: profileCode,
          user_id: String(serverUser.id || ''),
          email: exEmail,
          exchange_name: exExchangeName,
          name: exFullName,
          phone: exMobile,
          plan: 'free',
          quota_limit: 100,
          quota_used: 0,
          payment_status: 'none',
          status: 'active',
          last_login: new Date().toISOString(),
        });
      } catch (e3) {
        // ignore — profile creation is non-blocking
      }
      // Hard redirect so AuthContext re-initializes and picks up the new session
      window.location.href = '/dashboard';
    } catch (err) {
      const msg = (_optionalChain([err, 'optionalAccess', _24 => _24.message]) || '').toLowerCase();
      if (msg.includes('network') || msg.includes('fetch') || msg.includes('failed to fetch')) {
        setError(ERRORS.no_internet);
      } else {
        setError(err.message || 'خطا در ثبت‌نام');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCustomerRegister = async (e) => {
    e.preventDefault();
    setError('');
    if (!cuFullName || !cuMobile || !cuUsername || !cuPassword) {
      setError('لطفاً تمام فیلدهای ضروری را پر کنید');
      return;
    }
    if (cuPassword.length < 8) { setError('رمز عبور باید حداقل ۸ کاراکتر باشد'); return; }
    if (cuPassword !== cuConfirmPassword) { setError('تکرار رمز مطابقت ندارد'); return; }
    if (cuMobile.length < 10) { setError('شماره موبایل معتبر وارد کنید'); return; }

    // ── الزامی بودن اینترنت برای ثبت‌نام اولیه ──
    if (typeof navigator === 'undefined' || !navigator.onLine) {
      setError(ERRORS.no_internet);
      return;
    }

    setLoading(true);
    try {
      const res = await callSupabase('registerCustomer', {
        full_name: cuFullName,
        mobile: cuMobile,
        username: cuUsername,
        password: cuPassword,
        email: showEmail ? cuEmail : '',
      });
      if (!_optionalChain([res, 'optionalAccess', _25 => _25.success])) {
        throw new Error(ERRORS[_optionalChain([res, 'optionalAccess', _26 => _26.error])] || _optionalChain([res, 'optionalAccess', _27 => _27.error]) || 'خطا در ثبت‌نام');
      }
      // ── ثبت موفق در Supabase ──
      const serverUser = res.user;
      const mappedUser = {
        id: String(serverUser.id || ''),
        full_name: serverUser.full_name || '',
        name: serverUser.full_name || '',
        mobile: serverUser.mobile || '',
        username: serverUser.username || '',
        email: serverUser.email || '',
        role: serverUser.role || 'customer',
        account_type: serverUser.role === 'creator' ? 'admin' : serverUser.role,
        status: serverUser.status || 'active',
      };
      // ── کش اعتبارنامه برای ورود آفلاین (فقط بعد از ثبت موفق در سرور) ──
      await cacheCredentialsForOffline(cuMobile, cuPassword, mappedUser);
      localStorage.setItem('auth_user', JSON.stringify(mappedUser));
      localStorage.setItem('auth_token', res.token);
      // ── پردازش کد دعوت (در صورت وجود) ──
      if (cuReferralCode) {
        try {
          await processReferral(cuReferralCode, String(serverUser.id || ''), cuFullName, 'customer');
        } catch (e4) {
          // ignore — referral processing is non-blocking
        }
      }
      // ── ایجاد رکورد مشتری در دیتابیس Base44 (برای نمایش در پنل سازنده) ──
      try {
        const { offlineDB } = await import('../lib/offlineQueue.js');
        await offlineDB.Customer.create({
          name: cuFullName,
          phone: cuMobile,
          code: `CUS-${Date.now().toString().slice(-6)}`,
          status: 'active',
          customer_type: 'permanent',
          notes: `ثبت‌نام آنلاین — ${new Date().toLocaleDateString('fa-IR')}`,
        });
      } catch (e5) {
        // ignore — customer record creation is non-blocking
      }
      window.location.href = '/customer';
    } catch (err) {
      const msg = (_optionalChain([err, 'optionalAccess', _28 => _28.message]) || '').toLowerCase();
      if (msg.includes('network') || msg.includes('fetch') || msg.includes('failed to fetch')) {
        setError(ERRORS.no_internet);
      } else {
        setError(err.message || 'خطا در ثبت‌نام');
      }
    } finally {
      setLoading(false);
    }
  };

  const renderEmailToggle = (email, setEmail) => (
    _jsxDEV('div', { children: 
      !showEmail ? (
        _jsxDEV(Button, {
          type: "button",
          variant: "outline",
          className: "w-full text-sm" ,
          onClick: () => setShowEmail(true),
 children: [
          _jsxDEV(Mail, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 343}, this ), "ثبت‌نام با ایمیل (اختیاری)"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 337}, this)
      ) : (
        _jsxDEV('div', { className: "space-y-2", children: [
          _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
            _jsxDEV(Label, { children: "ایمیل (اختیاری)" }, void 0, false, {fileName: _jsxFileName, lineNumber: 349}, this)
            , _jsxDEV('button', {
              type: "button",
              className: "text-xs text-muted-foreground hover:text-foreground"  ,
              onClick: () => { setShowEmail(false); setEmail(''); },
 children: "حذف ایمیل"

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 350}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 348}, this)
          , _jsxDEV('div', { className: "relative", children: [
            _jsxDEV(Mail, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 359}, this )
            , _jsxDEV(Input, {
              type: "email",
              value: email,
              onChange: e => setEmail(e.target.value),
              placeholder: "email@example.com",
              className: "pr-9",}, void 0, false, {fileName: _jsxFileName, lineNumber: 360}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 358}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 347}, this)
      )
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 335}, this)
  );

  return (
    _jsxDEV('div', { className: "min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4"       , children: 
      _jsxDEV('div', { className: "w-full max-w-md" , children: [
        _jsxDEV('div', { className: "text-center mb-6" , children: [
          _jsxDEV('div', { className: "flex justify-center mb-3"  , children: 
            _jsxDEV(BrandMark, { size: "md",}, void 0, false, {fileName: _jsxFileName, lineNumber: 378}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 377}, this)
          , _jsxDEV('h1', { className: "text-xl font-bold text-foreground"  , children: "ثبت‌نام در حساب صراف"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 380}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground mt-1"  , children: "سامانه تخصصی مدیریت صرافی"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 381}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground mt-2 leading-relaxed"   , children: "📌 این صفحه فقط برای ثبت‌نام اولیه است و همیشه از شما خواسته نمی‌شود. اگر قبلاً حساب دارید، به صفحه ورود بروید."

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 382}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 376}, this)

        , !isOnline && (
          _jsxDEV('div', { className: "mb-4 rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-center"      , children: [
            _jsxDEV(WifiOff, { className: "w-5 h-5 text-destructive mx-auto mb-1"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 389}, this )
            , _jsxDEV('p', { className: "text-xs text-destructive font-medium"  , children: "برای ثبت‌نام اولیه، اینترنت لازم است. لطفاً اینترنت خود را وصل کنید و دوباره تلاش کنید."

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 390}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 388}, this)
        )

        , _jsxDEV(Tabs, { value: tab, onValueChange: (v) => { setTab(v); setError(''); setShowEmail(false); }, className: "w-full", children: [
          _jsxDEV(TabsList, { className: "grid w-full grid-cols-2"  , children: [
            _jsxDEV(TabsTrigger, { value: "sarraaf", children: [
              _jsxDEV(Store, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 399}, this ), "ثبت‌نام صراف"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 398}, this)
            , _jsxDEV(TabsTrigger, { value: "customer", children: [
              _jsxDEV(UserCircle, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 403}, this ), "ثبت‌نام مشتری"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 402}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 397}, this)

          /* Sarraaf Registration */
          , _jsxDEV(TabsContent, { value: "sarraaf", className: "mt-4", children: 
            _jsxDEV('form', { onSubmit: handleSarraafRegister, className: "space-y-3", children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: ["نام صرافی "  , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 412}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 412}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Store, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 414}, this )
                  , _jsxDEV(Input, {
                    value: exExchangeName,
                    onChange: e => setExExchangeName(e.target.value),
                    placeholder: "نام صرافی" ,
                    className: "pr-9",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 415}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 413}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 411}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: ["نام و نام خانوادگی مسئول صرافی "      , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 425}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 425}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(User, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 427}, this )
                  , _jsxDEV(Input, {
                    value: exFullName,
                    onChange: e => setExFullName(e.target.value),
                    placeholder: "نام و نام خانوادگی"   ,
                    className: "pr-9",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 428}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 426}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 424}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: ["شماره موبایل "  , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 438}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 438}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Phone, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 440}, this )
                  , _jsxDEV(Input, {
                    value: exMobile,
                    onChange: e => setExMobile(e.target.value),
                    placeholder: "07XXXXXXXX",
                    className: "pr-9",
                    inputMode: "numeric",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 441}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 439}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 437}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: ["نام کاربری "  , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 452}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 452}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(User, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 454}, this )
                  , _jsxDEV(Input, {
                    value: exUsername,
                    onChange: e => setExUsername(e.target.value),
                    placeholder: "نام کاربری (یکتا)"  ,
                    className: "pr-9",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 455}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 453}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 451}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: ["رمز عبور "  , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 465}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 465}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Lock, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 467}, this )
                  , _jsxDEV(Input, {
                    type: "password",
                    value: exPassword,
                    onChange: e => setExPassword(e.target.value),
                    placeholder: "حداقل ۸ کاراکتر"  ,
                    className: "pr-9",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 468}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 466}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 464}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: ["تکرار رمز عبور "   , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 479}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 479}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Lock, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 481}, this )
                  , _jsxDEV(Input, {
                    type: "password",
                    value: exConfirmPassword,
                    onChange: e => setExConfirmPassword(e.target.value),
                    placeholder: "تکرار رمز" ,
                    className: "pr-9",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 482}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 480}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 478}, this)
              , _jsxDEV('div', { className: "space-y-2", children: [
                _jsxDEV(Label, { children: ["ایمیل " , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 493}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 493}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Mail, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 495}, this )
                  , _jsxDEV(Input, {
                    type: "email",
                    value: exEmail,
                    onChange: (e) => { setExEmail(e.target.value); setExEmailVerified(false); setExCodeSent(false); },
                    placeholder: "email@example.com",
                    className: "pr-9",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 496}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 494}, this)
                , !exEmailVerified && (
                  _jsxDEV('div', { className: "flex gap-2" , children: [
                    _jsxDEV(Input, {
                      value: exEmailCode,
                      onChange: (e) => setExEmailCode(e.target.value),
                      onKeyDown: (e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          if (!exEmailVerified && exCodeSent) handleVerifyExCode();
                        }
                      },
                      placeholder: "کد تأیید ۶ رقمی"   ,
                      className: "flex-1 text-center tracking-widest"  ,
                      inputMode: "numeric",
                      maxLength: 6,}, void 0, false, {fileName: _jsxFileName, lineNumber: 507}, this
                    )
                    , _jsxDEV(Button, {
                      type: "button",
                      variant: "outline",
                      size: "sm",
                      onClick: handleSendExCode,
                      disabled: exCodeSending,
 children: 
                      exCodeSending ? _jsxDEV(Loader2, { className: "w-3.5 h-3.5 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 528}, this ) : exCodeSent ? 'ارسال مجدد' : (
                        _jsxDEV(_Fragment, { children: [_jsxDEV(Send, { className: "w-3.5 h-3.5 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 529}, this ), " ارسال کد"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 529}, this)
                      )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 521}, this)
                    , _jsxDEV(Button, {
                      type: "button",
                      variant: "secondary",
                      size: "sm",
                      onClick: handleVerifyExCode,
                      disabled: exCodeVerifying || !exCodeSent,
 children: 
                      exCodeVerifying ? _jsxDEV(Loader2, { className: "w-3.5 h-3.5 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 539}, this ) : _jsxDEV(_Fragment, { children: [_jsxDEV(ShieldCheck, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 539}, this ), " تأیید" ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 539}, this)
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 532}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 506}, this)
                )
                , exEmailVerified && (
                  _jsxDEV('p', { className: "text-xs text-green-600 flex items-center gap-1"    , children: [
                    _jsxDEV(ShieldCheck, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 545}, this ), " ایمیل تأیید شد"
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 544}, this)
                )
                , exCodeError && _jsxDEV('p', { className: "text-xs text-destructive" , children: exCodeError}, void 0, false, {fileName: _jsxFileName, lineNumber: 548}, this)
                , exCodeSent && !exEmailVerified && (
                  _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "کد ۶ رقمی به ایمیل شما ارسال شد. اگر دریافت نکردید، پوشه Spam/Bulk را چک کنید."

                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 550}, this)
                )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 492}, this)
              , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
                _jsxDEV('div', { children: [
                  _jsxDEV(Label, { children: "کشور"}, void 0, false, {fileName: _jsxFileName, lineNumber: 557}, this)
                  , _jsxDEV('div', { className: "relative", children: [
                    _jsxDEV(MapPin, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 559}, this )
                    , _jsxDEV(Input, {
                      value: exCountry,
                      onChange: e => setExCountry(e.target.value),
                      placeholder: "کشور",
                      className: "pr-9",}, void 0, false, {fileName: _jsxFileName, lineNumber: 560}, this
                    )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 558}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 556}, this)
                , _jsxDEV('div', { children: [
                  _jsxDEV(Label, { children: "شهر"}, void 0, false, {fileName: _jsxFileName, lineNumber: 569}, this)
                  , _jsxDEV(Input, {
                    value: exCity,
                    onChange: e => setExCity(e.target.value),
                    placeholder: "شهر",}, void 0, false, {fileName: _jsxFileName, lineNumber: 570}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 568}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 555}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "کد دعوت (اختیاری)"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 578}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Gift, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 580}, this )
                  , _jsxDEV(Input, {
                    value: exReferralCode,
                    onChange: e => setExReferralCode(e.target.value),
                    placeholder: "کد دعوت صراف/دوست"  ,
                    className: "pr-9 uppercase" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 581}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 579}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 577}, this)
              , error && _jsxDEV('p', { className: "text-sm text-destructive text-center"  , children: error}, void 0, false, {fileName: _jsxFileName, lineNumber: 589}, this)
              , _jsxDEV(Button, { type: "submit", className: "w-full", disabled: loading, children: [
                _jsxDEV(ArrowLeft, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 591}, this )
                , loading ? 'در حال ثبت...' : 'ثبت‌نام صراف'
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 590}, this)
              , _jsxDEV('p', { className: "text-xs text-muted-foreground text-center"  , children: "کد صرافی توسط سیستم به‌صورت خودکار ایجاد می‌شود."

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 594}, this)
              , _jsxDEV(Link, { to: "/login", className: "block text-center text-xs text-muted-foreground hover:text-foreground"    , children: "حساب دارم — ورود"

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 597}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 410}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 409}, this)

          /* Customer Registration */
          , _jsxDEV(TabsContent, { value: "customer", className: "mt-4", children: 
            _jsxDEV('form', { onSubmit: handleCustomerRegister, className: "space-y-3", children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: ["نام و نام خانوادگی "    , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 607}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 607}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(User, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 609}, this )
                  , _jsxDEV(Input, {
                    value: cuFullName,
                    onChange: e => setCuFullName(e.target.value),
                    placeholder: "نام و نام خانوادگی"   ,
                    className: "pr-9",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 610}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 608}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 606}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: ["شماره موبایل "  , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 620}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 620}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Phone, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 622}, this )
                  , _jsxDEV(Input, {
                    value: cuMobile,
                    onChange: e => setCuMobile(e.target.value),
                    placeholder: "07XXXXXXXX",
                    className: "pr-9",
                    inputMode: "numeric",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 623}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 621}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 619}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: ["نام کاربری "  , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 634}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 634}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(User, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 636}, this )
                  , _jsxDEV(Input, {
                    value: cuUsername,
                    onChange: e => setCuUsername(e.target.value),
                    placeholder: "نام کاربری (یکتا)"  ,
                    className: "pr-9",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 637}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 635}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 633}, this)
              , renderEmailToggle(cuEmail, setCUEmail)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: ["رمز عبور "  , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 648}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 648}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Lock, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 650}, this )
                  , _jsxDEV(Input, {
                    type: "password",
                    value: cuPassword,
                    onChange: e => setCuPassword(e.target.value),
                    placeholder: "حداقل ۸ کاراکتر"  ,
                    className: "pr-9",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 651}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 649}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 647}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: ["تکرار رمز عبور "   , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 662}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 662}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Lock, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 664}, this )
                  , _jsxDEV(Input, {
                    type: "password",
                    value: cuConfirmPassword,
                    onChange: e => setCuConfirmPassword(e.target.value),
                    placeholder: "تکرار رمز" ,
                    className: "pr-9",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 665}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 663}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 661}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "کد دعوت (اختیاری)"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 676}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Gift, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 678}, this )
                  , _jsxDEV(Input, {
                    value: cuReferralCode,
                    onChange: e => setCuReferralCode(e.target.value),
                    placeholder: "کد دعوت صراف/دوست"  ,
                    className: "pr-9 uppercase" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 679}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 677}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 675}, this)
              , error && _jsxDEV('p', { className: "text-sm text-destructive text-center"  , children: error}, void 0, false, {fileName: _jsxFileName, lineNumber: 687}, this)
              , _jsxDEV(Button, { type: "submit", className: "w-full", disabled: loading, children: [
                _jsxDEV(ArrowLeft, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 689}, this )
                , loading ? 'در حال ثبت...' : 'ثبت‌نام مشتری'
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 688}, this)
              , _jsxDEV(Link, { to: "/login", className: "block text-center text-xs text-muted-foreground hover:text-foreground"    , children: "حساب دارم — ورود"

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 692}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 605}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 604}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 396}, this)

        /* Google Registration — فقط برای صراف */
        , tab === 'sarraaf' && (
          _jsxDEV('div', { className: "mt-6 space-y-3" , children: [
            _jsxDEV('div', { className: "relative", children: [
              _jsxDEV('div', { className: "absolute inset-0 flex items-center"   , children: 
                _jsxDEV('span', { className: "w-full border-t" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 704}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 703}, this)
              , _jsxDEV('div', { className: "relative flex justify-center text-xs"   , children: 
                _jsxDEV('span', { className: "bg-background px-2 text-muted-foreground"  , children: "یا"}, void 0, false, {fileName: _jsxFileName, lineNumber: 707}, this)
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 706}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 702}, this)
            , _jsxDEV(Button, {
              type: "button",
              variant: "outline",
              className: "w-full h-11" ,
              onClick: () => initiateGoogleLogin('/dashboard'),
 children: [
              _jsxDEV(GoogleIcon, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 716}, this ), "ثبت‌نام با گوگل"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 710}, this)
            , _jsxDEV('p', { className: "text-[10px] text-muted-foreground text-center"  , children: "با ورود با گوگل، هویت شما توسط گوگل تأیید می‌شود و نیازی به رمز عبور نیست."

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 719}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 701}, this)
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 375}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 374}, this)
  );
}