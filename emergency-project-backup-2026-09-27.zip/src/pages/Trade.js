const _jsxFileName = "src/pages/Trade.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useCustomers, useCurrencies, useBankAccounts, useAgents, usePostDocument } from '../lib/useSarraaf.js';
import { PageHeader } from '../components/sarraaf/Pieces.js';
import { Field, AmountInput, CurrencySelect, CounterAccountSelect } from '../components/sarraaf/Fields.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Textarea } from '../components/ui/textarea.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
import { buildBuyLines, buildSellLines } from '../lib/ledgerApi.js';
import { suggestRate } from '../lib/exchange.js';
import { toast } from '../components/ui/use-toast.js';
import { Repeat, Loader2 } from 'lucide-react';

export default function Trade() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const customerId = params.get('customer') || '';
  const modeParam = params.get('mode') || 'buy';

  const { data: customers } = useCustomers();
  const { data: currencies } = useCurrencies();
  const { data: bankAccounts } = useBankAccounts();
  const { data: agents } = useAgents();
  const postMut = usePostDocument();

  const [customer, setCustomer] = useState(customerId);
  const [mode, setMode] = useState(modeParam);
  const [tradeCurrency, setTradeCurrency] = useState('USD');
  const [settleCurrency, setSettleCurrency] = useState('AFN');
  const [amount, setAmount] = useState(0);
  const [rate, setRate] = useState(0);
  const [counterType, setCounterType] = useState('cash');
  const [counterId, setCounterId] = useState('');
  const [fee, setFee] = useState(0);
  const [feeCurrency, setFeeCurrency] = useState('AFN');
  const [description, setDescription] = useState('');

  const settleAmount = amount * rate;

  const handleSuggestRate = () => {
    const r = suggestRate(currencies || [], tradeCurrency, mode);
    if (r) setRate(r);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!customer || !amount || !rate) {
      toast({ title: 'خطا', description: 'مشتری، مبلغ و نرخ الزامی است', variant: 'destructive' });
      return;
    }
    const cust = (customers || []).find(c => c.id === customer);
    const settleAmount = amount * rate;
    const lines = mode === 'buy'
      ? buildBuyLines({
          customer_id: customer, customer_name: _optionalChain([cust, 'optionalAccess', _ => _.name]) || '',
          currency: tradeCurrency, amount,
          paid_amount: settleAmount, paid_currency: settleCurrency,
          fee, fee_currency: feeCurrency,
        })
      : buildSellLines({
          customer_id: customer, customer_name: _optionalChain([cust, 'optionalAccess', _2 => _2.name]) || '',
          currency: tradeCurrency, amount,
          received_amount: settleAmount, received_currency: settleCurrency,
          fee, fee_currency: feeCurrency,
        });
    try {
      await postMut.mutateAsync({
        doc_type: mode,
        currency: tradeCurrency,
        amount,
        fee,
        related_type: 'customer',
        related_id: customer,
        related_name: _optionalChain([cust, 'optionalAccess', _3 => _3.name]) || '',
        description: description || (mode === 'buy' ? `خرید ${tradeCurrency}` : `فروش ${tradeCurrency}`),
        lines,
      });
      toast({ title: 'ثبت شد', description: 'معامله ثبت شد' });
      navigate(`/customers/${customer}`);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "خرید / فروش"  , icon: Repeat,}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this )
      , _jsxDEV('form', { onSubmit: handleSubmit, className: "space-y-4 max-w-md" , children: [
        _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
          _jsxDEV(Button, { type: "button", variant: mode === 'buy' ? 'default' : 'outline', onClick: () => setMode('buy'), children: "خرید"}, void 0, false, {fileName: _jsxFileName, lineNumber: 91}, this)
          , _jsxDEV(Button, { type: "button", variant: mode === 'sell' ? 'default' : 'outline', onClick: () => setMode('sell'), children: "فروش"}, void 0, false, {fileName: _jsxFileName, lineNumber: 92}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 90}, this)
        , _jsxDEV(Field, { label: "مشتری", required: true, children: 
          _jsxDEV(Select, { value: customer, onValueChange: setCustomer, children: [
            _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, { placeholder: "انتخاب مشتری" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this)
            , _jsxDEV(SelectContent, { children: 
              (customers || []).map(c => _jsxDEV(SelectItem, { value: c.id, children: c.name}, c.id, false, {fileName: _jsxFileName, lineNumber: 98}, this))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this)
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: [
          _jsxDEV(Field, { label: "ارز معامله" , required: true, children: 
            _jsxDEV(CurrencySelect, { value: tradeCurrency, onChange: setTradeCurrency, currencies: currencies,}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this)
          , _jsxDEV(Field, { label: "ارز تسویه" , children: 
            _jsxDEV(CurrencySelect, { value: settleCurrency, onChange: setSettleCurrency, currencies: currencies,}, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 102}, this)
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: [
          _jsxDEV(Field, { label: "مقدار", required: true, children: 
            _jsxDEV(AmountInput, { value: amount, onChange: setAmount,}, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this)
          , _jsxDEV(Field, { label: "نرخ", children: 
            _jsxDEV('div', { className: "flex gap-1" , children: [
              _jsxDEV(AmountInput, { value: rate, onChange: setRate, placeholder: "نرخ",}, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this )
              , _jsxDEV(Button, { type: "button", size: "sm", variant: "outline", onClick: handleSuggestRate, children: "پیشنهاد"}, void 0, false, {fileName: _jsxFileName, lineNumber: 117}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 115}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 110}, this)
        , _jsxDEV('div', { className: "p-3 rounded-lg bg-muted text-sm"   , children: [
          _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ تسویه: "  }, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this)
          , _jsxDEV('span', { className: "font-bold", children: [new Intl.NumberFormat('en-US').format(Math.round(settleAmount)), " " , settleCurrency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 123}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 121}, this)
        , _jsxDEV(Field, { label: "حساب تسویه" , children: 
          _jsxDEV(CounterAccountSelect, { value: counterId, onChange: setCounterId, bankAccounts: bankAccounts, agents: agents, type: counterType, onTypeChange: setCounterType,}, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 125}, this)
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: [
          _jsxDEV(Field, { label: "کارمزد", children: 
            _jsxDEV(AmountInput, { value: fee, onChange: setFee,}, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 129}, this)
          , _jsxDEV(Field, { label: "ارز کارمزد" , children: 
            _jsxDEV(CurrencySelect, { value: feeCurrency, onChange: setFeeCurrency, currencies: currencies,}, void 0, false, {fileName: _jsxFileName, lineNumber: 133}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 132}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 128}, this)
        , _jsxDEV(Field, { label: "توضیحات", children: _jsxDEV(Textarea, { value: description, onChange: e => setDescription(e.target.value), rows: 2,}, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 136}, this)
        , _jsxDEV(Button, { type: "submit", className: "w-full", disabled: postMut.isPending, children: [
          postMut.isPending ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this ) : _jsxDEV(Repeat, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this ), "ثبت"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 137}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 89}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 87}, this)
  );
}