const _jsxFileName = "src/pages/Dadogereft.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useCustomers, useBankAccounts, useAgents, usePostDocument, useCurrencies } from '../lib/useSarraaf.js';
import { useAuth } from '../lib/AuthContext.js';
import { PageHeader } from '../components/sarraaf/Pieces.js';
import { Field, AmountInput, CurrencySelect, CounterAccountSelect } from '../components/sarraaf/Fields.js';
import { Button } from '../components/ui/button.js';
import { Textarea } from '../components/ui/textarea.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
import { buildDadogereftLines } from '../lib/ledgerApi.js';
import { toast } from '../components/ui/use-toast.js';
import { ArrowLeftRight, Loader2 } from 'lucide-react';

export default function Dadogereft() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const { user } = useAuth();
  const customerId = params.get('customer') || '';

  const { data: customers } = useCustomers();
  const { data: currencies } = useCurrencies();
  const { data: bankAccounts } = useBankAccounts();
  const { data: agents } = useAgents();
  const postMut = usePostDocument();

  const [customer, setCustomer] = useState(customerId);
  const [type, setType] = useState('receive');
  const [currency, setCurrency] = useState('AFN');
  const [amount, setAmount] = useState(0);
  const [counterType, setCounterType] = useState('cash');
  const [counterId, setCounterId] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!customer || !amount || amount <= 0) {
      toast({ title: 'خطا', description: 'مشتری و مبلغ الزامی است', variant: 'destructive' });
      return;
    }
    const cust = (customers || []).find(c => c.id === customer);
    const lines = buildDadogereftLines({
      customer_id: customer,
      customer_name: _optionalChain([cust, 'optionalAccess', _ => _.name]) || '',
      direction: type,
      currency,
      amount,
      counter_type: counterType,
      counter_id: counterId,
    });
    try {
      await postMut.mutateAsync({
        doc_type: 'dadogereft',
        currency,
        amount,
        related_type: 'customer',
        related_id: customer,
        related_name: _optionalChain([cust, 'optionalAccess', _2 => _2.name]) || '',
        description: description || (type === 'receive' ? 'دریافت از مشتری' : 'پرداخت به مشتری'),
        lines,
      });
      toast({ title: 'ثبت شد', description: 'عملیات با موفقیت ثبت شد' });
      navigate(`/customers/${customer}`);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "داد و گرفت"  , subtitle: "دریافت / پرداخت"  , icon: ArrowLeftRight,}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this )

      , _jsxDEV('form', { onSubmit: handleSubmit, className: "space-y-4 max-w-md" , children: [
        _jsxDEV(Field, { label: "مشتری", required: true, children: 
          _jsxDEV(Select, { value: customer, onValueChange: setCustomer, children: [
            _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, { placeholder: "انتخاب مشتری" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
            , _jsxDEV(SelectContent, { children: 
              (customers || []).map(c => (
                _jsxDEV(SelectItem, { value: c.id, children: [c.name, " " , c.phone ? `— ${c.phone}` : '']}, c.id, true, {fileName: _jsxFileName, lineNumber: 78}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 74}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 73}, this)

        , _jsxDEV(Field, { label: "نوع عملیات" , required: true, children: 
          _jsxDEV(Select, { value: type, onValueChange: setType, children: [
            _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this)
            , _jsxDEV(SelectContent, { children: [
              _jsxDEV(SelectItem, { value: "receive", children: "دریافت از مشتری"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)
              , _jsxDEV(SelectItem, { value: "pay", children: "پرداخت به مشتری"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 87}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 85}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this)

        , _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: [
          _jsxDEV(Field, { label: "ارز", required: true, children: 
            _jsxDEV(CurrencySelect, { value: currency, onChange: setCurrency, currencies: currencies,}, void 0, false, {fileName: _jsxFileName, lineNumber: 96}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 95}, this)
          , _jsxDEV(Field, { label: "مبلغ", required: true, children: 
            _jsxDEV(AmountInput, { value: amount, onChange: setAmount,}, void 0, false, {fileName: _jsxFileName, lineNumber: 99}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 94}, this)

        , _jsxDEV(Field, { label: "حساب مقابل" , children: 
          _jsxDEV(CounterAccountSelect, {
            value: counterId,
            onChange: setCounterId,
            bankAccounts: bankAccounts,
            agents: agents,
            type: counterType,
            onTypeChange: setCounterType,}, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this
          )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 103}, this)

        , _jsxDEV(Field, { label: "توضیحات", children: 
          _jsxDEV(Textarea, { value: description, onChange: e => setDescription(e.target.value), rows: 2,}, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 114}, this)

        , _jsxDEV(Button, { type: "submit", className: "w-full", disabled: postMut.isPending, children: [
          postMut.isPending ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this ) : _jsxDEV(ArrowLeftRight, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this ), "ثبت"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 118}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 72}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 69}, this)
  );
}