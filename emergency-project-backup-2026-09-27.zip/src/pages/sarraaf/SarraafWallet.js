const _jsxFileName = "src/pages/sarraaf/SarraafWallet.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../lib/AuthContext.js';
import { loadWallets, loadTransactions, loadRates } from '../../lib/walletMockData.js';
import { Button } from '../../components/ui/button.js';
import { Skeleton } from '../../components/ui/skeleton.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { Plus, RefreshCw } from 'lucide-react';
import WalletCards from '../../components/customer/wallet/WalletCards.js';
import WalletDetailSheet from '../../components/customer/wallet/WalletDetailSheet.js';
import TransactionHistory from '../../components/customer/wallet/TransactionHistory.js';
import AddFundsSheet from '../../components/customer/wallet/AddFundsSheet.js';

export default function SarraafWallet() {
  const { user } = useAuth();
  const [wallets, setWallets] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [rates, setRates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState(null);
  const [addFundsOpen, setAddFundsOpen] = useState(false);

  const loadData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError(false);
    try {
      const [w, t, r] = await Promise.all([
        loadWallets(user.id),
        loadTransactions(user.id),
        loadRates(),
      ]);
      setWallets(w);
      setTransactions(t);
      setRates(r);
    } catch (e) {
      setError(true);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => { loadData(); }, [loadData]);

  if (loading) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV('div', { className: "space-y-2", children: [
          _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 48}, this )
          , _jsxDEV(Skeleton, { className: "h-3 w-24" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 49}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 47}, this)
        , _jsxDEV(Skeleton, { className: "h-20 w-full rounded-xl"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 51}, this )
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: 
          [1, 2, 3, 4].map((i) => _jsxDEV(Skeleton, { className: "h-28 rounded-xl" ,}, i, false, {fileName: _jsxFileName, lineNumber: 53}, this ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 52}, this)
        , _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 55}, this )
        , _jsxDEV('div', { className: "space-y-2", children: 
          [1, 2, 3].map((i) => _jsxDEV(Skeleton, { className: "h-16 rounded-xl" ,}, i, false, {fileName: _jsxFileName, lineNumber: 57}, this ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 46}, this)
    );
  }

  if (error) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "کیف پول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-8 text-center space-y-4"  , children: [
            _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "دریافت اطلاعات کیف پول با مشکل مواجه شد."       }, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this)
            , _jsxDEV(Button, { onClick: loadData, variant: "outline", size: "sm", children: [
              _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this ), "تلاش مجدد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 70}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 68}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 67}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)
    );
  }

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      _jsxDEV('div', { className: "min-w-0", children: [
        _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "کیف پول" }, void 0, false, {fileName: _jsxFileName, lineNumber: 83}, this)
        , _jsxDEV('p', { className: "text-xs text-muted-foreground truncate"  , children: 
          _optionalChain([user, 'optionalAccess', _ => _.full_name]) || 'صراف'
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 82}, this)

      , _jsxDEV(Button, { onClick: () => setAddFundsOpen(true), className: "w-full", children: [
        _jsxDEV(Plus, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this ), "افزودن موجودی"

      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 89}, this)

      , _jsxDEV(WalletCards, {
        wallets: wallets,
        transactions: transactions,
        rates: rates,
        onWalletClick: setSelectedCurrency,}, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this
      )

      , _jsxDEV(WalletDetailSheet, {
        open: !!selectedCurrency,
        onOpenChange: (open) => !open && setSelectedCurrency(null),
        currency: selectedCurrency,
        wallets: wallets,
        transactions: transactions,}, void 0, false, {fileName: _jsxFileName, lineNumber: 101}, this
      )

      , _jsxDEV(TransactionHistory, { transactions: transactions,}, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this )

      , _jsxDEV(AddFundsSheet, {
        open: addFundsOpen,
        onOpenChange: setAddFundsOpen,
        user: user,}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 81}, this)
  );
}