const _jsxFileName = "src/pages/sarraaf/SarraafGames.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../lib/AuthContext.js';
import {
  loadServices, loadPackages, loadWallets, submitRequest,
  loadDraft, saveDraft, clearDraft,
} from '../../lib/gamesMockData.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { Button } from '../../components/ui/button.js';
import { Input } from '../../components/ui/input.js';
import { Label } from '../../components/ui/label.js';
import { Skeleton } from '../../components/ui/skeleton.js';
import {
  Gamepad2, Wallet, Send, RefreshCw, AlertTriangle,
} from 'lucide-react';
import { Image } from '../../components/ui/image.js';
import ConfirmDialog from '../../components/customer/games/ConfirmDialog.js';
import SuccessSheet from '../../components/customer/games/SuccessSheet.js';
import UCCard from '../../components/customer/games/UCCard.js';

export default function SarraafGames() {
  const { user } = useAuth();
  const [services, setServices] = useState([]);
  const [packages, setPackages] = useState([]);
  const [wallets, setWallets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const [selectedService, setSelectedService] = useState(null);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [accountInfo, setAccountInfo] = useState({});
  const [walletCurrency, setWalletCurrency] = useState('AFN');
  const [description, setDescription] = useState('');
  const [errors, setErrors] = useState({});
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [successRequest, setSuccessRequest] = useState(null);
  const [successOpen, setSuccessOpen] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const [svcs, wals] = await Promise.all([loadServices(), loadWallets(_optionalChain([user, 'optionalAccess', _ => _.id]))]);
      setServices(svcs);
      setWallets(wals);
      const draft = loadDraft();
      if (draft) {
        if (draft.walletCurrency) setWalletCurrency(draft.walletCurrency);
        if (draft.description) setDescription(draft.description);
      }
    } catch (e2) {
      setError(true);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => { loadData(); }, [loadData]);

  useEffect(() => {
    if (selectedService) {
      loadPackages(selectedService.code).then((pkgs) => setPackages(pkgs));
    } else {
      setPackages([]);
    }
    setSelectedPackage(null);
    setAccountInfo({});
  }, [selectedService]);

  useEffect(() => {
    const draft = {
      selectedServiceCode: _optionalChain([selectedService, 'optionalAccess', _2 => _2.code]) || null,
      selectedPackageId: _optionalChain([selectedPackage, 'optionalAccess', _3 => _3.id]) || null,
      accountInfo,
      walletCurrency,
      description,
    };
    saveDraft(draft);
  }, [selectedService, selectedPackage, accountInfo, walletCurrency, description]);

  const selectedWallet = wallets.find((w) => w.currency === walletCurrency);
  const currentAmount = _optionalChain([selectedPackage, 'optionalAccess', _4 => _4.price]) || 0;
  const insufficientBalance = selectedWallet && currentAmount > 0 && (selectedWallet.balance || 0) < currentAmount;

  const validate = () => {
    const errs = {};
    if (!selectedService) errs.service = 'یک خدمت را انتخاب کنید.';
    if (!selectedPackage) errs.package = 'یک بسته/مقدار انتخاب کنید.';
    if (_optionalChain([selectedService, 'optionalAccess', _5 => _5.account_fields])) {
      const acctErrs = {};
      selectedService.account_fields.forEach((f) => {
        if (f.required && !_optionalChain([accountInfo, 'access', _6 => _6[f.key], 'optionalAccess', _7 => _7.trim, 'call', _8 => _8()])) {
          acctErrs[f.key] = `${f.label} را وارد کنید.`;
        }
      });
      if (Object.keys(acctErrs).length > 0) errs.account = acctErrs;
    }
    if (!walletCurrency) errs.walletCurrency = 'کیف پول پرداخت را انتخاب کنید.';
    if (currentAmount <= 0) errs.amount = 'مبلغ معتبر نیست.';
    if (insufficientBalance) errs.balance = 'موجودی کیف پول برای انجام این درخواست کافی نیست.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleOpenConfirm = () => { if (!validate()) return; setConfirmOpen(true); };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const result = await submitRequest({
        user_id: _optionalChain([user, 'optionalAccess', _9 => _9.id]) || 'demo-sarraaf',
        user_name: _optionalChain([user, 'optionalAccess', _10 => _10.full_name]) || 'صراف',
        service_code: selectedService.code,
        service_name: selectedService.name,
        product_type: selectedService.product_type,
        package_name: selectedPackage.name,
        package_amount: selectedPackage.amount,
        account_info: accountInfo,
        wallet_currency: walletCurrency,
        amount: currentAmount,
        description,
      });
      setSuccessRequest(result);
      setSuccessOpen(true);
      setConfirmOpen(false);
      clearDraft();
      setSelectedService(null);
      setSelectedPackage(null);
      setAccountInfo({});
      setDescription('');
    } catch (e3) { /* ignore */ }
    setSubmitting(false);
  };

  if (loading) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 137}, this )
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: 
          [1, 2, 3, 4].map((i) => _jsxDEV(Skeleton, { className: "h-24 rounded-xl" ,}, i, false, {fileName: _jsxFileName, lineNumber: 139}, this ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 136}, this)
    );
  }

  if (error) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "بازی‌ها و خدمات بازی"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this)
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-8 text-center space-y-4"  , children: [
            _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "دریافت اطلاعات با مشکل مواجه شد."     }, void 0, false, {fileName: _jsxFileName, lineNumber: 151}, this)
            , _jsxDEV(Button, { onClick: loadData, variant: "outline", size: "sm", children: [
              _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 153}, this ), "تلاش مجدد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 152}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 150}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 147}, this)
    );
  }

  const confirmData = selectedService && selectedPackage ? {
    service_name: selectedService.name,
    product_type: selectedService.product_type,
    package_name: selectedPackage.name,
    account_info: accountInfo,
    wallet_currency: walletCurrency,
    amount: currentAmount,
    description,
  } : null;

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      /* Header */
      _jsxDEV('div', { className: "min-w-0", children: [
        _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "بازی‌ها و خدمات بازی"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 176}, this)
        , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "UC پابجی، الماس IMO و سایر خدمات"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 177}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 175}, this)

      /* Services Grid */
      , _jsxDEV('div', { children: [
        _jsxDEV('h2', { className: "text-sm font-bold text-foreground mb-2"   , children: "خدمات بازی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 182}, this)
        , services.length === 0 ? (
          _jsxDEV(Card, { children: 
            _jsxDEV(CardContent, { className: "p-6 text-center text-sm text-muted-foreground"   , children: "در حال حاضر خدمتی برای نمایش وجود ندارد."

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 185}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 184}, this)
        ) : (
          _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: 
            services.map((svc) => (
              _jsxDEV('button', {

                onClick: () => { setSelectedService(svc); setErrors({}); },
                disabled: !svc.is_active,
                className: `p-3 rounded-xl border-2 text-center transition-all disabled:opacity-40 ${
                  _optionalChain([selectedService, 'optionalAccess', _11 => _11.id]) === svc.id ? 'border-primary bg-primary/5' : 'border-border bg-card hover:border-primary/30'
                }`,
 children: [
                _jsxDEV('div', { className: `w-11 h-11 rounded-2xl bg-gradient-to-br ${svc.color} flex items-center justify-center mx-auto mb-2 overflow-hidden`, children: 
                  svc.icon_url ? (
                    _jsxDEV(Image, { src: svc.icon_url, alt: svc.name, fittingType: "fit", className: "w-7 h-7 object-contain"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 202}, this )
                  ) : (
                    _jsxDEV('span', { className: "text-xl", children: svc.icon}, void 0, false, {fileName: _jsxFileName, lineNumber: 204}, this)
                  )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 200}, this)
                , _jsxDEV('p', { className: "text-xs font-bold text-foreground"  , children: svc.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 207}, this)
                , _jsxDEV('p', { className: "text-[9px] text-muted-foreground mt-0.5"  , children: svc.product_type}, void 0, false, {fileName: _jsxFileName, lineNumber: 208}, this)
                , !svc.is_active && _jsxDEV('p', { className: "text-[8px] text-destructive mt-0.5"  , children: "غیرفعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 209}, this)
              ]}, svc.id, true, {fileName: _jsxFileName, lineNumber: 192}, this)
            ))
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 190}, this)
        )
        , errors.service && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.service}, void 0, false, {fileName: _jsxFileName, lineNumber: 214}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 181}, this)

      /* Service Detail + Packages */
      , selectedService && (
        _jsxDEV(_Fragment, { children: [
          _jsxDEV(Card, { className: "shadow-sm", children: 
            _jsxDEV(CardContent, { className: "p-3", children: [
              _jsxDEV('div', { className: "flex items-center gap-2 mb-1"   , children: [
                _jsxDEV(Gamepad2, { className: "w-4 h-4 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this )
                , _jsxDEV('p', { className: "text-sm font-bold text-foreground"  , children: selectedService.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 224}, this)
                , _jsxDEV('span', { className: `text-[8px] px-1.5 py-0.5 rounded ${selectedService.is_active ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'}`, children: 
                  selectedService.is_active ? 'فعال' : 'غیرفعال'
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 225}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 222}, this)
              , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: selectedService.description}, void 0, false, {fileName: _jsxFileName, lineNumber: 229}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 221}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 220}, this)

          /* Packages */
          , _jsxDEV('div', { children: [
            _jsxDEV('h3', { className: "text-sm font-bold text-foreground mb-3"   , children: 
              selectedService.code === 'pubg_uc' ? 'بسته‌های UC پابجی موبایل' : selectedService.code === 'imo_diamonds' ? 'بسته‌های الماس IMO' : 'بسته‌ها'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 235}, this)
            , packages.length === 0 ? (
              _jsxDEV(Card, { children: 
                _jsxDEV(CardContent, { className: "p-4 text-center text-sm text-muted-foreground"   , children: "بسته‌ای برای این خدمت وجود ندارد."

                }, void 0, false, {fileName: _jsxFileName, lineNumber: 240}, this)
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 239}, this)
            ) : packages.some((p) => p.image) ? (
              _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: 
                packages.map((pkg) => (
                  _jsxDEV(UCCard, {

                    pkg: pkg,
                    selected: _optionalChain([selectedPackage, 'optionalAccess', _12 => _12.id]) === pkg.id,
                    onSelect: (p) => { setSelectedPackage(p); setErrors({}); },}, pkg.id, false, {fileName: _jsxFileName, lineNumber: 247}, this
                  )
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 245}, this)
            ) : (
              _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: 
                packages.map((pkg) => (
                  _jsxDEV('button', {

                    onClick: () => { setSelectedPackage(pkg); setErrors({}); },
                    disabled: !pkg.is_active,
                    className: `p-3 rounded-xl border-2 text-right transition-all disabled:opacity-40 ${
                      _optionalChain([selectedPackage, 'optionalAccess', _13 => _13.id]) === pkg.id ? 'border-primary bg-primary/5' : 'border-border bg-card hover:border-primary/30'
                    }`,
 children: [
                    _jsxDEV('p', { className: "text-xs font-bold text-foreground"  , children: pkg.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 266}, this)
                    , _jsxDEV('p', { className: "text-sm font-bold text-primary mt-1"   , children: [(pkg.price || 0).toLocaleString('fa-IR'), " " , pkg.currency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 267}, this)
                    , !pkg.is_active && _jsxDEV('p', { className: "text-[8px] text-destructive mt-0.5"  , children: "غیرفعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 268}, this)
                  ]}, pkg.id, true, {fileName: _jsxFileName, lineNumber: 258}, this)
                ))
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 256}, this)
            )
            , errors.package && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.package}, void 0, false, {fileName: _jsxFileName, lineNumber: 273}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 234}, this)

          /* Account Info Fields */
          , selectedPackage && selectedService.account_fields && selectedService.account_fields.length > 0 && (
            _jsxDEV(Card, { className: "shadow-sm border-purple-200 bg-purple-50/30"  , children: 
              _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
                _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                  _jsxDEV(Gamepad2, { className: "w-4 h-4 text-purple-600"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 281}, this )
                  , _jsxDEV('p', { className: "text-sm font-bold text-foreground"  , children: "اطلاعات حساب بازی"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 282}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 280}, this)
                , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: "برای تحویل UC به حساب شما، اطلاعات زیر را دقیق وارد کنید."

                }, void 0, false, {fileName: _jsxFileName, lineNumber: 284}, this)
                , selectedService.account_fields.map((f) => (
                  _jsxDEV('div', { children: [
                    _jsxDEV(Label, { className: "text-[11px] font-medium text-foreground"  , children: [f.label, f.required && ' *']}, void 0, true, {fileName: _jsxFileName, lineNumber: 289}, this)
                    , _jsxDEV(Input, {
                      placeholder: f.placeholder,
                      value: accountInfo[f.key] || '',
                      onChange: (e) => { setAccountInfo({ ...accountInfo, [f.key]: e.target.value }); setErrors({}); },
                      dir: "ltr",
                      className: "text-sm mt-1 bg-white"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 290}, this
                    )
                    , _optionalChain([errors, 'access', _14 => _14.account, 'optionalAccess', _15 => _15[f.key]]) && _jsxDEV('p', { className: "text-[10px] text-destructive mt-0.5"  , children: errors.account[f.key]}, void 0, false, {fileName: _jsxFileName, lineNumber: 297}, this)
                  ]}, f.key, true, {fileName: _jsxFileName, lineNumber: 288}, this)
                ))
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 279}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 278}, this)
          )

          /* Wallet Selection */
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "کیف پول پرداخت"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 306}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2 mt-1"   , children: 
              wallets.map((w) => (
                _jsxDEV('button', {

                  onClick: () => { setWalletCurrency(w.currency); setErrors({}); },
                  className: `p-2.5 rounded-lg border text-center transition-all ${walletCurrency === w.currency ? 'border-primary bg-primary/5' : 'border-border'}`,
 children: [
                  _jsxDEV(Wallet, { className: "w-4 h-4 mx-auto mb-1 text-muted-foreground"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 314}, this )
                  , _jsxDEV('p', { className: "text-[10px] font-bold text-foreground"  , children: w.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 315}, this)
                  , _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: (w.balance || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 316}, this)
                ]}, w.currency, true, {fileName: _jsxFileName, lineNumber: 309}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 307}, this)
            , errors.walletCurrency && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.walletCurrency}, void 0, false, {fileName: _jsxFileName, lineNumber: 320}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 305}, this)

          /* Insufficient Balance */
          , insufficientBalance && (
            _jsxDEV(Card, { className: "border-destructive/30 bg-destructive/5" , children: 
              _jsxDEV(CardContent, { className: "p-3 flex items-center gap-2"   , children: [
                _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-destructive shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 327}, this )
                , _jsxDEV('p', { className: "text-xs text-destructive font-medium"  , children: "موجودی کیف پول برای انجام این درخواست کافی نیست."

                }, void 0, false, {fileName: _jsxFileName, lineNumber: 328}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 326}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 325}, this)
          )

          /* Description */
          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "توضیحات (اختیاری)" }, void 0, false, {fileName: _jsxFileName, lineNumber: 337}, this)
            , _jsxDEV(Input, {
              placeholder: "توضیحات...",
              value: description,
              onChange: (e) => setDescription(e.target.value),
              className: "text-sm mt-1" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 338}, this
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 336}, this)

          /* Summary & Submit */
          , _jsxDEV(Card, { className: "shadow-sm border-primary/30" , children: 
            _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
              _jsxDEV('div', { className: "flex items-center justify-between text-sm"   , children: [
                _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ قابل پرداخت:"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 350}, this)
                , _jsxDEV('span', { className: "font-bold text-primary" , children: [currentAmount.toLocaleString('fa-IR'), " " , walletCurrency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 351}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 349}, this)
              , _jsxDEV(Button, { onClick: handleOpenConfirm, className: "w-full", disabled: insufficientBalance, children: [
                _jsxDEV(Send, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 354}, this ), "ادامه و تأیید"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 353}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 348}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 347}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 219}, this)
      )

      , _jsxDEV(ConfirmDialog, {
        open: confirmOpen,
        onOpenChange: setConfirmOpen,
        data: confirmData,
        onConfirm: handleSubmit,
        submitting: submitting,}, void 0, false, {fileName: _jsxFileName, lineNumber: 362}, this
      )

      , _jsxDEV(SuccessSheet, {
        open: successOpen,
        onOpenChange: setSuccessOpen,
        request: successRequest,
        onGoToOrders: () => { setSuccessOpen(false); },}, void 0, false, {fileName: _jsxFileName, lineNumber: 370}, this
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 173}, this)
  );
}