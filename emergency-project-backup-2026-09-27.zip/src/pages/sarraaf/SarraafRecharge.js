const _jsxFileName = "src/pages/sarraaf/SarraafRecharge.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../lib/AuthContext.js';
import {
  loadOperators, loadRechargeAmounts, loadPackages, loadWallets,
  submitRequest,
} from '../../lib/rechargeMockData.js';
import { Card, CardContent } from '../../components/ui/card.js';
import { Button } from '../../components/ui/button.js';
import { Input } from '../../components/ui/input.js';
import { Label } from '../../components/ui/label.js';
import { Skeleton } from '../../components/ui/skeleton.js';
import {
  Smartphone, Wifi, Wallet, Send, AlertTriangle, RefreshCw,
} from 'lucide-react';
import ConfirmDialog from '../../components/customer/recharge/ConfirmDialog.js';
import SuccessSheet from '../../components/customer/recharge/SuccessSheet.js';

const DRAFT_KEY = 'sarraaf_recharge_draft';

export default function SarraafRecharge() {
  const { user } = useAuth();
  const [tab, setTab] = useState('mobile_recharge');
  const [operators, setOperators] = useState([]);
  const [amounts, setAmounts] = useState([]);
  const [packages, setPackages] = useState([]);
  const [wallets, setWallets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const [operator, setOperator] = useState('');
  const [mobile, setMobile] = useState('');
  const [rechargeAmount, setRechargeAmount] = useState('');
  const [description, setDescription] = useState('');
  const [selectedPackage, setSelectedPackage] = useState(null);

  const [walletCurrency, setWalletCurrency] = useState('AFN');
  const [errors, setErrors] = useState({});
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [successRequest, setSuccessRequest] = useState(null);
  const [successOpen, setSuccessOpen] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const [ops, amts, pkgs, wals] = await Promise.all([
        loadOperators(),
        loadRechargeAmounts(),
        loadPackages(),
        loadWallets(_optionalChain([user, 'optionalAccess', _ => _.id])),
      ]);
      setOperators(ops);
      setAmounts(amts);
      setPackages(pkgs);
      setWallets(wals);
      try {
        const raw = localStorage.getItem(DRAFT_KEY);
        if (raw) {
          const draft = JSON.parse(raw);
          if (draft.tab) setTab(draft.tab);
          if (draft.operator) setOperator(draft.operator);
          if (draft.mobile) setMobile(draft.mobile);
          if (draft.rechargeAmount) setRechargeAmount(draft.rechargeAmount);
          if (draft.description) setDescription(draft.description);
          if (draft.walletCurrency) setWalletCurrency(draft.walletCurrency);
        }
      } catch (e2) { /* ignore */ }
    } catch (e3) {
      setError(true);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => { loadData(); }, [loadData]);

  useEffect(() => {
    const draft = { tab, operator, mobile, rechargeAmount, description, walletCurrency };
    try { localStorage.setItem(DRAFT_KEY, JSON.stringify(draft)); } catch (e4) { /* ignore */ }
  }, [tab, operator, mobile, rechargeAmount, description, walletCurrency]);

  const selectedWallet = wallets.find((w) => w.currency === walletCurrency);
  const currentAmount = tab === 'mobile_recharge' ? parseFloat(rechargeAmount) || 0 : _optionalChain([selectedPackage, 'optionalAccess', _2 => _2.price]) || 0;
  const insufficientBalance = selectedWallet && currentAmount > 0 && (selectedWallet.balance || 0) < currentAmount;

  const validate = () => {
    const errs = {};
    if (!operator) errs.operator = 'اپراتور را انتخاب کنید.';
    if (!mobile) {
      errs.mobile = 'شماره موبایل را وارد کنید.';
    } else if (!/^[0-9+\-\s]{7,15}$/.test(mobile.replace(/\s/g, ''))) {
      errs.mobile = 'فرمت شماره موبایل معتبر نیست.';
    }
    if (tab === 'mobile_recharge') {
      if (!rechargeAmount || parseFloat(rechargeAmount) <= 0) {
        errs.rechargeAmount = 'مبلغ شارژ معتبر وارد کنید.';
      }
    } else {
      if (!selectedPackage) errs.package = 'یک بسته اینترنت انتخاب کنید.';
    }
    if (!walletCurrency) errs.walletCurrency = 'کیف پول پرداخت را انتخاب کنید.';
    if (currentAmount <= 0) errs.amount = 'مبلغ باید بیشتر از صفر باشد.';
    if (insufficientBalance) errs.balance = 'موجودی کیف پول برای انجام این درخواست کافی نیست.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleOpenConfirm = () => { if (!validate()) return; setConfirmOpen(true); };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const op = operators.find((o) => o.code === operator);
      const payload = {
        user_id: _optionalChain([user, 'optionalAccess', _3 => _3.id]) || 'demo-sarraaf',
        user_name: _optionalChain([user, 'optionalAccess', _4 => _4.full_name]) || 'صراف',
        service_type: tab,
        operator: operator,
        operator_name: _optionalChain([op, 'optionalAccess', _5 => _5.name]) || operator,
        mobile,
        amount: currentAmount,
        package_name: _optionalChain([selectedPackage, 'optionalAccess', _6 => _6.name]) || null,
        package_volume: _optionalChain([selectedPackage, 'optionalAccess', _7 => _7.volume]) || null,
        package_duration: _optionalChain([selectedPackage, 'optionalAccess', _8 => _8.duration]) || null,
        wallet_currency: walletCurrency,
        description,
      };
      const result = await submitRequest(payload);
      setSuccessRequest(result);
      setSuccessOpen(true);
      setConfirmOpen(false);
      localStorage.removeItem(DRAFT_KEY);
      setOperator(''); setMobile(''); setRechargeAmount(''); setDescription(''); setSelectedPackage(null);
    } catch (e5) { /* ignore */ }
    setSubmitting(false);
  };

  if (loading) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV(Skeleton, { className: "h-6 w-32" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 141}, this )
        , _jsxDEV('div', { className: "flex gap-1 p-1 rounded-xl bg-muted"    , children: [
          _jsxDEV(Skeleton, { className: "flex-1 h-10 rounded-lg"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this )
          , _jsxDEV(Skeleton, { className: "flex-1 h-10 rounded-lg"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)
        , _jsxDEV(Skeleton, { className: "h-12 w-full rounded-lg"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 146}, this )
        , _jsxDEV(Skeleton, { className: "h-12 w-full rounded-lg"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this )
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
          _jsxDEV(Skeleton, { className: "h-20 rounded-xl" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this )
          , _jsxDEV(Skeleton, { className: "h-20 rounded-xl" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 150}, this )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 148}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 140}, this)
    );
  }

  if (error) {
    return (
      _jsxDEV('div', { className: "space-y-4", children: [
        _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "شارژ و اینترنت"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this)
        , _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-8 text-center space-y-4"  , children: [
            _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: "دریافت اطلاعات با مشکل مواجه شد."     }, void 0, false, {fileName: _jsxFileName, lineNumber: 162}, this)
            , _jsxDEV(Button, { onClick: loadData, variant: "outline", size: "sm", children: [
              _jsxDEV(RefreshCw, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 164}, this ), "تلاش مجدد"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 163}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 161}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 158}, this)
    );
  }

  const confirmData = {
    service_type: tab,
    operator_name: _optionalChain([operators, 'access', _9 => _9.find, 'call', _10 => _10((o) => o.code === operator), 'optionalAccess', _11 => _11.name]) || operator,
    mobile,
    amount: currentAmount,
    package_name: _optionalChain([selectedPackage, 'optionalAccess', _12 => _12.name]),
    wallet_currency: walletCurrency,
    description,
  };

  return (
    _jsxDEV('div', { className: "space-y-4", children: [
      _jsxDEV('div', { className: "min-w-0", children: [
        _jsxDEV('h1', { className: "text-lg font-bold text-foreground"  , children: "شارژ و اینترنت"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 186}, this)
        , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "شارژ موبایل و بسته اینترنت"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 185}, this)

      /* Tabs */
      , _jsxDEV('div', { className: "flex gap-1 p-1 rounded-xl bg-muted"    , children: [
        _jsxDEV('button', {
          onClick: () => { setTab('mobile_recharge'); setSelectedPackage(null); setErrors({}); },
          className: `flex-1 py-2.5 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-1.5 ${tab === 'mobile_recharge' ? 'bg-card shadow text-foreground' : 'text-muted-foreground'}`,
 children: [
          _jsxDEV(Smartphone, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 196}, this ), "شارژ موبایل"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 192}, this)
        , _jsxDEV('button', {
          onClick: () => { setTab('internet'); setErrors({}); },
          className: `flex-1 py-2.5 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-1.5 ${tab === 'internet' ? 'bg-card shadow text-foreground' : 'text-muted-foreground'}`,
 children: [
          _jsxDEV(Wifi, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 203}, this ), "بسته اینترنت"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 199}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 191}, this)

      /* Operator Selector */
      , _jsxDEV('div', { children: [
        _jsxDEV(Label, { className: "text-xs", children: "اپراتور"}, void 0, false, {fileName: _jsxFileName, lineNumber: 210}, this)
        , _jsxDEV('div', { className: "flex flex-wrap gap-2 mt-1"   , children: 
          operators.length === 0 ? (
            _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "اپراتوری موجود نیست."  }, void 0, false, {fileName: _jsxFileName, lineNumber: 213}, this)
          ) : (
            operators.map((op) => (
              _jsxDEV('button', {

                onClick: () => { setOperator(op.code); setErrors({}); },
                className: `px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${operator === op.code ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'}`,
 children: 
                op.name
              }, op.code, false, {fileName: _jsxFileName, lineNumber: 216}, this)
            ))
          )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 211}, this)
        , errors.operator && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.operator}, void 0, false, {fileName: _jsxFileName, lineNumber: 226}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 209}, this)

      /* Mobile Recharge Form */
      , tab === 'mobile_recharge' && (
        _jsxDEV(_Fragment, { children: [
          _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "شماره موبایل" }, void 0, false, {fileName: _jsxFileName, lineNumber: 233}, this)
            , _jsxDEV(Input, {
              placeholder: "مثال: 07XXXXXXXXX" ,
              value: mobile,
              onChange: (e) => { setMobile(e.target.value); setErrors({}); },
              dir: "ltr",
              className: "text-sm mt-1" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 234}, this
            )
            , errors.mobile && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.mobile}, void 0, false, {fileName: _jsxFileName, lineNumber: 241}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 232}, this)

          , _jsxDEV('div', { children: [
            _jsxDEV(Label, { className: "text-xs", children: "مبلغ شارژ (افغانی)"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 245}, this)
            , _jsxDEV(Input, {
              type: "number",
              placeholder: "مبلغ را وارد کنید"   ,
              value: rechargeAmount,
              onChange: (e) => { setRechargeAmount(e.target.value); setErrors({}); },
              className: "text-sm mt-1" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 246}, this
            )
            , errors.rechargeAmount && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.rechargeAmount}, void 0, false, {fileName: _jsxFileName, lineNumber: 253}, this)
            , _jsxDEV('div', { className: "flex flex-wrap gap-1.5 mt-2"   , children: 
              amounts.map((amt) => (
                _jsxDEV('button', {

                  onClick: () => { setRechargeAmount(String(amt)); setErrors({}); },
                  className: `px-2.5 py-1 rounded-lg text-[10px] font-medium border transition-all ${parseFloat(rechargeAmount) === amt ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground'}`,
 children: 
                  amt.toLocaleString('fa-IR')
                }, amt, false, {fileName: _jsxFileName, lineNumber: 256}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 254}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 244}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 231}, this)
      )

      /* Internet Packages */
      , tab === 'internet' && (
        _jsxDEV('div', { children: [
          _jsxDEV('h2', { className: "text-sm font-bold text-foreground mb-2"   , children: "بسته‌های اینترنت" }, void 0, false, {fileName: _jsxFileName, lineNumber: 272}, this)
          , packages.length === 0 ? (
            _jsxDEV(Card, { children: 
              _jsxDEV(CardContent, { className: "p-6 text-center text-sm text-muted-foreground"   , children: "در حال حاضر بسته‌ای برای نمایش وجود ندارد."

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 275}, this)
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 274}, this)
          ) : (
            _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: 
              packages.map((pkg) => (
                _jsxDEV('button', {

                  onClick: () => { setSelectedPackage(pkg); setErrors({}); },
                  disabled: !pkg.is_active,
                  className: `p-3 rounded-xl border-2 text-right transition-all disabled:opacity-40 ${
                    _optionalChain([selectedPackage, 'optionalAccess', _13 => _13.id]) === pkg.id ? 'border-primary bg-primary/5' : 'border-border bg-card hover:border-primary/30'
                  }`,
 children: [
                  _jsxDEV('p', { className: "text-xs font-bold text-foreground"  , children: pkg.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 290}, this)
                  , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: pkg.operator_name}, void 0, false, {fileName: _jsxFileName, lineNumber: 291}, this)
                  , _jsxDEV('p', { className: "text-[10px] text-muted-foreground mt-1"  , children: [pkg.volume, " • "  , pkg.duration]}, void 0, true, {fileName: _jsxFileName, lineNumber: 292}, this)
                  , _jsxDEV('p', { className: "text-sm font-bold text-primary mt-1"   , children: [(pkg.price || 0).toLocaleString('fa-IR'), " " , pkg.currency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 293}, this)
                  , !pkg.is_active && _jsxDEV('p', { className: "text-[8px] text-destructive mt-0.5"  , children: "غیرفعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 294}, this)
                ]}, pkg.id, true, {fileName: _jsxFileName, lineNumber: 282}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 280}, this)
          )
          , errors.package && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.package}, void 0, false, {fileName: _jsxFileName, lineNumber: 299}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 271}, this)
      )

      /* Wallet Selection */
      , _jsxDEV('div', { children: [
        _jsxDEV(Label, { className: "text-xs", children: "کیف پول پرداخت"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 305}, this)
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-2 mt-1"   , children: 
          wallets.map((w) => (
            _jsxDEV('button', {

              onClick: () => { setWalletCurrency(w.currency); setErrors({}); },
              className: `p-2.5 rounded-lg border text-center transition-all ${walletCurrency === w.currency ? 'border-primary bg-primary/5' : 'border-border'}`,
 children: [
              _jsxDEV(Wallet, { className: "w-4 h-4 mx-auto mb-1 text-muted-foreground"    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 313}, this )
              , _jsxDEV('p', { className: "text-[10px] font-bold text-foreground"  , children: w.currency}, void 0, false, {fileName: _jsxFileName, lineNumber: 314}, this)
              , _jsxDEV('p', { className: "text-[9px] text-muted-foreground" , children: (w.balance || 0).toLocaleString('fa-IR')}, void 0, false, {fileName: _jsxFileName, lineNumber: 315}, this)
            ]}, w.currency, true, {fileName: _jsxFileName, lineNumber: 308}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 306}, this)
        , errors.walletCurrency && _jsxDEV('p', { className: "text-[10px] text-destructive mt-1"  , children: errors.walletCurrency}, void 0, false, {fileName: _jsxFileName, lineNumber: 319}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 304}, this)

      /* Insufficient Balance Warning */
      , insufficientBalance && (
        _jsxDEV(Card, { className: "border-destructive/30 bg-destructive/5" , children: 
          _jsxDEV(CardContent, { className: "p-3 flex items-center gap-2"   , children: [
            _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-destructive shrink-0"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 326}, this )
            , _jsxDEV('p', { className: "text-xs text-destructive font-medium"  , children: "موجودی کیف پول برای انجام این درخواست کافی نیست."

            }, void 0, false, {fileName: _jsxFileName, lineNumber: 327}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 325}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 324}, this)
      )

      /* Description */
      , _jsxDEV('div', { children: [
        _jsxDEV(Label, { className: "text-xs", children: "توضیحات (اختیاری)" }, void 0, false, {fileName: _jsxFileName, lineNumber: 336}, this)
        , _jsxDEV(Input, {
          placeholder: "توضیحات...",
          value: description,
          onChange: (e) => setDescription(e.target.value),
          className: "text-sm mt-1" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 337}, this
        )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 335}, this)

      /* Summary & Submit */
      , _jsxDEV(Card, { className: "shadow-sm border-primary/30" , children: 
        _jsxDEV(CardContent, { className: "p-4 space-y-3" , children: [
          _jsxDEV('div', { className: "flex items-center justify-between text-sm"   , children: [
            _jsxDEV('span', { className: "text-muted-foreground", children: "مبلغ قابل پرداخت:"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 349}, this)
            , _jsxDEV('span', { className: "font-bold text-primary" , children: [currentAmount.toLocaleString('fa-IR'), " " , walletCurrency]}, void 0, true, {fileName: _jsxFileName, lineNumber: 350}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 348}, this)
          , _jsxDEV(Button, { onClick: handleOpenConfirm, className: "w-full", disabled: insufficientBalance, children: [
            _jsxDEV(Send, { className: "w-4 h-4 ml-2"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 353}, this ), "ادامه و تأیید"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 352}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 347}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 346}, this)

      , _jsxDEV(ConfirmDialog, {
        open: confirmOpen,
        onOpenChange: setConfirmOpen,
        data: confirmData,
        onConfirm: handleSubmit,
        submitting: submitting,}, void 0, false, {fileName: _jsxFileName, lineNumber: 359}, this
      )

      , _jsxDEV(SuccessSheet, {
        open: successOpen,
        onOpenChange: setSuccessOpen,
        request: successRequest,
        onGoToOrders: () => { setSuccessOpen(false); },}, void 0, false, {fileName: _jsxFileName, lineNumber: 367}, this
      )
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 184}, this)
  );
}