const _jsxFileName = "src/pages/Customers.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCustomers, useCreateCustomer, useUpdateCustomer } from '../lib/useSarraaf.js';
import { PageHeader, EmptyState, LoadingState, StatusBadge } from '../components/sarraaf/Pieces.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../components/ui/dialog.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
import { formatNumber } from '../lib/sarraaf.js';
import { Plus, Search, Users, Pencil, ChevronLeft, Contact } from 'lucide-react';
import { toast } from '../components/ui/use-toast.js';

export default function Customers() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ name: '', phone: '', code: '', customer_type: 'permanent', customer_group: '', status: 'active', tazkira_id: '', notes: '' });

  const { data: customers, isLoading } = useCustomers(search);
  const createMut = useCreateCustomer();
  const updateMut = useUpdateCustomer();

  const filtered = (customers || []).filter(c => {
    if (typeFilter !== 'all' && c.customer_type !== typeFilter) return false;
    if (statusFilter !== 'all' && c.status !== statusFilter) return false;
    return true;
  });

  const openCreate = () => {
    setEditId(null);
    setForm({ name: '', phone: '', code: '', customer_type: 'permanent', customer_group: '', status: 'active', tazkira_id: '', notes: '' });
    setDialogOpen(true);
  };

  const pickFromContacts = async () => {
    if ('contacts' in navigator && 'select' in navigator.contacts) {
      try {
        const contacts = await navigator.contacts.select(['name', 'tel'], { multiple: false });
        if (contacts && contacts.length > 0) {
          const c = contacts[0];
          setForm(prev => ({
            ...prev,
            name: (c.name && c.name[0]) || prev.name,
            phone: (c.tel && c.tel[0]) || prev.phone,
          }));
          toast({ title: 'موفق', description: 'اطلاعات مخاطب بارگذاری شد' });
        }
      } catch (e) {
        toast({ title: 'خطا', description: 'دسترسی به مخاطبین ناموفق بود', variant: 'destructive' });
      }
    } else {
      toast({ title: 'خطا', description: 'مرورگر شما از انتخاب مخاطب پشتیبانی نمی‌کند', variant: 'destructive' });
    }
  };

  const openEdit = (c) => {
    setEditId(c.id);
    setForm({
      name: c.name || '', phone: c.phone || '', code: c.code || '',
      customer_type: c.customer_type || 'permanent', customer_group: c.customer_group || '',
      status: c.status || 'active', tazkira_id: c.tazkira_id || '', notes: c.notes || '',
    });
    setDialogOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editId) {
      await updateMut.mutateAsync({ id: editId, data: form });
    } else {
      await createMut.mutateAsync(form);
    }
    setDialogOpen(false);
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, {
        title: "مشتریان",
        subtitle: `${formatNumber(filtered.length)} نفر`,
        icon: Users,
        actions: 
          _jsxDEV(Button, { size: "sm", onClick: openCreate, children: [
            _jsxDEV(Plus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this ), "افزودن"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 87}, this)
        ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this
      )

      /* Filters */
      , _jsxDEV('div', { className: "flex gap-2 mb-4"  , children: [
        _jsxDEV('div', { className: "relative flex-1" , children: [
          _jsxDEV(Search, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 97}, this )
          , _jsxDEV(Input, {
            value: search,
            onChange: e => setSearch(e.target.value),
            placeholder: "جستجو نام / موبایل / کد"     ,
            className: "pr-9",}, void 0, false, {fileName: _jsxFileName, lineNumber: 98}, this
          )
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 96}, this)
        , _jsxDEV(Select, { value: typeFilter, onValueChange: setTypeFilter, children: [
          _jsxDEV(SelectTrigger, { className: "w-28", children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 106}, this)
          , _jsxDEV(SelectContent, { children: [
            _jsxDEV(SelectItem, { value: "all", children: "همه انواع" }, void 0, false, {fileName: _jsxFileName, lineNumber: 108}, this)
            , _jsxDEV(SelectItem, { value: "permanent", children: "دائمی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this)
            , _jsxDEV(SelectItem, { value: "temporary", children: "موقت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 110}, this)
            , _jsxDEV(SelectItem, { value: "misc", children: "متفرقه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 107}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 105}, this)
        , _jsxDEV(Select, { value: statusFilter, onValueChange: setStatusFilter, children: [
          _jsxDEV(SelectTrigger, { className: "w-28", children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 115}, this)
          , _jsxDEV(SelectContent, { children: [
            _jsxDEV(SelectItem, { value: "all", children: "همه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 117}, this)
            , _jsxDEV(SelectItem, { value: "active", children: "فعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 118}, this)
            , _jsxDEV(SelectItem, { value: "inactive", children: "غیرفعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 116}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 114}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 95}, this)

      /* List */
      , isLoading ? (
        _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 126}, this )
      ) : filtered.length === 0 ? (
        _jsxDEV(EmptyState, { icon: Users, title: "مشتری‌ای یافت نشد"  , description: "مشتری جدید اضافه کنید"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 128}, this )
      ) : (
        _jsxDEV('div', { className: "space-y-2", children: 
          filtered.map(c => (
            _jsxDEV('div', {

              className: "flex items-center justify-between gap-2 p-3 rounded-xl border bg-card hover:bg-muted/30 transition-colors cursor-pointer"          ,
              onClick: () => navigate(`/customers/${c.id}`),
 children: [
              _jsxDEV('div', { className: "flex items-center gap-2 min-w-0"   , children: [
                _jsxDEV('div', { className: "w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm shrink-0"          , children: 
                  (c.name || '?').charAt(0)
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 138}, this)
                , _jsxDEV('div', { className: "min-w-0", children: [
                  _jsxDEV('div', { className: "flex items-center gap-1.5"  , children: [
                    _jsxDEV('span', { className: "text-sm font-medium truncate"  , children: c.name}, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this)
                    , _jsxDEV(StatusBadge, { status: c.status, labels: { active: 'فعال', inactive: 'غیرفعال' },}, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 142}, this)
                  , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: [
                    c.phone || '—', " " , c.code ? ` • ${c.code}` : ''
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 146}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 141}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 137}, this)
              , _jsxDEV('div', { className: "flex items-center gap-1 shrink-0"   , children: [
                _jsxDEV('button', {
                  onClick: e => { e.stopPropagation(); openEdit(c); },
                  className: "p-1.5 rounded-lg hover:bg-muted"  ,
 children: 
                  _jsxDEV(Pencil, { className: "w-4 h-4 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 152}, this)
                , _jsxDEV(ChevronLeft, { className: "w-4 h-4 text-muted-foreground"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 158}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 151}, this)
            ]}, c.id, true, {fileName: _jsxFileName, lineNumber: 132}, this)
          ))
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)
      )

      /* Create/Edit Dialog */
      , _jsxDEV(Dialog, { open: dialogOpen, onOpenChange: setDialogOpen, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: 
            _jsxDEV(DialogTitle, { children: editId ? 'ویرایش مشتری' : 'افزودن مشتری'}, void 0, false, {fileName: _jsxFileName, lineNumber: 169}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this)
          , _jsxDEV('form', { onSubmit: handleSubmit, className: "space-y-3", children: [
            !editId && (
              _jsxDEV(Button, { type: "button", variant: "outline", className: "w-full", onClick: pickFromContacts, children: [
                _jsxDEV(Contact, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 174}, this ), " انتخاب از مخاطبین"
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 173}, this)
            )
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: ["نام " , _jsxDEV('span', { className: "text-destructive", children: "*"}, void 0, false, {fileName: _jsxFileName, lineNumber: 178}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 178}, this)
              , _jsxDEV(Input, { value: form.name, onChange: e => setForm({...form, name: e.target.value}), required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 177}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "موبایل"}, void 0, false, {fileName: _jsxFileName, lineNumber: 183}, this)
                , _jsxDEV(Input, { value: form.phone, onChange: e => setForm({...form, phone: e.target.value}), inputMode: "numeric",}, void 0, false, {fileName: _jsxFileName, lineNumber: 184}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 182}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "کد"}, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this)
                , _jsxDEV(Input, { value: form.code, onChange: e => setForm({...form, code: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 188}, this )
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 186}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 181}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "نوع"}, void 0, false, {fileName: _jsxFileName, lineNumber: 193}, this)
                , _jsxDEV(Select, { value: form.customer_type, onValueChange: v => setForm({...form, customer_type: v}), children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 195}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 195}, this)
                  , _jsxDEV(SelectContent, { children: [
                    _jsxDEV(SelectItem, { value: "permanent", children: "دائمی"}, void 0, false, {fileName: _jsxFileName, lineNumber: 197}, this)
                    , _jsxDEV(SelectItem, { value: "temporary", children: "موقت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 198}, this)
                    , _jsxDEV(SelectItem, { value: "misc", children: "متفرقه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 199}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 196}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 194}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 192}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "وضعیت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 204}, this)
                , _jsxDEV(Select, { value: form.status, onValueChange: v => setForm({...form, status: v}), children: [
                  _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 206}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 206}, this)
                  , _jsxDEV(SelectContent, { children: [
                    _jsxDEV(SelectItem, { value: "active", children: "فعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 208}, this)
                    , _jsxDEV(SelectItem, { value: "inactive", children: "غیرفعال"}, void 0, false, {fileName: _jsxFileName, lineNumber: 209}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 207}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 205}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 203}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 191}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "گروه"}, void 0, false, {fileName: _jsxFileName, lineNumber: 215}, this)
              , _jsxDEV(Input, { value: form.customer_group, onChange: e => setForm({...form, customer_group: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 216}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 214}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "شماره تذکره" }, void 0, false, {fileName: _jsxFileName, lineNumber: 219}, this)
              , _jsxDEV(Input, { value: form.tazkira_id, onChange: e => setForm({...form, tazkira_id: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 220}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 218}, this)
            , _jsxDEV('div', { children: [
              _jsxDEV(Label, { children: "یادداشت"}, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this)
              , _jsxDEV(Input, { value: form.notes, onChange: e => setForm({...form, notes: e.target.value}),}, void 0, false, {fileName: _jsxFileName, lineNumber: 224}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 222}, this)
            , _jsxDEV(DialogFooter, { children: [
              _jsxDEV(Button, { type: "button", variant: "outline", onClick: () => setDialogOpen(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 227}, this)
              , _jsxDEV(Button, { type: "submit", disabled: createMut.isPending || updateMut.isPending, children: 
                editId ? 'ذخیره' : 'افزودن'
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 228}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 226}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 171}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 167}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 166}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 81}, this)
  );
}