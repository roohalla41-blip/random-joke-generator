const _jsxFileName = "src/pages/Login.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Label } from '../components/ui/label.js';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs.js';
import { callSupabase } from '../lib/supabaseApi.js';
import { login as localLogin } from '../lib/localAuth.js';
import { cacheCredentialsForOffline, offlineLogin, findCachedUser } from '../lib/credentialCache.js';
import { isLocalTestMode } from '../lib/localTestMode.js';
import { initiateGoogleLogin, handleGoogleCallback } from '../lib/googleAuth.js';
import { applyCreatorRole } from '../lib/creatorAuth.js';
import { recordLoginAttempt, isAccountLocked, getLockoutRemaining, getRemainingAttempts } from '../lib/loginSecurity.js';
import { logAudit, AUDIT_ACTIONS } from '../lib/auditLogger.js';
import { useAuth } from '../lib/AuthContext.js';
import GoogleIcon from '../components/GoogleIcon.js';
import BrandMark from '../components/BrandMark.js';
import ConnectionStatus from '../components/ConnectionStatus.js';
import { ArrowLeft, Phone, Lock, User, Store, UserCircle, WifiOff, Loader2, Shield } from 'lucide-react';

const ERR_MAP = {
  user_not_found: 'نام کاربری یا موبایل یافت نشد',
  wrong_password: 'رمز عبور اشتباه است',
  user_inactive: 'حساب کاربری غیرفعال است',
  missing_fields: 'نام کاربری و رمز عبور را وارد کنید',
  mobile_exists: 'این شماره موبایل قبلاً ثبت شده است',
  username_exists: 'این نام کاربری قبلاً ثبت شده است',
  server_error: 'خطا در ارتباط با سرور',
};

function mapServerUser(dbUser, exchange) {
  return applyCreatorRole({
    id: String(dbUser.id || ''),
    full_name: dbUser.full_name || dbUser.name || '',
    name: dbUser.full_name || dbUser.name || '',
    mobile: dbUser.mobile || '',
    username: dbUser.username || '',
    email: dbUser.email || '',
    role: dbUser.role || 'exchange',
    account_type: dbUser.account_type || (dbUser.role === 'creator' ? 'admin' : dbUser.role),
    status: dbUser.status || 'active',
    exchange_code: _optionalChain([exchange, 'optionalAccess', _ => _.exchange_code]) || dbUser.exchange_code || '',
    exchange_name: _optionalChain([exchange, 'optionalAccess', _2 => _2.exchange_name]) || dbUser.exchange_name || '',
  });
}

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, isAuthenticated } = useAuth();
  const offlineAdminBlocked = _optionalChain([location, 'access', _3 => _3.state, 'optionalAccess', _4 => _4.reason]) === 'offline_admin';
  const [tab, setTab] = useState('sarraaf');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [googleLoading, setGoogleLoading] = useState(false);
  // hasInternet = real device connectivity (navigator.onLine).
  // NOT affected by local test mode — device can have internet
  // even when we're storing data locally instead of in Supabase.
  const [hasInternet, setHasInternet] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  // Redirect already-authenticated users away from login
  useEffect(() => {
    if (isAuthenticated && user) {
      const role = user.role;
      if (role === 'creator') window.location.href = '/builder';
      else if (role === 'customer') window.location.href = '/customer';
      else window.location.href = '/dashboard';
    }
  }, [isAuthenticated, user]);

  useEffect(() => {
    const handleOnline = () => setHasInternet(true);
    const handleOffline = () => setHasInternet(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // ── Google OAuth callback handler (Supabase) ──
  // Supabase Auth redirects back with ?google_cb=1 — we exchange the
  // session for an HMAC token via the backend, then navigate.
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('google_cb') !== '1') return;
    setGoogleLoading(true);
    handleGoogleCallback().then(() => {
      const returnTo = urlParams.get('return_to') || '/dashboard';
      window.location.href = returnTo;
    }).catch(() => {
      setGoogleLoading(false);
    });
  }, []);

  const navigateByRole = (role) => {
    // Hard redirect so AuthContext re-initializes and picks up the new session
    if (role === 'creator') window.location.href = '/builder';
    else if (role === 'customer') window.location.href = '/customer';
    else window.location.href = '/dashboard';
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      // ── بررسی قفل شدن حساب ──
      if (isAccountLocked(identifier)) {
        const remaining = getLockoutRemaining(identifier);
        const mins = Math.ceil(remaining / 60);
        throw new Error(`حساب به دلیل تلاش‌های ناموفق متعدد قفل شده است. ${mins} دقیقه دیگر تلاش کنید.`);
      }

      const online = hasInternet && !isLocalTestMode();

      // ── مرحله ۱: ورود از طریق سرور (اولویت وقتی آنلاین هستیم) ──
      if (online) {
        let serverResult = null;
        let serverError = null;
        try {
          const res = await callSupabase('login', { identifier, password });
          if (_optionalChain([res, 'optionalAccess', _5 => _5.success])) {
            serverResult = res;
          } else {
            serverError = _optionalChain([res, 'optionalAccess', _6 => _6.error]) || 'server_error';
          }
        } catch (e2) {
          serverError = 'network_error';
        }

        if (serverResult) {
          const mappedUser = mapServerUser(serverResult.user, serverResult.exchange);
          // اطلاعات سازنده هرگز در localStorage ذخیره نمی‌شود
          if (mappedUser.role !== 'creator') {
            await cacheCredentialsForOffline(identifier, password, mappedUser);
            localStorage.setItem('auth_user', JSON.stringify(mappedUser));
          }
          localStorage.setItem('auth_token', serverResult.token);
          recordLoginAttempt(identifier, true);
          logAudit({ userId: mappedUser.id, userName: mappedUser.full_name, userRole: mappedUser.role, action: AUDIT_ACTIONS.LOGIN, description: 'ورود سرور موفق', status: 'success' });
          navigateByRole(mappedUser.role);
          return;
        }

        // اگر سرور خطای قطعی داد (کاربر وجود دارد ولی رمز اشتباه، یا کاربر یافت نشد)،
        // به Local Auth برنمی‌گردیم — این خطای واقعی Login است.
        if (serverError === 'wrong_password' || serverError === 'user_not_found' || serverError === 'user_inactive' || serverError === 'too_many_attempts') {
          recordLoginAttempt(identifier, false);
          logAudit({ userName: identifier, action: AUDIT_ACTIONS.LOGIN_FAILED, description: `ورود ناموفق (${serverError})`, status: 'failed' });
          throw new Error(ERR_MAP[serverError] || 'خطا در ورود');
        }
        // در غیر این صورت (خطای شبکه/سرور) — به fallback آفلاین ادامه می‌دهیم
        // سازنده نمی‌تواند آفلاین وارد شود چون اطلاعات او در localStorage ذخیره نمی‌شود
      }

      // ── مرحله ۲: اعتبارنامه‌های کش‌شده (offline cache) ──
      const offRes = await offlineLogin(identifier, password);
      if (offRes.success) {
        const finalUser = applyCreatorRole(offRes.user);
        // سازنده نمی‌تواند از طریق کش آفلاین وارد شود
        if (finalUser.role === 'creator') {
          throw new Error('حساب سازنده نیازمند اتصال به سرور است. لطفاً اتصال اینترنت را بررسی کنید.');
        }
        localStorage.setItem('auth_user', JSON.stringify(finalUser));
        localStorage.setItem('auth_token', `local_token_${Date.now()}`);
        recordLoginAttempt(identifier, true);
        logAudit({ userId: finalUser.id, userName: finalUser.full_name, userRole: finalUser.role, action: AUDIT_ACTIONS.LOGIN, description: 'ورود آفلاین موفق', status: 'success' });
        navigateByRole(finalUser.role);
        return;
      }

      // ── مرحله ۳: کاربران محلی (localAuth) — فقط در حالت آفلاین ──
      if (!online) {
        const locRes = localLogin(identifier, password);
        if (locRes.success) {
          const finalUser = applyCreatorRole(locRes.user);
          // سازنده نمی‌تواند از طریق کاربران محلی وارد شود
          if (finalUser.role === 'creator') {
            throw new Error('حساب سازنده نیازمند اتصال به سرور است. لطفاً اتصال اینترنت را بررسی کنید.');
          }
          await cacheCredentialsForOffline(identifier, password, finalUser);
          recordLoginAttempt(identifier, true);
          logAudit({ userId: finalUser.id, userName: finalUser.full_name, userRole: finalUser.role, action: AUDIT_ACTIONS.LOGIN, description: 'ورود محلی موفق', status: 'success' });
          navigateByRole(finalUser.role);
          return;
        }
      }

      // ── مرحله ۴: خطا بر اساس وضعیت ──
      recordLoginAttempt(identifier, false);
      logAudit({ userName: identifier, action: AUDIT_ACTIONS.LOGIN_FAILED, description: 'ورود ناموفق', status: 'failed' });
      const remaining = getRemainingAttempts(identifier);
      if (findCachedUser(identifier)) {
        throw new Error(`رمز عبور اشتباه است. ${remaining} تلاش باقی مانده.`);
      }
      if (!hasInternet) {
        throw new Error('برای اولین ورود، اتصال به اینترنت لازم است.');
      }
      throw new Error(`نام کاربری یا رمز عبور اشتباه است. ${remaining} تلاش باقی مانده.`);
    } catch (err) {
      setError(err.message || 'خطا در ورود');
    } finally {
      setLoading(false);
    }
  };

  return (
    _jsxDEV('div', { className: "min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4"       , children: 
      _jsxDEV('div', { className: "w-full max-w-md" , children: [
        /* نشانگر وضعیت اتصال */
        _jsxDEV('div', { className: "flex justify-center mb-4"  , children: 
          _jsxDEV(ConnectionStatus, { compact: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 216}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 215}, this)

        /* هشدار آفلاین */
        , !hasInternet && (
          _jsxDEV('div', { className: "flex items-center gap-2 mb-4 p-3 rounded-lg bg-warning/10 text-warning text-xs text-center justify-center"          , children: [
            _jsxDEV(WifiOff, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 222}, this )
            , _jsxDEV('span', { children: "حالت آفلاین — فقط کاربرانی که قبلاً روی این دستگاه وارد شده‌اند می‌توانند وارد شوند."              }, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 221}, this)
        )

        /* هشدار: پنل سازنده فقط آنلاین */
        , offlineAdminBlocked && (
          _jsxDEV('div', { className: "flex items-center gap-2 mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-xs text-center justify-center"          , children: [
            _jsxDEV(Shield, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 230}, this )
            , _jsxDEV('span', { children: "ورود به پنل سازنده فقط در حالت آنلاین ممکن است. لطفاً اتصال اینترنت را برقرار کنید."               }, void 0, false, {fileName: _jsxFileName, lineNumber: 231}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 229}, this)
        )

        , _jsxDEV('div', { className: "text-center mb-6" , children: [
          _jsxDEV('div', { className: "flex justify-center mb-3"  , children: 
            _jsxDEV(BrandMark, { size: "md",}, void 0, false, {fileName: _jsxFileName, lineNumber: 237}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 236}, this)
          , _jsxDEV('h1', { className: "text-xl font-bold text-foreground"  , children: "ورود به حساب صراف"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 239}, this)
          , _jsxDEV('p', { className: "text-xs text-muted-foreground mt-1"  , children: "سامانه تخصصی مدیریت صرافی"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 240}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 235}, this)

        , _jsxDEV(Tabs, { value: tab, onValueChange: setTab, className: "w-full", children: [
          _jsxDEV(TabsList, { className: "grid w-full grid-cols-2"  , children: [
            _jsxDEV(TabsTrigger, { value: "sarraaf", children: [
              _jsxDEV(Store, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 246}, this ), "ورود صراف"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 245}, this)
            , _jsxDEV(TabsTrigger, { value: "customer", children: [
              _jsxDEV(UserCircle, { className: "w-4 h-4 ml-1"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 250}, this ), "ورود مشتری"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 249}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 244}, this)

          , _jsxDEV(TabsContent, { value: "sarraaf", className: "mt-4", children: 
            _jsxDEV('form', { onSubmit: handleLogin, className: "space-y-3", children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "نام کاربری یا موبایل"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 258}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(User, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 260}, this )
                  , _jsxDEV(Input, {
                    value: identifier,
                    onChange: e => setIdentifier(e.target.value),
                    placeholder: "نام کاربری / موبایل / admin"     ,
                    className: "pr-9",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 261}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 259}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 257}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "رمز عبور" }, void 0, false, {fileName: _jsxFileName, lineNumber: 271}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Lock, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 273}, this )
                  , _jsxDEV(Input, {
                    type: "password",
                    value: password,
                    onChange: e => setPassword(e.target.value),
                    placeholder: "رمز عبور" ,
                    className: "pr-9",}, void 0, false, {fileName: _jsxFileName, lineNumber: 274}, this
                  )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 272}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 270}, this)
                  , error && _jsxDEV('p', { className: "text-sm text-destructive text-center"  , children: error}, void 0, false, {fileName: _jsxFileName, lineNumber: 283}, this)
                  , _jsxDEV(Button, { type: "submit", className: "w-full", disabled: loading, children: [
                  _jsxDEV(ArrowLeft, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 285}, this )
                  , loading ? 'در حال ورود...' : 'ورود'
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 284}, this)
                  , _jsxDEV(Link, { to: "/register?type=sarraaf", className: "block text-center text-xs text-muted-foreground hover:text-foreground"    , children: "حساب ندارید؟ ثبت‌نام صراف"

                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 288}, this)
              , _jsxDEV(Link, { to: "/forgot-password", className: "block text-center text-xs text-muted-foreground hover:text-foreground"    , children: "فراموشی رمز عبور"

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 291}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 256}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 255}, this)

          , _jsxDEV(TabsContent, { value: "customer", className: "mt-4", children: 
            _jsxDEV('form', { onSubmit: handleLogin, className: "space-y-3", children: [
              _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "نام کاربری یا موبایل"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 300}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Phone, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 302}, this )
                  , _jsxDEV(Input, {
                    value: identifier,
                    onChange: e => setIdentifier(e.target.value),
                    placeholder: "نام کاربری / موبایل / ایمیل"     ,
                    className: "pr-9",
                    required: true,}, void 0, false, {fileName: _jsxFileName, lineNumber: 303}, this
                  )
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 301}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 299}, this)
              , _jsxDEV('div', { children: [
                _jsxDEV(Label, { children: "رمز عبور" }, void 0, false, {fileName: _jsxFileName, lineNumber: 313}, this)
                , _jsxDEV('div', { className: "relative", children: [
                  _jsxDEV(Lock, { className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"      ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 315}, this )
                  , _jsxDEV(Input, {
                    type: "password",
                    value: password,
                    onChange: e => setPassword(e.target.value),
                    placeholder: "رمز عبور" ,
                    className: "pr-9",}, void 0, false, {fileName: _jsxFileName, lineNumber: 316}, this
                  )
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 314}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 312}, this)
                  , error && _jsxDEV('p', { className: "text-sm text-destructive text-center"  , children: error}, void 0, false, {fileName: _jsxFileName, lineNumber: 325}, this)
                  , _jsxDEV(Button, { type: "submit", className: "w-full", disabled: loading, children: [
                  _jsxDEV(ArrowLeft, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 327}, this )
                  , loading ? 'در حال ورود...' : 'ورود'
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 326}, this)
                  , _jsxDEV(Link, { to: "/register?type=customer", className: "block text-center text-xs text-muted-foreground hover:text-foreground"    , children: "حساب ندارید؟ ثبت‌نام مشتری"

                  }, void 0, false, {fileName: _jsxFileName, lineNumber: 330}, this)
              , _jsxDEV(Link, { to: "/forgot-password", className: "block text-center text-xs text-muted-foreground hover:text-foreground"    , children: "فراموشی رمز عبور"

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 333}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 298}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 297}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 243}, this)

        /* Google Login — فقط برای صراف */
        , tab === 'sarraaf' && (
          googleLoading ? (
            _jsxDEV('div', { className: "mt-6 flex items-center justify-center gap-2 text-sm text-muted-foreground"      , children: [
              _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 344}, this ), "در حال ورود با گوگل..."

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 343}, this)
          ) : (
            _jsxDEV('div', { className: "mt-6 space-y-3" , children: [
              _jsxDEV('div', { className: "relative", children: [
                _jsxDEV('div', { className: "absolute inset-0 flex items-center"   , children: 
                  _jsxDEV('span', { className: "w-full border-t" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 351}, this )
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 350}, this)
                , _jsxDEV('div', { className: "relative flex justify-center text-xs"   , children: 
                  _jsxDEV('span', { className: "bg-background px-2 text-muted-foreground"  , children: "یا"}, void 0, false, {fileName: _jsxFileName, lineNumber: 354}, this)
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 353}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 349}, this)
              , _jsxDEV(Button, {
                type: "button",
                variant: "outline",
                className: "w-full h-11" ,
                onClick: () => initiateGoogleLogin('/dashboard'),
 children: [
                _jsxDEV(GoogleIcon, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 363}, this ), "ورود با گوگل"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 357}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 348}, this)
          )
        )

        , _jsxDEV('div', { className: "mt-4 text-center" , children: 
          _jsxDEV(Link, { to: "/", className: "text-xs text-muted-foreground hover:text-foreground"  , children: "بازگشت به صفحه اصلی"

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 371}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 370}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 213}, this)
    }, void 0, false, {fileName: _jsxFileName, lineNumber: 212}, this)
  );
}