const _jsxFileName = "src/pages/CurrencyConvert.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useCustomers, useCurrencies, useCustomerBalances, usePostDocument } from '../lib/useSarraaf.js';
import { PageHeader } from '../components/sarraaf/Pieces.js';
import { Field, AmountInput, CurrencySelect } from '../components/sarraaf/Fields.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
import { buildConversionLines } from '../lib/ledgerApi.js';
import { formatNumber } from '../lib/sarraaf.js';
import { toast } from '../components/ui/use-toast.js';
import { ArrowRightLeft, Loader2 } from 'lucide-react';

export default function CurrencyConvert() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const customerId = params.get('customer') || '';
  const { data: customers } = useCustomers();
  const { data: currencies } = useCurrencies();
  const { data: customerBalancesData } = useCustomerBalances();
  const postMut = usePostDocument();

  const [customer, setCustomer] = useState(customerId);
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [fromAmount, setFromAmount] = useState(0);
  const [toCurrency, setToCurrency] = useState('AFN');
  const [toAmount, setToAmount] = useState(0);
  const [rate, setRate] = useState(0);

  const custBalRow = (customerBalancesData || []).find(b => String(b.customer_id) === String(customer));
  const balances = custBalRow ? { [custBalRow.balance_currency || 'AFN']: custBalRow.net_balance || 0 } : {};

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!customer || !fromAmount || !toAmount || !rate) {
      toast({ title: 'خطا', description: 'تمام فیلدها الزامی است', variant: 'destructive' });
      return;
    }
    const lines = buildConversionLines({ from_currency: fromCurrency, from_amount: fromAmount, to_currency: toCurrency, to_amount: toAmount, rate });
    try {
      await postMut.mutateAsync({
        doc_type: 'convert',
        currency: fromCurrency,
        amount: fromAmount,
        related_type: 'customer',
        related_id: customer,
        description: `تبدیل ${fromCurrency} به ${toCurrency}`,
        lines,
      });
      toast({ title: 'ثبت شد' });
      navigate(`/customers/${customer}`);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "تبدیل ارز" , icon: ArrowRightLeft,}, void 0, false, {fileName: _jsxFileName, lineNumber: 59}, this )
      , _jsxDEV('form', { onSubmit: handleSubmit, className: "space-y-4 max-w-md" , children: [
        _jsxDEV(Field, { label: "مشتری", required: true, children: 
          _jsxDEV(Select, { value: customer, onValueChange: setCustomer, children: [
            _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, { placeholder: "انتخاب مشتری" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 63}, this)
            , _jsxDEV(SelectContent, { children: 
              (customers || []).map(c => _jsxDEV(SelectItem, { value: c.id, children: c.name}, c.id, false, {fileName: _jsxFileName, lineNumber: 65}, this))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 64}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 62}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 61}, this)
        , Object.keys(balances).length > 0 && (
          _jsxDEV('div', { className: "p-3 rounded-lg bg-muted text-xs space-y-1"    , children: [
            _jsxDEV('p', { className: "font-medium", children: "موجودی:"}, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this)
            , Object.entries(balances).map(([cur, val]) => (
              _jsxDEV('p', { children: [cur, ": " , formatNumber(val)]}, cur, true, {fileName: _jsxFileName, lineNumber: 73}, this)
            ))
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 70}, this)
        )
        , _jsxDEV('div', { className: "grid grid-cols-2 gap-3"  , children: [
          _jsxDEV(Field, { label: "از ارز" , required: true, children: 
            _jsxDEV(CurrencySelect, { value: fromCurrency, onChange: setFromCurrency, currencies: currencies,}, void 0, false, {fileName: _jsxFileName, lineNumber: 79}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 78}, this)
          , _jsxDEV(Field, { label: "به ارز" , required: true, children: 
            _jsxDEV(CurrencySelect, { value: toCurrency, onChange: setToCurrency, currencies: currencies,}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this )
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 77}, this)
        , _jsxDEV('div', { className: "grid grid-cols-3 gap-2"  , children: [
          _jsxDEV(Field, { label: "مقدار", required: true, children: _jsxDEV(AmountInput, { value: fromAmount, onChange: setFromAmount,}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this)
          , _jsxDEV(Field, { label: "نرخ", required: true, children: _jsxDEV(AmountInput, { value: rate, onChange: setRate, placeholder: "نرخ",}, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 87}, this)
          , _jsxDEV(Field, { label: "مبلغ تبدیل" , children: _jsxDEV(AmountInput, { value: toAmount, onChange: setToAmount,}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 88}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 85}, this)
        , _jsxDEV(Button, { type: "submit", className: "w-full", disabled: postMut.isPending, children: [
          postMut.isPending ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 91}, this ) : _jsxDEV(ArrowRightLeft, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 91}, this ), "ثبت تبدیل"

        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 90}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 60}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 58}, this)
  );
}