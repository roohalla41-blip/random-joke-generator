const _jsxFileName = "src/pages/Backup.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime"; function _nullishCoalesce(lhs, rhsFn) { if (lhs != null) { return lhs; } else { return rhsFn(); } } function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useRef, useState } from 'react';
import { useAuth } from '../lib/AuthContext.js';
import { useBackupHistory, useCreateBackup, useRestoreBackup, useBackupAddon, useBackupLimit, useLocalBackups, useCreateLocalBackup, useRestoreLocalBackup, useDeleteLocalBackup } from '../lib/useBackup.js';
import { FREE_MONTHLY_LIMIT } from '../lib/backupService.js';
import { Smartphone, Trash2 } from 'lucide-react';
import { useToast } from '../components/ui/use-toast.js';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card.js';
import { Button } from '../components/ui/button.js';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '../components/ui/dialog.js';
import { Database, Download, Upload, Shield, Clock, CheckCircle2, AlertTriangle, Loader2 } from 'lucide-react';
import { useUpgrade } from '../lib/UpgradeContext.js';

export default function Backup() {
  const { user } = useAuth();
  const userId = _optionalChain([user, 'optionalAccess', _ => _.id]);
  const userName = _optionalChain([user, 'optionalAccess', _2 => _2.full_name]) || _optionalChain([user, 'optionalAccess', _3 => _3.email]) || '';
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  const { openUpgrade } = useUpgrade();
  const [restoreConfirm, setRestoreConfirm] = useState(null);
  const [localWarning, setLocalWarning] = useState(false);
  const [localRestoreConfirm, setLocalRestoreConfirm] = useState(null);

  const { data: history, isLoading: historyLoading } = useBackupHistory(userId);
  const { data: hasAddon } = useBackupAddon(userId);
  const { data: backupLimit } = useBackupLimit(userId, hasAddon);
  const createMut = useCreateBackup();
  const restoreMut = useRestoreBackup();
  const { data: localBackups } = useLocalBackups();
  const localCreateMut = useCreateLocalBackup();
  const localRestoreMut = useRestoreLocalBackup();
  const localDeleteMut = useDeleteLocalBackup();

  const canBackupNow = _optionalChain([backupLimit, 'optionalAccess', _4 => _4.allowed]) !== false;
  const remainingBackups = _nullishCoalesce(_optionalChain([backupLimit, 'optionalAccess', _5 => _5.remaining]), () => ( 0));

  const handleManualBackup = async () => {
    if (!canBackupNow) {
      toast({
        title: 'محدودیت بکاپ',
        description: `سقف ماهانه ${FREE_MONTHLY_LIMIT} بکاپ رایگان تکمیل شده. برای بکاپ نامحدود، نسخه پولی را تهیه کنید.`,
        variant: 'destructive',
      });
      return;
    }
    try {
      const result = await createMut.mutateAsync({ userId, userName });
      toast({
        title: 'بکاپ گرفته شد',
        description: `${Object.values(result.counts).reduce((a, b) => a + b, 0)} رکورد دانلود شد (Excel + PDF)`,
      });
    } catch (e) {
      toast({ title: 'خطا در بکاپ', description: e.message, variant: 'destructive' });
    }
  };

  const handleLocalBackup = async () => {
    setLocalWarning(false);
    try {
      const result = await localCreateMut.mutateAsync({ userId, userName });
      toast({
        title: 'بکاپ محلی ذخیره شد',
        description: `${Object.values(result.counts).reduce((a, b) => a + b, 0)} رکورد در حافظه گوشی ذخیره شد`,
      });
    } catch (e) {
      toast({ title: 'خطا در بکاپ محلی', description: e.message, variant: 'destructive' });
    }
  };

  const handleLocalRestore = async () => {
    if (!localRestoreConfirm) return;
    try {
      const counts = await localRestoreMut.mutateAsync({ backupId: localRestoreConfirm, userId, userName });
      toast({
        title: 'بازیابی انجام شد',
        description: `${Object.values(counts).reduce((a, b) => a + b, 0)} رکورد بازگردانی شد`,
      });
    } catch (e) {
      toast({ title: 'خطا در بازیابی', description: e.message, variant: 'destructive' });
    }
    setLocalRestoreConfirm(null);
  };

  const handleFileSelect = (e) => {
    const file = _optionalChain([e, 'access', _6 => _6.target, 'access', _7 => _7.files, 'optionalAccess', _8 => _8[0]]);
    if (!file) return;
    setRestoreConfirm(file);
    e.target.value = '';
  };

  const handleRestore = async () => {
    if (!restoreConfirm) return;
    try {
      const counts = await restoreMut.mutateAsync({ file: restoreConfirm, userId, userName });
      toast({
        title: 'بازیابی انجام شد',
        description: `${Object.values(counts).reduce((a, b) => a + b, 0)} رکورد بازگردانی شد`,
      });
    } catch (e) {
      toast({ title: 'خطا در بازیابی', description: e.message, variant: 'destructive' });
    }
    setRestoreConfirm(null);
  };

  return (
    _jsxDEV('div', { className: "space-y-4 pb-4" , children: [
      /* Header */
      _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
        _jsxDEV(Database, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 111}, this )
        , _jsxDEV('h1', { className: "text-lg font-bold" , children: "بکاپ و بازیابی"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 112}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 110}, this)

      /* Plan status */
      , _jsxDEV(Card, { className: hasAddon ? 'border-success' : 'border-warning/50', children: 
        _jsxDEV(CardContent, { className: "p-4 flex items-start gap-3"   , children: [
          hasAddon ? (
            _jsxDEV(CheckCircle2, { className: "w-5 h-5 text-success mt-0.5"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 119}, this )
          ) : (
            _jsxDEV(AlertTriangle, { className: "w-5 h-5 text-warning mt-0.5"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this )
          )
          , _jsxDEV('div', { className: "flex-1", children: [
            _jsxDEV('p', { className: "text-sm font-bold" , children: 
              hasAddon ? 'نسخه پولی بکاپ فعال است' : 'نسخه رایگان - بکاپ دستی فقط'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 124}, this)
            , _jsxDEV('p', { className: "text-xs text-muted-foreground mt-1"  , children: 
              hasAddon
                ? 'بکاپ خودکار روزانه و بازیابی برای شما فعال است'
                : 'برای بکاپ خودکار روزانه و بازیابی، نسخه پولی بکاپ را تهیه کنید'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this)
            , !hasAddon && (
              _jsxDEV(Button, { size: "sm", className: "mt-2", onClick: () => openUpgrade('backup'), children: [
                _jsxDEV(Shield, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 134}, this ), "ارتقا به بکاپ پولی"

              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 133}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 123}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 117}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 116}, this)

      /* Actions */
      , _jsxDEV('div', { className: "grid grid-cols-1 gap-3"  , children: [
        _jsxDEV(Card, { children: 
          _jsxDEV(CardContent, { className: "p-4", children: [
            _jsxDEV('div', { className: "flex items-center gap-3 mb-2"   , children: [
              _jsxDEV(Download, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this )
              , _jsxDEV('div', { children: [
                _jsxDEV('p', { className: "text-sm font-bold" , children: "بکاپ دستی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this)
                , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "دانلود فایل Excel (CSV) و PDF خلاصه"      }, void 0, false, {fileName: _jsxFileName, lineNumber: 150}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 148}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 146}, this)
            , !hasAddon && (
              _jsxDEV('div', { className: "mb-2 px-2 py-1.5 rounded-lg bg-warning/10 text-xs text-warning font-medium text-center"        , children: 
                canBackupNow
                  ? `${remainingBackups} بکاپ رایگان این ماه باقی مانده (از ${FREE_MONTHLY_LIMIT})`
                  : `سقف ماهانه ${FREE_MONTHLY_LIMIT} بکاپ رایگان تکمیل شد`
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 154}, this)
            )
            , _jsxDEV(Button, {
              className: "w-full",
              onClick: handleManualBackup,
              disabled: createMut.isPending || !canBackupNow,
 children: 
              createMut.isPending ? (
                _jsxDEV(_Fragment, { children: [_jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 166}, this ), " در حال بکاپ..."   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 166}, this)
              ) : (
                _jsxDEV(_Fragment, { children: [_jsxDEV(Database, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 168}, this ), " بکاپ بگیر"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 168}, this)
              )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 145}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 144}, this)

        , _jsxDEV(Card, { className: hasAddon ? '' : 'opacity-60', children: 
          _jsxDEV(CardContent, { className: "p-4", children: [
            _jsxDEV('div', { className: "flex items-center gap-3 mb-2"   , children: [
              _jsxDEV(Upload, { className: "w-5 h-5 text-primary"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 177}, this )
              , _jsxDEV('div', { children: [
                _jsxDEV('p', { className: "text-sm font-bold" , children: "بازیابی (Restore)" }, void 0, false, {fileName: _jsxFileName, lineNumber: 179}, this)
                , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: 
                  hasAddon ? 'بازگردانی داده‌ها از فایل بکاپ' : 'مخصوص نسخه پولی بکاپ'
                }, void 0, false, {fileName: _jsxFileName, lineNumber: 180}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 178}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 176}, this)
            , _jsxDEV('input', {
              ref: fileInputRef,
              type: "file",
              accept: ".csv,.json",
              className: "hidden",
              onChange: handleFileSelect,}, void 0, false, {fileName: _jsxFileName, lineNumber: 185}, this
            )
            , _jsxDEV(Button, {
              variant: "outline",
              className: "w-full",
              onClick: () => _optionalChain([fileInputRef, 'access', _9 => _9.current, 'optionalAccess', _10 => _10.click, 'call', _11 => _11()]),
              disabled: !hasAddon || restoreMut.isPending,
 children: 
              restoreMut.isPending ? (
                _jsxDEV(_Fragment, { children: [_jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 199}, this ), " در حال بازیابی..."   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 199}, this)
              ) : (
                _jsxDEV(_Fragment, { children: [_jsxDEV(Upload, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 201}, this ), " انتخاب فایل بکاپ"   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 201}, this)
              )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 192}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 175}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 174}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 143}, this)

      /* Local backup — when free limit exhausted */
      , !hasAddon && !canBackupNow && (
        _jsxDEV(Card, { className: "border-warning/50", children: 
          _jsxDEV(CardContent, { className: "p-4", children: [
            _jsxDEV('div', { className: "flex items-center gap-3 mb-2"   , children: [
              _jsxDEV(Smartphone, { className: "w-5 h-5 text-warning"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 213}, this )
              , _jsxDEV('div', { children: [
                _jsxDEV('p', { className: "text-sm font-bold" , children: "بکاپ محلی (حافظه گوشی)"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 215}, this)
                , _jsxDEV('p', { className: "text-xs text-muted-foreground" , children: "ذخیره در حافظه گوشی — بدون ارسال به سرور"        }, void 0, false, {fileName: _jsxFileName, lineNumber: 216}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 214}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 212}, this)
            , _jsxDEV('div', { className: "mb-2 px-3 py-2 rounded-lg bg-destructive/10 border border-destructive/20 text-xs text-destructive leading-relaxed"         , children: [
              _jsxDEV(AlertTriangle, { className: "w-4 h-4 inline-block ml-1"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 220}, this ), "هشدار مهم: بکاپ محلی فقط در همین گوشی ذخیره می‌شود. اگر گوشی گم شود، خراب شود یا برنامه پاک شود، تمام اطلاعات بکاپ از بین می‌رود و قابل بازیابی نیست. مسئولیت حفظ داده‌ها کاملاً بر عهده خود شماست."

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 219}, this)
            , _jsxDEV(Button, {
              variant: "outline",
              className: "w-full border-warning text-warning hover:bg-warning/10"   ,
              onClick: () => setLocalWarning(true),
              disabled: localCreateMut.isPending,
 children: 
              localCreateMut.isPending ? (
                _jsxDEV(_Fragment, { children: [_jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 230}, this ), " در حال بکاپ..."   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 230}, this)
              ) : (
                _jsxDEV(_Fragment, { children: [_jsxDEV(Smartphone, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 232}, this ), " بکاپ محلی بگیر"   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 232}, this)
              )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 223}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 211}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 210}, this)
      )

      /* Local backups history */
      , localBackups && localBackups.length > 0 && (
        _jsxDEV(Card, { children: [
          _jsxDEV(CardHeader, { className: "pb-2", children: 
            _jsxDEV(CardTitle, { className: "text-sm flex items-center gap-2"   , children: [
              _jsxDEV(Smartphone, { className: "w-4 h-4 text-warning"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 244}, this ), "بکاپ‌های محلی (حافظه گوشی)"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 243}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 242}, this)
          , _jsxDEV(CardContent, { children: [
            _jsxDEV('div', { className: "space-y-2", children: 
              localBackups.map(rec => (
                _jsxDEV('div', { className: "flex items-center justify-between p-2 rounded-lg bg-muted/50"     , children: [
                  _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                    _jsxDEV('div', { className: "w-2 h-2 rounded-full bg-warning"   ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 253}, this )
                    , _jsxDEV('div', { children: [
                      _jsxDEV('p', { className: "text-xs font-medium" , children: "بکاپ محلی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 255}, this)
                      , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: 
                        rec.created_date ? new Date(rec.created_date).toLocaleDateString('fa-IR') : ''
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 256}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 254}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 252}, this)
                  , _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                    _jsxDEV('div', { className: "text-left", children: [
                      _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: 
                        rec.size_bytes ? `${(rec.size_bytes / 1024).toFixed(0)} KB` : ''
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 263}, this)
                      , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: [
                        rec.record_counts ? Object.values(rec.record_counts).reduce((a, b) => a + b, 0) : 0, " رکورد"
                      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 266}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 262}, this)
                    , _jsxDEV(Button, {
                      size: "sm",
                      variant: "ghost",
                      className: "h-7 w-7 p-0 text-primary"   ,
                      onClick: () => setLocalRestoreConfirm(rec.id),
                      disabled: !hasAddon,
                      title: hasAddon ? 'بازیابی' : 'مخصوص نسخه پولی',
 children: 
                      _jsxDEV(Upload, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 278}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 270}, this)
                    , _jsxDEV(Button, {
                      size: "sm",
                      variant: "ghost",
                      className: "h-7 w-7 p-0 text-destructive"   ,
                      onClick: () => localDeleteMut.mutate(rec.id),
 children: 
                      _jsxDEV(Trash2, { className: "w-3.5 h-3.5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 286}, this )
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 280}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 261}, this)
                ]}, rec.id, true, {fileName: _jsxFileName, lineNumber: 251}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 249}, this)
            , !hasAddon && (
              _jsxDEV('p', { className: "text-[10px] text-muted-foreground mt-2 text-center"   , children: "بازیابی بکاپ محلی فقط برای نسخه پولی بکاپ فعال است"

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 293}, this)
            )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 248}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 241}, this)
      )

      /* History */
      , _jsxDEV(Card, { children: [
        _jsxDEV(CardHeader, { className: "pb-2", children: 
          _jsxDEV(CardTitle, { className: "text-sm flex items-center gap-2"   , children: [
            _jsxDEV(Clock, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 305}, this ), "تاریخچه بکاپ‌ها"

          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 304}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 303}, this)
        , _jsxDEV(CardContent, { children: 
          historyLoading ? (
            _jsxDEV('p', { className: "text-xs text-muted-foreground text-center py-4"   , children: "در حال بارگذاری..."  }, void 0, false, {fileName: _jsxFileName, lineNumber: 311}, this)
          ) : !history || history.length === 0 ? (
            _jsxDEV('p', { className: "text-xs text-muted-foreground text-center py-4"   , children: "هنوز بکاپی ثبت نشده است"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 313}, this)
          ) : (
            _jsxDEV('div', { className: "space-y-2", children: 
              history.map(rec => (
                _jsxDEV('div', { className: "flex items-center justify-between p-2 rounded-lg bg-muted/50"     , children: [
                  _jsxDEV('div', { className: "flex items-center gap-2"  , children: [
                    _jsxDEV('div', { className: 
                      rec.type === 'manual' ? 'w-2 h-2 rounded-full bg-primary' :
                      rec.type === 'auto' ? 'w-2 h-2 rounded-full bg-success' :
                      'w-2 h-2 rounded-full bg-warning'
                    ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 319}, this )
                    , _jsxDEV('div', { children: [
                      _jsxDEV('p', { className: "text-xs font-medium" , children: 
                        rec.type === 'manual' ? 'دستی' : rec.type === 'auto' ? 'خودکار' : 'بازیابی'
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 325}, this)
                      , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: 
                        rec.created_date ? new Date(rec.created_date).toLocaleDateString('fa-IR') : ''
                      }, void 0, false, {fileName: _jsxFileName, lineNumber: 328}, this)
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 324}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 318}, this)
                  , _jsxDEV('div', { className: "text-left", children: [
                    _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: 
                      rec.size_bytes ? `${(rec.size_bytes / 1024).toFixed(0)} KB` : ''
                    }, void 0, false, {fileName: _jsxFileName, lineNumber: 334}, this)
                    , _jsxDEV('p', { className: "text-[10px] text-muted-foreground" , children: [
                      rec.record_counts ? Object.values(rec.record_counts).reduce((a, b) => a + b, 0) : 0, " رکورد"
                    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 337}, this)
                  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 333}, this)
                ]}, rec.id, true, {fileName: _jsxFileName, lineNumber: 317}, this)
              ))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 315}, this)
          )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 309}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 302}, this)

      /* Restore Confirm Dialog */
      , _jsxDEV(Dialog, { open: !!restoreConfirm, onOpenChange: (o) => !o && setRestoreConfirm(null), children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: 
            _jsxDEV(DialogTitle, { children: "تأیید بازیابی" }, void 0, false, {fileName: _jsxFileName, lineNumber: 352}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 351}, this)
          , _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: ["آیا مطمئنید که می‌خواهید داده‌ها از فایل «"
                   , _optionalChain([restoreConfirm, 'optionalAccess', _12 => _12.name]), "» بازیابی شود؟"
            , _jsxDEV('br', {}, void 0, false, {fileName: _jsxFileName, lineNumber: 356}, this )
            , _jsxDEV('span', { className: "text-destructive font-medium" , children: "داده‌های فعلی شما با داده‌های بکاپ جایگزین/ادغام خواهد شد."        }, void 0, false, {fileName: _jsxFileName, lineNumber: 357}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 354}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setRestoreConfirm(null), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 360}, this)
            , _jsxDEV(Button, { onClick: handleRestore, disabled: restoreMut.isPending, children: 
              restoreMut.isPending ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 362}, this ) : 'بازیابی کن'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 361}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 359}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 350}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 349}, this)

      /* Local Backup Warning Dialog */
      , _jsxDEV(Dialog, { open: localWarning, onOpenChange: setLocalWarning, children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: 
            _jsxDEV(DialogTitle, { className: "flex items-center gap-2 text-destructive"   , children: [
              _jsxDEV(AlertTriangle, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 373}, this ), "هشدار مهم — مسئولیت شما"

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 372}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 371}, this)
          , _jsxDEV('div', { className: "space-y-3 py-2" , children: 
            _jsxDEV('div', { className: "p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-sm leading-relaxed"      , children: ["بکاپ محلی فقط در حافظه همین گوشی ذخیره می‌شود و به سرور ارسال نمی‌شود."

              , _jsxDEV('br', {}, void 0, false, {fileName: _jsxFileName, lineNumber: 380}, this ), _jsxDEV('br', {}, void 0, false, {fileName: _jsxFileName, lineNumber: 380}, this )
              , _jsxDEV('strong', { className: "text-destructive", children: "در صورت موارد زیر، اطلاعات شما برای همیشه از دست می‌رود:"          }, void 0, false, {fileName: _jsxFileName, lineNumber: 381}, this)
              , _jsxDEV('ul', { className: "list-disc pr-5 mt-2 space-y-1 text-xs"    , children: [
                _jsxDEV('li', { children: "گم شدن یا دزدیده شدن گوشی"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 383}, this)
                , _jsxDEV('li', { children: "خراب شدن یا شکستن گوشی"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 384}, this)
                , _jsxDEV('li', { children: "پاک کردن برنامه یا داده‌های برنامه"     }, void 0, false, {fileName: _jsxFileName, lineNumber: 385}, this)
                , _jsxDEV('li', { children: "ریست فکتوری کردن گوشی"   }, void 0, false, {fileName: _jsxFileName, lineNumber: 386}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 382}, this)
              , _jsxDEV('br', {}, void 0, false, {fileName: _jsxFileName, lineNumber: 388}, this ), "مسئولیت حفظ و نگه‌داری بکاپ محلی کاملاً بر عهده خود شماست. برای محافظت کامل، نسخه پولی بکاپ را تهیه کنید تا بکاپ‌ها به‌صورت خودکار در فضای ابری ذخیره شوند."

            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 378}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 377}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setLocalWarning(false), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 393}, this)
            , _jsxDEV(Button, { onClick: handleLocalBackup, disabled: localCreateMut.isPending, children: 
              localCreateMut.isPending ? (
                _jsxDEV(_Fragment, { children: [_jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 396}, this ), " در حال بکاپ..."   ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 396}, this)
              ) : (
                'متوجه شدم، بکاپ بگیر'
              )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 394}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 392}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 370}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 369}, this)

      /* Local Restore Confirm Dialog */
      , _jsxDEV(Dialog, { open: !!localRestoreConfirm, onOpenChange: (o) => !o && setLocalRestoreConfirm(null), children: 
        _jsxDEV(DialogContent, { children: [
          _jsxDEV(DialogHeader, { children: 
            _jsxDEV(DialogTitle, { children: "تأیید بازیابی از حافظه محلی"    }, void 0, false, {fileName: _jsxFileName, lineNumber: 409}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 408}, this)
          , _jsxDEV('p', { className: "text-sm text-muted-foreground" , children: 
            _jsxDEV('span', { className: "text-destructive font-medium" , children: "داده‌های فعلی شما با داده‌های بکاپ محلی جایگزین/ادغام خواهد شد."         }, void 0, false, {fileName: _jsxFileName, lineNumber: 412}, this)
          }, void 0, false, {fileName: _jsxFileName, lineNumber: 411}, this)
          , _jsxDEV(DialogFooter, { children: [
            _jsxDEV(Button, { variant: "outline", onClick: () => setLocalRestoreConfirm(null), children: "انصراف"}, void 0, false, {fileName: _jsxFileName, lineNumber: 415}, this)
            , _jsxDEV(Button, { onClick: handleLocalRestore, disabled: localRestoreMut.isPending, children: 
              localRestoreMut.isPending ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 417}, this ) : 'بازیابی کن'
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 416}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 414}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 407}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 406}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 108}, this)
  );
}