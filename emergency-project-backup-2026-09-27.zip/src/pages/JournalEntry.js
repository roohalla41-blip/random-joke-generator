const _jsxFileName = "src/pages/JournalEntry.jsx";import {jsxDEV as _jsxDEV, Fragment as _Fragment} from "react/jsx-dev-runtime";import React, { useState } from 'react';
import { useCustomers, useBankAccounts, useAgents, usePostDocument } from '../lib/useSarraaf.js';
import { PageHeader } from '../components/sarraaf/Pieces.js';
import { AmountInput } from '../components/sarraaf/Fields.js';
import { Button } from '../components/ui/button.js';
import { Input } from '../components/ui/input.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select.js';
import { buildManualVoucher } from '../lib/ledger.js';
import { toast } from '../components/ui/use-toast.js';
import { BookCopy, Plus, Trash2, Loader2 } from 'lucide-react';

export default function JournalEntry() {
  const { data: customers } = useCustomers();
  const { data: bankAccounts } = useBankAccounts();
  const { data: agents } = useAgents();
  const postMut = usePostDocument();

  const [lines, setLines] = useState([
    { account_type: 'cash', counter_id: '', currency: 'AFN', amount: 0, side: 'debit', description: '' },
    { account_type: 'cash', counter_id: '', currency: 'AFN', amount: 0, side: 'credit', description: '' },
  ]);

  const updateLine = (i, field, value) => {
    const next = [...lines];
    next[i] = { ...next[i], [field]: value };
    setLines(next);
  };

  const addLine = () => setLines([...lines, { account_type: 'cash', counter_id: '', currency: 'AFN', amount: 0, side: 'debit', description: '' }]);
  const removeLine = (i) => setLines(lines.filter((_, idx) => idx !== i));

  const balances = {};
  lines.forEach(l => {
    const cur = l.currency;
    if (!balances[cur]) balances[cur] = { debit: 0, credit: 0 };
    if (l.side === 'debit') balances[cur].debit += l.amount || 0;
    else balances[cur].credit += l.amount || 0;
  });
  const isBalanced = Object.values(balances).every(b => Math.abs(b.debit - b.credit) < 1);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (lines.length < 2) { toast({ title: 'خطا', description: 'حداقل ۲ خط لازم است', variant: 'destructive' }); return; }
    if (!isBalanced) { toast({ title: 'خطا', description: 'سند ناتراز است', variant: 'destructive' }); return; }
    const built = buildManualVoucher(lines);
    try {
      await postMut.mutateAsync(built);
      toast({ title: 'ثبت شد' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  return (
    _jsxDEV(_Fragment, { children: [
      _jsxDEV(PageHeader, { title: "سند دستی" , icon: BookCopy,}, void 0, false, {fileName: _jsxFileName, lineNumber: 56}, this )
      , _jsxDEV('form', { onSubmit: handleSubmit, className: "space-y-3", children: [
        lines.map((line, i) => (
          _jsxDEV('div', { className: "p-3 rounded-xl border space-y-2"   , children: [
            _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
              _jsxDEV('span', { className: "text-xs font-medium" , children: ["خط " , i + 1]}, void 0, true, {fileName: _jsxFileName, lineNumber: 61}, this)
              , lines.length > 2 && _jsxDEV(Button, { type: "button", size: "icon", variant: "ghost", onClick: () => removeLine(i), children: _jsxDEV(Trash2, { className: "w-4 h-4 text-destructive"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 62}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 60}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV(Select, { value: line.account_type, onValueChange: v => updateLine(i, 'account_type', v), children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 66}, this)
                , _jsxDEV(SelectContent, { children: [
                  _jsxDEV(SelectItem, { value: "cash", children: "صندوق"}, void 0, false, {fileName: _jsxFileName, lineNumber: 68}, this)
                  , _jsxDEV(SelectItem, { value: "bank", children: "بانک"}, void 0, false, {fileName: _jsxFileName, lineNumber: 69}, this)
                  , _jsxDEV(SelectItem, { value: "agent", children: "نماینده"}, void 0, false, {fileName: _jsxFileName, lineNumber: 70}, this)
                  , _jsxDEV(SelectItem, { value: "customer", children: "مشتری"}, void 0, false, {fileName: _jsxFileName, lineNumber: 71}, this)
                ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 67}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 65}, this)
              , _jsxDEV(Select, { value: line.currency, onValueChange: v => updateLine(i, 'currency', v), children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 75}, this)
                , _jsxDEV(SelectContent, { children: [_jsxDEV(SelectItem, { value: "AFN", children: "AFN"}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this), _jsxDEV(SelectItem, { value: "USD", children: "USD"}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this), _jsxDEV(SelectItem, { value: "IRT", children: "IRT"}, void 0, false, {fileName: _jsxFileName, lineNumber: 76}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 76}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 74}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 64}, this)
            , _jsxDEV('div', { className: "grid grid-cols-2 gap-2"  , children: [
              _jsxDEV(Select, { value: line.side, onValueChange: v => updateLine(i, 'side', v), children: [
                _jsxDEV(SelectTrigger, { children: _jsxDEV(SelectValue, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this )}, void 0, false, {fileName: _jsxFileName, lineNumber: 81}, this)
                , _jsxDEV(SelectContent, { children: [_jsxDEV(SelectItem, { value: "debit", children: "بدهکار"}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this), _jsxDEV(SelectItem, { value: "credit", children: "بستانکار"}, void 0, false, {fileName: _jsxFileName, lineNumber: 82}, this)]}, void 0, true, {fileName: _jsxFileName, lineNumber: 82}, this)
              ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 80}, this)
              , _jsxDEV(AmountInput, { value: line.amount, onChange: v => updateLine(i, 'amount', v),}, void 0, false, {fileName: _jsxFileName, lineNumber: 84}, this )
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 79}, this)
            , _jsxDEV(Input, { value: line.description, onChange: e => updateLine(i, 'description', e.target.value), placeholder: "توضیحات",}, void 0, false, {fileName: _jsxFileName, lineNumber: 86}, this )
          ]}, i, true, {fileName: _jsxFileName, lineNumber: 59}, this)
        ))
        , _jsxDEV(Button, { type: "button", variant: "outline", className: "w-full", onClick: addLine, children: [_jsxDEV(Plus, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 89}, this ), " افزودن خط"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 89}, this)
        , _jsxDEV('div', { className: `text-sm text-center font-medium ${isBalanced ? 'text-success' : 'text-destructive'}`, children: 
          isBalanced ? '✓ سند تراز است' : '✗ سند ناتراز است'
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 90}, this)
        , _jsxDEV(Button, { type: "submit", className: "w-full", disabled: postMut.isPending || !isBalanced, children: 
          postMut.isPending ? _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin"  ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 94}, this ) : 'ثبت سند'
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 93}, this)
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 57}, this)
    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 55}, this)
  );
}