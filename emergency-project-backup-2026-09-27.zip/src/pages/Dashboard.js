const _jsxFileName = "src/pages/Dashboard.jsx";import {jsxDEV as _jsxDEV} from "react/jsx-dev-runtime"; function _optionalChain(ops) { let lastAccessLHS = undefined; let value = ops[0]; let i = 1; while (i < ops.length) { const op = ops[i]; const fn = ops[i + 1]; i += 2; if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) { return undefined; } if (op === 'access' || op === 'optionalAccess') { lastAccessLHS = value; value = fn(value); } else if (op === 'call' || op === 'optionalCall') { value = fn((...args) => value.call(lastAccessLHS, ...args)); lastAccessLHS = undefined; } } return value; }import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTransactions, useCustomers, useSarraafProfile, useFeatures, useTreasuryBalances, useExchangeSummary } from '../lib/useSarraaf.js';
import { useAuth } from '../lib/AuthContext.js';
import { formatNumber, TX_TYPE_LABELS } from '../lib/sarraaf.js';
import { StatCard, EmptyState, LoadingState, TransactionRow } from '../components/sarraaf/Pieces.js';
import FeatureGate from '../components/FeatureGate.js';
import { getFeatureStatus } from '../lib/features.js';
import { getPlanStatus } from '../lib/permissions.js';
import { DEFAULT_FREE_QUOTAS } from '../lib/pricingService.js';
import CampaignBanner from '../components/sarraaf/CampaignBanner.js';
import UsageBar from '../components/sarraaf/UsageBar.js';
import { useUpgrade } from '../lib/UpgradeContext.js';
import { getAllowedDashboardLinks } from '../lib/rbac.js';
import { Card, CardContent } from '../components/ui/card.js';
import {
  Users, Send, ArrowLeftRight, ArrowRightLeft, FileText, Banknote, Store, MessageSquareMore,
  Landmark, Coins, TrendingUp, Wallet, Network, Share2, BookOpen, BookCopy,
  ScrollText, Scale, FileSearch, ShoppingBag, CreditCard, Settings, MoreHorizontal, X, Repeat,
  Receipt, Handshake,
} from 'lucide-react';
import { useToast } from '../components/ui/use-toast.js';

const PRIMARY_LINKS = [
  { label: 'مشتریان', path: '/customers', icon: Users, gradient: 'from-blue-500 to-blue-600' },
  { label: 'خرید/فروش', path: '/trade', icon: Repeat, gradient: 'from-violet-500 to-violet-600' },
  { label: 'داد و گرفت', path: '/dadogereft', icon: Handshake, gradient: 'from-teal-500 to-teal-600' },
  { label: 'صندوق', path: '/cash', icon: Banknote, gradient: 'from-emerald-500 to-emerald-600' },
  { label: 'بانک', path: '/bank', icon: Landmark, gradient: 'from-indigo-500 to-indigo-600' },
  { label: 'حواله', path: '/transfer-book', icon: Send, gradient: 'from-orange-500 to-orange-600' },
  { label: 'تبدیل ارز', path: '/convert', icon: ArrowRightLeft, gradient: 'from-cyan-500 to-cyan-600' },
  { label: 'دریافت', path: '/receipt', icon: Receipt, gradient: 'from-rose-500 to-rose-600' },
  { label: 'گزارش‌ها', path: '/reports', icon: FileText, gradient: 'from-amber-500 to-amber-600' },
];

const SECONDARY_LINKS = [
  { label: 'بازار نرخ', path: '/sarraaf-market', icon: Store, gradient: 'from-cyan-500 to-cyan-600' },
  { label: 'محصولات آنلاین', path: '/online-products', icon: ShoppingBag, gradient: 'from-pink-500 to-pink-600' },
  { label: 'چت صراف‌ها', path: '/sarraaf-chat', icon: MessageSquareMore, gradient: 'from-teal-500 to-teal-600' },
  { label: 'ارز و نرخ', path: '/currencies', icon: Coins, gradient: 'from-amber-500 to-amber-600' },
  { label: 'سود و زیان', path: '/profit-loss', icon: TrendingUp, gradient: 'from-green-500 to-green-600' },
  { label: 'بدهکاران', path: '/debtors', icon: Wallet, gradient: 'from-red-500 to-red-600' },
  { label: 'نمایندگی‌ها', path: '/agents', icon: Network, gradient: 'from-cyan-500 to-cyan-600' },
  { label: 'شبکه نمایندگی', path: '/agency-network', icon: Share2, gradient: 'from-blue-500 to-blue-600' },
  { label: 'دفتر روزنامه', path: '/journal', icon: BookCopy, gradient: 'from-slate-500 to-slate-600' },
  { label: 'دفتر کل', path: '/general-ledger', icon: ScrollText, gradient: 'from-gray-500 to-gray-600' },
  { label: 'ترازنامه', path: '/balance-sheet', icon: Scale, gradient: 'from-stone-500 to-stone-600' },
  { label: 'مغایرت‌گیری', path: '/reconciliation', icon: FileSearch, gradient: 'from-neutral-500 to-neutral-600' },
  { label: 'تنظیمات', path: '/settings', icon: Settings, gradient: 'from-slate-500 to-slate-600' },
];

export default function Dashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = useSarraafProfile(_optionalChain([user, 'optionalAccess', _ => _.id]));
  const { data: txs, isLoading: txLoading } = useTransactions();
  const { data: customers, isLoading: custLoading } = useCustomers();
  const { data: features } = useFeatures();
  const { data: treasuryBalances } = useTreasuryBalances();
  const { data: exchangeSummary } = useExchangeSummary();
  const [moreOpen, setMoreOpen] = useState(false);
  const { openUpgrade } = useUpgrade();
  const { toast } = useToast();

  const userRole = _optionalChain([user, 'optionalAccess', _2 => _2.role]) || 'user';
  const primaryLinks = getAllowedDashboardLinks(userRole, PRIMARY_LINKS);
  const secondaryLinks = getAllowedDashboardLinks(userRole, SECONDARY_LINKS);

  const cash = {};
  for (const b of (treasuryBalances || [])) {
    cash[b.currency] = b.balance;
  }
  const afnCash = cash['AFN'] || 0;
  const usdCash = cash['USD'] || 0;
  const today = new Date().toISOString().split('T')[0];
  const todayTxs = (txs || []).filter(t => t.date === today);
  const todayCount = todayTxs.length;

  const quota = profile ? {
    used: profile.quota_used || 0,
    limit: profile.quota_limit || 0,
    remaining: Math.max(0, (profile.quota_limit || 0) - (profile.quota_used || 0)),
  } : null;

  const isFree = !profile || getPlanStatus(profile) === 'free';
  const custCount = _optionalChain([customers, 'optionalAccess', _3 => _3.length]) || 0;
  const todayTransferCount = (txs || []).filter(t => t.date === today && t.type === 'transfer').length;
  const monthTxCount = (txs || []).filter(t => {
    const d = new Date(t.date || t.created_date);
    return d && d.getMonth() === new Date().getMonth();
  }).length;

  const renderLink = (link, isSecondary = false) => {
    const featureKey = link.path.replace('/', '').replace(/-/g, '_');
    const status = getFeatureStatus(features || [], featureKey);
    const isUpdating = status === 'updating';
    const Icon = link.icon;
    return (
      _jsxDEV(Link, {

        to: link.path,
        className: "flex flex-col items-center gap-2 p-2.5 rounded-xl bg-card border border-border hover:border-primary/30 hover:shadow-card-hover transition-all relative group"             ,
 children: [
        _jsxDEV('div', { className: `w-11 h-11 rounded-xl bg-gradient-to-br ${link.gradient} flex items-center justify-center shadow-sm ${isUpdating ? 'opacity-50' : ''} group-hover:scale-105 transition-transform`, children: 
          _jsxDEV(Icon, { className: "w-5 h-5 text-white"  , strokeWidth: 2.2,}, void 0, false, {fileName: _jsxFileName, lineNumber: 105}, this )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 104}, this)
        , _jsxDEV('span', { className: "text-[11px] font-medium text-center leading-tight text-foreground"    , children: link.label}, void 0, false, {fileName: _jsxFileName, lineNumber: 107}, this)
        , isUpdating && (
          _jsxDEV('span', { className: "absolute -top-1 -left-1 px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700 text-[8px] font-bold"         , children: "به‌روزرسانی"

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 109}, this)
        )
      ]}, link.path, true, {fileName: _jsxFileName, lineNumber: 99}, this)
    );
  };

  return (
    _jsxDEV(FeatureGate, { featureKey: "dashboard", children: [
      /* Summary cards */
      _jsxDEV('div', { className: "grid grid-cols-3 gap-2.5 mb-5"   , children: [
        _jsxDEV(StatCard, { label: "معاملات امروز" , value: txLoading ? '...' : formatNumber(todayCount), icon: ArrowLeftRight, gradient: "from-blue-500 to-blue-600" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 121}, this )
        , _jsxDEV(StatCard, { label: "حواله امروز" , value: txLoading ? '...' : formatNumber(todayTransferCount), icon: Send, gradient: "from-emerald-500 to-emerald-600" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 122}, this )
        , _jsxDEV(StatCard, { label: "مشتریان", value: custLoading ? '...' : formatNumber(_optionalChain([customers, 'optionalAccess', _4 => _4.length]) || 0), icon: Users, gradient: "from-amber-500 to-amber-600" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 123}, this )
      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 120}, this)

      /* Primary Quick Links */
      , _jsxDEV('div', { className: "flex items-center justify-between mb-2.5"   , children: 
        _jsxDEV('h3', { className: "text-sm font-bold text-foreground"  , children: "دسترسی سریع" }, void 0, false, {fileName: _jsxFileName, lineNumber: 128}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 127}, this)
      , _jsxDEV('div', { className: "grid grid-cols-3 gap-2.5 mb-4"   , children: 
        primaryLinks.map(link => renderLink(link))
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 130}, this)

      /* Discount Campaign Banner */
      , _jsxDEV(CampaignBanner, { onUpgrade: () => openUpgrade(),}, void 0, false, {fileName: _jsxFileName, lineNumber: 135}, this )

      /* Usage Bars — only for free plan */
      , isFree && (
        _jsxDEV(Card, { className: "mb-4 shadow-card" , children: 
          _jsxDEV(CardContent, { className: "p-3.5 space-y-2.5" , children: [
            _jsxDEV('div', { className: "flex items-center justify-between"  , children: [
              _jsxDEV('span', { className: "text-xs font-semibold text-foreground"  , children: "مصرف طرح رایگان"  }, void 0, false, {fileName: _jsxFileName, lineNumber: 142}, this)
              , _jsxDEV('button', { onClick: () => openUpgrade('customers'), className: "text-[10px] text-primary font-medium"  , children: "ارتقا →"

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 143}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 141}, this)
            , _jsxDEV(UsageBar, { label: "مشتریان", used: custCount, limit: DEFAULT_FREE_QUOTAS.customers,}, void 0, false, {fileName: _jsxFileName, lineNumber: 147}, this )
            , _jsxDEV(UsageBar, { label: "حواله امروز" , used: todayTransferCount, limit: DEFAULT_FREE_QUOTAS.daily_transfers,}, void 0, false, {fileName: _jsxFileName, lineNumber: 148}, this )
            , _jsxDEV(UsageBar, { label: "تراکنش ماه" , used: monthTxCount, limit: DEFAULT_FREE_QUOTAS.monthly_transactions,}, void 0, false, {fileName: _jsxFileName, lineNumber: 149}, this )
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 140}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 139}, this)
      )

      /* Quota Card — compact, for free plan */
      , isFree && quota && (
        _jsxDEV(Card, { className: "mb-4 overflow-hidden shadow-card"  , children: 
          _jsxDEV(CardContent, { className: "p-4", children: [
            _jsxDEV('div', { className: "flex items-center justify-between mb-2"   , children: [
              _jsxDEV('span', { className: "text-sm font-medium text-foreground"  , children: "سهمیه عملیات" }, void 0, false, {fileName: _jsxFileName, lineNumber: 159}, this)
              , _jsxDEV('button', { onClick: () => openUpgrade(), className: "text-[10px] text-primary font-medium"  , children: "ارتقا →"

              }, void 0, false, {fileName: _jsxFileName, lineNumber: 160}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 158}, this)
            , _jsxDEV('div', { className: "w-full h-2 bg-muted rounded-full overflow-hidden"    , children: 
              _jsxDEV('div', {
                className: "h-full bg-primary rounded-full transition-all"   ,
                style: { width: `${quota.limit > 0 ? Math.min(100, (quota.used / quota.limit) * 100) : 0}%` },}, void 0, false, {fileName: _jsxFileName, lineNumber: 165}, this
              )
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 164}, this)
            , _jsxDEV('p', { className: "text-xs text-muted-foreground mt-1"  , children: [formatNumber(quota.remaining), " عملیات باقی‌مانده"  ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 170}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 157}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 156}, this)
      )

      /* Secondary Links — collapsible */
      , _jsxDEV('button', {
        onClick: () => setMoreOpen(true),
        className: "w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-muted/50 hover:bg-muted text-sm text-muted-foreground font-medium transition-colors mb-4"             ,
 children: [
        _jsxDEV(MoreHorizontal, { className: "w-4 h-4" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 180}, this ), "بخش‌های بیشتر"

      ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 176}, this)

      /* Free plan — branding badge note */
      , isFree && (
        _jsxDEV('div', { className: "mb-2 rounded-xl border border-warning/30 bg-warning/5 p-3 flex items-center gap-2"        , children: [
          _jsxDEV('span', { className: "text-xs text-muted-foreground flex-1"  , children: "🏷️ نسخه رایگان — با ارتقا به نسخه پولی، برند سازنده از پایین صفحه حذف می‌شود"

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 187}, this)
          , _jsxDEV('button', { onClick: () => openUpgrade(), className: "text-[10px] text-primary font-medium whitespace-nowrap"   , children: "ارتقا →"

          }, void 0, false, {fileName: _jsxFileName, lineNumber: 190}, this)
        ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 186}, this)
      )

      /* Recent Transactions */
      , _jsxDEV('h3', { className: "text-sm font-bold text-foreground mb-2.5 mt-4"    , children: "تراکنش‌های اخیر" }, void 0, false, {fileName: _jsxFileName, lineNumber: 197}, this)
      , _jsxDEV(Card, { className: "shadow-card", children: 
        _jsxDEV(CardContent, { className: "p-2", children: 
          txLoading ? (
            _jsxDEV(LoadingState, {}, void 0, false, {fileName: _jsxFileName, lineNumber: 201}, this )
          ) : (txs || []).length === 0 ? (
            _jsxDEV(EmptyState, { icon: FileText, title: "تراکنشی ثبت نشده"  , description: "اولین عملیات خود را انجام دهید"     ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 203}, this )
          ) : (
            (txs || []).slice(0, 8).map(tx => (
              _jsxDEV(TransactionRow, { tx: tx, labels: TX_TYPE_LABELS, onClick: () => navigate(`/receipt?type=tx&id=${tx.id}`),}, tx.id, false, {fileName: _jsxFileName, lineNumber: 206}, this )
            ))
          )
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 199}, this)
      }, void 0, false, {fileName: _jsxFileName, lineNumber: 198}, this)

      /* More Menu Modal */
      , moreOpen && (
        _jsxDEV('div', { className: "fixed inset-0 z-50 bg-black/50"   , onClick: () => setMoreOpen(false), children: 
          _jsxDEV('div', { className: "absolute bottom-0 inset-x-0 bg-background rounded-t-2xl p-4 max-h-[70vh] overflow-y-auto scrollbar-thin"        , onClick: e => e.stopPropagation(), children: [
            _jsxDEV('div', { className: "flex items-center justify-between mb-3"   , children: [
              _jsxDEV('h3', { className: "text-sm font-bold text-foreground"  , children: "همه بخش‌ها" }, void 0, false, {fileName: _jsxFileName, lineNumber: 217}, this)
              , _jsxDEV('button', { onClick: () => setMoreOpen(false), className: "p-1.5 rounded-lg hover:bg-muted"  , children: 
                _jsxDEV(X, { className: "w-5 h-5" ,}, void 0, false, {fileName: _jsxFileName, lineNumber: 219}, this )
              }, void 0, false, {fileName: _jsxFileName, lineNumber: 218}, this)
            ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 216}, this)
            , _jsxDEV('div', { className: "grid grid-cols-3 gap-2.5"  , children: 
              secondaryLinks.map(link => renderLink(link, true))
            }, void 0, false, {fileName: _jsxFileName, lineNumber: 222}, this)
          ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 215}, this)
        }, void 0, false, {fileName: _jsxFileName, lineNumber: 214}, this)
      )

    ]}, void 0, true, {fileName: _jsxFileName, lineNumber: 118}, this)
  );
}